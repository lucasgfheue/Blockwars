package com.blockwars.gun;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

/**
 * Per-stack weapon state stored in the item's custom data: loaded rounds, ammo type, attachment, fire mode,
 * heat and reload timing. Heat and reload are stored as timestamps so the stack only changes when something happens.
 */
public final class GunData {
    private GunData() {}

    public static CompoundTag read(ItemStack s) {
        CustomData d = s.get(DataComponents.CUSTOM_DATA);
        return d == null ? new CompoundTag() : d.copyTag();
    }

    public static void edit(ItemStack s, Consumer<CompoundTag> f) {
        CustomData.update(DataComponents.CUSTOM_DATA, s, f);
    }

    public static int ammo(ItemStack s) {
        return read(s).getInt("Ammo");
    }

    public static void setAmmo(ItemStack s, int n) {
        edit(s, t -> t.putInt("Ammo", Math.max(0, n)));
    }

    @Nullable
    public static AmmoType ammoType(ItemStack s) {
        CompoundTag t = read(s);
        return t.contains("AmmoType") ? AmmoType.byName(t.getString("AmmoType")) : null;
    }

    @Nullable
    public static Attachment attachment(ItemStack s) {
        CompoundTag t = read(s);
        return t.contains("Att") ? Attachment.byName(t.getString("Att")) : null;
    }

    public static void setAttachment(ItemStack s, @Nullable Attachment a) {
        edit(s, t -> {
            if (a == null) t.remove("Att");
            else t.putString("Att", a.name());
        });
    }

    public static int mode(ItemStack s) {
        return read(s).getInt("Mode");
    }

    /** Current heat 0..1 (decays over time since the last write). */
    public static float heat(ItemStack s, GunSpec spec, long now) {
        CompoundTag t = read(s);
        float h = t.getFloat("Heat");
        long at = t.getLong("HeatT");
        if (t.getBoolean("Lock")) {
            // overheated weapons cool down more slowly
            return Mth.clamp(h - (now - at) * spec.heatDecay * 0.6F, 0.0F, 1.0F);
        }
        return Mth.clamp(h - (now - at) * spec.heatDecay, 0.0F, 1.0F);
    }

    public static boolean locked(ItemStack s) {
        return read(s).getBoolean("Lock");
    }

    public static void setHeat(ItemStack s, float h, long now, boolean lock) {
        edit(s, t -> {
            t.putFloat("Heat", Mth.clamp(h, 0.0F, 1.0F));
            t.putLong("HeatT", now);
            t.putBoolean("Lock", lock);
        });
    }

    /** Reload progress 0..1, or -1 when not reloading. */
    public static float reloadProgress(ItemStack s, long now) {
        CompoundTag t = read(s);
        if (!t.contains("RelEnd")) return -1.0F;
        long end = t.getLong("RelEnd");
        int len = Math.max(1, t.getInt("RelLen"));
        if (now >= end) return 1.0F;
        return Mth.clamp(1.0F - (end - now) / (float) len, 0.0F, 1.0F);
    }

    public static boolean reloading(ItemStack s) {
        return read(s).contains("RelEnd");
    }

    /** Meltdown deadline (SOLARIS), or 0. */
    public static long meltdown(ItemStack s) {
        return read(s).getLong("Melt");
    }
}
