package com.blockwars.gun;

import com.blockwars.ModEntities;
import com.blockwars.ModParticles;
import com.blockwars.ModSounds;
import com.blockwars.entity.BaseMechaEntity;
import com.blockwars.entity.GunBulletEntity;
import com.blockwars.entity.GunRocketEntity;
import com.blockwars.entity.SingularityEntity;
import com.blockwars.mecha.WeaponSpec;
import com.blockwars.network.GunFeedbackPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/** Server-side weapon behaviour: triggers, ammunition, reloading, heat, every kind of shot and the two dangerous guns. */
public final class GunLogic {
    private GunLogic() {}

    private static final class State {
        boolean trigger;
        int hold;
        int cooldown;
        int burstLeft;
        int slot = -1;
        int sound;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    private static State state(Player p) {
        return STATES.computeIfAbsent(p.getUUID(), k -> new State());
    }

    public static void forget(Player p) {
        STATES.remove(p.getUUID());
    }

    // ================================================================= network entry points

    @Nullable
    private static GunItem held(ServerPlayer p) {
        if (p.getVehicle() instanceof BaseMechaEntity || p.isSpectator()) return null;
        return p.getMainHandItem().getItem() instanceof GunItem g ? g : null;
    }

    public static void trigger(ServerPlayer p, boolean down) {
        GunItem g = held(p);
        State st = state(p);
        if (g == null) {
            st.trigger = false;
            return;
        }
        ItemStack s = p.getMainHandItem();
        GunSpec spec = g.spec;
        Attachment att = GunData.attachment(s);
        GunSpec.Fire fire = spec.effectiveFire(GunData.mode(s), att);
        if (down) {
            if (st.trigger) return;
            st.trigger = true;
            st.hold = 0;
            switch (fire) {
                case SEMI -> tryShoot(p, s, spec, 1.0F);
                case BURST -> {
                    if (st.burstLeft <= 0 && st.cooldown <= 0) st.burstLeft = spec.burst;
                }
                case CHARGE -> {
                    if (!canShoot(p, s, spec, true)) st.trigger = false;
                    else p.level().playSound(p, p.getX(), p.getEyeY(), p.getZ(), ModSounds.get("gun." + spec.id + ".special"), SoundSource.PLAYERS, 1.0F, 1.0F);
                }
                default -> { }
            }
        } else {
            if (!st.trigger) return;
            st.trigger = false;
            if (fire == GunSpec.Fire.CHARGE) {
                if (st.hold >= spec.chargeMin) {
                    tryShoot(p, s, spec, Mth.clamp(st.hold / (float) spec.chargeFull, 0.0F, 1.0F));
                } else {
                    p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.4F, 1.6F);
                }
            }
            st.hold = 0;
        }
    }

    public static void reloadRequest(ServerPlayer p) {
        GunItem g = held(p);
        if (g == null) return;
        startReload(p, p.getMainHandItem(), g.spec, null);
    }

    public static void alt(ServerPlayer p) {
        GunItem g = held(p);
        if (g == null) return;
        ItemStack s = p.getMainHandItem();
        GunSpec spec = g.spec;
        long now = p.level().getGameTime();
        if (spec.modeToggle) {
            int mode = 1 - GunData.mode(s);
            GunData.edit(s, t -> t.putInt("Mode", mode));
            p.displayClientMessage(Component.translatable(mode == 1 ? "message.blockwars.mode_auto" : "message.blockwars.mode_burst"), true);
            p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LEVER_CLICK, SoundSource.PLAYERS, 0.6F, 1.6F);
            return;
        }
        if (spec.kind == GunSpec.Kind.FUSION || spec.kind == GunSpec.Kind.TESLA) {
            vent(p, s, spec, now);
            return;
        }
        if (spec.usesAmmo()) {
            // cycle to the next kind of ammunition you are carrying
            AmmoType cur = GunData.ammoType(s);
            AmmoType[] all = AmmoType.values();
            int start = cur == null ? 0 : cur.ordinal() + 1;
            for (int i = 0; i < all.length; i++) {
                AmmoType a = all[(start + i) % all.length];
                if (a.caliber == spec.caliber && a != cur && (p.isCreative() || count(p, a) > 0)) {
                    startReload(p, s, spec, a);
                    return;
                }
            }
            p.displayClientMessage(Component.translatable("message.blockwars.no_other_ammo"), true);
        }
    }

    // ================================================================= attachments

    public static void toggleAttachment(ServerPlayer p, ItemStack gun, GunSpec spec) {
        ItemStack off = p.getOffhandItem();
        Attachment current = GunData.attachment(gun);
        if (off.getItem() instanceof AttachmentItem ai) {
            if (!spec.allowed.contains(ai.attachment)) {
                p.displayClientMessage(Component.translatable("message.blockwars.attach_incompatible"), true);
                p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.VILLAGER_NO, SoundSource.PLAYERS, 0.4F, 1.4F);
                return;
            }
            if (ai.attachment == current) return;
            GunData.setAttachment(gun, ai.attachment);
            if (!p.isCreative()) off.shrink(1);
            if (current != null) give(p, new ItemStack(ModGuns.ATTACHMENTS.get(current).get()));
            clampMag(gun, spec);
            p.displayClientMessage(Component.translatable("message.blockwars.attached", Component.translatable("item.blockwars." + ai.attachment.itemId)), true);
            playAll(p, ModSounds.get("gun.attach"), 1.0F, 1.0F);
        } else if (current != null) {
            GunData.setAttachment(gun, null);
            give(p, new ItemStack(ModGuns.ATTACHMENTS.get(current).get()));
            clampMag(gun, spec);
            p.displayClientMessage(Component.translatable("message.blockwars.detached"), true);
            playAll(p, ModSounds.get("gun.attach"), 1.0F, 0.8F);
        } else {
            p.displayClientMessage(Component.translatable("message.blockwars.attach_hint"), true);
        }
    }

    private static void clampMag(ItemStack gun, GunSpec spec) {
        int mag = spec.effectiveMag(GunData.attachment(gun));
        if (GunData.ammo(gun) > mag) GunData.setAmmo(gun, mag);
    }

    // ================================================================= ammunition

    private static int count(Player p, AmmoType a) {
        int n = 0;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.getItem() instanceof AmmoItem ai && ai.type == a) n += s.getCount();
        }
        return n;
    }

    /** Total rounds the player carries for the loaded type (HUD reserve). */
    public static int reserve(Player p, ItemStack gun, GunSpec spec) {
        AmmoType t = GunData.ammoType(gun);
        if (t == null) t = AmmoType.defaultFor(spec.caliber);
        int n = count(p, t);
        return t.perMag ? n * spec.mag : n;
    }

    private static int take(Player p, AmmoType a, int max) {
        int got = 0;
        ItemStack off = p.getOffhandItem();
        if (off.getItem() instanceof AmmoItem ai && ai.type == a) {
            int k = Math.min(max, off.getCount());
            off.shrink(k);
            got += k;
        }
        for (int i = 0; i < p.getInventory().getContainerSize() && got < max; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.getItem() instanceof AmmoItem ai && ai.type == a) {
                int k = Math.min(max - got, s.getCount());
                s.shrink(k);
                got += k;
            }
        }
        return got;
    }

    private static void give(Player p, ItemStack stack) {
        if (stack.isEmpty()) return;
        if (!p.getInventory().add(stack)) p.drop(stack, false);
    }

    private static void startReload(ServerPlayer p, ItemStack s, GunSpec spec, @Nullable AmmoType wanted) {
        if (!spec.usesAmmo() || GunData.reloading(s)) return;
        AmmoType cur = GunData.ammoType(s);
        AmmoType want = wanted;
        if (want == null && p.getOffhandItem().getItem() instanceof AmmoItem ai && ai.type.caliber == spec.caliber) want = ai.type;
        if (want == null && cur != null && (p.isCreative() || count(p, cur) > 0)) want = cur;
        if (want == null) {
            for (AmmoType a : AmmoType.values()) {
                if (a.caliber == spec.caliber && count(p, a) > 0) {
                    want = a;
                    break;
                }
            }
        }
        if (want == null && p.isCreative()) want = cur != null ? cur : AmmoType.defaultFor(spec.caliber);
        Attachment att = GunData.attachment(s);
        int mag = spec.effectiveMag(att);
        if (want == null) {
            p.displayClientMessage(Component.translatable("message.blockwars.no_ammo", Component.translatable("caliber.blockwars." + spec.caliber.name().toLowerCase())), true);
            playAll(p, ModSounds.get("gun.empty"), 1.0F, 0.8F);
            return;
        }
        if (want == cur && GunData.ammo(s) >= mag) return;
        long now = p.level().getGameTime();
        int len = spec.effectiveReload(att);
        String type = want.name();
        GunData.edit(s, t -> {
            t.putLong("RelEnd", now + len);
            t.putInt("RelLen", len);
            t.putString("RelType", type);
        });
        state(p).burstLeft = 0;
        playAll(p, ModSounds.get("gun." + spec.id + ".reload"), 1.0F, 1.0F);
    }

    private static void finishReload(ServerPlayer p, ItemStack s, GunSpec spec) {
        CompoundTag t = GunData.read(s);
        AmmoType want = AmmoType.byName(t.getString("RelType"));
        AmmoType cur = GunData.ammoType(s);
        int ammo = GunData.ammo(s);
        int mag = spec.effectiveMag(GunData.attachment(s));
        GunData.edit(s, tag -> {
            tag.remove("RelEnd");
            tag.remove("RelLen");
            tag.remove("RelType");
        });
        if (want == null) return;
        boolean creative = p.isCreative();
        if (want != cur && cur != null && ammo > 0 && !cur.perMag && !creative) {
            give(p, new ItemStack(ModGuns.AMMO.get(cur).get(), ammo)); // unload the old rounds
            ammo = 0;
        }
        if (want != cur) ammo = 0;
        int loaded;
        if (want.perMag) {
            if (!creative && take(p, want, 1) < 1) return;
            if (cur != null && cur.caliber == GunSpec.Caliber.CELL && !creative) give(p, new ItemStack(ModGuns.EMPTY_CELL.get()));
            loaded = mag;
        } else {
            int need = mag - ammo;
            int got = creative ? need : take(p, want, need);
            loaded = ammo + got;
            if (got <= 0 && want != cur) return;
        }
        int fin = loaded;
        GunData.edit(s, tag -> {
            tag.putInt("Ammo", fin);
            tag.putString("AmmoType", want.name());
        });
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ARMOR_EQUIP_IRON.value(), SoundSource.PLAYERS, 0.5F, 1.4F);
    }

    // ================================================================= ticking

    public static void inventoryTick(ServerPlayer p, ItemStack s, GunSpec spec, int slot, boolean selected) {
        long now = p.level().getGameTime();
        CompoundTag t = GunData.read(s);
        if (t.contains("RelEnd") && now >= t.getLong("RelEnd")) {
            if (selected) finishReload(p, s, spec);
            else GunData.edit(s, tag -> tag.remove("RelEnd")); // reload interrupted by switching weapons
        }
        long melt = t.getLong("Melt");
        if (melt > 0) {
            tickMeltdown(p.serverLevel(), p.position().add(0, 1.2, 0), p, s, melt, now);
            if (s.isEmpty()) return;
        }
        if (spec.usesHeat() && t.getBoolean("Lock") && GunData.heat(s, spec, now) <= 0.25F && melt == 0) {
            GunData.setHeat(s, GunData.heat(s, spec, now), now, false);
            p.displayClientMessage(Component.translatable("message.blockwars.cooled"), true);
        }
        if (!selected) return;
        State st = state(p);
        if (st.slot != slot) {
            st.slot = slot;
            st.trigger = false;
            st.burstLeft = 0;
            st.hold = 0;
        }
        if (p.getVehicle() instanceof BaseMechaEntity) {
            st.trigger = false;
            return;
        }
        if (st.cooldown > 0) st.cooldown--;
        if (st.trigger) st.hold++;
        Attachment att = GunData.attachment(s);
        GunSpec.Fire fire = spec.effectiveFire(GunData.mode(s), att);
        switch (fire) {
            case AUTO, BEAM -> {
                if (st.trigger && st.cooldown <= 0) {
                    if (!tryShoot(p, s, spec, 1.0F)) {
                        if (fire == GunSpec.Fire.AUTO || GunData.ammo(s) <= 0) st.trigger = false;
                    }
                }
            }
            case BURST -> {
                if (st.burstLeft > 0 && st.cooldown <= 0) {
                    if (tryShoot(p, s, spec, 1.0F)) {
                        st.burstLeft--;
                        if (st.burstLeft == 0) st.cooldown = spec.rate * 3;
                    } else {
                        st.burstLeft = 0;
                    }
                }
            }
            case CHARGE -> {
                if (st.trigger) {
                    Vec3 mz = muzzle(p);
                    float c = Math.min(1.0F, st.hold / (float) spec.chargeFull);
                    p.serverLevel().sendParticles(ModParticles.of(WeaponSpec.PType.ORB, spec.color), mz.x, mz.y, mz.z, 1 + (int) (c * 3), 0.08, 0.08, 0.08, 0.01);
                    if (spec.overcharge > 0 && st.hold > spec.chargeFull) {
                        // UMBRAL: the core is destabilising in your hands
                        if (st.hold % 5 == 0) playAll(p, ModSounds.get("shared.alarm"), 1.5F, 0.6F + (st.hold - spec.chargeFull) / (float) (spec.overcharge - spec.chargeFull));
                        if (st.hold == spec.chargeFull + 1) p.displayClientMessage(Component.translatable("message.blockwars.umbral_unstable"), true);
                        if (st.hold >= spec.overcharge) {
                            st.trigger = false;
                            st.hold = 0;
                            collapse(p, s, spec);
                        }
                    }
                }
            }
            default -> { }
        }
    }

    public static void droppedTick(ItemEntity entity, ItemStack s, GunSpec spec) {
        long melt = GunData.meltdown(s);
        if (melt > 0 && entity.level() instanceof ServerLevel sl) {
            tickMeltdown(sl, entity.position(), null, s, melt, sl.getGameTime());
            if (s.isEmpty()) entity.discard();
        }
    }

    // ================================================================= shooting

    private static boolean canShoot(ServerPlayer p, ItemStack s, GunSpec spec, boolean feedback) {
        if (GunData.reloading(s)) return false;
        long now = p.level().getGameTime();
        if (spec.usesHeat() && GunData.locked(s)) {
            if (feedback) playAll(p, SoundEvents.FIRE_EXTINGUISH, 0.5F, 1.4F);
            return false;
        }
        if (spec.usesAmmo() && GunData.ammo(s) <= 0) {
            if (feedback) {
                playAll(p, ModSounds.get("gun.empty"), 1.0F, 1.0F);
                startReload(p, s, spec, null);
            }
            return false;
        }
        return now >= 0;
    }

    private static boolean tryShoot(ServerPlayer p, ItemStack s, GunSpec spec, float charge) {
        State st = state(p);
        if (st.cooldown > 0) return false;
        if (!canShoot(p, s, spec, true)) return false;
        Attachment att = GunData.attachment(s);
        AmmoType ammo = spec.usesAmmo() ? GunData.ammoType(s) : null;
        if (spec.usesAmmo() && ammo == null) ammo = AmmoType.defaultFor(spec.caliber);
        st.cooldown = spec.effectiveRate(att);
        long now = p.level().getGameTime();
        if (spec.usesAmmo()) GunData.setAmmo(s, GunData.ammo(s) - 1);
        ServerLevel level = p.serverLevel();
        boolean aiming = p.isUsingItem() && p.getUseItem() == s;
        float mul = ammo != null ? ammo.damageMul : 1.0F;
        if (att == Attachment.SUPPRESSOR) mul *= 0.9F;
        if (att == Attachment.SCOPE && aiming) mul *= 1.25F;
        switch (spec.kind) {
            case BULLET -> shootBullets(p, level, spec, att, ammo, aiming, mul);
            case RAIL -> shootRail(p, level, spec, att, mul, charge, aiming);
            case FLAME -> shootFlame(p, level, spec, mul, now);
            case TESLA -> shootTesla(p, level, spec, att, mul);
            case ROCKET -> shootRocket(p, level, spec, att, ammo);
            case SINGULARITY -> shootSingularity(p, level, spec, charge);
            case FUSION -> shootFusion(p, level, s, spec, mul, now);
        }
        if (spec.usesHeat()) {
            float h = GunData.heat(s, spec, now) + spec.heatPerShot * (ammo == AmmoType.CELL_OVERCHARGED ? 1.6F : 1.0F);
            if (h >= 1.0F) {
                GunData.setHeat(s, 1.0F, now, true);
                overheat(p, s, spec, now);
            } else {
                GunData.setHeat(s, h, now, false);
            }
            if (spec.kind == GunSpec.Kind.FUSION && h > 0.8F && p.tickCount % 20 == 0) {
                p.igniteForSeconds(2); // the casing glows through your gloves
            }
        }
        // sound for everyone else (the shooter's client plays its own copy instantly)
        boolean continuous = spec.fire == GunSpec.Fire.BEAM;
        if (!continuous || st.sound-- <= 0) {
            float vol = att == Attachment.SUPPRESSOR ? 0.35F : (spec.kind == GunSpec.Kind.ROCKET || spec.kind == GunSpec.Kind.SINGULARITY ? 3.0F : 2.0F);
            float pitch = att == Attachment.SUPPRESSOR ? 1.5F : 0.95F + p.getRandom().nextFloat() * 0.1F;
            Vec3 m = muzzle(p);
            level.playSound(p, m.x, m.y, m.z, ModSounds.get("gun." + spec.id + ".fire"), SoundSource.PLAYERS, vol, pitch);
            st.sound = 3;
        }
        if (att != Attachment.SUPPRESSOR && spec.kind != GunSpec.Kind.FLAME && spec.kind != GunSpec.Kind.FUSION) {
            Vec3 m = muzzle(p);
            othersParticles(level, p, ModParticles.of(WeaponSpec.PType.ORB, spec.color), m, 3, 0.05, 0.02);
            othersParticles(level, p, ParticleTypes.SMOKE, m, 2, 0.04, 0.01);
        }
        return true;
    }

    /** Where the barrel ends, roughly, for particles and beams. */
    public static Vec3 muzzle(Player p) {
        Vec3 look = p.getLookAngle();
        float yaw = p.getYRot() * Mth.DEG_TO_RAD;
        Vec3 right = new Vec3(-Mth.cos(yaw), 0, -Mth.sin(yaw));
        return p.getEyePosition().add(look.scale(0.9)).add(right.scale(0.3)).add(0, -0.2, 0);
    }

    private static Vec3 spreadDir(Player p, float spread, float yawOffset) {
        float yaw = p.getYRot() + yawOffset;
        float pitch = p.getXRot();
        Vec3 d = Vec3.directionFromRotation(pitch, yaw);
        if (spread <= 0) return d;
        double k = spread * 0.0075 * 2.2;
        return d.add(p.getRandom().nextGaussian() * k, p.getRandom().nextGaussian() * k, p.getRandom().nextGaussian() * k).normalize();
    }

    @Nullable
    private static Entity crosshairTarget(Player p, double range) {
        Vec3 from = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Entity best = null;
        double bestScore = 0.96;
        for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range), e -> e != p && e.isAlive() && !e.isSpectator())) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(from);
            double d = to.length();
            if (d > range) continue;
            double dot = to.normalize().dot(look);
            if (dot > bestScore) {
                bestScore = dot;
                best = e;
            }
        }
        return best;
    }

    private static void shootBullets(ServerPlayer p, ServerLevel level, GunSpec spec, @Nullable Attachment att, @Nullable AmmoType ammo, boolean aiming, float mul) {
        int n = spec.pellets * (att == Attachment.SPLITTER ? 3 : 1);
        float dmg = spec.damage * mul * (att == Attachment.SPLITTER ? 0.45F : 1.0F);
        float spread = aiming ? spec.adsSpread : spec.spread;
        if (aiming && att == Attachment.SCOPE) spread = 0;
        if (p.isCrouching()) spread *= 0.7F;
        Entity seek = att == Attachment.SEEKER ? crosshairTarget(p, 96) : null;
        AmmoType.Special sp = ammo != null ? ammo.special : AmmoType.Special.NONE;
        boolean dragon = sp == AmmoType.Special.DRAGON;
        for (int i = 0; i < n; i++) {
            GunBulletEntity b = new GunBulletEntity(level, p);
            Vec3 eye = p.getEyePosition();
            b.setPos(eye.x, eye.y - 0.1, eye.z);
            float fan = att == Attachment.SPLITTER ? ((i % 3) - 1) * 3.5F : 0.0F;
            Vec3 d = spreadDir(p, spread, fan);
            float speed = dragon ? spec.speed * 0.55F : spec.speed;
            b.setDeltaMovement(d.scale(speed));
            b.damage = dmg;
            b.maxAge = (int) Math.ceil((dragon ? 12 : spec.range) / speed) + 2;
            b.fireSeconds = sp == AmmoType.Special.INCENDIARY ? 4 : dragon ? 8 : 0;
            b.placesFire = sp == AmmoType.Special.INCENDIARY || dragon;
            b.pierce = sp == AmmoType.Special.PIERCING ? 2 : 0;
            b.bounces = att == Attachment.RICOCHET ? 3 : 0;
            b.breaksGlass = spec.breaksGlass;
            b.homingTarget = seek;
            int color = ammo != null && ammo.special != AmmoType.Special.NONE ? ammo.color : spec.color;
            b.setLook(color, att == Attachment.SUPPRESSOR, sp == AmmoType.Special.INCENDIARY, dragon, sp == AmmoType.Special.PIERCING);
            level.addFreshEntity(b);
        }
        if (dragon) {
            Vec3 m = muzzle(p);
            Vec3 look = p.getLookAngle();
            for (int i = 0; i < 14; i++) {
                Vec3 v = look.add(p.getRandom().nextGaussian() * 0.15, p.getRandom().nextGaussian() * 0.15, p.getRandom().nextGaussian() * 0.15).scale(0.5 + p.getRandom().nextDouble() * 0.4);
                level.sendParticles(ParticleTypes.FLAME, m.x, m.y, m.z, 0, v.x, v.y, v.z, 1.0);
            }
        }
    }

    private static void shootRail(ServerPlayer p, ServerLevel level, GunSpec spec, @Nullable Attachment att, float mul, float charge, boolean aiming) {
        float dmg = spec.damage * mul * (0.25F + 0.75F * charge);
        int beams = att == Attachment.SPLITTER ? 3 : 1;
        if (beams > 1) dmg *= 0.5F;
        for (int i = 0; i < beams; i++) {
            float yawOff = beams > 1 ? (i - 1) * 4.0F : 0.0F;
            Vec3 dir = spreadDir(p, aiming ? 0 : spec.spread * (1.0F - charge), yawOff);
            beamPath(p, level, p.getEyePosition(), muzzle(p), dir, spec.range, att == Attachment.RICOCHET ? 2 : 0, dmg, spec, charge, true);
        }
        // a full charge pushes the shooter back
        if (charge >= 0.99F) {
            Vec3 back = p.getLookAngle().scale(-0.35);
            p.push(back.x, 0.05, back.z);
            p.hurtMarked = true;
        }
    }

    /** Hitscan beam with optional reflections. Returns the final end point. */
    private static Vec3 beamPath(ServerPlayer p, ServerLevel level, Vec3 from, Vec3 visualFrom, Vec3 dir, float range, int reflections, float dmg,
                                 GunSpec spec, float charge, boolean pierce) {
        Vec3 start = from;
        Vec3 vstart = visualFrom;
        float left = range;
        Set<Integer> hit = new HashSet<>();
        Vec3 end = from;
        for (int r = 0; r <= reflections && left > 0.5F; r++) {
            Vec3 to = start.add(dir.scale(left));
            BlockHitResult bh = level.clip(new ClipContext(start, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            end = bh.getType() == HitResult.Type.MISS ? to : bh.getLocation();
            List<LivingEntity> targets = new ArrayList<>();
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(start, end).inflate(1.0), e -> e != p && e.isAlive() && !hit.contains(e.getId()))) {
                Optional<Vec3> c = e.getBoundingBox().inflate(0.3).clip(start, end);
                if (c.isPresent()) targets.add(e);
            }
            Vec3 s0 = start;
            targets.sort(Comparator.comparingDouble(e -> e.distanceToSqr(s0)));
            if (!pierce && !targets.isEmpty()) {
                targets = List.of(targets.get(0));
                end = targets.get(0).getBoundingBox().getCenter();
            }
            for (LivingEntity e : targets) {
                hit.add(e.getId());
                boolean head = e.getBbHeight() > 0.9F && Math.abs(e.getEyeY() - closestY(start, end, e)) < 0.3;
                damage(p, null, e, head ? dmg * 1.5F : dmg, spec.kind == GunSpec.Kind.FUSION ? 5 : 0, head, dir.scale(spec.knock * charge), 1.0F);
            }
            drawBeam(level, vstart, end, spec, charge);
            if (bh.getType() != HitResult.Type.MISS) {
                BlockState st = level.getBlockState(bh.getBlockPos());
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), end.x, end.y, end.z, 10, 0.1, 0.1, 0.1, 0.15);
                if (spec.kind == GunSpec.Kind.RAIL && charge > 0.95F && (st.is(Tags.Blocks.GLASS_BLOCKS) || st.is(Tags.Blocks.GLASS_PANES)) && level.mayInteract(p, bh.getBlockPos())) {
                    level.destroyBlock(bh.getBlockPos(), false, p);
                }
                if (r < reflections) {
                    Direction d = bh.getDirection();
                    dir = switch (d.getAxis()) {
                        case X -> new Vec3(-dir.x, dir.y, dir.z);
                        case Y -> new Vec3(dir.x, -dir.y, dir.z);
                        case Z -> new Vec3(dir.x, dir.y, -dir.z);
                    };
                    left -= (float) start.distanceTo(end);
                    start = end.add(dir.scale(0.05));
                    vstart = start;
                    level.sendParticles(ModParticles.of(WeaponSpec.PType.SPARK, 0xFFFFFF), end.x, end.y, end.z, 12, 0.05, 0.05, 0.05, 0.3);
                    continue;
                }
            }
            break;
        }
        return end;
    }

    private static double closestY(Vec3 a, Vec3 b, Entity e) {
        Vec3 ab = b.subtract(a);
        Vec3 c = e.getBoundingBox().getCenter();
        double t = Mth.clamp(c.subtract(a).dot(ab) / Math.max(1e-6, ab.lengthSqr()), 0, 1);
        return a.add(ab.scale(t)).y;
    }

    private static void drawBeam(ServerLevel level, Vec3 from, Vec3 to, GunSpec spec, float charge) {
        Vec3 d = to.subtract(from);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 n = d.normalize();
        Vec3 side = n.cross(new Vec3(0, 1, 0));
        if (side.lengthSqr() < 1e-4) side = new Vec3(1, 0, 0);
        side = side.normalize();
        Vec3 up = side.cross(n).normalize();
        ParticleOptions core = ModParticles.of(WeaponSpec.PType.SPARK, 0xFFFFFF);
        ParticleOptions glow = ModParticles.of(spec.kind == GunSpec.Kind.FUSION ? WeaponSpec.PType.EMBER : WeaponSpec.PType.ORB, spec.color);
        double step = spec.kind == GunSpec.Kind.FUSION ? 0.45 : 0.3;
        for (double s = 0; s < len; s += step) {
            Vec3 q = from.add(n.scale(s));
            level.sendParticles(glow, q.x, q.y, q.z, 1, 0.02, 0.02, 0.02, 0.0);
            if (((int) (s / step)) % 3 == 0) level.sendParticles(core, q.x, q.y, q.z, 1, 0, 0, 0, 0);
            if (spec.kind == GunSpec.Kind.RAIL) {
                // the coil leaves a spiral wake
                double a = s * 2.4;
                double r = 0.12 + 0.18 * charge;
                Vec3 o = side.scale(Math.cos(a) * r).add(up.scale(Math.sin(a) * r));
                level.sendParticles(ModParticles.of(WeaponSpec.PType.SHARD, spec.color), q.x + o.x, q.y + o.y, q.z + o.z, 1, 0, 0, 0, 0);
            }
        }
        level.sendParticles(glow, to.x, to.y, to.z, 12, 0.15, 0.15, 0.15, 0.12);
    }

    private static void shootFlame(ServerPlayer p, ServerLevel level, GunSpec spec, float mul, long now) {
        Vec3 from = muzzle(p);
        Vec3 look = p.getLookAngle();
        if (p.isUnderWater()) {
            level.sendParticles(ParticleTypes.BUBBLE, from.x, from.y, from.z, 6, 0.2, 0.2, 0.2, 0.1);
            return;
        }
        double cos = Math.cos(Math.toRadians(spec.angle));
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(spec.range), e -> e != p && e.isAlive())) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(from);
            if (to.length() > spec.range || to.normalize().dot(look) < cos) continue;
            if (e.tickCount % 4 == 0 || e.getRemainingFireTicks() <= 0) damage(p, null, e, spec.damage * mul, 6, false, Vec3.ZERO, 0.0F);
        }
        for (int i = 0; i < 6; i++) {
            Vec3 v = look.add(p.getRandom().nextGaussian() * 0.12, p.getRandom().nextGaussian() * 0.12, p.getRandom().nextGaussian() * 0.12)
                    .normalize().scale(0.45 + p.getRandom().nextDouble() * 0.35);
            level.sendParticles(i % 2 == 0 ? ParticleTypes.FLAME : ModParticles.of(WeaponSpec.PType.EMBER, spec.color), from.x, from.y, from.z, 0, v.x, v.y, v.z, 1.0);
        }
        if (now % 3 == 0) {
            Vec3 v = look.scale(0.25);
            level.sendParticles(ModParticles.of(WeaponSpec.PType.SMOKE, 0x302820), from.x + look.x * 4, from.y + look.y * 4, from.z + look.z * 4, 0, v.x, 0.05, v.z, 1.0);
        }
        if (now % 4 == 0) {
            BlockHitResult bh = level.clip(new ClipContext(from, from.add(look.scale(spec.range)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            if (bh.getType() != HitResult.Type.MISS) {
                BlockPos fp = bh.getBlockPos().relative(bh.getDirection());
                if (level.getBlockState(fp).isAir() && level.mayInteract(p, fp) && p.getRandom().nextInt(3) == 0) {
                    level.setBlockAndUpdate(fp, Blocks.FIRE.defaultBlockState());
                }
            }
        }
    }

    private static void shootTesla(ServerPlayer p, ServerLevel level, GunSpec spec, @Nullable Attachment att, float mul) {
        int chains = att == Attachment.SPLITTER ? 2 : 1;
        Set<Integer> used = new HashSet<>();
        Vec3 from = muzzle(p);
        for (int c = 0; c < chains; c++) {
            LivingEntity cur = null;
            double best = 0.82;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(spec.range), e -> e != p && e.isAlive() && !used.contains(e.getId()))) {
                Vec3 to = e.getBoundingBox().getCenter().subtract(p.getEyePosition());
                double d = to.length();
                if (d > spec.range) continue;
                double score = to.normalize().dot(p.getLookAngle()) - d / (spec.range * 6);
                if (score > best) {
                    best = score;
                    cur = e;
                }
            }
            if (cur == null) {
                Vec3 end = beamEnd(level, p, Math.min(10, spec.range));
                arc(level, from, end, spec.color);
                level.sendParticles(ModParticles.of(WeaponSpec.PType.SPARK, spec.color), end.x, end.y, end.z, 6, 0.1, 0.1, 0.1, 0.2);
                continue;
            }
            Vec3 last = from;
            for (int j = 0; j <= spec.jumps && cur != null; j++) {
                used.add(cur.getId());
                Vec3 at = cur.getBoundingBox().getCenter();
                arc(level, last, at, spec.color);
                damage(p, null, cur, spec.damage * mul * (j == 0 ? 1.0F : 0.7F), 0, false, Vec3.ZERO, 0.0F);
                cur.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 2));
                last = at;
                LivingEntity next = null;
                double nd = 7.0;
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, cur.getBoundingBox().inflate(7.0), e -> e != p && e.isAlive() && !used.contains(e.getId()))) {
                    double d = e.distanceTo(cur);
                    if (d < nd) {
                        nd = d;
                        next = e;
                    }
                }
                cur = next;
            }
        }
    }

    private static Vec3 beamEnd(ServerLevel level, Player p, double range) {
        Vec3 from = p.getEyePosition();
        Vec3 to = from.add(p.getLookAngle().scale(range));
        BlockHitResult bh = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return bh.getType() == HitResult.Type.MISS ? to : bh.getLocation();
    }

    private static void arc(ServerLevel level, Vec3 a, Vec3 b, int color) {
        ParticleOptions po = ModParticles.of(WeaponSpec.PType.SPARK, color);
        ParticleOptions white = ModParticles.of(WeaponSpec.PType.SPARK, 0xFFFFFF);
        Vec3 d = b.subtract(a);
        int n = Math.max(4, (int) (d.length() * 3));
        Vec3 prev = a;
        for (int i = 1; i <= n; i++) {
            Vec3 q = a.add(d.scale(i / (double) n));
            if (i < n) q = q.add(level.random.nextGaussian() * 0.22, level.random.nextGaussian() * 0.22, level.random.nextGaussian() * 0.22);
            Vec3 seg = q.subtract(prev);
            for (int s = 0; s < 3; s++) {
                Vec3 r = prev.add(seg.scale(s / 3.0));
                level.sendParticles(s == 0 ? white : po, r.x, r.y, r.z, 1, 0, 0, 0, 0);
            }
            prev = q;
        }
    }

    private static void shootRocket(ServerPlayer p, ServerLevel level, GunSpec spec, @Nullable Attachment att, @Nullable AmmoType ammo) {
        boolean thermo = ammo == AmmoType.ROCKET_THERMO;
        GunRocketEntity r = new GunRocketEntity(level, p, thermo ? 1 : 0);
        Vec3 m = muzzle(p);
        r.setPos(m.x, m.y, m.z);
        r.setDeltaMovement(spreadDir(p, p.isUsingItem() ? spec.adsSpread : spec.spread, 0).scale(spec.speed));
        r.damage = spec.damage;
        if (att == Attachment.SEEKER) r.homingTarget = crosshairTarget(p, 120);
        level.addFreshEntity(r);
        // backblast
        Vec3 back = p.getLookAngle().scale(-1);
        Vec3 bb = p.getEyePosition().add(back.scale(0.8));
        level.sendParticles(ParticleTypes.LARGE_SMOKE, bb.x, bb.y, bb.z, 12, 0.2, 0.2, 0.2, 0.08);
        level.sendParticles(ParticleTypes.FLAME, bb.x, bb.y, bb.z, 8, 0.1, 0.1, 0.1, 0.12);
        Vec3 push = p.getLookAngle().scale(-0.5);
        p.push(push.x, 0.08, push.z);
        p.hurtMarked = true;
    }

    public static void rocketBlast(ServerLevel level, Vec3 at, Entity rocket, @Nullable Entity owner, boolean thermo, float damage) {
        if (thermo) {
            level.explode(rocket, at.x, at.y, at.z, 2.2F, true, Level.ExplosionInteraction.MOB);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(6))) {
                if (e.position().distanceTo(at) > 6) continue;
                damage(owner, rocket, e, damage * 0.6F, 8, false, Vec3.ZERO, 0.0F);
            }
            for (int i = 0; i < 60; i++) {
                double a = i * Math.PI * 2 / 60;
                level.sendParticles(ParticleTypes.FLAME, at.x, at.y + 0.3, at.z, 0, Math.cos(a) * 0.45, 0.05, Math.sin(a) * 0.45, 1.0);
            }
            level.sendParticles(ModParticles.of(WeaponSpec.PType.EMBER, 0xFF5020), at.x, at.y + 1, at.z, 50, 2.0, 1.5, 2.0, 0.1);
        } else {
            level.explode(rocket, at.x, at.y, at.z, 3.2F, false, Level.ExplosionInteraction.MOB);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(3))) {
                if (e.position().distanceTo(at) > 3) continue;
                damage(owner, rocket, e, damage * 0.5F, 0, false, Vec3.ZERO, 0.0F);
            }
        }
        level.sendParticles(ModParticles.of(WeaponSpec.PType.SPARK, 0xFFD080), at.x, at.y + 0.5, at.z, 40, 0.5, 0.5, 0.5, 0.5);
        level.sendParticles(ModParticles.of(WeaponSpec.PType.SMOKE, 0x404040), at.x, at.y + 1, at.z, 20, 1.5, 1.0, 1.5, 0.05);
        shakeAround(level, at, 32, thermo ? 2.4F : 2.0F);
    }

    // ================================================================= UMBRAL

    private static void shootSingularity(ServerPlayer p, ServerLevel level, GunSpec spec, float charge) {
        GunRocketEntity seed = new GunRocketEntity(level, p, 2);
        Vec3 m = muzzle(p);
        seed.setPos(m.x, m.y, m.z);
        seed.setDeltaMovement(p.getLookAngle().scale(spec.speed * (0.6F + 0.4F * charge)));
        level.addFreshEntity(seed);
        Vec3 push = p.getLookAngle().scale(-0.9);
        p.push(push.x, 0.15, push.z);
        p.hurtMarked = true;
        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0));
        shakeAround(level, p.position(), 16, 1.5F);
    }

    /** Held the charge too long: the core collapses where you stand. */
    private static void collapse(ServerPlayer p, ItemStack s, GunSpec spec) {
        GunData.setAmmo(s, 0);
        p.displayClientMessage(Component.translatable("message.blockwars.umbral_collapse"), false);
        openSingularity(p.serverLevel(), p.getEyePosition().add(p.getLookAngle().scale(1.2)), p, 90, true);
        p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 160, 0));
        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 160, 0));
    }

    public static void openSingularity(ServerLevel level, Vec3 at, @Nullable Entity owner, int life, boolean collapse) {
        SingularityEntity e = ModEntities.SINGULARITY.get().create(level);
        if (e == null) return;
        e.moveTo(at.x, at.y, at.z);
        e.setup(owner, life);
        level.addFreshEntity(e);
        level.playSound(null, at.x, at.y, at.z, ModSounds.get("shared.singularity"), SoundSource.HOSTILE, 4.0F, collapse ? 0.5F : 0.7F);
        shakeAround(level, at, 32, collapse ? 3.0F : 1.8F);
    }

    // ================================================================= SOLARIS & TESLA heat

    private static void shootFusion(ServerPlayer p, ServerLevel level, ItemStack s, GunSpec spec, float mul, long now) {
        Vec3 end = beamPath(p, level, p.getEyePosition(), muzzle(p), p.getLookAngle(), spec.range, 0, spec.damage * mul, spec, 1.0F, true);
        // the lance melts what it touches
        if (now % 4 == 0) {
            BlockHitResult bh = level.clip(new ClipContext(p.getEyePosition(), p.getEyePosition().add(p.getLookAngle().scale(spec.range)),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            if (bh.getType() != HitResult.Type.MISS) {
                BlockPos bp = bh.getBlockPos();
                BlockState st = level.getBlockState(bp);
                float hardness = st.getDestroySpeed(level, bp);
                if (hardness >= 0 && hardness <= 4.0F && level.mayInteract(p, bp)) {
                    level.destroyBlock(bp, false, p);
                    if (p.getRandom().nextInt(3) == 0 && level.getBlockState(bp).isAir()) level.setBlockAndUpdate(bp, Blocks.FIRE.defaultBlockState());
                    level.sendParticles(ParticleTypes.LAVA, end.x, end.y, end.z, 3, 0.2, 0.2, 0.2, 0.1);
                }
            }
        }
        level.sendParticles(ParticleTypes.SMOKE, end.x, end.y, end.z, 2, 0.1, 0.1, 0.1, 0.03);
    }

    private static void overheat(ServerPlayer p, ItemStack s, GunSpec spec, long now) {
        if (spec.kind == GunSpec.Kind.FUSION) {
            if (GunData.meltdown(s) == 0) {
                GunData.edit(s, t -> t.putLong("Melt", now + 60));
                p.displayClientMessage(Component.translatable("message.blockwars.solaris_meltdown"), false);
                playAll(p, ModSounds.get("shared.alarm"), 2.0F, 1.2F);
            }
            state(p).trigger = false;
        } else {
            p.displayClientMessage(Component.translatable("message.blockwars.overheated"), true);
            playAll(p, ModSounds.get("gun." + spec.id + ".special"), 1.2F, 0.8F);
            state(p).trigger = false;
        }
    }

    private static void vent(ServerPlayer p, ItemStack s, GunSpec spec, long now) {
        float heat = GunData.heat(s, spec, now);
        if (heat < 0.15F && GunData.meltdown(s) == 0) {
            p.displayClientMessage(Component.translatable("message.blockwars.vent_cold"), true);
            return;
        }
        boolean wasMelting = GunData.meltdown(s) > 0;
        GunData.edit(s, t -> {
            t.putFloat("Heat", 0.0F);
            t.putLong("HeatT", now);
            t.putBoolean("Lock", false);
            t.remove("Melt");
        });
        ServerLevel level = p.serverLevel();
        Vec3 c = p.position().add(0, 1, 0);
        float r = 2.0F + heat * 4.0F;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r), e -> e != p && e.isAlive())) {
            if (e.position().distanceTo(p.position()) > r) continue;
            damage(p, null, e, 4.0F + heat * 8.0F, spec.kind == GunSpec.Kind.FUSION ? 6 : 0, false, e.position().subtract(p.position()).normalize().scale(0.8), 1.0F);
        }
        ParticleOptions po = spec.kind == GunSpec.Kind.FUSION ? ModParticles.of(WeaponSpec.PType.EMBER, 0xFF8020) : ModParticles.of(WeaponSpec.PType.SPARK, spec.color);
        for (int i = 0; i < 50; i++) {
            double a = i * Math.PI * 2 / 50;
            level.sendParticles(po, c.x, c.y, c.z, 0, Math.cos(a) * r * 0.1, 0.02, Math.sin(a) * r * 0.1, 1.0);
        }
        level.sendParticles(ParticleTypes.CLOUD, c.x, c.y + 0.5, c.z, 20, 0.4, 0.4, 0.4, 0.08);
        if (spec.kind == GunSpec.Kind.FUSION) {
            p.igniteForSeconds(3); // venting a fusion lance is never clean
            if (wasMelting) p.displayClientMessage(Component.translatable("message.blockwars.solaris_saved"), false);
        }
        playAll(p, ModSounds.get("gun." + spec.id + ".special"), 1.5F, 1.0F);
        shakeAround(level, c, 8, 1.0F);
    }

    private static void tickMeltdown(ServerLevel level, Vec3 at, @Nullable ServerPlayer holder, ItemStack s, long melt, long now) {
        long left = melt - now;
        if (left % 10 == 0) {
            level.playSound(null, at.x, at.y, at.z, ModSounds.get("shared.alarm"), SoundSource.PLAYERS, 2.0F, 1.0F + (60 - left) / 60.0F);
            if (holder != null) holder.displayClientMessage(Component.translatable("message.blockwars.solaris_countdown", String.format("%.1f", left / 20.0F)), true);
        }
        level.sendParticles(ModParticles.of(WeaponSpec.PType.EMBER, 0xFF3010), at.x, at.y, at.z, 4, 0.3, 0.3, 0.3, 0.06);
        if (now >= melt) {
            s.shrink(1);
            level.playSound(null, at.x, at.y, at.z, ModSounds.get("shared.meltdown"), SoundSource.PLAYERS, 4.0F, 0.9F);
            level.explode(null, at.x, at.y, at.z, 6.0F, true, Level.ExplosionInteraction.TNT);
            level.sendParticles(ModParticles.of(WeaponSpec.PType.EMBER, 0xFFFFFF), at.x, at.y, at.z, 120, 2.5, 2.5, 2.5, 0.6);
            shakeAround(level, at, 64, 4.0F);
        }
    }

    // ================================================================= shared helpers

    /** Damage with gun rules: no invulnerability frames between bullets, softened knockback, hit markers. */
    public static void damage(@Nullable Entity owner, @Nullable Entity direct, Entity target, float dmg, int fireSeconds, boolean head,
                              Vec3 push, float knockScale) {
        if (target == owner) return;
        Level level = target.level();
        Vec3 before = target.getDeltaMovement();
        if (target instanceof LivingEntity le) le.invulnerableTime = 0;
        boolean hurt;
        if (direct instanceof Projectile proj) {
            hurt = target.hurt(level.damageSources().thrown(proj, owner), dmg);
        } else if (owner instanceof Player pl) {
            hurt = target.hurt(level.damageSources().playerAttack(pl), dmg);
        } else {
            hurt = target.hurt(level.damageSources().magic(), dmg);
        }
        if (!hurt) return;
        if (fireSeconds > 0) target.igniteForSeconds(fireSeconds);
        // bullets nudge, they don't launch
        Vec3 after = target.getDeltaMovement();
        target.setDeltaMovement(before.add(after.subtract(before).scale(knockScale)).add(push));
        target.hurtMarked = true;
        if (owner instanceof ServerPlayer sp && target instanceof LivingEntity le) {
            byte kind = !le.isAlive() || le.getHealth() <= 0 ? GunFeedbackPayload.KILL : head ? GunFeedbackPayload.HEADSHOT : GunFeedbackPayload.HIT;
            PacketDistributor.sendToPlayer(sp, new GunFeedbackPayload(kind, dmg));
        }
        if (level instanceof ServerLevel sl && target instanceof LivingEntity) {
            Vec3 c = target.getBoundingBox().getCenter();
            sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState()), c.x, c.y, c.z, head ? 10 : 4, 0.15, 0.2, 0.15, 0.1);
        }
    }

    public static void impactSound(ServerLevel level, Vec3 at, BlockState st) {
        SoundEvent s = ModSounds.get("gun.impact");
        level.playSound(null, at.x, at.y, at.z, s, SoundSource.PLAYERS, 0.5F, 0.8F + level.random.nextFloat() * 0.5F);
        if (st.is(Tags.Blocks.GLASS_BLOCKS) || st.is(Tags.Blocks.GLASS_PANES)) {
            level.playSound(null, at.x, at.y, at.z, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 0.7F, 1.2F);
        }
    }

    /** Screen shake for every player near a blast. */
    public static void shakeAround(ServerLevel level, Vec3 at, double radius, float strength) {
        for (ServerPlayer sp : level.players()) {
            double d = sp.position().distanceTo(at);
            if (d > radius) continue;
            float s = strength * (float) (1.0 - d / radius);
            if (s > 0.05F) PacketDistributor.sendToPlayer(sp, new GunFeedbackPayload(GunFeedbackPayload.SHAKE, s));
        }
    }

    private static void playAll(ServerPlayer p, SoundEvent s, float vol, float pitch) {
        p.level().playSound(null, p.getX(), p.getY() + 1, p.getZ(), s, SoundSource.PLAYERS, vol, pitch);
    }

    private static void othersParticles(ServerLevel level, ServerPlayer shooter, ParticleOptions po, Vec3 at, int n, double spread, double speed) {
        for (ServerPlayer sp : level.players()) {
            if (sp == shooter) continue;
            level.sendParticles(sp, po, false, at.x, at.y, at.z, n, spread, spread, spread, speed);
        }
    }
}
