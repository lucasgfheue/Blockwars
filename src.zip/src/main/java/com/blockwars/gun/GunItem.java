package com.blockwars.gun;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

/**
 * A hand-held BlockWars weapon. Left click fires (handled by {@link GunLogic} through the network),
 * right click aims down sights, SHIFT + right click installs the attachment held in the off hand.
 */
public class GunItem extends Item {
    public final GunSpec spec;

    public GunItem(Properties props, GunSpec spec) {
        super(props);
        this.spec = spec;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND) return InteractionResultHolder.pass(stack);
        if (player.isShiftKeyDown()) {
            if (!level.isClientSide && player instanceof ServerPlayer sp) {
                GunLogic.toggleAttachment(sp, stack, this.spec);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        player.startUsingItem(hand); // aim down sights
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.NONE;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (!level.isClientSide && entity instanceof ServerPlayer sp) {
            GunLogic.inventoryTick(sp, stack, this.spec, slot, selected);
        }
    }

    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        // a dropped SOLARIS in meltdown still goes off
        if (!entity.level().isClientSide) {
            GunLogic.droppedTick(entity, stack, this.spec);
        }
        return false;
    }

    @Override
    public boolean canAttackBlock(BlockState state, Level level, BlockPos pos, Player player) {
        return false;
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return this.spec.usesAmmo() || this.spec.usesHeat();
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        if (!this.spec.usesAmmo()) return Math.round(13.0F * (1.0F - GunData.read(stack).getFloat("Heat")));
        int mag = this.spec.effectiveMag(GunData.attachment(stack));
        return Math.round(13.0F * Mth.clamp(GunData.ammo(stack) / (float) mag, 0.0F, 1.0F));
    }

    @Override
    public int getBarColor(ItemStack stack) {
        if (!this.spec.usesAmmo()) return 0xFF6020;
        AmmoType t = GunData.ammoType(stack);
        return t != null ? t.color : 0x909090;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        String base = "item.blockwars." + this.spec.id;
        Language lang = Language.getInstance();
        for (int i = 0; i < 8 && lang.has(base + ".lore." + i); i++) {
            tooltip.add(Component.translatable(base + ".lore." + i).withStyle(ChatFormatting.DARK_AQUA, ChatFormatting.ITALIC));
        }
        if (this.spec.dangerous) {
            tooltip.add(Component.translatable("item.blockwars.gun.danger").withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
        }
        tooltip.add(Component.translatable(base + ".stats").withStyle(ChatFormatting.GRAY));
        if (this.spec.kind != GunSpec.Kind.SINGULARITY) {
            tooltip.add(Component.translatable("arsenal.blockwars.range", Math.round(this.spec.range)).withStyle(ChatFormatting.GRAY));
        }
        if (this.spec.usesAmmo()) {
            AmmoType t = GunData.ammoType(stack);
            Component ammoName = t != null ? Component.translatable("item.blockwars." + t.itemId) : Component.translatable("caliber.blockwars." + this.spec.caliber.name().toLowerCase());
            tooltip.add(Component.translatable("tooltip.blockwars.loaded", GunData.ammo(stack), this.spec.effectiveMag(GunData.attachment(stack)), ammoName).withStyle(ChatFormatting.YELLOW));
        }
        Attachment att = GunData.attachment(stack);
        if (att != null) {
            tooltip.add(Component.translatable("tooltip.blockwars.attachment", Component.translatable("item.blockwars." + att.itemId)).withStyle(ChatFormatting.GREEN));
        } else if (!this.spec.allowed.isEmpty()) {
            tooltip.add(Component.translatable("tooltip.blockwars.no_attachment").withStyle(ChatFormatting.DARK_GREEN));
        }
        tooltip.add(Component.translatable("tooltip.blockwars.gun_controls").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable(base + ".alt").withStyle(ChatFormatting.DARK_GRAY));
    }
}
