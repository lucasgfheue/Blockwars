package com.blockwars.gun;

import org.jetbrains.annotations.Nullable;

/** Every kind of ammunition, energy cell and fuel. */
public enum AmmoType {
    LIGHT("ammo_bala_ligera", GunSpec.Caliber.LIGHT, false, 1.0F, Special.NONE, 0xFFE2A0),
    LIGHT_INCENDIARY("ammo_bala_ligera_incendiaria", GunSpec.Caliber.LIGHT, false, 0.9F, Special.INCENDIARY, 0xFF7A30),
    HEAVY("ammo_bala_pesada", GunSpec.Caliber.HEAVY, false, 1.0F, Special.NONE, 0xFFD890),
    HEAVY_AP("ammo_bala_pesada_perforante", GunSpec.Caliber.HEAVY, false, 1.15F, Special.PIERCING, 0x9FE0FF),
    SHELL("ammo_cartucho", GunSpec.Caliber.SHELL, false, 1.0F, Special.NONE, 0xFFC070),
    SHELL_DRAGON("ammo_cartucho_dragon", GunSpec.Caliber.SHELL, false, 0.7F, Special.DRAGON, 0xFF5020),
    CELL("ammo_celda_energia", GunSpec.Caliber.CELL, true, 1.0F, Special.NONE, 0x70D8FF),
    CELL_OVERCHARGED("ammo_celda_sobrecargada", GunSpec.Caliber.CELL, true, 1.5F, Special.OVERCHARGE, 0xFF60E0),
    ROCKET_HE("ammo_cohete_he", GunSpec.Caliber.ROCKET, false, 1.0F, Special.HE, 0xFFA040),
    ROCKET_THERMO("ammo_cohete_termobarico", GunSpec.Caliber.ROCKET, false, 1.0F, Special.THERMOBARIC, 0xFF4020),
    NAPALM("ammo_bidon_napalm", GunSpec.Caliber.FUEL, true, 1.0F, Special.NONE, 0xFF8020),
    CORE("ammo_nucleo_singular", GunSpec.Caliber.CORE, false, 1.0F, Special.NONE, 0xA060FF);

    public enum Special { NONE, INCENDIARY, PIERCING, DRAGON, OVERCHARGE, HE, THERMOBARIC }

    public final String itemId;
    public final GunSpec.Caliber caliber;
    /** true: one item fills the whole magazine (cells, fuel); false: one item = one round. */
    public final boolean perMag;
    public final float damageMul;
    public final Special special;
    public final int color;

    AmmoType(String itemId, GunSpec.Caliber caliber, boolean perMag, float damageMul, Special special, int color) {
        this.itemId = itemId;
        this.caliber = caliber;
        this.perMag = perMag;
        this.damageMul = damageMul;
        this.special = special;
        this.color = color;
    }

    @Nullable
    public static AmmoType byName(String name) {
        for (AmmoType a : values()) if (a.name().equals(name)) return a;
        return null;
    }

    public static AmmoType defaultFor(GunSpec.Caliber c) {
        for (AmmoType a : values()) if (a.caliber == c) return a;
        return LIGHT;
    }
}
