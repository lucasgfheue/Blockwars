package com.blockwars.gun;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

public class AttachmentItem extends Item {
    public final Attachment attachment;

    public AttachmentItem(Properties props, Attachment attachment) {
        super(props);
        this.attachment = attachment;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.blockwars." + this.attachment.itemId + ".desc").withStyle(ChatFormatting.GRAY));
        for (GunSpec g : Guns.ALL) {
            if (g.allowed.contains(this.attachment)) {
                tooltip.add(Component.literal("  • ").append(Component.translatable("item.blockwars." + g.id)).withStyle(ChatFormatting.DARK_GREEN));
            }
        }
        tooltip.add(Component.translatable("tooltip.blockwars.attach_howto").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
    }
}
