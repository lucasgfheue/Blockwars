package com.blockwars.gun;

import java.util.List;

/** Generated: the 120 weapons of the 4.0 armory (stats, behaviour, allowed attachments). */
public final class GunCatalog {
    private GunCatalog() {}

    /** "Spark" Pistol — Rustborn */
    private static GunSpec g_chispa() {
        return new GunSpec("chispa", GunSpec.Caliber.LIGHT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(12, 28)
                .rate(4)
                .dmg(5F)
                .spread(1.4F, 0.2F)
                .speed(5F)
                .range(72F)
                .feel(3F, 0.7F, 0.5F, 1F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** Mk-II Officer's Pistol — Iron Concord */
    private static GunSpec g_oficial() {
        return new GunSpec("oficial", GunSpec.Caliber.LIGHT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(15, 28)
                .rate(4)
                .dmg(6F)
                .spread(1.4F, 0.2F)
                .speed(5F)
                .range(72F)
                .feel(3F, 0.7F, 0.5F, 1F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Hummingbird" Pistol — Aurora Syndicate */
    private static GunSpec g_colibri() {
        return new GunSpec("colibri", GunSpec.Caliber.LIGHT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(17, 28)
                .rate(3)
                .dmg(5F)
                .spread(1.4F, 0.2F)
                .speed(5F)
                .range(72F)
                .feel(2.4F, 0.7F, 0.5F, 1F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Ash Fox" Pistol — Black Ash */
    private static GunSpec g_zorro() {
        return new GunSpec("zorro", GunSpec.Caliber.LIGHT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(13, 28)
                .rate(4)
                .dmg(6.5F)
                .spread(1F, 0.2F)
                .speed(5F)
                .range(72F)
                .feel(3F, 0.7F, 0.5F, 1F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Lantern" Flare Pistol — Ironclad Navy */
    private static GunSpec g_farolillo() {
        return new GunSpec("farolillo", GunSpec.Caliber.LIGHT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(4, 28)
                .rate(10)
                .dmg(6F)
                .spread(1.4F, 0.2F)
                .speed(2.2F)
                .range(72F)
                .feel(3F, 0.7F, 0.5F, 1F)
                .color(0xFF6030)
                .casings(false, 0xD8A040)
                .gravity(0.02F)
                .tracer(1.8F, 2)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.GLOW, 200, 0)
                .ignite(5)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Rime" Cryo Pistol — Frostline */
    private static GunSpec g_escarcha() {
        return new GunSpec("escarcha", GunSpec.Caliber.LIGHT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(14, 28)
                .rate(4)
                .dmg(4.5F)
                .spread(1.4F, 0.2F)
                .speed(5F)
                .range(72F)
                .feel(3F, 0.7F, 0.5F, 1F)
                .color(0xA0E8FF)
                .casings(false, 0xD8A040)
                .tracer(1F, 5)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.FREEZE, 60, 1)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Little Riveter" Nail Pistol — Federal Works */
    private static GunSpec g_avispon2() {
        return new GunSpec("avispon2", GunSpec.Caliber.LIGHT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(20, 28)
                .rate(3)
                .dmg(4.5F)
                .spread(1.4F, 0.2F)
                .speed(4F)
                .range(72F)
                .feel(3F, 0.7F, 0.5F, 1F)
                .color(0xC0C0C0)
                .casings(false, 0xD8A040)
                .gravity(0.01F)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Mamba" Dart Pistol — Verdant Choir */
    private static GunSpec g_veneno() {
        return new GunSpec("veneno", GunSpec.Caliber.LIGHT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(10, 28)
                .rate(4)
                .dmg(3.5F)
                .spread(1.4F, 0.2F)
                .speed(4F)
                .range(72F)
                .feel(3F, 0.7F, 0.5F, 1F)
                .color(0xA0FF60)
                .casings(false, 0xD8A040)
                .tracer(1F, 6)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.POISON, 120, 1)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Horsefly" Machine Pistol — Dust Legion */
    private static GunSpec g_tabano() {
        return new GunSpec("tabano", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(24, 32)
                .rate(2)
                .dmg(3.2F)
                .spread(3.4F, 1.2F)
                .speed(5F)
                .range(56F)
                .feel(1.3F, 1F, 0.4F, 0.7F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Cricket" Machine Pistol — Mining Guild */
    private static GunSpec g_grillo() {
        return new GunSpec("grillo", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(30, 32)
                .rate(2)
                .dmg(3F)
                .spread(4F, 1.2F)
                .speed(5F)
                .range(56F)
                .feel(1.3F, 1F, 0.4F, 0.7F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Flash" Machine Pistol — Tempest Order */
    private static GunSpec g_relampago() {
        return new GunSpec("relampago", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(36, 32)
                .rate(1)
                .dmg(2.4F)
                .spread(4.6F, 1.2F)
                .speed(5F)
                .range(56F)
                .feel(0.9F, 1F, 0.4F, 0.7F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Bull" Heavy Pistol — Deepforge */
    private static GunSpec g_toro() {
        return new GunSpec("toro", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(7, 34)
                .rate(7)
                .dmg(12F)
                .spread(1.2F, 0.15F)
                .speed(6F)
                .range(90F)
                .feel(5.5F, 1F, 0.9F, 1.6F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .head(1.8F)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Magistrate" Pistol — Hollow Court */
    private static GunSpec g_magistrado() {
        return new GunSpec("magistrado", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(7, 34)
                .rate(7)
                .dmg(11F)
                .spread(1.2F, 0.15F)
                .speed(6F)
                .range(90F)
                .feel(5.5F, 1F, 0.9F, 1.6F)
                .color(0xB080FF)
                .casings(true, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.WITHER, 40, 0)
                .head(1.8F)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Driller" Pistol — Mining Guild */
    private static GunSpec g_perforadora() {
        return new GunSpec("perforadora", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(8, 34)
                .rate(7)
                .dmg(10F)
                .spread(1.2F, 0.15F)
                .speed(6F)
                .range(90F)
                .feel(5.5F, 1F, 0.9F, 1.6F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .pierce(1)
                .head(1.8F)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Lawbringer" Revolver — Dust Legion */
    private static GunSpec g_justiciero() {
        return new GunSpec("justiciero", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 46)
                .rate(9)
                .dmg(14F)
                .spread(1F, 0.1F)
                .speed(6.5F)
                .range(100F)
                .feel(6.5F, 1.2F, 1F, 1.9F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .head(2F)
                .allowNames("SCOPE,LASER,STABILIZER,RICOCHET,SPLITTER,SEEKER,OVERCLOCK");
    }

    /** "Hunter" Long Revolver — Verdant Choir */
    private static GunSpec g_cazador() {
        return new GunSpec("cazador", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 46)
                .rate(11)
                .dmg(16F)
                .spread(0.6F, 0.1F)
                .speed(6.5F)
                .range(100F)
                .feel(6.5F, 1.2F, 1F, 1.9F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .head(2F)
                .allowNames("SCOPE,LASER,STABILIZER,RICOCHET,SPLITTER,SEEKER,OVERCLOCK");
    }

    /** "Snubby" Revolver — Black Ash */
    private static GunSpec g_chato() {
        return new GunSpec("chato", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 46)
                .rate(7)
                .dmg(12F)
                .spread(1.6F, 0.1F)
                .speed(6.5F)
                .range(100F)
                .feel(6.5F, 1.2F, 1F, 1.9F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .head(2F)
                .allowNames("SCOPE,LASER,STABILIZER,RICOCHET,SPLITTER,SEEKER,OVERCLOCK");
    }

    /** "Thunder" Revolver — Tempest Order */
    private static GunSpec g_trueno() {
        return new GunSpec("trueno", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 46)
                .rate(9)
                .dmg(13F)
                .spread(1F, 0.1F)
                .speed(6.5F)
                .range(100F)
                .feel(6.5F, 1.2F, 1F, 1.9F)
                .color(0xFFF080)
                .casings(false, 0xD8A040)
                .splash(1.8F)
                .tracer(1F, 0)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.SLOW, 30, 1)
                .head(2F)
                .allowNames("SCOPE,LASER,STABILIZER,RICOCHET,SPLITTER,SEEKER,OVERCLOCK");
    }

    /** "Bellringer" Revolver — Rustborn */
    private static GunSpec g_campanero() {
        return new GunSpec("campanero", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 46)
                .rate(9)
                .dmg(12F)
                .spread(1F, 0.1F)
                .speed(6.5F)
                .range(100F)
                .feel(6.5F, 1.2F, 1F, 1.9F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .bounces(2)
                .head(2F)
                .allowNames("SCOPE,LASER,STABILIZER,RICOCHET,SPLITTER,SEEKER,OVERCLOCK");
    }

    /** "Selene" Energy Revolver — Aurora Syndicate */
    private static GunSpec g_lunar() {
        return new GunSpec("lunar", GunSpec.Caliber.CELL, GunSpec.Fire.SEMI, GunSpec.Kind.LASER)
                .mag(6, 46)
                .rate(8)
                .dmg(13F)
                .spread(1F, 0.1F)
                .speed(6.5F)
                .range(100F)
                .feel(6.5F, 1.2F, 1F, 1.9F)
                .color(0xC0E8FF)
                .casings(false, 0xD8A040)
                .head(2F)
                .allowNames("SCOPE,LASER,STABILIZER,RICOCHET,SPLITTER,SEEKER,OVERCLOCK");
    }

    /** "Buzz" SMG — Iron Concord */
    private static GunSpec g_zumbido() {
        return new GunSpec("zumbido", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(32, 38)
                .rate(2)
                .dmg(3.6F)
                .spread(3.4F, 1F)
                .speed(5F)
                .range(64F)
                .feel(1.15F, 0.95F, 0.38F, 0.6F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Lynx" SMG — Aurora Syndicate */
    private static GunSpec g_lince() {
        return new GunSpec("lince", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(40, 38)
                .rate(2)
                .dmg(3.4F)
                .spread(2.8F, 1F)
                .speed(5F)
                .range(64F)
                .feel(1.15F, 0.95F, 0.38F, 0.6F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Little Drum" SMG — Dust Legion */
    private static GunSpec g_tamborcito() {
        return new GunSpec("tamborcito", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(50, 60)
                .rate(2)
                .dmg(3.8F)
                .spread(3.4F, 1F)
                .speed(5F)
                .range(64F)
                .feel(1.15F, 0.95F, 0.38F, 0.6F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Whisper" Integrated SMG — Black Ash */
    private static GunSpec g_susurro() {
        return new GunSpec("susurro", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(30, 38)
                .rate(2)
                .dmg(3.4F)
                .spread(3.4F, 1F)
                .speed(5F)
                .range(64F)
                .feel(1.15F, 0.95F, 0.38F, 0.6F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Fly" PDW — Project Prometheus */
    private static GunSpec g_mosca() {
        return new GunSpec("mosca", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(40, 38)
                .rate(2)
                .dmg(3.2F)
                .spread(3.4F, 1F)
                .speed(5F)
                .range(64F)
                .feel(1.15F, 0.95F, 0.38F, 0.6F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .pierce(1)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Grinder" SMG — Rustborn */
    private static GunSpec g_trituradora_smg() {
        return new GunSpec("trituradora_smg", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(34, 38)
                .rate(2)
                .dmg(3.8F)
                .spread(5F, 1F)
                .speed(5F)
                .range(64F)
                .feel(1.15F, 0.95F, 0.38F, 0.6F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Beetle" SMG — Verdant Choir */
    private static GunSpec g_escarabajo() {
        return new GunSpec("escarabajo", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(36, 38)
                .rate(2)
                .dmg(3F)
                .spread(3.4F, 1F)
                .speed(5F)
                .range(64F)
                .feel(1.15F, 0.95F, 0.38F, 0.6F)
                .color(0xB0FF60)
                .casings(false, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.POISON, 60, 0)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Raven" SMG — Hollow Court */
    private static GunSpec g_cuervo() {
        return new GunSpec("cuervo", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(32, 38)
                .rate(2)
                .dmg(3.6F)
                .spread(3.4F, 1F)
                .speed(5F)
                .range(64F)
                .feel(1.15F, 0.95F, 0.38F, 0.6F)
                .color(0x9060FF)
                .casings(true, 0xD8A040)
                .tracer(1F, 7)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.BLIND, 30, 0)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Hail" SMG — Frostline */
    private static GunSpec g_granizo() {
        return new GunSpec("granizo", GunSpec.Caliber.LIGHT, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(32, 38)
                .rate(2)
                .dmg(3F)
                .spread(3.4F, 1F)
                .speed(5F)
                .range(64F)
                .feel(1.15F, 0.95F, 0.38F, 0.6F)
                .color(0xC0F0FF)
                .casings(true, 0xD8A040)
                .tracer(1F, 5)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.SLOW, 40, 1)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Centurion" Assault Rifle — Iron Concord */
    private static GunSpec g_centurion() {
        return new GunSpec("centurion", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(3)
                .dmg(7F)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Falcon" Carbine — Aurora Syndicate */
    private static GunSpec g_halcon() {
        return new GunSpec("halcon", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(3)
                .dmg(6F)
                .spread(2.3F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Sirocco" Rifle — Dust Legion */
    private static GunSpec g_duna_rifle() {
        return new GunSpec("duna_rifle", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(3)
                .dmg(7.5F)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Scorpion" Bullpup — Black Ash */
    private static GunSpec g_bullpup() {
        return new GunSpec("bullpup", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(3)
                .dmg(7F)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Typhoon" Rifle — Ironclad Navy */
    private static GunSpec g_tifon() {
        return new GunSpec("tifon", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(3)
                .dmg(7F)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Quarry" Rifle — Mining Guild */
    private static GunSpec g_cantera() {
        return new GunSpec("cantera", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(4)
                .dmg(7.5F)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Shard" Rifle — Project Prometheus */
    private static GunSpec g_fragmento() {
        return new GunSpec("fragmento", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(3)
                .dmg(6F)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0x80F0FF)
                .casings(false, 0xD8A040)
                .splash(1.5F)
                .tracer(1F, 3)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Ember" Incendiary Rifle — Deepforge */
    private static GunSpec g_brasa() {
        return new GunSpec("brasa", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(3)
                .dmg(6.5F)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0xFF7030)
                .casings(true, 0xD8A040)
                .tracer(1F, 2)
                .ignite(3)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Echo" Burst Rifle — Tempest Order */
    private static GunSpec g_eco() {
        return new GunSpec("eco", GunSpec.Caliber.HEAVY, GunSpec.Fire.BURST, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(2)
                .dmg(8F)
                .burst(3)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Root" Rifle — Verdant Choir */
    private static GunSpec g_raiz() {
        return new GunSpec("raiz", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(3)
                .dmg(6.5F)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0x90FF60)
                .casings(true, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.ROOT, 30, 0)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Cadet" Carbine — Federal Works */
    private static GunSpec g_cadete() {
        return new GunSpec("cadete", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(28, 48)
                .rate(4)
                .dmg(8F)
                .spread(2F, 0.25F)
                .speed(6.5F)
                .range(120F)
                .feel(2.1F, 0.75F, 0.6F, 0.9F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Oak" Battle Rifle — Iron Concord */
    private static GunSpec g_roble() {
        return new GunSpec("roble", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(20, 52)
                .rate(4)
                .dmg(10F)
                .spread(1.6F, 0.15F)
                .speed(7F)
                .range(140F)
                .feel(3.2F, 0.8F, 0.8F, 1.2F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Watchtower" Battle Rifle — Ironclad Navy */
    private static GunSpec g_centinela_br() {
        return new GunSpec("centinela_br", GunSpec.Caliber.HEAVY, GunSpec.Fire.BURST, GunSpec.Kind.BULLET)
                .mag(20, 52)
                .rate(3)
                .dmg(10F)
                .burst(2)
                .spread(1.6F, 0.15F)
                .speed(7F)
                .range(140F)
                .feel(3.2F, 0.8F, 0.8F, 1.2F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Drop Hammer" Battle Rifle — Deepforge */
    private static GunSpec g_yunque_br() {
        return new GunSpec("yunque_br", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(20, 52)
                .rate(5)
                .dmg(12F)
                .spread(1.6F, 0.15F)
                .speed(7F)
                .range(140F)
                .feel(3.8F, 0.8F, 0.8F, 1.2F)
                .knock(0.4F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Automaton" Battle Rifle — Omega Directorate */
    private static GunSpec g_automata() {
        return new GunSpec("automata", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(20, 52)
                .rate(4)
                .dmg(9F)
                .spread(1.6F, 0.15F)
                .speed(7F)
                .range(140F)
                .feel(3.2F, 0.8F, 0.8F, 1.2F)
                .color(0xFF5050)
                .casings(true, 0xD8A040)
                .homing(0.12F)
                .allowNames("SCOPE,SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Heron" Marksman Rifle — Iron Concord */
    private static GunSpec g_garza() {
        return new GunSpec("garza", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(12, 50)
                .rate(6)
                .dmg(14F)
                .spread(0.8F, 0F)
                .speed(8F)
                .range(160F)
                .feel(4F, 0.6F, 0.9F, 1.4F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .head(2F)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,AUTO");
    }

    /** "Owl" Marksman Rifle — Hollow Court */
    private static GunSpec g_lechuza() {
        return new GunSpec("lechuza", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(12, 50)
                .rate(6)
                .dmg(15F)
                .spread(0.8F, 0F)
                .speed(8F)
                .range(160F)
                .feel(4F, 0.6F, 0.9F, 1.4F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.GLOW, 100, 0)
                .head(2F)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,AUTO");
    }

    /** "Mistral" Marksman Rifle — Tempest Order */
    private static GunSpec g_mistral() {
        return new GunSpec("mistral", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(12, 50)
                .rate(5)
                .dmg(14F)
                .spread(0.8F, 0F)
                .speed(8F)
                .range(160F)
                .feel(4F, 0.6F, 0.9F, 1.4F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .head(2F)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,AUTO");
    }

    /** "Scarp" Marksman Rifle — Dust Legion */
    private static GunSpec g_escarpa() {
        return new GunSpec("escarpa", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(12, 50)
                .rate(6)
                .dmg(15F)
                .spread(0.8F, 0F)
                .speed(8F)
                .range(160F)
                .feel(4F, 0.6F, 0.9F, 1.4F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .head(2F)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,AUTO");
    }

    /** "Crystal" Marksman Rifle — Project Prometheus */
    private static GunSpec g_cristal() {
        return new GunSpec("cristal", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(12, 50)
                .rate(6)
                .dmg(12F)
                .spread(0.8F, 0F)
                .speed(8F)
                .range(160F)
                .feel(4F, 0.6F, 0.9F, 1.4F)
                .color(0x80F0FF)
                .casings(false, 0xD8A040)
                .tracer(1F, 3)
                .head(2F)
                .homing(0.2F)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,AUTO");
    }

    /** "Corrosion" Marksman Rifle — Rustborn */
    private static GunSpec g_herrumbre() {
        return new GunSpec("herrumbre", GunSpec.Caliber.HEAVY, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(12, 50)
                .rate(6)
                .dmg(11F)
                .spread(0.8F, 0F)
                .speed(8F)
                .range(160F)
                .feel(4F, 0.6F, 0.9F, 1.4F)
                .color(0xB8FF40)
                .casings(true, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.POISON, 140, 1)
                .head(2F)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,AUTO");
    }

    /** "Needle" Sniper Rifle — Iron Concord */
    private static GunSpec g_aguja() {
        return new GunSpec("aguja", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(5, 60)
                .rate(24)
                .dmg(32F)
                .spread(1F, 0F)
                .speed(9F)
                .range(220F)
                .feel(8.5F, 1F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .pierce(1)
                .head(2.5F)
                .allowNames("SCOPE,SUPPRESSOR,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,LASER");
    }

    /** "Reaper" Anti-Materiel Rifle — Black Ash */
    private static GunSpec g_segador() {
        return new GunSpec("segador", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(4, 70)
                .rate(30)
                .dmg(40F)
                .spread(1F, 0F)
                .speed(9F)
                .range(220F)
                .feel(11F, 1F, 1.6F, 2.4F)
                .knock(0.8F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .pierce(3)
                .head(2.5F)
                .breaksGlass()
                .allowNames("SCOPE,SUPPRESSOR,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,LASER");
    }

    /** "White Wolf" Sniper Rifle — Frostline */
    private static GunSpec g_lobo() {
        return new GunSpec("lobo", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(5, 60)
                .rate(24)
                .dmg(30F)
                .spread(1F, 0F)
                .speed(9F)
                .range(220F)
                .feel(8.5F, 1F, 1.6F, 2.4F)
                .color(0xC0F0FF)
                .casings(true, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.FREEZE, 80, 2)
                .pierce(1)
                .head(2.5F)
                .allowNames("SCOPE,SUPPRESSOR,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,LASER");
    }

    /** "Seer" Sniper Rifle — Hollow Court */
    private static GunSpec g_oraculo_sn() {
        return new GunSpec("oraculo_sn", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(5, 60)
                .rate(24)
                .dmg(30F)
                .spread(1F, 0F)
                .speed(9F)
                .range(220F)
                .feel(8.5F, 1F, 1.6F, 2.4F)
                .color(0xB080FF)
                .casings(true, 0xD8A040)
                .tracer(1F, 7)
                .pierce(1)
                .head(2.5F)
                .homing(0.08F)
                .allowNames("SCOPE,SUPPRESSOR,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,LASER");
    }

    /** "Whale" Sniper Rifle — Ironclad Navy */
    private static GunSpec g_arpon_sn() {
        return new GunSpec("arpon_sn", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(5, 60)
                .rate(24)
                .dmg(34F)
                .spread(1F, 0F)
                .speed(9F)
                .range(220F)
                .feel(8.5F, 1F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .pierce(2)
                .head(2.5F)
                .allowNames("SCOPE,SUPPRESSOR,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,LASER");
    }

    /** "Grandpa" Bolt Rifle — Dust Legion */
    private static GunSpec g_cerrojo() {
        return new GunSpec("cerrojo", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(5, 60)
                .rate(18)
                .dmg(26F)
                .spread(0.7F, 0F)
                .speed(9F)
                .range(220F)
                .feel(8.5F, 1F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .pierce(1)
                .head(2.5F)
                .allowNames("SCOPE,SUPPRESSOR,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,LASER");
    }

    /** "Meteor" Sniper Rifle — Deepforge */
    private static GunSpec g_meteoro() {
        return new GunSpec("meteoro", GunSpec.Caliber.MAGNUM, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(5, 60)
                .rate(24)
                .dmg(28F)
                .spread(1F, 0F)
                .speed(9F)
                .range(220F)
                .feel(8.5F, 1F, 1.6F, 2.4F)
                .color(0xFF8040)
                .casings(true, 0xD8A040)
                .tracer(1.5F, 2)
                .pierce(1)
                .ignite(5)
                .head(2.5F)
                .allowNames("SCOPE,SUPPRESSOR,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM,LASER");
    }

    /** "Pack" Light Machine Gun — Iron Concord */
    private static GunSpec g_jauria() {
        return new GunSpec("jauria", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(90, 95)
                .rate(2)
                .dmg(6F)
                .spread(3F, 0.8F)
                .speed(6.5F)
                .range(120F)
                .feel(1.5F, 1.1F, 0.65F, 0.8F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM");
    }

    /** "Hailstorm" Machine Gun — Ironclad Navy */
    private static GunSpec g_tormenta_lmg() {
        return new GunSpec("tormenta_lmg", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(60, 95)
                .rate(2)
                .dmg(6.5F)
                .spread(3F, 0.8F)
                .speed(6.5F)
                .range(120F)
                .feel(1.5F, 1.1F, 0.65F, 0.8F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM");
    }

    /** "Mill" Machine Gun — Mining Guild */
    private static GunSpec g_molinillo() {
        return new GunSpec("molinillo", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(120, 110)
                .rate(2)
                .dmg(5.5F)
                .spread(3F, 0.8F)
                .speed(6.5F)
                .range(120F)
                .feel(1.5F, 1.1F, 0.65F, 0.8F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM");
    }

    /** "Ashfall" Machine Gun — Black Ash */
    private static GunSpec g_cenizal() {
        return new GunSpec("cenizal", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(90, 95)
                .rate(2)
                .dmg(5.5F)
                .spread(3F, 0.8F)
                .speed(6.5F)
                .range(120F)
                .feel(1.5F, 1.1F, 0.65F, 0.8F)
                .color(0xFF6030)
                .casings(true, 0xD8A040)
                .tracer(1F, 2)
                .ignite(3)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM");
    }

    /** "Thornswarm" Machine Gun — Verdant Choir */
    private static GunSpec g_coro_lmg() {
        return new GunSpec("coro_lmg", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(90, 95)
                .rate(2)
                .dmg(4.5F)
                .spread(3F, 0.8F)
                .speed(6.5F)
                .range(120F)
                .feel(1.5F, 1.1F, 0.65F, 0.8F)
                .color(0xB0FF60)
                .casings(false, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.POISON, 60, 0)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM");
    }

    /** "Legionary" Machine Gun — Dust Legion */
    private static GunSpec g_legionaria() {
        return new GunSpec("legionaria", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(100, 95)
                .rate(2)
                .dmg(6F)
                .spread(3F, 0.8F)
                .speed(6.5F)
                .range(120F)
                .feel(1.5F, 1.1F, 0.65F, 0.8F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .allowNames("SCOPE,SUPPRESSOR,LASER,STABILIZER,RICOCHET,SEEKER,OVERCLOCK,DRUM");
    }

    /** "Harvester" Minigun — Federal Works */
    private static GunSpec g_segadora() {
        return new GunSpec("segadora", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(200, 120)
                .rate(1)
                .dmg(4.2F)
                .spread(3.8F, 2.5F)
                .speed(6.5F)
                .range(100F)
                .feel(0.6F, 0.9F, 0.5F, 0.4F)
                .color(0xFFD890)
                .casings(true, 0xD8A040)
                .spinUp(24)
                .allowNames("SUPPRESSOR,STABILIZER,RICOCHET,OVERCLOCK,DRUM,LASER");
    }

    /** "Hurricane" Minigun — Tempest Order */
    private static GunSpec g_huracan() {
        return new GunSpec("huracan", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(200, 120)
                .rate(1)
                .dmg(3.8F)
                .spread(3.8F, 2.5F)
                .speed(6.5F)
                .range(100F)
                .feel(0.6F, 0.9F, 0.5F, 0.4F)
                .color(0xFFF080)
                .casings(true, 0xD8A040)
                .tracer(1F, 0)
                .spinUp(14)
                .allowNames("SUPPRESSOR,STABILIZER,RICOCHET,OVERCLOCK,DRUM,LASER");
    }

    /** "Inferno" Minigun — Deepforge */
    private static GunSpec g_infierno() {
        return new GunSpec("infierno", GunSpec.Caliber.HEAVY, GunSpec.Fire.AUTO, GunSpec.Kind.BULLET)
                .mag(200, 120)
                .rate(1)
                .dmg(4F)
                .spread(3.8F, 2.5F)
                .speed(6.5F)
                .range(100F)
                .feel(0.6F, 0.9F, 0.5F, 0.4F)
                .color(0xFF6020)
                .casings(true, 0xD8A040)
                .tracer(1F, 2)
                .spinUp(30)
                .ignite(2)
                .allowNames("SUPPRESSOR,STABILIZER,RICOCHET,OVERCLOCK,DRUM,LASER");
    }

    /** "Boarding" Shotgun — Ironclad Navy */
    private static GunSpec g_abordaje() {
        return new GunSpec("abordaje", GunSpec.Caliber.SHELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 60)
                .rate(15)
                .dmg(3.3F)
                .pellets(9)
                .spread(7.5F, 5F)
                .speed(3.8F)
                .range(28F)
                .feel(7.5F, 1.6F, 1.5F, 2.4F)
                .color(0xFFD890)
                .casings(true, 0xC03020)
                .breaksGlass()
                .allowNames("SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Badger" Auto Shotgun — Iron Concord */
    private static GunSpec g_tejon() {
        return new GunSpec("tejon", GunSpec.Caliber.SHELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(8, 60)
                .rate(6)
                .dmg(3.3F)
                .pellets(9)
                .spread(7.5F, 5F)
                .speed(3.8F)
                .range(28F)
                .feel(6F, 1.6F, 1.5F, 2.4F)
                .color(0xFFD890)
                .casings(true, 0xC03020)
                .breaksGlass()
                .allowNames("SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Street Sweeper" Shotgun — Rustborn */
    private static GunSpec g_barredora() {
        return new GunSpec("barredora", GunSpec.Caliber.SHELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(12, 80)
                .rate(8)
                .dmg(3.3F)
                .pellets(9)
                .spread(9F, 5F)
                .speed(3.8F)
                .range(28F)
                .feel(7.5F, 1.6F, 1.5F, 2.4F)
                .color(0xFFD890)
                .casings(true, 0xC03020)
                .breaksGlass()
                .allowNames("SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Mule" Slug Shotgun — Dust Legion */
    private static GunSpec g_posta() {
        return new GunSpec("posta", GunSpec.Caliber.SHELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 60)
                .rate(14)
                .dmg(20F)
                .pellets(1)
                .spread(1.2F, 0.2F)
                .speed(5F)
                .range(70F)
                .feel(7.5F, 1.6F, 1.5F, 2.4F)
                .color(0xFFD890)
                .casings(true, 0xC03020)
                .breaksGlass()
                .allowNames("SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Whiteout" Shotgun — Frostline */
    private static GunSpec g_escarcha_sg() {
        return new GunSpec("escarcha_sg", GunSpec.Caliber.SHELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 60)
                .rate(15)
                .dmg(3.3F)
                .pellets(9)
                .spread(7.5F, 5F)
                .speed(3.8F)
                .range(28F)
                .feel(7.5F, 1.6F, 1.5F, 2.4F)
                .color(0xC0F0FF)
                .casings(true, 0x80C0E0)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.FREEZE, 50, 1)
                .breaksGlass()
                .allowNames("SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Little Dragon" Shotgun — Deepforge */
    private static GunSpec g_dragoncito() {
        return new GunSpec("dragoncito", GunSpec.Caliber.SHELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 60)
                .rate(15)
                .dmg(3F)
                .pellets(9)
                .spread(7.5F, 5F)
                .speed(3.8F)
                .range(28F)
                .feel(7.5F, 1.6F, 1.5F, 2.4F)
                .color(0xFF7030)
                .casings(true, 0xC03020)
                .tracer(1F, 2)
                .ignite(4)
                .breaksGlass()
                .allowNames("SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Resonant" Energy Shotgun — Project Prometheus */
    private static GunSpec g_resonante() {
        return new GunSpec("resonante", GunSpec.Caliber.CELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(10, 60)
                .rate(15)
                .dmg(3.3F)
                .pellets(9)
                .spread(7.5F, 5F)
                .speed(3.8F)
                .range(28F)
                .feel(7.5F, 1.6F, 1.5F, 2.4F)
                .color(0x80F0FF)
                .casings(false, 0xC03020)
                .tracer(1F, 3)
                .breaksGlass()
                .allowNames("SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Dragonslayer" Shotgun — Hollow Court */
    private static GunSpec g_cazadragones() {
        return new GunSpec("cazadragones", GunSpec.Caliber.SHELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(6, 60)
                .rate(15)
                .dmg(3.3F)
                .pellets(9)
                .spread(7.5F, 5F)
                .speed(3.8F)
                .range(28F)
                .feel(7.5F, 1.6F, 1.5F, 2.4F)
                .color(0xB080FF)
                .casings(true, 0xC03020)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.WITHER, 40, 0)
                .breaksGlass()
                .allowNames("SUPPRESSOR,SPLITTER,RICOCHET,SEEKER,AUTO,DRUM,LASER,STABILIZER,OVERCLOCK");
    }

    /** "Twins" Double-Barrel — Dust Legion */
    private static GunSpec g_gemelas() {
        return new GunSpec("gemelas", GunSpec.Caliber.SHELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(2, 40)
                .rate(5)
                .dmg(3.4F)
                .pellets(12)
                .spread(9F, 7F)
                .speed(3.6F)
                .range(22F)
                .feel(10F, 2F, 2F, 3F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .breaksGlass()
                .allowNames("SPLITTER,RICOCHET,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Sawn-Off" Shotgun — Rustborn */
    private static GunSpec g_recortada() {
        return new GunSpec("recortada", GunSpec.Caliber.SHELL, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(2, 40)
                .rate(5)
                .dmg(3.6F)
                .pellets(12)
                .spread(12F, 7F)
                .speed(3.6F)
                .range(22F)
                .feel(12F, 2F, 2F, 3F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .breaksGlass()
                .allowNames("SPLITTER,RICOCHET,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Pocket Mortar" Grenade Launcher — Iron Concord */
    private static GunSpec g_mortero() {
        return new GunSpec("mortero", GunSpec.Caliber.GRENADE, GunSpec.Fire.SEMI, GunSpec.Kind.GRENADE)
                .mag(1, 50)
                .rate(16)
                .dmg(14F)
                .spread(1.5F, 0.5F)
                .speed(1.3F)
                .feel(6.5F, 1.5F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .splash(2.6F)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Grasshopper" Grenade Launcher — Mining Guild */
    private static GunSpec g_saltamontes() {
        return new GunSpec("saltamontes", GunSpec.Caliber.GRENADE, GunSpec.Fire.SEMI, GunSpec.Kind.GRENADE)
                .mag(1, 50)
                .rate(16)
                .dmg(14F)
                .spread(1.5F, 0.5F)
                .speed(1.1F)
                .feel(6.5F, 1.5F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .splash(2.6F)
                .bounces(4)
                .fuse(40)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Churner" Drum Launcher — Federal Works */
    private static GunSpec g_revolvedora() {
        return new GunSpec("revolvedora", GunSpec.Caliber.GRENADE, GunSpec.Fire.SEMI, GunSpec.Kind.GRENADE)
                .mag(6, 90)
                .rate(12)
                .dmg(14F)
                .spread(1.5F, 0.5F)
                .speed(1.3F)
                .feel(6.5F, 1.5F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .splash(2.6F)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Firecracker" Grenade Launcher — Rustborn */
    private static GunSpec g_petardo() {
        return new GunSpec("petardo", GunSpec.Caliber.GRENADE, GunSpec.Fire.SEMI, GunSpec.Kind.GRENADE)
                .mag(1, 50)
                .rate(16)
                .dmg(14F)
                .spread(1.5F, 0.5F)
                .speed(1.2F)
                .feel(6.5F, 1.5F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .splash(2.2F)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Frostbite" Grenade Launcher — Frostline */
    private static GunSpec g_escarcha_gl() {
        return new GunSpec("escarcha_gl", GunSpec.Caliber.GRENADE, GunSpec.Fire.SEMI, GunSpec.Kind.GRENADE)
                .mag(1, 50)
                .rate(16)
                .dmg(10F)
                .spread(1.5F, 0.5F)
                .speed(1.3F)
                .feel(6.5F, 1.5F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .splash(1.8F)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.FREEZE, 100, 2)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Bombardon" Grenade Launcher — Ironclad Navy */
    private static GunSpec g_cuchillo_gl() {
        return new GunSpec("cuchillo_gl", GunSpec.Caliber.GRENADE, GunSpec.Fire.SEMI, GunSpec.Kind.GRENADE)
                .mag(1, 50)
                .rate(16)
                .dmg(14F)
                .spread(1.5F, 0.5F)
                .speed(1.7F)
                .feel(6.5F, 1.5F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .splash(2.6F)
                .bounces(1)
                .fuse(50)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Huntress" Crossbow — Verdant Choir */
    private static GunSpec g_cazadora() {
        return new GunSpec("cazadora", GunSpec.Caliber.BOLT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(1, 36)
                .rate(10)
                .dmg(17F)
                .spread(0.8F, 0F)
                .speed(3.6F)
                .range(120F)
                .feel(2F, 0.4F, 0.6F, 1.2F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .gravity(0.025F)
                .tracer(0.7F, -1)
                .pierce(1)
                .head(2.2F)
                .allowNames("SCOPE,SPLITTER,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Chu-Ko" Repeating Crossbow — Dust Legion */
    private static GunSpec g_repetidora() {
        return new GunSpec("repetidora", GunSpec.Caliber.BOLT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(10, 50)
                .rate(5)
                .dmg(10F)
                .spread(2F, 0F)
                .speed(3.6F)
                .range(120F)
                .feel(2F, 0.4F, 0.6F, 1.2F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .gravity(0.025F)
                .tracer(0.7F, -1)
                .pierce(1)
                .head(2.2F)
                .allowNames("SCOPE,SPLITTER,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Silent" Assault Crossbow — Black Ash */
    private static GunSpec g_silenciosa() {
        return new GunSpec("silenciosa", GunSpec.Caliber.BOLT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(1, 36)
                .rate(10)
                .dmg(20F)
                .spread(0.8F, 0F)
                .speed(3.6F)
                .range(120F)
                .feel(2F, 0.4F, 0.6F, 1.2F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .gravity(0.025F)
                .tracer(0.7F, -1)
                .pierce(2)
                .head(2.2F)
                .allowNames("SCOPE,SPLITTER,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Bolt" Lightning Crossbow — Tempest Order */
    private static GunSpec g_tormenta_cb() {
        return new GunSpec("tormenta_cb", GunSpec.Caliber.BOLT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(1, 36)
                .rate(10)
                .dmg(14F)
                .spread(0.8F, 0F)
                .speed(3.6F)
                .range(120F)
                .feel(2F, 0.4F, 0.6F, 1.2F)
                .color(0xFFF080)
                .casings(false, 0xD8A040)
                .gravity(0.025F)
                .splash(2.2F)
                .tracer(0.7F, 0)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.SLOW, 40, 1)
                .pierce(1)
                .head(2.2F)
                .allowNames("SCOPE,SPLITTER,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Rampart" Arbalest — Iron Concord */
    private static GunSpec g_arbalesta() {
        return new GunSpec("arbalesta", GunSpec.Caliber.BOLT, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(1, 55)
                .rate(14)
                .dmg(24F)
                .spread(0.8F, 0F)
                .speed(3.6F)
                .range(120F)
                .feel(2F, 0.4F, 0.6F, 1.2F)
                .knock(0.9F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .gravity(0.025F)
                .tracer(0.7F, -1)
                .pierce(2)
                .head(2.2F)
                .allowNames("SCOPE,SPLITTER,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Whaler" Harpoon Gun — Ironclad Navy */
    private static GunSpec g_ballenera() {
        return new GunSpec("ballenera", GunSpec.Caliber.BOLT, GunSpec.Fire.SEMI, GunSpec.Kind.HARPOON)
                .mag(1, 40)
                .rate(14)
                .dmg(12F)
                .spread(0.6F, 0F)
                .speed(3.2F)
                .range(48F)
                .feel(3F, 0.6F, 0.9F, 1.6F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .gravity(0.02F)
                .tracer(0.9F, -1)
                .pull(1.2F)
                .allowNames("SCOPE,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Crane Hook" Harpoon — Federal Works */
    private static GunSpec g_gancho() {
        return new GunSpec("gancho", GunSpec.Caliber.BOLT, GunSpec.Fire.SEMI, GunSpec.Kind.HARPOON)
                .mag(1, 40)
                .rate(14)
                .dmg(8F)
                .spread(0.6F, 0F)
                .speed(3.2F)
                .range(48F)
                .feel(3F, 0.6F, 0.9F, 1.6F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .gravity(0.02F)
                .tracer(0.9F, -1)
                .pull(1.6F)
                .allowNames("SCOPE,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Fishhook" Harpoon — Rustborn */
    private static GunSpec g_anzuelo() {
        return new GunSpec("anzuelo", GunSpec.Caliber.BOLT, GunSpec.Fire.SEMI, GunSpec.Kind.HARPOON)
                .mag(1, 40)
                .rate(14)
                .dmg(14F)
                .spread(0.6F, 0F)
                .speed(3.2F)
                .range(48F)
                .feel(3F, 0.6F, 0.9F, 1.6F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .gravity(0.02F)
                .tracer(0.9F, -1)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.SLOW, 60, 2)
                .pull(1.4F)
                .allowNames("SCOPE,SEEKER,DRUM,LASER,STABILIZER");
    }

    /** "Sunbeam" Laser Pistol — Aurora Syndicate */
    private static GunSpec g_rayito() {
        return new GunSpec("rayito", GunSpec.Caliber.CELL, GunSpec.Fire.SEMI, GunSpec.Kind.LASER)
                .mag(20, 40)
                .rate(4)
                .dmg(6F)
                .spread(0.8F, 0.1F)
                .range(72F)
                .feel(0.5F, 0.3F, 0.25F, 0.35F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .allowNames("SCOPE,SPLITTER,RICOCHET,LASER,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Prism" Laser Rifle — Aurora Syndicate */
    private static GunSpec g_prisma_l() {
        return new GunSpec("prisma_l", GunSpec.Caliber.CELL, GunSpec.Fire.AUTO, GunSpec.Kind.LASER)
                .mag(40, 40)
                .rate(2)
                .dmg(4.5F)
                .spread(0.8F, 0.1F)
                .range(72F)
                .feel(0.5F, 0.3F, 0.25F, 0.35F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .allowNames("SCOPE,SPLITTER,RICOCHET,LASER,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Scalpel" Precision Laser — Project Prometheus */
    private static GunSpec g_bisturi() {
        return new GunSpec("bisturi", GunSpec.Caliber.CELL, GunSpec.Fire.SEMI, GunSpec.Kind.LASER)
                .mag(12, 40)
                .rate(8)
                .dmg(15F)
                .spread(0.8F, 0.1F)
                .range(110F)
                .feel(0.5F, 0.3F, 0.25F, 0.35F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .pierce(1)
                .allowNames("SCOPE,SPLITTER,RICOCHET,LASER,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Boreal" Burst Laser — Frostline */
    private static GunSpec g_aurora_l() {
        return new GunSpec("aurora_l", GunSpec.Caliber.CELL, GunSpec.Fire.BURST, GunSpec.Kind.LASER)
                .mag(30, 40)
                .rate(2)
                .dmg(5F)
                .burst(3)
                .spread(0.8F, 0.1F)
                .range(72F)
                .feel(0.5F, 0.3F, 0.25F, 0.35F)
                .color(0xB0F0FF)
                .casings(false, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.SLOW, 40, 1)
                .allowNames("SCOPE,SPLITTER,RICOCHET,LASER,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Firebrand" Laser — Deepforge */
    private static GunSpec g_tizon() {
        return new GunSpec("tizon", GunSpec.Caliber.CELL, GunSpec.Fire.AUTO, GunSpec.Kind.LASER)
                .mag(30, 40)
                .rate(3)
                .dmg(4F)
                .spread(0.8F, 0.1F)
                .range(72F)
                .feel(0.5F, 0.3F, 0.25F, 0.35F)
                .color(0xFF5020)
                .casings(false, 0xD8A040)
                .ignite(4)
                .allowNames("SCOPE,SPLITTER,RICOCHET,LASER,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Dazzler" Laser — Black Ash */
    private static GunSpec g_cegador() {
        return new GunSpec("cegador", GunSpec.Caliber.CELL, GunSpec.Fire.AUTO, GunSpec.Kind.LASER)
                .mag(30, 40)
                .rate(3)
                .dmg(3F)
                .spread(0.8F, 0.1F)
                .range(72F)
                .feel(0.5F, 0.3F, 0.25F, 0.35F)
                .color(0xFF60FF)
                .casings(false, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.BLIND, 60, 0)
                .allowNames("SCOPE,SPLITTER,RICOCHET,LASER,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Lookout" Designator — Omega Directorate */
    private static GunSpec g_vigia() {
        return new GunSpec("vigia", GunSpec.Caliber.CELL, GunSpec.Fire.AUTO, GunSpec.Kind.LASER)
                .mag(30, 40)
                .rate(3)
                .dmg(3.5F)
                .spread(0.8F, 0.1F)
                .range(72F)
                .feel(0.5F, 0.3F, 0.25F, 0.35F)
                .color(0xFF3030)
                .casings(false, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.GLOW, 200, 0)
                .allowNames("SCOPE,SPLITTER,RICOCHET,LASER,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Lightthorn" Bio-Laser — Verdant Choir */
    private static GunSpec g_espina_l() {
        return new GunSpec("espina_l", GunSpec.Caliber.CELL, GunSpec.Fire.AUTO, GunSpec.Kind.LASER)
                .mag(30, 40)
                .rate(3)
                .dmg(3.5F)
                .spread(0.8F, 0.1F)
                .range(72F)
                .feel(0.5F, 0.3F, 0.25F, 0.35F)
                .color(0xA0FF60)
                .casings(false, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.POISON, 60, 0)
                .allowNames("SCOPE,SPLITTER,RICOCHET,LASER,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Plasmite" Plasma Pistol — Aurora Syndicate */
    private static GunSpec g_plasmita() {
        return new GunSpec("plasmita", GunSpec.Caliber.CELL, GunSpec.Fire.SEMI, GunSpec.Kind.PLASMA)
                .mag(12, 44)
                .rate(6)
                .dmg(7F)
                .spread(1.2F, 0.3F)
                .speed(1.9F)
                .range(90F)
                .feel(2.4F, 0.6F, 0.8F, 1.2F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .splash(1.8F)
                .tracer(2F, 1)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,AUTO,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Stove" Plasma Rifle — Deepforge */
    private static GunSpec g_caldera_pl() {
        return new GunSpec("caldera_pl", GunSpec.Caliber.CELL, GunSpec.Fire.SEMI, GunSpec.Kind.PLASMA)
                .mag(16, 44)
                .rate(6)
                .dmg(9F)
                .spread(1.2F, 0.3F)
                .speed(1.9F)
                .range(90F)
                .feel(2.4F, 0.6F, 0.8F, 1.2F)
                .color(0xFF8030)
                .casings(false, 0xD8A040)
                .splash(2.4F)
                .tracer(2.6F, 1)
                .ignite(5)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,AUTO,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Nebula" Plasma Rifle — Project Prometheus */
    private static GunSpec g_nebulosa() {
        return new GunSpec("nebulosa", GunSpec.Caliber.CELL, GunSpec.Fire.AUTO, GunSpec.Kind.PLASMA)
                .mag(30, 44)
                .rate(4)
                .dmg(6F)
                .spread(1.2F, 0.3F)
                .speed(1.9F)
                .range(90F)
                .feel(2.4F, 0.6F, 0.8F, 1.2F)
                .color(0x60F0E0)
                .casings(false, 0xD8A040)
                .splash(1.6F)
                .tracer(2.6F, 1)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,AUTO,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Comet" Plasma Cannon — Tempest Order */
    private static GunSpec g_cometa() {
        return new GunSpec("cometa", GunSpec.Caliber.CELL, GunSpec.Fire.CHARGE, GunSpec.Kind.PLASMA)
                .mag(8, 44)
                .rate(6)
                .dmg(20F)
                .spread(1.2F, 0.3F)
                .speed(1.6F)
                .range(90F)
                .feel(5F, 0.6F, 0.8F, 1.2F)
                .charge(8, 30, 0)
                .color(0xFFF080)
                .casings(false, 0xD8A040)
                .splash(3.2F)
                .tracer(3.4F, 1)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,AUTO,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Will-o'-Wisp" Plasma Caster — Hollow Court */
    private static GunSpec g_fuego_fatuo() {
        return new GunSpec("fuego_fatuo", GunSpec.Caliber.CELL, GunSpec.Fire.SEMI, GunSpec.Kind.PLASMA)
                .mag(16, 44)
                .rate(6)
                .dmg(8F)
                .spread(1.2F, 0.3F)
                .speed(1.4F)
                .range(90F)
                .feel(2.4F, 0.6F, 0.8F, 1.2F)
                .color(0xB070FF)
                .casings(false, 0xD8A040)
                .splash(2.4F)
                .tracer(2.6F, 1)
                .homing(0.18F)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,AUTO,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Jellyfish" Plasma Rifle — Ironclad Navy */
    private static GunSpec g_medusa() {
        return new GunSpec("medusa", GunSpec.Caliber.CELL, GunSpec.Fire.SEMI, GunSpec.Kind.PLASMA)
                .mag(16, 44)
                .rate(6)
                .dmg(7F)
                .spread(1.2F, 0.3F)
                .speed(1.9F)
                .range(90F)
                .feel(2.4F, 0.6F, 0.8F, 1.2F)
                .color(0x60D0FF)
                .casings(false, 0xD8A040)
                .splash(2.4F)
                .tracer(2.6F, 1)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.SLOW, 60, 2)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,AUTO,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Bile" Plasma Rifle — Verdant Choir */
    private static GunSpec g_acido_pl() {
        return new GunSpec("acido_pl", GunSpec.Caliber.CELL, GunSpec.Fire.SEMI, GunSpec.Kind.PLASMA)
                .mag(16, 44)
                .rate(6)
                .dmg(7F)
                .spread(1.2F, 0.3F)
                .speed(1.9F)
                .range(90F)
                .feel(2.4F, 0.6F, 0.8F, 1.2F)
                .color(0xB8FF40)
                .casings(false, 0xD8A040)
                .splash(2.4F)
                .tracer(2.6F, 1)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.WEAKNESS, 120, 1)
                .allowNames("SCOPE,SPLITTER,RICOCHET,SEEKER,AUTO,STABILIZER,OVERCLOCK,DRUM");
    }

    /** "Blowtorch" Flamethrower — Federal Works */
    private static GunSpec g_soplete() {
        return new GunSpec("soplete", GunSpec.Caliber.FUEL, GunSpec.Fire.BEAM, GunSpec.Kind.FLAME)
                .mag(120, 50)
                .rate(1)
                .dmg(1.3F)
                .spread(1F, 0.2F)
                .range(8.5F)
                .angle(22F)
                .feel(0.12F, 0.2F, 0.16F, 0.12F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .allowNames("DRUM,STABILIZER");
    }

    /** "Icebox" Cryo Projector — Frostline */
    private static GunSpec g_nevera() {
        return new GunSpec("nevera", GunSpec.Caliber.FUEL, GunSpec.Fire.BEAM, GunSpec.Kind.FLAME)
                .mag(120, 50)
                .rate(1)
                .dmg(1.3F)
                .spread(1F, 0.2F)
                .range(8.5F)
                .angle(22F)
                .feel(0.12F, 0.2F, 0.16F, 0.12F)
                .color(0xB0F0FF)
                .casings(false, 0xD8A040)
                .allowNames("DRUM,STABILIZER");
    }

    /** "Corrosive" Sprayer — Rustborn */
    private static GunSpec g_corrosivo() {
        return new GunSpec("corrosivo", GunSpec.Caliber.FUEL, GunSpec.Fire.BEAM, GunSpec.Kind.FLAME)
                .mag(120, 50)
                .rate(1)
                .dmg(1.3F)
                .spread(1F, 0.2F)
                .range(8.5F)
                .angle(22F)
                .feel(0.12F, 0.2F, 0.16F, 0.12F)
                .color(0xB8FF40)
                .casings(false, 0xD8A040)
                .allowNames("DRUM,STABILIZER");
    }

    /** "Volcano" Heavy Flamethrower — Deepforge */
    private static GunSpec g_volcan() {
        return new GunSpec("volcan", GunSpec.Caliber.FUEL, GunSpec.Fire.BEAM, GunSpec.Kind.FLAME)
                .mag(160, 50)
                .rate(1)
                .dmg(1.6F)
                .spread(1F, 0.2F)
                .range(11F)
                .angle(26F)
                .feel(0.12F, 0.2F, 0.16F, 0.12F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .allowNames("DRUM,STABILIZER");
    }

    /** "Thanatos" Flamethrower — Hollow Court */
    private static GunSpec g_tanatos() {
        return new GunSpec("tanatos", GunSpec.Caliber.FUEL, GunSpec.Fire.BEAM, GunSpec.Kind.FLAME)
                .mag(120, 50)
                .rate(1)
                .dmg(1.5F)
                .spread(1F, 0.2F)
                .range(8.5F)
                .angle(22F)
                .feel(0.12F, 0.2F, 0.16F, 0.12F)
                .color(0xB070FF)
                .casings(false, 0xD8A040)
                .allowNames("DRUM,STABILIZER");
    }

    /** "Scream" Sonic Cannon — Tempest Order */
    private static GunSpec g_grito() {
        return new GunSpec("grito", GunSpec.Caliber.NONE, GunSpec.Fire.AUTO, GunSpec.Kind.SONIC)
                .mag(12, 30)
                .rate(10)
                .dmg(4F)
                .spread(1F, 0.2F)
                .range(11F)
                .angle(28F)
                .feel(2.5F, 0.4F, 1.1F, 1.6F)
                .heat(0.13F, 0.008F)
                .knock(2.2F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .allowNames("OVERCLOCK,STABILIZER");
    }

    /** "Trumpet" War Horn — Dust Legion */
    private static GunSpec g_trompeta() {
        return new GunSpec("trompeta", GunSpec.Caliber.NONE, GunSpec.Fire.AUTO, GunSpec.Kind.SONIC)
                .mag(12, 30)
                .rate(10)
                .dmg(3F)
                .spread(1F, 0.2F)
                .range(11F)
                .angle(28F)
                .feel(2.5F, 0.4F, 1.1F, 1.6F)
                .heat(0.13F, 0.008F)
                .knock(1.4F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.NAUSEA, 100, 0)
                .allowNames("OVERCLOCK,STABILIZER");
    }

    /** "Battering Ram" Sonic Hammer — Mining Guild */
    private static GunSpec g_martinete() {
        return new GunSpec("martinete", GunSpec.Caliber.NONE, GunSpec.Fire.AUTO, GunSpec.Kind.SONIC)
                .mag(12, 30)
                .rate(14)
                .dmg(6F)
                .spread(1F, 0.2F)
                .range(11F)
                .angle(28F)
                .feel(2.5F, 0.4F, 1.1F, 1.6F)
                .heat(0.18F, 0.008F)
                .knock(3.4F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .allowNames("OVERCLOCK,STABILIZER");
    }

    /** "Sparker" Coil Gun — Tempest Order */
    private static GunSpec g_chispero() {
        return new GunSpec("chispero", GunSpec.Caliber.NONE, GunSpec.Fire.AUTO, GunSpec.Kind.TESLA)
                .mag(12, 30)
                .rate(6)
                .dmg(5F)
                .spread(1F, 0.2F)
                .range(14F)
                .feel(1F, 1F, 0.7F, 0.8F)
                .heat(0.1F, 0.007F)
                .jumps(5)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .allowNames("SPLITTER,OVERCLOCK,STABILIZER");
    }

    /** "Faraday" Arc Cannon — Project Prometheus */
    private static GunSpec g_faraday() {
        return new GunSpec("faraday", GunSpec.Caliber.NONE, GunSpec.Fire.AUTO, GunSpec.Kind.TESLA)
                .mag(12, 30)
                .rate(12)
                .dmg(13F)
                .spread(1F, 0.2F)
                .range(20F)
                .feel(1F, 1F, 0.7F, 0.8F)
                .heat(0.16F, 0.007F)
                .jumps(1)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.ROOT, 30, 0)
                .allowNames("SPLITTER,OVERCLOCK,STABILIZER");
    }

    /** "Nailer" Rail Rifle — Federal Works */
    private static GunSpec g_clavadora() {
        return new GunSpec("clavadora", GunSpec.Caliber.CELL, GunSpec.Fire.CHARGE, GunSpec.Kind.RAIL)
                .mag(8, 46)
                .rate(10)
                .dmg(28F)
                .spread(0.8F, 0F)
                .range(110F)
                .feel(6F, 0.4F, 1.2F, 2F)
                .charge(6, 26, 0)
                .knock(1.2F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .allowNames("SCOPE,RICOCHET,SPLITTER,STABILIZER,OVERCLOCK");
    }

    /** "Icicle" Rail Rifle — Frostline */
    private static GunSpec g_aguja_r() {
        return new GunSpec("aguja_r", GunSpec.Caliber.CELL, GunSpec.Fire.CHARGE, GunSpec.Kind.RAIL)
                .mag(8, 46)
                .rate(10)
                .dmg(24F)
                .spread(0.8F, 0F)
                .range(110F)
                .feel(6F, 0.4F, 1.2F, 2F)
                .charge(6, 26, 0)
                .knock(1.2F)
                .color(0xB0F0FF)
                .casings(false, 0xD8A040)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.FREEZE, 60, 2)
                .allowNames("SCOPE,RICOCHET,SPLITTER,STABILIZER,OVERCLOCK");
    }

    /** ⚠ REAPER · Blood Rifle — Hollow Court */
    private static GunSpec g_parca() {
        return new GunSpec("parca", GunSpec.Caliber.NONE, GunSpec.Fire.SEMI, GunSpec.Kind.BULLET)
                .mag(5, 60)
                .rate(16)
                .dmg(38F)
                .spread(1F, 0F)
                .speed(9F)
                .range(220F)
                .feel(8.5F, 1F, 1.6F, 2.4F)
                .color(0xC02030)
                .casings(false, 0xD8A040)
                .tracer(1.6F, 7)
                .fx(com.blockwars.mecha.WeaponSpec.Fx.WITHER, 60, 1)
                .pierce(4)
                .bloodPrice(3F)
                .head(2.5F)
                .dangerous()
                .allowNames("SCOPE,STABILIZER");
    }

    /** ⚠ DWARF STAR · Stellar Cannon — Omega Directorate */
    private static GunSpec g_enana() {
        return new GunSpec("enana", GunSpec.Caliber.CELL, GunSpec.Fire.CHARGE, GunSpec.Kind.PLASMA)
                .mag(6, 70)
                .rate(6)
                .dmg(24F)
                .spread(1.2F, 0.3F)
                .speed(1.3F)
                .range(90F)
                .feel(7F, 0.6F, 2F, 1.2F)
                .charge(10, 30, 0)
                .color(0xFFD040)
                .casings(false, 0xD8A040)
                .splash(4.5F)
                .tracer(4F, 2)
                .ignite(8)
                .misfire(0.07F)
                .dangerous()
                .allowNames("STABILIZER");
    }

    /** ⚠ GREY SWARM · Nanite Launcher — Omega Directorate */
    private static GunSpec g_gris() {
        return new GunSpec("gris", GunSpec.Caliber.NANO, GunSpec.Fire.SEMI, GunSpec.Kind.NANITE)
                .mag(3, 70)
                .rate(20)
                .dmg(0F)
                .spread(1.5F, 0.5F)
                .speed(1.2F)
                .feel(6.5F, 1.5F, 1.6F, 2.4F)
                .color(0xFFD890)
                .casings(false, 0xD8A040)
                .splash(2.6F)
                .dangerous();
    }

    public static final List<GunSpec> ALL = List.of(
            g_chispa(),
            g_oficial(),
            g_colibri(),
            g_zorro(),
            g_farolillo(),
            g_escarcha(),
            g_avispon2(),
            g_veneno(),
            g_tabano(),
            g_grillo(),
            g_relampago(),
            g_toro(),
            g_magistrado(),
            g_perforadora(),
            g_justiciero(),
            g_cazador(),
            g_chato(),
            g_trueno(),
            g_campanero(),
            g_lunar(),
            g_zumbido(),
            g_lince(),
            g_tamborcito(),
            g_susurro(),
            g_mosca(),
            g_trituradora_smg(),
            g_escarabajo(),
            g_cuervo(),
            g_granizo(),
            g_centurion(),
            g_halcon(),
            g_duna_rifle(),
            g_bullpup(),
            g_tifon(),
            g_cantera(),
            g_fragmento(),
            g_brasa(),
            g_eco(),
            g_raiz(),
            g_cadete(),
            g_roble(),
            g_centinela_br(),
            g_yunque_br(),
            g_automata(),
            g_garza(),
            g_lechuza(),
            g_mistral(),
            g_escarpa(),
            g_cristal(),
            g_herrumbre(),
            g_aguja(),
            g_segador(),
            g_lobo(),
            g_oraculo_sn(),
            g_arpon_sn(),
            g_cerrojo(),
            g_meteoro(),
            g_jauria(),
            g_tormenta_lmg(),
            g_molinillo(),
            g_cenizal(),
            g_coro_lmg(),
            g_legionaria(),
            g_segadora(),
            g_huracan(),
            g_infierno(),
            g_abordaje(),
            g_tejon(),
            g_barredora(),
            g_posta(),
            g_escarcha_sg(),
            g_dragoncito(),
            g_resonante(),
            g_cazadragones(),
            g_gemelas(),
            g_recortada(),
            g_mortero(),
            g_saltamontes(),
            g_revolvedora(),
            g_petardo(),
            g_escarcha_gl(),
            g_cuchillo_gl(),
            g_cazadora(),
            g_repetidora(),
            g_silenciosa(),
            g_tormenta_cb(),
            g_arbalesta(),
            g_ballenera(),
            g_gancho(),
            g_anzuelo(),
            g_rayito(),
            g_prisma_l(),
            g_bisturi(),
            g_aurora_l(),
            g_tizon(),
            g_cegador(),
            g_vigia(),
            g_espina_l(),
            g_plasmita(),
            g_caldera_pl(),
            g_nebulosa(),
            g_cometa(),
            g_fuego_fatuo(),
            g_medusa(),
            g_acido_pl(),
            g_soplete(),
            g_nevera(),
            g_corrosivo(),
            g_volcan(),
            g_tanatos(),
            g_grito(),
            g_trompeta(),
            g_martinete(),
            g_chispero(),
            g_faraday(),
            g_clavadora(),
            g_aguja_r(),
            g_parca(),
            g_enana(),
            g_gris());
}
