package com.blockwars.gun;

import org.jetbrains.annotations.Nullable;

/** Weapon modules. Each one changes how a gun behaves, not just its numbers. */
public enum Attachment {
    SCOPE("att_mira"),         // 4x zoom while aiming, perfect accuracy, +25% damage when aiming
    SUPPRESSOR("att_supresor"),// silent, no flash, no tracer — 10% less damage
    SPLITTER("att_divisor"),   // every shot splits into three (beams fork into three)
    RICOCHET("att_rebote"),    // projectiles bounce off walls; beams reflect
    SEEKER("att_buscador"),    // shots curve toward whatever is under your crosshair
    AUTO("att_kit_auto"),      // semi-auto becomes full-auto; automatic weapons fire 40% faster
    DRUM("att_tambor");        // double magazine (3 rockets), 50% slower reload

    public final String itemId;

    Attachment(String itemId) {
        this.itemId = itemId;
    }

    /** 1..7 for the model override predicate; 0 = none. */
    public int index() {
        return this.ordinal() + 1;
    }

    @Nullable
    public static Attachment byName(String name) {
        for (Attachment a : values()) if (a.name().equals(name)) return a;
        return null;
    }
}
