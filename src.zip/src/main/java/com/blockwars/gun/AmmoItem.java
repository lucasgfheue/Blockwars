package com.blockwars.gun;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

public class AmmoItem extends Item {
    public final AmmoType type;

    public AmmoItem(Properties props, AmmoType type) {
        super(props);
        this.type = type;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.blockwars." + this.type.itemId + ".desc").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("caliber.blockwars." + this.type.caliber.name().toLowerCase()).withStyle(ChatFormatting.DARK_AQUA));
    }
}
