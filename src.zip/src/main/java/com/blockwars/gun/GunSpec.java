package com.blockwars.gun;

import java.util.EnumSet;
import java.util.Set;

/** Stats of one hand-held weapon. The ten weapons are defined in {@link Guns}. */
public final class GunSpec {
    public enum Caliber { LIGHT, HEAVY, SHELL, CELL, FUEL, ROCKET, CORE, NONE, MAGNUM, BOLT, GRENADE, NANO }
    public enum Fire { SEMI, AUTO, BURST, CHARGE, BEAM }
    public enum Kind { BULLET, RAIL, FLAME, TESLA, ROCKET, SINGULARITY, FUSION, GRENADE, PLASMA, HARPOON, LASER, SONIC, NANITE }

    public final String id;
    public final Caliber caliber;
    public final Fire fire;
    public final Kind kind;
    public int mag = 12, rate = 4, reload = 30, pellets = 1, burst = 3, chargeFull = 20, chargeMin = 4, overcharge = 0, jumps = 4;
    public float damage = 5, spread = 1, adsSpread = 0.2F, speed = 5, range = 64, angle = 20;
    public float recoil = 2, recoilYaw = 0.5F, shake = 0.5F, kick = 1;
    public float heatPerShot = 0, heatDecay = 0.01F;
    public float knock = 0;
    public int color = 0xFFD27A;
    public boolean dangerous;
    public boolean breaksGlass;
    public boolean modeToggle;     // G switches burst <-> auto
    public boolean casings = true; // ejects brass
    public int casingColor = 0xD8A040;
    public final Set<Attachment> allowed = EnumSet.noneOf(Attachment.class);
    public int loreLines = 2;
    // ---- extended behaviour (4.0)
    public float gravity = 0;          // bullet drop per tick
    public float splash = 0;           // area damage radius on impact
    public float tracerWidth = 1.0F;   // tracer / plasma bolt size
    public int trail = -1;             // WeaponSpec.PType ordinal for a particle trail, -1 = none
    public com.blockwars.mecha.WeaponSpec.Fx fx = com.blockwars.mecha.WeaponSpec.Fx.NONE;
    public int fxTime = 60, fxAmp = 0;
    public int pierce = 0;             // extra entities a shot passes through
    public int bounces = 0;            // grenades and ricochets
    public int fuse = 0;               // grenade fuse in ticks (0 = impact)
    public int spinUp = 0;             // ticks the barrels must spin before firing
    public float bloodPrice = 0;       // health the wielder pays per shot
    public float misfire = 0;          // chance a shot detonates in the barrel
    public float headMul = 1.6F;
    public float homing = 0;           // built-in seeking strength
    public float pull = 0;             // harpoons drag the target toward you
    public int family = 0;             // model/sound family (cosmetic)
    public int ignite = 0;             // seconds of fire on hit

    public GunSpec(String id, Caliber caliber, Fire fire, Kind kind) {
        this.id = id;
        this.caliber = caliber;
        this.fire = fire;
        this.kind = kind;
    }

    public GunSpec mag(int mag, int reload) { this.mag = mag; this.reload = reload; return this; }
    public GunSpec rate(int ticks) { this.rate = ticks; return this; }
    public GunSpec dmg(float d) { this.damage = d; return this; }
    public GunSpec pellets(int n) { this.pellets = n; return this; }
    public GunSpec burst(int n) { this.burst = n; return this; }
    public GunSpec spread(float hip, float ads) { this.spread = hip; this.adsSpread = ads; return this; }
    public GunSpec speed(float s) { this.speed = s; return this; }
    public GunSpec range(float r) { this.range = r; return this; }
    public GunSpec angle(float a) { this.angle = a; return this; }
    public GunSpec feel(float recoil, float yaw, float shake, float kick) { this.recoil = recoil; this.recoilYaw = yaw; this.shake = shake; this.kick = kick; return this; }
    public GunSpec heat(float perShot, float decay) { this.heatPerShot = perShot; this.heatDecay = decay; return this; }
    public GunSpec charge(int min, int full, int over) { this.chargeMin = min; this.chargeFull = full; this.overcharge = over; return this; }
    public GunSpec knock(float k) { this.knock = k; return this; }
    public GunSpec jumps(int j) { this.jumps = j; return this; }
    public GunSpec color(int c) { this.color = c; return this; }
    public GunSpec casings(boolean on, int color) { this.casings = on; this.casingColor = color; return this; }
    public GunSpec dangerous() { this.dangerous = true; return this; }
    public GunSpec breaksGlass() { this.breaksGlass = true; return this; }
    public GunSpec modeToggle() { this.modeToggle = true; return this; }
    public GunSpec lore(int n) { this.loreLines = n; return this; }
    public GunSpec allow(Attachment... a) { for (Attachment x : a) this.allowed.add(x); return this; }
    public GunSpec gravity(float g) { this.gravity = g; return this; }
    public GunSpec splash(float r) { this.splash = r; return this; }
    public GunSpec tracer(float width, int trail) { this.tracerWidth = width; this.trail = trail; return this; }
    public GunSpec fx(com.blockwars.mecha.WeaponSpec.Fx fx, int time, int amp) { this.fx = fx; this.fxTime = time; this.fxAmp = amp; return this; }
    public GunSpec pierce(int n) { this.pierce = n; return this; }
    public GunSpec bounces(int n) { this.bounces = n; return this; }
    public GunSpec fuse(int t) { this.fuse = t; return this; }
    public GunSpec spinUp(int t) { this.spinUp = t; return this; }
    public GunSpec bloodPrice(float hp) { this.bloodPrice = hp; return this; }
    public GunSpec misfire(float p) { this.misfire = p; return this; }
    public GunSpec head(float m) { this.headMul = m; return this; }
    public GunSpec homing(float h) { this.homing = h; return this; }
    public GunSpec pull(float p) { this.pull = p; return this; }
    public GunSpec family(int f) { this.family = f; return this; }
    public GunSpec ignite(int seconds) { this.ignite = seconds; return this; }
    public GunSpec allowNames(String csv) {
        for (String n : csv.split(",")) {
            Attachment a = Attachment.byName(n.trim());
            if (a != null) this.allowed.add(a);
        }
        return this;
    }

    public boolean usesHeat() { return this.heatPerShot > 0; }
    public boolean usesAmmo() { return this.caliber != Caliber.NONE; }

    /** Fire mode actually in use, after the G toggle and the auto-conversion kit. */
    public Fire effectiveFire(int mode, Attachment att) {
        if (this.fire == Fire.SEMI && att == Attachment.AUTO) return Fire.AUTO;
        if (this.modeToggle && mode == 1) return Fire.AUTO;
        return this.fire;
    }

    public int effectiveRate(Attachment att) {
        if (att == Attachment.AUTO && this.fire != Fire.SEMI) return Math.max(1, Math.round(this.rate * 0.6F));
        if (att == Attachment.AUTO && this.fire == Fire.SEMI) return Math.max(2, this.rate);
        if (att == Attachment.OVERCLOCK) return Math.max(1, Math.round(this.rate * 0.65F));
        return this.rate;
    }

    /** Recoil multiplier from attachments. */
    public float recoilMul(Attachment att) {
        return att == Attachment.STABILIZER ? 0.5F : att == Attachment.OVERCLOCK ? 1.2F : 1.0F;
    }

    /** Spread multiplier from attachments (hip fire). */
    public float spreadMul(Attachment att, boolean aiming) {
        if (att == Attachment.LASER && !aiming) return 0.35F;
        if (att == Attachment.STABILIZER) return 0.7F;
        return 1.0F;
    }

    public int effectiveMag(Attachment att) {
        return att == Attachment.DRUM ? (this.caliber == Caliber.ROCKET ? 3 : this.mag * 2) : this.mag;
    }

    public int effectiveReload(Attachment att) {
        return att == Attachment.DRUM ? Math.round(this.reload * 1.5F) : this.reload;
    }
}
