package com.blockwars.gun;

import java.util.EnumSet;
import java.util.Set;

/** Stats of one hand-held weapon. The ten weapons are defined in {@link Guns}. */
public final class GunSpec {
    public enum Caliber { LIGHT, HEAVY, SHELL, CELL, FUEL, ROCKET, CORE, NONE }
    public enum Fire { SEMI, AUTO, BURST, CHARGE, BEAM }
    public enum Kind { BULLET, RAIL, FLAME, TESLA, ROCKET, SINGULARITY, FUSION }

    public final String id;
    public final Caliber caliber;
    public final Fire fire;
    public final Kind kind;
    public int mag = 12, rate = 4, reload = 30, pellets = 1, burst = 3, chargeFull = 20, chargeMin = 4, overcharge = 0, jumps = 4;
    public float damage = 5, spread = 1, adsSpread = 0.2F, speed = 5, range = 64, angle = 20;
    public float recoil = 2, recoilYaw = 0.5F, shake = 0.5F, kick = 1;
    public float heatPerShot = 0, heatDecay = 0.01F;
    public float knock = 0;
    public int color = 0xFFD27A;
    public boolean dangerous;
    public boolean breaksGlass;
    public boolean modeToggle;     // G switches burst <-> auto
    public boolean casings = true; // ejects brass
    public int casingColor = 0xD8A040;
    public final Set<Attachment> allowed = EnumSet.noneOf(Attachment.class);
    public int loreLines = 2;

    public GunSpec(String id, Caliber caliber, Fire fire, Kind kind) {
        this.id = id;
        this.caliber = caliber;
        this.fire = fire;
        this.kind = kind;
    }

    public GunSpec mag(int mag, int reload) { this.mag = mag; this.reload = reload; return this; }
    public GunSpec rate(int ticks) { this.rate = ticks; return this; }
    public GunSpec dmg(float d) { this.damage = d; return this; }
    public GunSpec pellets(int n) { this.pellets = n; return this; }
    public GunSpec burst(int n) { this.burst = n; return this; }
    public GunSpec spread(float hip, float ads) { this.spread = hip; this.adsSpread = ads; return this; }
    public GunSpec speed(float s) { this.speed = s; return this; }
    public GunSpec range(float r) { this.range = r; return this; }
    public GunSpec angle(float a) { this.angle = a; return this; }
    public GunSpec feel(float recoil, float yaw, float shake, float kick) { this.recoil = recoil; this.recoilYaw = yaw; this.shake = shake; this.kick = kick; return this; }
    public GunSpec heat(float perShot, float decay) { this.heatPerShot = perShot; this.heatDecay = decay; return this; }
    public GunSpec charge(int min, int full, int over) { this.chargeMin = min; this.chargeFull = full; this.overcharge = over; return this; }
    public GunSpec knock(float k) { this.knock = k; return this; }
    public GunSpec jumps(int j) { this.jumps = j; return this; }
    public GunSpec color(int c) { this.color = c; return this; }
    public GunSpec casings(boolean on, int color) { this.casings = on; this.casingColor = color; return this; }
    public GunSpec dangerous() { this.dangerous = true; return this; }
    public GunSpec breaksGlass() { this.breaksGlass = true; return this; }
    public GunSpec modeToggle() { this.modeToggle = true; return this; }
    public GunSpec lore(int n) { this.loreLines = n; return this; }
    public GunSpec allow(Attachment... a) { for (Attachment x : a) this.allowed.add(x); return this; }

    public boolean usesHeat() { return this.heatPerShot > 0; }
    public boolean usesAmmo() { return this.caliber != Caliber.NONE; }

    /** Fire mode actually in use, after the G toggle and the auto-conversion kit. */
    public Fire effectiveFire(int mode, Attachment att) {
        if (this.fire == Fire.SEMI && att == Attachment.AUTO) return Fire.AUTO;
        if (this.modeToggle && mode == 1) return Fire.AUTO;
        return this.fire;
    }

    public int effectiveRate(Attachment att) {
        if (att == Attachment.AUTO && this.fire != Fire.SEMI) return Math.max(1, Math.round(this.rate * 0.6F));
        if (att == Attachment.AUTO && this.fire == Fire.SEMI) return Math.max(2, this.rate);
        return this.rate;
    }

    public int effectiveMag(Attachment att) {
        return att == Attachment.DRUM ? (this.caliber == Caliber.ROCKET ? 3 : this.mag * 2) : this.mag;
    }

    public int effectiveReload(Attachment att) {
        return att == Attachment.DRUM ? Math.round(this.reload * 1.5F) : this.reload;
    }
}
