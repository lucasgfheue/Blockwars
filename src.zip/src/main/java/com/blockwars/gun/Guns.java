package com.blockwars.gun;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.blockwars.gun.Attachment.*;
import static com.blockwars.gun.GunSpec.Caliber;
import static com.blockwars.gun.GunSpec.Fire;
import static com.blockwars.gun.GunSpec.Kind;

/** The ten hand-held weapons of BlockWars. */
public final class Guns {
    private Guns() {}

    /** P-9 "Pulga": the Salvagers' sidearm, built from a nail gun. */
    public static final GunSpec PULGA = new GunSpec("pulga", Caliber.LIGHT, Fire.SEMI, Kind.BULLET)
            .mag(12, 28).rate(4).dmg(6).spread(1.4F, 0.15F).speed(5.0F).range(250)
            .feel(3.2F, 0.7F, 0.55F, 1.0F).color(0xFFD27A).allow(Attachment.values());

    /** SMG "Avispa": Iron Concord tunnel-fighting submachine gun. */
    public static final GunSpec AVISPA = new GunSpec("avispa", Caliber.LIGHT, Fire.AUTO, Kind.BULLET)
            .mag(32, 40).rate(2).dmg(3.5F).spread(3.6F, 1.1F).speed(5.0F).range(250)
            .feel(1.15F, 0.95F, 0.38F, 0.6F).color(0xFFE08A).allow(Attachment.values());

    /** M7 "Concordia": battle rifle, 3-round burst or full-auto (G). */
    public static final GunSpec M7 = new GunSpec("m7", Caliber.HEAVY, Fire.BURST, Kind.BULLET)
            .mag(24, 50).rate(3).burst(3).dmg(8).spread(1.8F, 0.2F).speed(6.5F).range(250)
            .feel(2.3F, 0.75F, 0.65F, 0.95F).color(0xFFD890).modeToggle().allow(Attachment.values());

    /** "Rompepuertas": breaching pump shotgun. Shatters glass. */
    public static final GunSpec ROMPEPUERTAS = new GunSpec("rompepuertas", Caliber.SHELL, Fire.SEMI, Kind.BULLET)
            .mag(6, 60).rate(16).pellets(9).dmg(3.4F).spread(7.5F, 5.0F).speed(3.8F).range(80)
            .feel(7.5F, 1.6F, 1.5F, 2.4F).color(0xFFC070).casings(true, 0xC03020).breaksGlass()
            .allow(SUPPRESSOR, SPLITTER, RICOCHET, SEEKER, AUTO, DRUM, LASER, STABILIZER, OVERCLOCK);

    /** "Lanza de Gauss": charge-up coil rifle. Hold to charge, release to fire. */
    public static final GunSpec GAUSS = new GunSpec("gauss", Caliber.CELL, Fire.CHARGE, Kind.RAIL)
            .mag(6, 45).rate(10).dmg(34).spread(0.8F, 0.0F).range(250).charge(6, 30, 0)
            .feel(6.5F, 0.4F, 1.3F, 2.2F).color(0x60D8FF).casings(false, 0).knock(1.6F).lore(3)
            .allow(SCOPE, RICOCHET, SPLITTER, STABILIZER, OVERCLOCK);

    /** "Aliento de Fragua": Red Foundry flamethrower. */
    public static final GunSpec FRAGUA = new GunSpec("fragua", Caliber.FUEL, Fire.BEAM, Kind.FLAME)
            .mag(120, 50).rate(1).dmg(1.3F).range(24).angle(22).spread(0, 0)
            .feel(0.12F, 0.2F, 0.16F, 0.12F).color(0xFF7A20).casings(false, 0).allow(DRUM);

    /** "Arco de Prometeo": tesla coil. No ammo — it overheats. */
    public static final GunSpec TESLA = new GunSpec("tesla", Caliber.NONE, Fire.AUTO, Kind.TESLA)
            .rate(6).dmg(7).range(64).jumps(4).heat(0.11F, 0.007F)
            .feel(1.0F, 1.2F, 0.75F, 0.8F).color(0x9FD8FF).casings(false, 0).allow(SPLITTER, OVERCLOCK);

    /** "Obús de Mano": shoulder-fired rocket launcher. */
    public static final GunSpec OBUS = new GunSpec("obus_mano", Caliber.ROCKET, Fire.SEMI, Kind.ROCKET)
            .mag(1, 55).rate(20).dmg(12).speed(1.7F).spread(1.0F, 0.2F).range(250)
            .feel(9.5F, 1.8F, 2.3F, 3.2F).color(0xFFA040).casings(false, 0).allow(SEEKER, DRUM, SCOPE, LASER);

    /** ⚠ "UMBRAL": pocket singularity projector. */
    public static final GunSpec UMBRAL = new GunSpec("umbral", Caliber.CORE, Fire.CHARGE, Kind.SINGULARITY)
            .mag(1, 80).rate(30).dmg(0).speed(2.4F).charge(20, 30, 70)
            .feel(8.0F, 2.0F, 2.6F, 3.0F).color(0xA060FF).casings(false, 0).dangerous().lore(4);

    /** ⚠ "SOLARIS": hand-held fusion lance. */
    public static final GunSpec SOLARIS = new GunSpec("solaris", Caliber.CELL, Fire.BEAM, Kind.FUSION)
            .mag(140, 60).rate(1).dmg(2.6F).range(250).heat(0.0115F, 0.004F)
            .feel(0.25F, 0.3F, 0.42F, 0.3F).color(0xFFD040).casings(false, 0).dangerous().lore(4);

    /** The original ten (3.1). */
    public static final List<GunSpec> CORE = List.of(PULGA, AVISPA, M7, ROMPEPUERTAS, GAUSS, FRAGUA, TESLA, OBUS, UMBRAL, SOLARIS);
    /** Every weapon of this system: the original ten (the 4.x armory was replaced by the 5.0 Arsenal, see com.blockwars.arsenal). */
    public static final List<GunSpec> ALL = CORE;
    public static final Map<String, GunSpec> BY_ID = new LinkedHashMap<>();

    static {
        for (GunSpec g : ALL) BY_ID.put(g.id, g);
    }
}
