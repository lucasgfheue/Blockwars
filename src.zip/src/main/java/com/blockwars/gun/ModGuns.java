package com.blockwars.gun;

import com.blockwars.ModItems;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;

/** Item registration for weapons, ammunition and attachments. */
public final class ModGuns {
    private ModGuns() {}

    public static final Map<String, DeferredItem<GunItem>> GUNS = new LinkedHashMap<>();
    public static final Map<AmmoType, DeferredItem<AmmoItem>> AMMO = new EnumMap<>(AmmoType.class);
    public static final Map<Attachment, DeferredItem<AttachmentItem>> ATTACHMENTS = new EnumMap<>(Attachment.class);

    public static final DeferredItem<Item> EMPTY_CELL = ModItems.ITEMS.register("ammo_celda_vacia",
            () -> new Item(new Item.Properties().stacksTo(16)));

    static {
        for (GunSpec spec : Guns.ALL) {
            GUNS.put(spec.id, ModItems.ITEMS.register(spec.id, () -> new GunItem(
                    new Item.Properties().stacksTo(1).rarity(spec.dangerous ? Rarity.EPIC : Rarity.UNCOMMON), spec)));
        }
        for (AmmoType a : AmmoType.values()) {
            int stack = a.perMag ? 16 : 64;
            Rarity r = a == AmmoType.CORE ? Rarity.EPIC : (a.special == AmmoType.Special.NONE ? Rarity.COMMON : Rarity.UNCOMMON);
            AMMO.put(a, ModItems.ITEMS.register(a.itemId, () -> new AmmoItem(new Item.Properties().stacksTo(stack).rarity(r), a)));
        }
        for (Attachment a : Attachment.values()) {
            ATTACHMENTS.put(a, ModItems.ITEMS.register(a.itemId, () -> new AttachmentItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON), a)));
        }
    }

    /** Forces the static initializer (call from the mod constructor before registries fire). */
    public static void init() {}

    /** True when at least one weapon fires this ammunition (the 4.x calibers are kept registered for old worlds, but hidden). */
    public static boolean inUse(AmmoType a) {
        for (GunSpec g : Guns.ALL) if (g.caliber == a.caliber) return true;
        return false;
    }
}
