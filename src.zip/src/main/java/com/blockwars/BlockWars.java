package com.blockwars;

import com.blockwars.entity.BaseMechaEntity;
import com.blockwars.entity.BastionEntity;
import com.blockwars.entity.GenericMechaEntity;
import com.blockwars.entity.GoliathEntity;
import com.blockwars.mecha.MechaSpec;
import com.blockwars.mecha.MechaSpecs;
import com.blockwars.entity.MechaEntity;
import com.blockwars.entity.VanguardEntity;
import com.blockwars.network.ModNetwork;
import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.EntityMountEvent;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.slf4j.Logger;

@Mod(BlockWars.MODID)
public class BlockWars {
    public static final String MODID = "blockwars";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> BLOCKWARS_TAB =
            CREATIVE_MODE_TABS.register("blockwars", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.blockwars"))
                    .withTabsBefore(CreativeModeTabs.COMBAT)
                    .icon(() -> ModItems.MECHA_CORE.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.MECHA_CORE.get());
                        output.accept(ModItems.GOLIATH_CORE.get());
                        output.accept(ModItems.VANGUARD_CORE.get());
                        output.accept(ModItems.BASTION_CORE.get());
                        ModItems.GENERATED_CORES.values().forEach(core -> output.accept(core.get()));
                    })
                    .build());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> ARMORY_TAB =
            CREATIVE_MODE_TABS.register("armory", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.blockwars.armory"))
                    .withTabsBefore(BLOCKWARS_TAB.getKey())
                    .icon(() -> com.blockwars.gun.ModGuns.GUNS.get("m7").get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        com.blockwars.gun.ModGuns.GUNS.values().forEach(g -> output.accept(g.get()));
                        com.blockwars.gun.ModGuns.AMMO.forEach((type, a) -> {
                            if (com.blockwars.gun.ModGuns.inUse(type)) output.accept(a.get());
                        });
                        output.accept(com.blockwars.gun.ModGuns.EMPTY_CELL.get());
                        com.blockwars.gun.ModGuns.ATTACHMENTS.values().forEach(a -> output.accept(a.get()));
                    })
                    .build());

    public BlockWars(IEventBus modEventBus, ModContainer modContainer) {
        ModEntities.ENTITY_TYPES.register(modEventBus);
        com.blockwars.gun.ModGuns.init();
        // 5.0: the fictional Arsenal (ten weapons, their ammunition and upgrades) registers its items before the item register is attached
        com.blockwars.arsenal.Arsenal.init(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        CREATIVE_MODE_TABS.register(modEventBus);
        ModSounds.SOUNDS.register(modEventBus);
        ModParticles.PARTICLES.register(modEventBus);

        modEventBus.addListener(BlockWars::registerAttributes);
        modEventBus.addListener(ModNetwork::register);

        NeoForge.EVENT_BUS.addListener(BlockWars::protectPilot);
        NeoForge.EVENT_BUS.addListener(BlockWars::lockRoguePilot);
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }

    /** While a rogue AI has the controls, sneaking does not open the hatch. */
    private static void lockRoguePilot(EntityMountEvent event) {
        if (!event.isDismounting()) return;
        if (!(event.getEntityBeingMounted() instanceof GenericMechaEntity mecha) || !mecha.isRogueActive()) return;
        if (event.getEntityMounting() instanceof ServerPlayer sp && sp.isAlive() && !sp.hasDisconnected() && sp.isShiftKeyDown()) {
            sp.displayClientMessage(Component.translatable("message.blockwars.rogue_locked"), true);
            event.setCanceled(true);
        }
    }

    private static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.MECHA.get(), MechaEntity.createAttributes().build());
        event.put(ModEntities.GOLIATH.get(), GoliathEntity.createAttributes().build());
        event.put(ModEntities.VANGUARD.get(), VanguardEntity.createAttributes().build());
        event.put(ModEntities.BASTION.get(), BastionEntity.createAttributes().build());
        for (MechaSpec spec : MechaSpecs.ALL) {
            event.put(ModEntities.GENERATED.get(spec.id).get(), GenericMechaEntity.createAttributes(spec).build());
        }
    }

    /**
     * The mecha's armored cockpit protects the pilot: damage aimed at the pilot
     * is absorbed by the mecha instead.
     */
    private static void protectPilot(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!(player.getVehicle() instanceof BaseMechaEntity mecha)) return;

        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return; // /kill, void...

        event.setCanceled(true);
        if (source.is(DamageTypes.IN_WALL) || source.is(DamageTypeTags.IS_FALL)) return;
        if (!player.level().isClientSide) {
            mecha.hurt(source, event.getAmount());
        }
    }
}
