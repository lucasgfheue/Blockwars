package com.blockwars.client;

import java.util.ArrayList;
import java.util.List;

/** Describes how a generated model is animated: which parts are legs, arms, weapons, spinning rings... (paths use "/") */
public final class Rig {
    public enum Arch { BIPED, REVERSE, QUAD, HEXA, TREAD, HOVER, SERPENT }
    public enum MountKind { ARM, TURRET, POD, BODY }

    public record Leg(String upper, String lower, String foot, int side, float phase, int kind) {}   // kind 0 pendulum, 1 reverse, 2 spider
    public record Arm(String shoulder, String forearm, int side, boolean floating) {}
    public record Spin(String path, int axis, float speed, int mode) {}   // axis 0=x 1=y 2=z ; mode 0 always, 1 walk, 2 active
    public record Sway(String path, int axis, float amp, float phase) {}
    public record Wing(String path, int side) {}
    public record Mount(MountKind kind, String mount, String barrel, String flash, String spin) {}

    public final Arch arch;
    public String body, torso, head;
    public float upperLen = 10, lowerLen = 11, hover, walkRate = 0.33F;
    public final List<Leg> legs = new ArrayList<>();
    public final List<Arm> arms = new ArrayList<>();
    public final List<Spin> spins = new ArrayList<>();
    public final List<Sway> sways = new ArrayList<>();
    public final List<Wing> wings = new ArrayList<>();
    public final List<String> flames = new ArrayList<>();
    public final List<String> segments = new ArrayList<>();
    public final List<String> jaws = new ArrayList<>();
    public Mount primary, secondary, primaryTwin, secondaryTwin;

    public Rig(Arch arch) {
        this.arch = arch;
    }

    public Rig parts(String body, String torso, String head) { this.body = body; this.torso = torso; this.head = head; return this; }
    public Rig legLengths(float upper, float lower) { this.upperLen = upper; this.lowerLen = lower; return this; }
    public Rig hover(float h) { this.hover = h; return this; }
    public Rig walkRate(float r) { this.walkRate = r; return this; }
    public Rig leg(String u, String l, String f, int side, float phase, int kind) { this.legs.add(new Leg(u, l, f, side, phase, kind)); return this; }
    public Rig arm(String s, String f, int side, boolean floating) { this.arms.add(new Arm(s, f, side, floating)); return this; }
    public Rig spin(String p, int axis, float speed, int mode) { this.spins.add(new Spin(p, axis, speed, mode)); return this; }
    public Rig sway(String p, int axis, float amp, float phase) { this.sways.add(new Sway(p, axis, amp, phase)); return this; }
    public Rig wing(String p, int side) { this.wings.add(new Wing(p, side)); return this; }
    public Rig flame(String p) { this.flames.add(p); return this; }
    public Rig segment(String p) { this.segments.add(p); return this; }
    public Rig jaw(String p) { this.jaws.add(p); return this; }
    public Rig primary(MountKind k, String mount, String barrel, String flash, String spin) { this.primary = new Mount(k, mount, barrel, flash, spin); return this; }
    public Rig secondary(MountKind k, String mount, String barrel, String flash, String spin) { this.secondary = new Mount(k, mount, barrel, flash, spin); return this; }
    public Rig primaryTwin(MountKind k, String mount, String barrel, String flash, String spin) { this.primaryTwin = new Mount(k, mount, barrel, flash, spin); return this; }
    public Rig secondaryTwin(MountKind k, String mount, String barrel, String flash, String spin) { this.secondaryTwin = new Mount(k, mount, barrel, flash, spin); return this; }
}
