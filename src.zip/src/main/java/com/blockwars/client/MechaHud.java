package com.blockwars.client;

import com.blockwars.entity.BaseMechaEntity;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/** Cockpit HUD: hull integrity, weapon recharge bars, reactor heat and critical alerts. */
public final class MechaHud {
    private MechaHud() {}

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || !(mc.player.getVehicle() instanceof BaseMechaEntity m)) return;
        Font font = mc.font;
        int w = g.guiWidth(), h = g.guiHeight();
        int x = 8, y = h - 84;
        int pw = 150;

        // panel
        g.fill(x - 4, y - 4, x + pw + 4, y + 62, 0x88101418);
        g.fill(x - 4, y - 4, x + pw + 4, y - 3, 0xFF3FA9F5);
        g.drawString(font, m.getDisplayName(), x, y, 0xFFE8F4FF, true);

        // hull
        float hp = Mth.clamp(m.getHealth() / m.getMaxHealth(), 0, 1);
        int hpCol = hp > 0.5F ? 0xFF4CD964 : hp > 0.25F ? 0xFFFFCC00 : 0xFFFF3B30;
        bar(g, font, x, y + 12, pw, hp, hpCol, Component.translatable("hud.blockwars.hull", Math.round(m.getHealth()), Math.round(m.getMaxHealth())));

        // weapons
        float pr = 1.0F - m.getPrimaryCooldown() / (float) m.getPrimaryCooldownMax();
        float sr = 1.0F - m.getSecondaryCooldown() / (float) m.getSecondaryCooldownMax();
        bar(g, font, x, y + 26, pw, pr, pr >= 1 ? 0xFF5AC8FA : 0xFF2C6E8F,
                Component.literal("[").append(BlockWarsClient.PRIMARY_KEY.getTranslatedKeyMessage()).append("] ").append(Component.translatable(m.primaryNameKey())));
        bar(g, font, x, y + 40, pw, sr, sr >= 1 ? 0xFFFF9500 : 0xFF8F5A1F,
                Component.literal("[").append(BlockWarsClient.SECONDARY_KEY.getTranslatedKeyMessage()).append("] ").append(Component.translatable(m.secondaryNameKey())));

        // reactor heat
        float heat = m.getHeatFraction();
        if (heat >= 0) {
            int hc = heat < 0.6F ? 0xFFFFCC00 : heat < 0.85F ? 0xFFFF6B00 : 0xFFFF1A1A;
            g.fill(x - 4, y - 22, x + pw + 4, y - 6, 0x88101418);
            bar(g, font, x, y - 19, pw, heat, hc, Component.translatable("hud.blockwars.heat", Math.round(heat * 100)));
        }

        // critical alert
        int alert = m.getAlertTicks();
        if (alert > 0) {
            boolean blink = (mc.player.tickCount / 4) % 2 == 0;
            Component msg = Component.translatable(m.getAlertKey(), String.format("%.1f", alert / 20.0F));
            int tw = font.width(msg);
            g.fill(w / 2 - tw / 2 - 8, h / 2 - 52, w / 2 + tw / 2 + 8, h / 2 - 36, blink ? 0xCCB00000 : 0xCC400000);
            g.drawString(font, msg, w / 2 - tw / 2, h / 2 - 48, 0xFFFFFFFF, true);
        }

        // targeting reticle (first person only)
        if (mc.options.getCameraType().isFirstPerson()) {
            int cx = w / 2, cy = h / 2, r = 10, l = 4, col = 0xAA7FE0FF;
            g.fill(cx - r, cy - r, cx - r + l, cy - r + 1, col);
            g.fill(cx - r, cy - r, cx - r + 1, cy - r + l, col);
            g.fill(cx + r - l, cy - r, cx + r, cy - r + 1, col);
            g.fill(cx + r - 1, cy - r, cx + r, cy - r + l, col);
            g.fill(cx - r, cy + r - 1, cx - r + l, cy + r, col);
            g.fill(cx - r, cy + r - l, cx - r + 1, cy + r, col);
            g.fill(cx + r - l, cy + r - 1, cx + r, cy + r, col);
            g.fill(cx + r - 1, cy + r - l, cx + r, cy + r, col);
        }
    }

    private static void bar(GuiGraphics g, Font font, int x, int y, int w, float frac, int color, Component label) {
        g.fill(x, y + 9, x + w, y + 12, 0xFF1C2228);
        g.fill(x, y + 9, x + Math.round(w * Mth.clamp(frac, 0, 1)), y + 12, color);
        g.drawString(font, label, x, y, 0xFFCFE3EE, true);
    }
}
