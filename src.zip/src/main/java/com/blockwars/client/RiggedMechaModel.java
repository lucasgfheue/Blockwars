package com.blockwars.client;

import com.blockwars.entity.GenericMechaEntity;
import com.blockwars.mecha.WeaponSpec;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Animates any generated mecha from its {@link Rig}: walk cycles per archetype, idle motion, spinning parts,
 * thruster flames, and weapon animations (aim + recoil, sword swings, stomps, casting, pods...).
 * Models are built at 2x resolution, so pixel offsets are multiplied by S.
 */
public class RiggedMechaModel extends HierarchicalModel<GenericMechaEntity> {
    private static final float S = 2.0F;

    private final ModelPart root;
    private final Rig rig;
    @Nullable private final ModelPart body, torso, head;
    private final List<ModelPart[]> legs = new ArrayList<>();
    private final List<ModelPart[]> arms = new ArrayList<>();
    private final List<ModelPart> spins = new ArrayList<>(), sways = new ArrayList<>(), wings = new ArrayList<>(),
            flames = new ArrayList<>(), segments = new ArrayList<>(), jaws = new ArrayList<>();
    private final ModelPart[] pMount, sMount, pTwin, sTwin; // [mount, barrel, flash, spin]

    public RiggedMechaModel(ModelPart root, Rig rig) {
        super(RenderType::entityCutout);
        this.root = root;
        this.rig = rig;
        this.body = find(rig.body);
        this.torso = find(rig.torso);
        this.head = find(rig.head);
        for (Rig.Leg l : rig.legs) this.legs.add(new ModelPart[]{find(l.upper()), find(l.lower()), find(l.foot())});
        for (Rig.Arm a : rig.arms) this.arms.add(new ModelPart[]{find(a.shoulder()), find(a.forearm())});
        for (Rig.Spin s : rig.spins) this.spins.add(find(s.path()));
        for (Rig.Sway s : rig.sways) this.sways.add(find(s.path()));
        for (Rig.Wing w : rig.wings) this.wings.add(find(w.path()));
        for (String f : rig.flames) this.flames.add(find(f));
        for (String f : rig.segments) this.segments.add(find(f));
        for (String f : rig.jaws) this.jaws.add(find(f));
        this.pMount = mount(rig.primary);
        this.sMount = mount(rig.secondary);
        this.pTwin = mount(rig.primaryTwin);
        this.sTwin = mount(rig.secondaryTwin);
    }

    private ModelPart[] mount(@Nullable Rig.Mount m) {
        if (m == null) return new ModelPart[4];
        return new ModelPart[]{find(m.mount()), find(m.barrel()), find(m.flash()), find(m.spin())};
    }

    @Nullable
    private ModelPart find(@Nullable String path) {
        if (path == null || path.isEmpty()) return null;
        ModelPart p = this.root;
        for (String n : path.split("/")) {
            if (!p.hasChild(n)) return null;
            p = p.getChild(n);
        }
        return p;
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    private static void rot(@Nullable ModelPart p, int axis, float v) {
        if (p == null) return;
        if (axis == 0) p.xRot += v; else if (axis == 1) p.yRot += v; else p.zRot += v;
    }

    @Override
    public void setupAnim(GenericMechaEntity e, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float pt = age - e.tickCount;
        float a = Math.min(1.0F, limbSwingAmount * 1.4F);
        float ph = limbSwing * this.rig.walkRate;
        float pitch = headPitch * Mth.DEG_TO_RAD;
        float boost = e.getBoostAmount(pt);
        float tp = e.primaryTime(pt), ts = e.secondaryTime(pt);
        WeaponSpec wp = e.spec.primary, ws = e.spec.secondary;
        float activeP = activity(wp, tp), activeS = activity(ws, ts);
        float active = Math.max(activeP, activeS);

        // ------------------------------------------------ idle
        float br = Mth.sin(age * 0.08F);
        if (this.torso != null && this.torso != this.body) {
            this.torso.xRot += br * 0.02F;
            this.torso.y += -br * 0.25F * S;
        }
        if (this.rig.arch == Rig.Arch.HOVER) {
            if (this.body != null) {
                this.body.y += Mth.sin(age * 0.1F) * 1.5F * S - boost * 2.0F * S;
                this.body.xRot += 0.12F * a + Mth.sin(age * 0.05F) * 0.02F;
                this.body.zRot += Mth.sin(age * 0.043F) * 0.03F;
            }
        } else if (this.body != null) {
            this.body.y += br * 0.2F * S;
        }
        if (this.head != null && this.head != this.body) {
            this.head.xRot += pitch * 0.6F;
            this.head.yRot += Mth.sin(age * 0.03F) * 0.25F * (1.0F - a) * (1.0F - active);
        }
        for (int i = 0; i < this.sways.size(); i++) {
            Rig.Sway s = this.rig.sways.get(i);
            rot(this.sways.get(i), s.axis(), Mth.sin(age * 0.12F + s.phase()) * s.amp() * (1.0F + a * 2.0F));
        }
        for (int i = 0; i < this.spins.size(); i++) {
            Rig.Spin s = this.rig.spins.get(i);
            float v = switch (s.mode()) {
                case 1 -> limbSwing * 0.6F;
                case 2 -> age * s.speed() * (1.0F + 4.0F * active);
                case 3 -> age * s.speed() * active;
                default -> age * s.speed();
            };
            rot(this.spins.get(i), s.axis(), v);
        }
        float flame = 0.55F + 0.12F * Mth.sin(age * 1.9F) + 0.08F * Mth.sin(age * 3.3F) + boost * 2.2F + a * 0.2F;
        for (ModelPart f : this.flames) if (f != null) f.yScale = Math.max(0.15F, flame);
        for (int i = 0; i < this.wings.size(); i++) {
            ModelPart w = this.wings.get(i);
            if (w == null) continue;
            int side = this.rig.wings.get(i).side();
            w.zRot += side * 0.45F * boost + side * Mth.sin(age * 0.06F) * 0.04F;
            w.xRot += Mth.sin(age * 0.5F) * 0.1F * boost;
        }
        for (ModelPart j : this.jaws) {
            if (j != null) j.xRot += 0.06F + 0.05F * Mth.sin(age * 0.1F) + 0.55F * active;
        }
        for (int i = 0; i < this.segments.size(); i++) {
            ModelPart s = this.segments.get(i);
            if (s == null) continue;
            s.yRot += Mth.sin(age * 0.12F - i * 0.7F) * 0.05F + Mth.sin(limbSwing * 0.45F - i * 0.8F) * 0.22F * a;
            s.y += Mth.sin(limbSwing * 0.45F - i * 0.8F + 1.2F) * 0.4F * a * S;
        }

        // ------------------------------------------------ legs
        this.animateLegs(e, ph, a);

        // ------------------------------------------------ arms (walk counter-swing / floating bob)
        for (int i = 0; i < this.arms.size(); i++) {
            ModelPart[] arm = this.arms.get(i);
            Rig.Arm ar = this.rig.arms.get(i);
            if (arm[0] == null) continue;
            if (ar.floating()) {
                arm[0].y += Mth.sin(age * 0.11F + ar.side()) * 0.8F * S;
            } else {
                arm[0].xRot += -Mth.cos(ph + (ar.side() < 0 ? 0 : Mth.PI)) * 0.3F * a;
                arm[0].zRot += ar.side() * (0.05F + br * 0.015F);
            }
        }

        // ------------------------------------------------ weapons
        this.animateWeapon(e, wp, tp, this.pMount, this.pTwin, pitch, age, true);
        this.animateWeapon(e, ws, ts, this.sMount, this.sTwin, pitch, age, false);
    }

    private static float activity(WeaponSpec w, float t) {
        if (t < 0) return 0.0F;
        float dur = w.duration / 20.0F;
        return MechaAnim.ease(t / 0.2F) * (1.0F - MechaAnim.ease((t - (dur - 0.2F)) / 0.2F));
    }

    private void animateLegs(GenericMechaEntity e, float ph, float a) {
        boolean airborne = !e.onGround() && e.canFly();
        float dropMax = 0.0F;
        int pendulumCount = 0;
        for (int i = 0; i < this.legs.size(); i++) {
            ModelPart[] leg = this.legs.get(i);
            Rig.Leg l = this.rig.legs.get(i);
            float p = ph + l.phase();
            switch (l.kind()) {
                case 1 -> { // reverse joint
                    float th = Mth.cos(p) * 0.45F * a;
                    float kn = Math.max(0.0F, Mth.sin(p)) * 0.55F * a;
                    rot(leg[0], 0, th);
                    rot(leg[1], 0, kn);
                    rot(leg[2], 0, -(th + kn));
                    if (airborne) { rot(leg[0], 0, -0.3F); rot(leg[1], 0, 0.4F); }
                }
                case 2 -> { // spider
                    rot(leg[0], 1, Mth.cos(p) * 0.32F * a);
                    rot(leg[1], 2, -l.side() * Math.max(0.0F, Mth.sin(p)) * 0.38F * a);
                    rot(leg[2], 2, l.side() * Math.max(0.0F, Mth.sin(p)) * 0.2F * a);
                }
                default -> { // pendulum (biped / quad)
                    boolean quad = this.rig.arch == Rig.Arch.QUAD;
                    float amp = quad ? 0.5F : 0.55F;
                    float th = Mth.cos(p) * amp * a;
                    float kn = (Math.max(0.0F, Mth.sin(p)) * (quad ? 0.7F : 1.0F) + 0.04F) * a;
                    rot(leg[0], 0, th);
                    rot(leg[1], 0, kn);
                    rot(leg[2], 0, -(th + kn) * 0.9F);
                    if (airborne) { rot(leg[0], 0, -0.25F); rot(leg[1], 0, 0.5F); rot(leg[2], 0, -0.2F); }
                    if (!quad) {
                        float h = this.rig.upperLen * Mth.cos(th) + this.rig.lowerLen * Mth.cos(th + kn);
                        dropMax = Math.max(dropMax, (this.rig.upperLen + this.rig.lowerLen) - h);
                        pendulumCount++;
                    }
                }
            }
        }
        // biped: keep the planted foot on the ground by lowering the hips (legs are root parts)
        if (pendulumCount >= 2 && !airborne) {
            float drop = Math.min(dropMax, (this.rig.upperLen + this.rig.lowerLen) * 0.2F) * 0.5F;
            if (this.body != null) this.body.y += drop * S;
            for (ModelPart[] leg : this.legs) if (leg[0] != null) leg[0].y += drop * S;
            if (this.torso != null) {
                this.torso.yRot += Mth.cos(ph) * -0.12F * a;
                this.torso.zRot += Mth.sin(ph) * 0.03F * a;
            }
        }
        if (this.rig.arch == Rig.Arch.TREAD && this.body != null) {
            this.body.y += Mth.sin(e.tickCount * 1.7F) * 0.12F * a * S;
        }
        if (this.rig.arch == Rig.Arch.QUAD || this.rig.arch == Rig.Arch.HEXA) {
            if (this.body != null) {
                this.body.y += Math.abs(Mth.sin(ph)) * 0.6F * a * S;
                this.body.zRot += Mth.sin(ph) * 0.025F * a;
            }
        }
    }

    private void animateWeapon(GenericMechaEntity e, WeaponSpec w, float t, ModelPart[] mt, ModelPart[] twin, float pitch, float age, boolean primary) {
        // flashes are hidden unless a shot just happened
        if (mt[2] != null) mt[2].visible = false;
        if (twin[2] != null) twin[2].visible = false;
        if (t < 0) return;
        float dur = w.duration / 20.0F;
        float wu = w.windup / 20.0F;
        float aim = activity(w, t);
        float rec = 0.0F, recTwin = 0.0F;
        boolean flash = false, flashTwin = false;
        for (int i = 0; i < w.count; i++) {
            float te = w.eventTime(i);
            if (t < te) break;
            float r = (float) Math.exp(-(t - te) * 14.0F);
            boolean onTwin = w.hasMuzzle2 && i % 2 == 1;
            if (onTwin) recTwin = Math.max(recTwin, r); else rec = Math.max(rec, r);
            if (t - te < 0.06F) { if (onTwin) flashTwin = true; else flash = true; }
        }
        boolean beamOn = w.kind == WeaponSpec.Kind.BEAM && t >= wu && t < w.eventTime(Math.max(0, w.count - 1)) + 0.1F;
        ModelPart m = mt[0];
        switch (w.anim) {
            case AIM, BEAM, SPIN -> {
                this.aimMount(m, aim, pitch);
                if (w.twin || w.hasMuzzle2) this.aimMount(twin[0], aim, pitch);
                if (mt[1] != null) mt[1].z += 3.0F * rec * S;
                if (twin[1] != null) twin[1].z += 3.0F * recTwin * S;
                if (m != null) m.xRot -= 0.07F * rec;
                if (twin[0] != null) twin[0].xRot -= 0.07F * recTwin;
                if (mt[2] != null) mt[2].visible = flash || beamOn;
                if (twin[2] != null) twin[2].visible = flashTwin || (beamOn && w.twin);
                if (mt[3] != null) mt[3].zRot += age * 0.9F * aim;
                if (twin[3] != null) twin[3].zRot += age * 0.9F * aim;
                if (w.anim == WeaponSpec.Anim.BEAM && m != null) m.yRot += Mth.sin(age * 0.9F) * 0.015F * aim;
            }
            case SWING -> {
                float s = Math.min(1.0F, t / dur);
                float wf = Mth.clamp(wu / dur, 0.15F, 0.7F);
                float wnd = MechaAnim.easeOut(s / wf), k = MechaAnim.ease((s - wf) / 0.12F), r = MechaAnim.ease((s - (wf + 0.22F)) / 0.3F);
                if (m != null && mt[0] != this.body && mt[0] != this.torso) {
                    m.xRot += ph3(0, -2.3F, -0.6F, wnd, k, r);
                    m.yRot += ph3(0, 0.3F, -0.6F, wnd, k, r);
                    m.zRot += ph3(0, -0.9F, 0.9F, wnd, k, r);
                }
                if (w.twin && twin[0] != null) {
                    float s2 = Math.min(1.0F, Math.max(0.0F, t - w.interval / 20.0F) / dur);
                    float wnd2 = MechaAnim.easeOut(s2 / wf), k2 = MechaAnim.ease((s2 - wf) / 0.12F), r2 = MechaAnim.ease((s2 - (wf + 0.22F)) / 0.3F);
                    twin[0].xRot += ph3(0, -2.3F, -0.6F, wnd2, k2, r2);
                    twin[0].yRot += ph3(0, -0.3F, 0.6F, wnd2, k2, r2);
                    twin[0].zRot += ph3(0, 0.9F, -0.9F, wnd2, k2, r2);
                }
                if (this.torso != null) {
                    this.torso.yRot += ph3(0, 0.35F, -0.45F, wnd, k, r);
                    this.torso.xRot += ph3(0, -0.06F, 0.15F, wnd, k, r);
                }
                if (this.rig.arch == Rig.Arch.SERPENT || this.rig.arch == Rig.Arch.HOVER) {
                    for (int i = 0; i < this.segments.size(); i++) {
                        ModelPart sg = this.segments.get(i);
                        if (sg != null) sg.yRot += ph3(0, 0.25F, -0.4F, wnd, k, r);
                    }
                    if (this.body != null && this.rig.arch == Rig.Arch.HOVER) this.body.yRot += ph3(0, 0.6F, -6.28F, wnd, k, r);
                }
            }
            case STOMP -> {
                float c = MechaAnim.ease(t / Math.max(0.05F, wu)) * (1.0F - MechaAnim.ease((t - wu) / 0.12F));
                float after = MechaAnim.ease((t - wu) / 0.1F) * (1.0F - MechaAnim.ease((t - wu - 0.3F) / 0.4F));
                if (this.body != null) this.body.y += (-2.0F * c + 2.5F * after) * S;
                if (this.torso != null) this.torso.xRot += 0.25F * after - 0.15F * c;
                if (!this.legs.isEmpty() && this.legs.get(0)[0] != null && this.rig.arch == Rig.Arch.BIPED) {
                    this.legs.get(0)[0].xRot -= 0.9F * c;
                    if (this.legs.get(0)[1] != null) this.legs.get(0)[1].xRot += 0.9F * c;
                }
                for (ModelPart[] arm : this.arms) if (arm[0] != null) arm[0].xRot -= 1.2F * c;
            }
            case CAST -> {
                for (int i = 0; i < this.arms.size(); i++) {
                    ModelPart[] arm = this.arms.get(i);
                    if (arm[0] == null) continue;
                    int side = this.rig.arms.get(i).side();
                    if (this.rig.arms.get(i).floating()) {
                        arm[0].y -= 3.0F * aim * S;
                        arm[0].x += side * 2.0F * aim * S;
                    } else {
                        arm[0].xRot += (-1.9F + pitch * 0.5F) * aim;
                        arm[0].zRot += side * 0.45F * aim;
                    }
                }
                if (this.torso != null && this.torso != this.body) this.torso.xRot -= 0.12F * aim;
                if (this.head != null && this.head != this.body) this.head.xRot -= 0.25F * aim;
            }
            case POUNCE -> {
                float c = MechaAnim.ease(t / Math.max(0.05F, wu)) * (1.0F - MechaAnim.ease((t - wu) / 0.1F));
                float air = MechaAnim.ease((t - wu) / 0.1F) * (1.0F - MechaAnim.ease((t - dur + 0.2F) / 0.2F));
                if (this.body != null) this.body.y += 3.0F * c * S;
                if (this.torso != null) this.torso.xRot += 0.35F * c - 0.2F * air;
                for (ModelPart[] leg : this.legs) {
                    if (leg[1] != null) leg[1].xRot += 0.7F * c;
                    if (leg[0] != null) leg[0].xRot += -0.4F * c + 0.4F * air;
                }
                for (ModelPart[] arm : this.arms) if (arm[0] != null) arm[0].xRot += -1.0F * air + 0.5F * c;
            }
            case POD -> {
                float up = aim;
                if (m != null) m.xRot -= 0.6F * up + 0.06F * -rec;
                if (twin[0] != null) twin[0].xRot -= 0.6F * up;
                if (this.torso != null && this.torso != this.body) this.torso.xRot -= 0.03F * rec;
            }
            default -> { }
        }
    }

    private void aimMount(@Nullable ModelPart m, float aim, float pitch) {
        if (m == null) return;
        if (m == this.body) {
            m.xRot += pitch * 0.25F * aim;
        } else {
            m.xRot += (-0.3F + pitch * 0.8F) * aim;
        }
    }

    private static float ph3(float rest, float wind, float strike, float w, float k, float r) {
        return Mth.lerp(r, Mth.lerp(k, Mth.lerp(w, rest, wind), strike), rest);
    }
}
