package com.blockwars.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.util.Mth;

/** One particle class with eight looks (spark, orb, ember, shard, smoke, frost, toxic, void). */
public class MechaParticle extends TextureSheetParticle {
    public enum Style { SPARK, ORB, EMBER, SHARD, SMOKE, FROST, TOXIC, VOID }

    private final SpriteSet sprites;
    private final Style style;
    private final float baseSize;
    private final boolean emissive;

    protected MechaParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                            float r, float g, float b, SpriteSet sprites, Style style) {
        super(level, x, y, z, vx, vy, vz);
        this.sprites = sprites;
        this.style = style;
        this.xd = vx; this.yd = vy; this.zd = vz;
        this.rCol = r; this.gCol = g; this.bCol = b;
        this.hasPhysics = false;
        float s;
        switch (style) {
            case SPARK -> { this.lifetime = 6 + this.random.nextInt(6); s = 0.09F; this.friction = 0.82F; this.gravity = 0.15F; this.hasPhysics = true; }
            case ORB -> { this.lifetime = 10 + this.random.nextInt(8); s = 0.22F; this.friction = 0.9F; }
            case EMBER -> { this.lifetime = 14 + this.random.nextInt(14); s = 0.14F; this.friction = 0.92F; this.gravity = -0.03F; }
            case SHARD -> { this.lifetime = 12 + this.random.nextInt(10); s = 0.12F; this.friction = 0.88F; this.roll = this.random.nextFloat() * 6.28F; }
            case SMOKE -> { this.lifetime = 30 + this.random.nextInt(30); s = 0.45F; this.friction = 0.95F; this.gravity = -0.01F; }
            case FROST -> { this.lifetime = 18 + this.random.nextInt(14); s = 0.14F; this.friction = 0.9F; this.gravity = 0.02F; this.roll = this.random.nextFloat() * 6.28F; }
            case TOXIC -> { this.lifetime = 24 + this.random.nextInt(20); s = 0.3F; this.friction = 0.93F; this.gravity = -0.005F; }
            default -> { this.lifetime = 16 + this.random.nextInt(14); s = 0.2F; this.friction = 0.9F; this.gravity = -0.01F; }
        }
        this.baseSize = s * (0.8F + this.random.nextFloat() * 0.4F);
        this.quadSize = this.baseSize;
        this.emissive = style != Style.SMOKE && style != Style.TOXIC;
        this.alpha = style == Style.SMOKE ? 0.75F : 1.0F;
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.removed) {
            this.setSpriteFromAge(this.sprites);
            float life = this.age / (float) this.lifetime;
            switch (this.style) {
                case SMOKE, TOXIC -> { this.quadSize = this.baseSize * (1.0F + life * 1.8F); this.alpha = (this.style == Style.SMOKE ? 0.75F : 0.6F) * (1.0F - life); }
                case ORB, VOID -> { this.quadSize = this.baseSize * (1.0F - life * 0.7F); this.alpha = 1.0F - life * life; }
                case SHARD, FROST -> { this.oRoll = this.roll; this.roll += 0.25F; this.alpha = 1.0F - life; }
                default -> this.alpha = 1.0F - life * life;
            }
        }
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        if (!this.emissive) return super.getLightColor(partialTick);
        return 0xF000F0;
    }

    @Override
    public float getQuadSize(float partialTick) {
        return this.quadSize * Mth.clamp((this.age + partialTick) / 2.0F, 0.3F, 1.0F);
    }

    public static ParticleProvider<ColorParticleOption> provider(SpriteSet sprites, Style style) {
        return (ColorParticleOption o, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) ->
                new MechaParticle(level, x, y, z, vx, vy, vz, o.getRed(), o.getGreen(), o.getBlue(), sprites, style);
    }
}
