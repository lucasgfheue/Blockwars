package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Prism (prisma). */
@SuppressWarnings("unused")
public final class M_prisma {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("prisma"), "main");

    private M_prisma() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_core = root.addOrReplaceChild("core", CubeListBuilder.create()
                .texOffs(0, 54).addBox(-8F, -4F, -8F, 16F, 4F, 16F)
                .texOffs(116, 54).addBox(-3F, -15F, -3F, 6F, 6F, 6F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_gem = p_core.addOrReplaceChild("gem", CubeListBuilder.create()
                .texOffs(40, 0).addBox(-13F, -13F, -13F, 26F, 26F, 26F),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_gem2 = p_core.addOrReplaceChild("gem2", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5F, -22F, -5F, 10F, 44F, 10F),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0F, 0.7854F, 0F));
        PartDefinition p_head = p_core.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(200, 54).addBox(-3F, -4F, -3F, 6F, 4F, 6F),
                PartPose.offsetAndRotation(0F, -48F, 0F, 0F, 0F, 0F));
        PartDefinition p_ring0 = p_core.addOrReplaceChild("ring0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 1.5708F, 0F, 0F));
        PartDefinition p_ring0_s0 = p_ring0.addOrReplaceChild("ring0_s0", CubeListBuilder.create()
                .texOffs(172, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(26F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring0_s1 = p_ring0.addOrReplaceChild("ring0_s1", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(23F, 11F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring0_s2 = p_ring0.addOrReplaceChild("ring0_s2", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(16F, 20F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring0_s3 = p_ring0.addOrReplaceChild("ring0_s3", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(6F, 25F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring0_s4 = p_ring0.addOrReplaceChild("ring0_s4", CubeListBuilder.create()
                .texOffs(172, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(-6F, 25F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring0_s5 = p_ring0.addOrReplaceChild("ring0_s5", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(-16F, 20F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring0_s6 = p_ring0.addOrReplaceChild("ring0_s6", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(-23F, 11F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring0_s7 = p_ring0.addOrReplaceChild("ring0_s7", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(-26F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring0_s8 = p_ring0.addOrReplaceChild("ring0_s8", CubeListBuilder.create()
                .texOffs(172, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(-23F, -11F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring0_s9 = p_ring0.addOrReplaceChild("ring0_s9", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(-16F, -20F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring0_s10 = p_ring0.addOrReplaceChild("ring0_s10", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(-6F, -25F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring0_s11 = p_ring0.addOrReplaceChild("ring0_s11", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(6F, -25F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring0_s12 = p_ring0.addOrReplaceChild("ring0_s12", CubeListBuilder.create()
                .texOffs(172, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(16F, -20F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring0_s13 = p_ring0.addOrReplaceChild("ring0_s13", CubeListBuilder.create()
                .texOffs(208, 74).addBox(-7F, -2F, -2F, 14F, 3F, 4F),
                PartPose.offsetAndRotation(23F, -11F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring1 = p_core.addOrReplaceChild("ring1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0.4F, 0.3F, 0F));
        PartDefinition p_ring1_s0 = p_ring1.addOrReplaceChild("ring1_s0", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(32F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring1_s1 = p_ring1.addOrReplaceChild("ring1_s1", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(29F, 14F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring1_s2 = p_ring1.addOrReplaceChild("ring1_s2", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(20F, 25F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring1_s3 = p_ring1.addOrReplaceChild("ring1_s3", CubeListBuilder.create()
                .texOffs(132, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(7F, 31F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring1_s4 = p_ring1.addOrReplaceChild("ring1_s4", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(-7F, 31F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring1_s5 = p_ring1.addOrReplaceChild("ring1_s5", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(-20F, 25F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring1_s6 = p_ring1.addOrReplaceChild("ring1_s6", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(-29F, 14F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring1_s7 = p_ring1.addOrReplaceChild("ring1_s7", CubeListBuilder.create()
                .texOffs(132, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(-32F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring1_s8 = p_ring1.addOrReplaceChild("ring1_s8", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(-29F, -14F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring1_s9 = p_ring1.addOrReplaceChild("ring1_s9", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(-20F, -25F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring1_s10 = p_ring1.addOrReplaceChild("ring1_s10", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(-7F, -31F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring1_s11 = p_ring1.addOrReplaceChild("ring1_s11", CubeListBuilder.create()
                .texOffs(132, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(7F, -31F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring1_s12 = p_ring1.addOrReplaceChild("ring1_s12", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(20F, -25F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring1_s13 = p_ring1.addOrReplaceChild("ring1_s13", CubeListBuilder.create()
                .texOffs(92, 74).addBox(-8F, -2F, -2F, 16F, 3F, 4F),
                PartPose.offsetAndRotation(29F, -14F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring2 = p_core.addOrReplaceChild("ring2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 1.5708F, 0.6F, 0F));
        PartDefinition p_ring2_s0 = p_ring2.addOrReplaceChild("ring2_s0", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(38F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring2_s1 = p_ring2.addOrReplaceChild("ring2_s1", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(34F, 16F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring2_s2 = p_ring2.addOrReplaceChild("ring2_s2", CubeListBuilder.create()
                .texOffs(46, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(24F, 30F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring2_s3 = p_ring2.addOrReplaceChild("ring2_s3", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(8F, 37F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring2_s4 = p_ring2.addOrReplaceChild("ring2_s4", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, 37F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring2_s5 = p_ring2.addOrReplaceChild("ring2_s5", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-24F, 30F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring2_s6 = p_ring2.addOrReplaceChild("ring2_s6", CubeListBuilder.create()
                .texOffs(46, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-34F, 16F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring2_s7 = p_ring2.addOrReplaceChild("ring2_s7", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-38F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring2_s8 = p_ring2.addOrReplaceChild("ring2_s8", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-34F, -16F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring2_s9 = p_ring2.addOrReplaceChild("ring2_s9", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-24F, -30F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring2_s10 = p_ring2.addOrReplaceChild("ring2_s10", CubeListBuilder.create()
                .texOffs(46, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, -37F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring2_s11 = p_ring2.addOrReplaceChild("ring2_s11", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(8F, -37F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring2_s12 = p_ring2.addOrReplaceChild("ring2_s12", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(24F, -30F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring2_s13 = p_ring2.addOrReplaceChild("ring2_s13", CubeListBuilder.create()
                .texOffs(0, 74).addBox(-10F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(34F, -16F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_float_r = p_core.addOrReplaceChild("float_r", CubeListBuilder.create()
                .texOffs(144, 0).addBox(-5F, -7F, -6F, 10F, 14F, 12F)
                .texOffs(0, 81).addBox(-3F, 7F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(-30F, -20F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter = p_float_r.addOrReplaceChild("float_r_emitter", CubeListBuilder.create()
                .texOffs(188, 0).addBox(-4F, -4F, -10F, 9F, 9F, 12F)
                .texOffs(140, 54).addBox(-1F, 4F, -17F, 2F, 2F, 10F)
                .texOffs(140, 54).addBox(-5F, -3F, -17F, 2F, 2F, 10F)
                .texOffs(140, 54).addBox(3F, -4F, -17F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 4F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter_orb = p_float_r_emitter.addOrReplaceChild("float_r_emitter_orb", CubeListBuilder.create()
                .texOffs(164, 54).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(188, 54).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_float_l = p_core.addOrReplaceChild("float_l", CubeListBuilder.create()
                .texOffs(144, 0).mirror().addBox(-5F, -7F, -6F, 10F, 14F, 12F).mirror(false)
                .texOffs(0, 81).addBox(-3F, 7F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(30F, -20F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_l_emitter = p_float_l.addOrReplaceChild("float_l_emitter", CubeListBuilder.create()
                .texOffs(188, 0).addBox(-4F, -4F, -10F, 9F, 9F, 12F)
                .texOffs(140, 54).addBox(-1F, 4F, -17F, 2F, 2F, 10F)
                .texOffs(140, 54).addBox(-5F, -3F, -17F, 2F, 2F, 10F)
                .texOffs(140, 54).addBox(3F, -4F, -17F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 4F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_l_emitter_orb = p_float_l_emitter.addOrReplaceChild("float_l_emitter_orb", CubeListBuilder.create()
                .texOffs(164, 54).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(188, 54).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_jet_r = p_core.addOrReplaceChild("jet_r", CubeListBuilder.create()
                .texOffs(84, 54).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(-8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_r = p_jet_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(64, 54).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_jet_l = p_core.addOrReplaceChild("jet_l", CubeListBuilder.create()
                .texOffs(84, 54).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_l = p_jet_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(64, 54).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 128);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HOVER).parts("core", "core", "core/head").walkRate(0F)
                .arm("core/float_r", null, -1, true)
                .arm("core/float_l", null, 1, true)
                .spin("core/gem", 1, 0.03F, 0)
                .spin("core/ring0", 2, 0.05F, 2)
                .spin("core/ring1", 2, -0.07F, 2)
                .spin("core/ring2", 2, 0.09F, 2)
                .spin("core/float_r/float_r_emitter/float_r_emitter_orb", 2, 0.25F, 0)
                .spin("core/float_l/float_l_emitter/float_l_emitter_orb", 2, 0.25F, 0)
                .flame("core/jet_r/flame_r")
                .flame("core/jet_l/flame_l")
                .primary(Rig.MountKind.ARM, "core/float_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "core/float_l", null, null, null);
    }
}
