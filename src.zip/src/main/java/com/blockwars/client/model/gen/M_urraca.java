package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Magpie (urraca). */
@SuppressWarnings("unused")
public final class M_urraca {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("urraca"), "main");

    private M_urraca() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(84, 130).addBox(-12F, -5F, -8F, 24F, 10F, 16F)
                .texOffs(102, 157).addBox(-13F, -4F, -9F, 26F, 5F, 18F)
                .texOffs(204, 219).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = p_hips.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(36, 0).addBox(-6F, 0F, -6F, 12F, 24F, 12F)
                .texOffs(62, 130).addBox(-7F, 4F, -5F, 1F, 17F, 10F),
                PartPose.offsetAndRotation(-14F, 0F, 0F, -0.55F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4F, 0F, -4F, 9F, 28F, 9F)
                .texOffs(80, 182).addBox(-6F, -4F, -6F, 12F, 8F, 12F)
                .texOffs(194, 182).addBox(-4F, 4F, 4F, 7F, 17F, 2F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 1.15F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(76, 69).addBox(-8F, 0F, -14F, 16F, 6F, 24F)
                .texOffs(86, 234).addBox(-7F, 2F, -15F, 14F, 3F, 1F)
                .texOffs(108, 219).addBox(-3F, 0F, 8F, 6F, 4F, 8F),
                PartPose.offsetAndRotation(0F, 28F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_thigh_l = p_hips.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(36, 0).mirror().addBox(-6F, 0F, -6F, 12F, 24F, 12F).mirror(false)
                .texOffs(62, 130).mirror().addBox(6F, 4F, -5F, 1F, 17F, 10F).mirror(false),
                PartPose.offsetAndRotation(14F, 0F, 0F, -0.55F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-4F, 0F, -4F, 9F, 28F, 9F).mirror(false)
                .texOffs(80, 182).mirror().addBox(-6F, -4F, -6F, 12F, 8F, 12F).mirror(false)
                .texOffs(194, 182).mirror().addBox(-4F, 4F, 4F, 7F, 17F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 1.15F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(76, 69).mirror().addBox(-8F, 0F, -14F, 16F, 6F, 24F).mirror(false)
                .texOffs(86, 234).mirror().addBox(-7F, 2F, -15F, 14F, 3F, 1F).mirror(false)
                .texOffs(108, 219).mirror().addBox(-3F, 0F, 8F, 6F, 4F, 8F).mirror(false),
                PartPose.offsetAndRotation(0F, 28F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(164, 130).addBox(-11F, -10F, -8F, 22F, 10F, 16F)
                .texOffs(84, 0).addBox(-18F, -16F, -13F, 36F, 8F, 26F)
                .texOffs(140, 37).addBox(-12F, -28F, -7F, 24F, 16F, 16F)
                .texOffs(156, 69).addBox(-20F, -33F, -12F, 3F, 27F, 3F)
                .texOffs(156, 69).addBox(-20F, -33F, 10F, 3F, 27F, 3F)
                .texOffs(156, 69).addBox(16F, -33F, -12F, 3F, 27F, 3F)
                .texOffs(156, 69).addBox(16F, -33F, 10F, 3F, 27F, 3F)
                .texOffs(0, 234).addBox(-20F, -36F, -12F, 40F, 3F, 3F)
                .texOffs(0, 234).addBox(-20F, -36F, 10F, 40F, 3F, 3F)
                .texOffs(0, 37).addBox(-21F, -33F, -14F, 42F, 4F, 28F)
                .texOffs(0, 219).addBox(-15F, -27F, -12F, 30F, 14F, 1F)
                .texOffs(198, 234).addBox(-14F, -36F, -14F, 4F, 2F, 1F)
                .texOffs(198, 234).addBox(10F, -36F, -14F, 4F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(126, 202).addBox(-6F, -4F, -6F, 12F, 4F, 12F)
                .texOffs(0, 69).addBox(-10F, -18F, -8F, 20F, 14F, 18F)
                .texOffs(152, 219).addBox(-8F, -16F, -9F, 16F, 8F, 1F)
                .texOffs(168, 182).addBox(-11F, -16F, -5F, 1F, 8F, 12F)
                .texOffs(168, 182).addBox(10F, -16F, -5F, 1F, 8F, 12F)
                .texOffs(0, 182).addBox(-10F, -19F, -8F, 21F, 1F, 19F)
                .texOffs(124, 234).addBox(-10F, -6F, -9F, 20F, 2F, 1F)
                .texOffs(208, 234).addBox(-8F, -20F, -7F, 2F, 1F, 2F)
                .texOffs(208, 234).addBox(6F, -20F, -7F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -36F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(50, 157).addBox(0F, -24F, 0F, 1F, 24F, 1F)
                .texOffs(116, 234).addBox(-1F, -25F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -12F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(128, 182).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(42, 101).addBox(-10F, -10F, -9F, 16F, 10F, 18F)
                .texOffs(0, 202).addBox(-9F, -11F, -8F, 14F, 1F, 16F)
                .texOffs(110, 101).addBox(-4F, 2F, -4F, 8F, 20F, 8F),
                PartPose.offsetAndRotation(-26F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(0, 101).addBox(-5F, 0F, -6F, 10F, 18F, 11F)
                .texOffs(62, 219).addBox(-6F, 17F, -6F, 11F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_magnet = p_forearm_r.addOrReplaceChild("forearm_r_magnet", CubeListBuilder.create()
                .texOffs(54, 157).addBox(-4F, -4F, -14F, 8F, 8F, 16F)
                .texOffs(168, 69).addBox(-13F, -13F, -18F, 26F, 26F, 3F)
                .texOffs(0, 157).addBox(-11F, -11F, -20F, 22F, 22F, 3F)
                .texOffs(186, 219).addBox(-4F, -4F, -20F, 8F, 8F, 1F)
                .texOffs(136, 219).addBox(-2F, 8F, -10F, 4F, 8F, 4F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(128, 182).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(42, 101).mirror().addBox(-6F, -10F, -9F, 16F, 10F, 18F).mirror(false)
                .texOffs(0, 202).mirror().addBox(-5F, -11F, -8F, 14F, 1F, 16F).mirror(false)
                .texOffs(110, 101).mirror().addBox(-4F, 2F, -4F, 8F, 20F, 8F).mirror(false),
                PartPose.offsetAndRotation(26F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(0, 101).mirror().addBox(-5F, 0F, -6F, 10F, 18F, 11F).mirror(false)
                .texOffs(62, 219).mirror().addBox(-6F, 17F, -6F, 11F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_claw = p_forearm_l.addOrReplaceChild("forearm_l_claw", CubeListBuilder.create()
                .texOffs(174, 202).addBox(-5F, -1F, -5F, 10F, 6F, 10F),
                PartPose.offsetAndRotation(0F, 21F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_claw_f0 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f0", CubeListBuilder.create()
                .texOffs(214, 202).addBox(-2F, 0F, -2F, 3F, 12F, 4F)
                .texOffs(218, 219).addBox(-2F, 12F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(-4F, 5F, -2F, 0F, 0F, 0.25F));
        PartDefinition p_forearm_l_claw_f1 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f1", CubeListBuilder.create()
                .texOffs(214, 202).addBox(-2F, 0F, -2F, 3F, 12F, 4F)
                .texOffs(218, 219).addBox(-2F, 12F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(4F, 5F, -2F, 0F, 0F, -0.25F));
        PartDefinition p_forearm_l_claw_f2 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f2", CubeListBuilder.create()
                .texOffs(214, 202).addBox(-2F, 0F, -2F, 3F, 12F, 4F)
                .texOffs(218, 219).addBox(-2F, 12F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(0F, 5F, 4F, 0.25F, 0F, 0F));
        PartDefinition p_cargo0 = p_torso.addOrReplaceChild("cargo0", CubeListBuilder.create()
                .texOffs(142, 101).addBox(-8F, -6F, -7F, 17F, 13F, 14F)
                .texOffs(166, 234).addBox(-7F, -1F, -8F, 15F, 2F, 1F)
                .texOffs(60, 202).addBox(-9F, -7F, -8F, 18F, 1F, 15F),
                PartPose.offsetAndRotation(-9F, -26F, 21F, 0F, 0F, 0F));
        PartDefinition p_cargo1 = p_torso.addOrReplaceChild("cargo1", CubeListBuilder.create()
                .texOffs(142, 101).addBox(-8F, -6F, -7F, 17F, 13F, 14F)
                .texOffs(166, 234).addBox(-7F, -1F, -8F, 15F, 2F, 1F)
                .texOffs(60, 202).addBox(-9F, -7F, -8F, 18F, 1F, 15F),
                PartPose.offsetAndRotation(9F, -26F, 21F, 0F, 0F, 0F));
        PartDefinition p_cargo2 = p_torso.addOrReplaceChild("cargo2", CubeListBuilder.create()
                .texOffs(0, 130).addBox(-8F, -6F, -7F, 17F, 13F, 14F)
                .texOffs(166, 234).addBox(-7F, -1F, -8F, 15F, 2F, 1F)
                .texOffs(60, 202).addBox(-9F, -7F, -8F, 18F, 1F, 15F),
                PartPose.offsetAndRotation(0F, -40F, 21F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.REVERSE).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(12F, 14F)
                .leg("hips/thigh_r", "hips/thigh_r/shin_r", "hips/thigh_r/shin_r/foot_r", -1, 0F, 1)
                .leg("hips/thigh_l", "hips/thigh_l/shin_l", "hips/thigh_l/shin_l/foot_l", 1, 3.1416F, 1)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
