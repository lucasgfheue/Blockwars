package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Magmaforge (forjamagma). */
@SuppressWarnings("unused")
public final class M_forjamagma {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("forjamagma"), "main");

    private M_forjamagma() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 146).addBox(-20F, -6F, -10F, 39F, 13F, 21F)
                .texOffs(0, 180).addBox(-21F, -6F, -12F, 42F, 6F, 23F)
                .texOffs(164, 231).addBox(-4F, -3F, -13F, 8F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(222, 65).addBox(-9F, 0F, -9F, 18F, 25F, 18F)
                .texOffs(0, 209).addBox(-10F, 3F, -13F, 21F, 17F, 5F)
                .texOffs(192, 146).addBox(-10F, 3F, -9F, 3F, 15F, 18F),
                PartPose.offsetAndRotation(-17F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(426, 0).addBox(-10F, 0F, -10F, 21F, 26F, 21F)
                .texOffs(16, 231).addBox(-9F, -6F, -14F, 18F, 10F, 5F)
                .texOffs(406, 209).addBox(-8F, 8F, 10F, 16F, 13F, 4F),
                PartPose.offsetAndRotation(0F, 25F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(354, 209).addBox(-6F, -1F, -6F, 13F, 5F, 13F)
                .texOffs(0, 65).addBox(-14F, 4F, -21F, 29F, 8F, 36F)
                .texOffs(344, 231).addBox(-13F, 6F, -23F, 26F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(222, 65).mirror().addBox(-9F, 0F, -9F, 18F, 25F, 18F).mirror(false)
                .texOffs(0, 209).mirror().addBox(-10F, 3F, -13F, 21F, 17F, 5F).mirror(false)
                .texOffs(192, 146).mirror().addBox(8F, 3F, -9F, 3F, 15F, 18F).mirror(false),
                PartPose.offsetAndRotation(17F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(426, 0).mirror().addBox(-10F, 0F, -10F, 21F, 26F, 21F).mirror(false)
                .texOffs(16, 231).mirror().addBox(-9F, -6F, -14F, 18F, 10F, 5F).mirror(false)
                .texOffs(406, 209).mirror().addBox(-8F, 8F, 10F, 16F, 13F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 25F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(354, 209).mirror().addBox(-6F, -1F, -6F, 13F, 5F, 13F).mirror(false)
                .texOffs(0, 65).mirror().addBox(-14F, 4F, -21F, 29F, 8F, 36F).mirror(false)
                .texOffs(344, 231).mirror().addBox(-13F, 6F, -23F, 26F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(356, 109).addBox(-16F, -13F, -11F, 33F, 13F, 22F)
                .texOffs(160, 0).addBox(-27F, -44F, -15F, 55F, 34F, 29F)
                .texOffs(0, 0).addBox(-22F, -42F, -18F, 44F, 29F, 36F)
                .texOffs(0, 109).addBox(-28F, -31F, -15F, 56F, 6F, 31F)
                .texOffs(310, 146).addBox(-19F, -47F, -13F, 38F, 5F, 25F)
                .texOffs(102, 231).addBox(-5F, -36F, -20F, 10F, 10F, 3F)
                .texOffs(446, 209).addBox(-8F, -39F, -19F, 16F, 16F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(0, 231).addBox(-2F, -13F, -2F, 4F, 13F, 4F),
                PartPose.offsetAndRotation(-25F, -44F, 5F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(0, 231).addBox(-2F, -13F, -2F, 4F, 13F, 4F),
                PartPose.offsetAndRotation(-25F, -44F, 13F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(0, 231).addBox(-2F, -13F, -2F, 4F, 13F, 4F),
                PartPose.offsetAndRotation(25F, -44F, 5F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(0, 231).addBox(-2F, -13F, -2F, 4F, 13F, 4F),
                PartPose.offsetAndRotation(25F, -44F, 13F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(62, 231).addBox(-5F, -5F, -5F, 10F, 5F, 10F)
                .texOffs(120, 146).addBox(-9F, -21F, -9F, 18F, 16F, 18F)
                .texOffs(398, 231).addBox(-6F, -14F, -10F, 13F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -47F, -3F, 0F, 0F, 0F));
        PartDefinition p_horn_r = p_head.addOrReplaceChild("horn_r", CubeListBuilder.create()
                .texOffs(278, 209).addBox(-2F, -16F, -2F, 4F, 16F, 4F)
                .texOffs(182, 231).addBox(-1F, -20F, 0F, 3F, 5F, 3F),
                PartPose.offsetAndRotation(-9F, -18F, 0F, 0.4F, 0F, -0.9F));
        PartDefinition p_horn_l = p_head.addOrReplaceChild("horn_l", CubeListBuilder.create()
                .texOffs(278, 209).mirror().addBox(-2F, -16F, -2F, 4F, 16F, 4F).mirror(false)
                .texOffs(182, 231).mirror().addBox(-1F, -20F, 0F, 3F, 5F, 3F).mirror(false),
                PartPose.offsetAndRotation(9F, -18F, 0F, 0.4F, 0F, 0.9F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(230, 180).addBox(-6F, -6F, -6F, 13F, 13F, 13F)
                .texOffs(228, 109).addBox(-13F, -13F, -12F, 21F, 13F, 23F)
                .texOffs(330, 180).addBox(-12F, -14F, -10F, 18F, 1F, 21F)
                .texOffs(316, 109).addBox(-5F, 3F, -5F, 10F, 26F, 10F),
                PartPose.offsetAndRotation(-35F, -38F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_r0 = p_shoulder_r.addOrReplaceChild("sspike_r0", CubeListBuilder.create()
                .texOffs(0, 231).addBox(-2F, -13F, -2F, 4F, 13F, 4F),
                PartPose.offsetAndRotation(-5F, -13F, -5F, 0F, 0F, -0.3F));
        PartDefinition p_sspike_r4 = p_shoulder_r.addOrReplaceChild("sspike_r4", CubeListBuilder.create()
                .texOffs(0, 231).addBox(-2F, -13F, -2F, 4F, 13F, 4F),
                PartPose.offsetAndRotation(-5F, -13F, 5F, 0F, 0F, -0.3F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(174, 109).addBox(-6F, 0F, -7F, 13F, 23F, 14F)
                .texOffs(294, 209).addBox(-7F, 22F, -8F, 14F, 3F, 16F),
                PartPose.offsetAndRotation(0F, 27F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_cannon = p_forearm_r.addOrReplaceChild("forearm_r_cannon", CubeListBuilder.create()
                .texOffs(328, 0).addBox(-9F, -9F, -26F, 18F, 18F, 31F)
                .texOffs(408, 180).addBox(-6F, -10F, -21F, 13F, 1F, 21F)
                .texOffs(234, 146).addBox(9F, -5F, -21F, 1F, 10F, 21F),
                PartPose.offsetAndRotation(0F, 31F, -3F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_barrel = p_forearm_r_cannon.addOrReplaceChild("forearm_r_cannon_barrel", CubeListBuilder.create()
                .texOffs(294, 65).addBox(-5F, -5F, -31F, 9F, 9F, 31F)
                .texOffs(52, 209).addBox(-7F, -7F, -36F, 14F, 14F, 8F),
                PartPose.offsetAndRotation(0F, 0F, -26F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_flash = p_forearm_r_cannon_barrel.addOrReplaceChild("forearm_r_cannon_flash", CubeListBuilder.create()
                .texOffs(282, 180).addBox(-4F, -4F, -16F, 8F, 8F, 16F)
                .texOffs(194, 231).addBox(-9F, -1F, -5F, 18F, 3F, 4F)
                .texOffs(96, 209).addBox(-1F, -9F, -5F, 3F, 18F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -36F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(230, 180).mirror().addBox(-6F, -6F, -6F, 13F, 13F, 13F).mirror(false)
                .texOffs(228, 109).mirror().addBox(-8F, -13F, -12F, 21F, 13F, 23F).mirror(false)
                .texOffs(330, 180).mirror().addBox(-6F, -14F, -10F, 18F, 1F, 21F).mirror(false)
                .texOffs(316, 109).mirror().addBox(-5F, 3F, -5F, 10F, 26F, 10F).mirror(false),
                PartPose.offsetAndRotation(35F, -38F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_l0 = p_shoulder_l.addOrReplaceChild("sspike_l0", CubeListBuilder.create()
                .texOffs(0, 231).mirror().addBox(-2F, -13F, -2F, 4F, 13F, 4F).mirror(false),
                PartPose.offsetAndRotation(5F, -13F, -5F, 0F, 0F, 0.3F));
        PartDefinition p_sspike_l4 = p_shoulder_l.addOrReplaceChild("sspike_l4", CubeListBuilder.create()
                .texOffs(0, 231).mirror().addBox(-2F, -13F, -2F, 4F, 13F, 4F).mirror(false),
                PartPose.offsetAndRotation(5F, -13F, 5F, 0F, 0F, 0.3F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(174, 109).mirror().addBox(-6F, 0F, -7F, 13F, 23F, 14F).mirror(false)
                .texOffs(294, 209).mirror().addBox(-7F, 22F, -8F, 14F, 3F, 16F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_fist = p_forearm_l.addOrReplaceChild("forearm_l_fist", CubeListBuilder.create()
                .texOffs(130, 65).addBox(-12F, -1F, -12F, 23F, 21F, 23F)
                .texOffs(238, 231).addBox(-10F, 14F, -13F, 21F, 5F, 1F)
                .texOffs(130, 180).addBox(-12F, -2F, -12F, 25F, 4F, 25F)
                .texOffs(110, 209).addBox(-9F, 20F, -9F, 18F, 3F, 18F),
                PartPose.offsetAndRotation(0F, 27F, -3F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(278, 146).addBox(-4F, -22F, -4F, 8F, 23F, 8F)
                .texOffs(128, 231).addBox(-5F, -24F, -5F, 9F, 3F, 9F)
                .texOffs(324, 231).addBox(-3F, -25F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(-16F, -42F, 23F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(278, 146).addBox(-4F, -22F, -4F, 8F, 23F, 8F)
                .texOffs(128, 231).addBox(-5F, -24F, -5F, 9F, 3F, 9F)
                .texOffs(324, 231).addBox(-3F, -25F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(16F, -42F, 23F, -0.15F, 0F, -0.1F));
        PartDefinition p_reactor = p_torso.addOrReplaceChild("reactor", CubeListBuilder.create()
                .texOffs(374, 65).addBox(-12F, -13F, -6F, 23F, 26F, 13F)
                .texOffs(480, 209).addBox(-5F, -8F, 6F, 10F, 16F, 1F)
                .texOffs(194, 209).addBox(-13F, -11F, -6F, 26F, 4F, 16F)
                .texOffs(194, 209).addBox(-13F, 7F, -6F, 26F, 4F, 16F),
                PartPose.offsetAndRotation(0F, -26F, 26F, 0F, 0F, 0F));
        PartDefinition p_reactor_ring = p_reactor.addOrReplaceChild("reactor_ring", CubeListBuilder.create()
                .texOffs(282, 231).addBox(-9F, -1F, -1F, 18F, 3F, 3F)
                .texOffs(182, 209).addBox(-1F, -9F, -1F, 3F, 18F, 3F),
                PartPose.offsetAndRotation(0F, 0F, 8F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2538F)
                .legLengths(12.35F, 13F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/reactor/reactor_ring", 2, 0.15F, 0)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
