package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Chronos (cronos). */
@SuppressWarnings("unused")
public final class M_cronos {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("cronos"), "main");

    private M_cronos() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_core = root.addOrReplaceChild("core", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-20F, -44F, -6F, 40F, 40F, 12F)
                .texOffs(104, 0).addBox(-16F, -40F, -7F, 32F, 32F, 1F)
                .texOffs(130, 80).addBox(-2F, -26F, -8F, 4F, 4F, 1F)
                .texOffs(148, 80).addBox(12F, -25F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(10F, -18F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(6F, -14F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(-1F, -12F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(-7F, -14F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(-12F, -18F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(-14F, -25F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(-12F, -32F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(-8F, -36F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(-1F, -38F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(6F, -36F, -8F, 2F, 2F, 1F)
                .texOffs(148, 80).addBox(10F, -32F, -8F, 2F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, 0F));
        PartDefinition p_hand_h = p_core.addOrReplaceChild("hand_h", CubeListBuilder.create()
                .texOffs(184, 52).addBox(-1F, -9F, 0F, 2F, 9F, 1F),
                PartPose.offsetAndRotation(0F, -24F, -8F, 0F, 0F, 0F));
        PartDefinition p_hand_m = p_core.addOrReplaceChild("hand_m", CubeListBuilder.create()
                .texOffs(62, 52).addBox(-1F, -14F, 0F, 2F, 14F, 1F),
                PartPose.offsetAndRotation(0F, -24F, -8F, 0F, 0F, 0F));
        PartDefinition p_gear = p_core.addOrReplaceChild("gear", CubeListBuilder.create()
                .texOffs(190, 52).addBox(-14F, -3F, -1F, 28F, 6F, 2F)
                .texOffs(170, 0).addBox(-3F, -14F, -1F, 6F, 28F, 2F),
                PartPose.offsetAndRotation(0F, -24F, 7F, 0F, 0F, 0F));
        PartDefinition p_head = p_core.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(160, 52).addBox(-3F, -4F, -3F, 6F, 4F, 6F),
                PartPose.offsetAndRotation(0F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_ring0 = p_core.addOrReplaceChild("ring0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 1.5708F, 0F, 0F));
        PartDefinition p_ring0_s0 = p_ring0.addOrReplaceChild("ring0_s0", CubeListBuilder.create()
                .texOffs(188, 73).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(30F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring0_s1 = p_ring0.addOrReplaceChild("ring0_s1", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(27F, 13F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring0_s2 = p_ring0.addOrReplaceChild("ring0_s2", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(19F, 23F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring0_s3 = p_ring0.addOrReplaceChild("ring0_s3", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(7F, 29F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring0_s4 = p_ring0.addOrReplaceChild("ring0_s4", CubeListBuilder.create()
                .texOffs(188, 73).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-7F, 29F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring0_s5 = p_ring0.addOrReplaceChild("ring0_s5", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-19F, 23F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring0_s6 = p_ring0.addOrReplaceChild("ring0_s6", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-27F, 13F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring0_s7 = p_ring0.addOrReplaceChild("ring0_s7", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-30F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring0_s8 = p_ring0.addOrReplaceChild("ring0_s8", CubeListBuilder.create()
                .texOffs(188, 73).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-27F, -13F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring0_s9 = p_ring0.addOrReplaceChild("ring0_s9", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-19F, -23F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring0_s10 = p_ring0.addOrReplaceChild("ring0_s10", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-7F, -29F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring0_s11 = p_ring0.addOrReplaceChild("ring0_s11", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(7F, -29F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring0_s12 = p_ring0.addOrReplaceChild("ring0_s12", CubeListBuilder.create()
                .texOffs(188, 73).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(19F, -23F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring0_s13 = p_ring0.addOrReplaceChild("ring0_s13", CubeListBuilder.create()
                .texOffs(0, 80).addBox(-8F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(27F, -13F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring1 = p_core.addOrReplaceChild("ring1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0.4F, 0.3F, 0F));
        PartDefinition p_ring1_s0 = p_ring1.addOrReplaceChild("ring1_s0", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(36F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring1_s1 = p_ring1.addOrReplaceChild("ring1_s1", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(32F, 16F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring1_s2 = p_ring1.addOrReplaceChild("ring1_s2", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(22F, 28F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring1_s3 = p_ring1.addOrReplaceChild("ring1_s3", CubeListBuilder.create()
                .texOffs(144, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(8F, 35F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring1_s4 = p_ring1.addOrReplaceChild("ring1_s4", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, 35F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring1_s5 = p_ring1.addOrReplaceChild("ring1_s5", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(-22F, 28F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring1_s6 = p_ring1.addOrReplaceChild("ring1_s6", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(-32F, 16F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring1_s7 = p_ring1.addOrReplaceChild("ring1_s7", CubeListBuilder.create()
                .texOffs(144, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(-36F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring1_s8 = p_ring1.addOrReplaceChild("ring1_s8", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(-32F, -16F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring1_s9 = p_ring1.addOrReplaceChild("ring1_s9", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(-22F, -28F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring1_s10 = p_ring1.addOrReplaceChild("ring1_s10", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, -35F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring1_s11 = p_ring1.addOrReplaceChild("ring1_s11", CubeListBuilder.create()
                .texOffs(144, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(8F, -35F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring1_s12 = p_ring1.addOrReplaceChild("ring1_s12", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(22F, -28F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring1_s13 = p_ring1.addOrReplaceChild("ring1_s13", CubeListBuilder.create()
                .texOffs(100, 73).addBox(-9F, -2F, -2F, 18F, 3F, 4F),
                PartPose.offsetAndRotation(32F, -16F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring2 = p_core.addOrReplaceChild("ring2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 1.5708F, 0.6F, 0F));
        PartDefinition p_ring2_s0 = p_ring2.addOrReplaceChild("ring2_s0", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(42F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring2_s1 = p_ring2.addOrReplaceChild("ring2_s1", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(38F, 18F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring2_s2 = p_ring2.addOrReplaceChild("ring2_s2", CubeListBuilder.create()
                .texOffs(50, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(26F, 33F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring2_s3 = p_ring2.addOrReplaceChild("ring2_s3", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(9F, 41F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring2_s4 = p_ring2.addOrReplaceChild("ring2_s4", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(-9F, 41F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring2_s5 = p_ring2.addOrReplaceChild("ring2_s5", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(-26F, 33F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring2_s6 = p_ring2.addOrReplaceChild("ring2_s6", CubeListBuilder.create()
                .texOffs(50, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(-38F, 18F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring2_s7 = p_ring2.addOrReplaceChild("ring2_s7", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(-42F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring2_s8 = p_ring2.addOrReplaceChild("ring2_s8", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(-38F, -18F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring2_s9 = p_ring2.addOrReplaceChild("ring2_s9", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(-26F, -33F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring2_s10 = p_ring2.addOrReplaceChild("ring2_s10", CubeListBuilder.create()
                .texOffs(50, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(-9F, -41F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring2_s11 = p_ring2.addOrReplaceChild("ring2_s11", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(9F, -41F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring2_s12 = p_ring2.addOrReplaceChild("ring2_s12", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(26F, -33F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring2_s13 = p_ring2.addOrReplaceChild("ring2_s13", CubeListBuilder.create()
                .texOffs(0, 73).addBox(-10F, -2F, -2F, 21F, 3F, 4F),
                PartPose.offsetAndRotation(38F, -18F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_float_r = p_core.addOrReplaceChild("float_r", CubeListBuilder.create()
                .texOffs(186, 0).addBox(-5F, -7F, -6F, 10F, 14F, 12F)
                .texOffs(38, 80).addBox(-3F, 7F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(-34F, -20F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter = p_float_r.addOrReplaceChild("float_r_emitter", CubeListBuilder.create()
                .texOffs(0, 52).addBox(-4F, -4F, -10F, 9F, 9F, 12F)
                .texOffs(100, 52).addBox(-1F, 4F, -17F, 2F, 2F, 10F)
                .texOffs(100, 52).addBox(-5F, -3F, -17F, 2F, 2F, 10F)
                .texOffs(100, 52).addBox(3F, -4F, -17F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 4F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter_orb = p_float_r_emitter.addOrReplaceChild("float_r_emitter_orb", CubeListBuilder.create()
                .texOffs(124, 52).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(148, 52).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_float_l = p_core.addOrReplaceChild("float_l", CubeListBuilder.create()
                .texOffs(186, 0).mirror().addBox(-5F, -7F, -6F, 10F, 14F, 12F).mirror(false)
                .texOffs(38, 80).addBox(-3F, 7F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(34F, -20F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_l_emitter = p_float_l.addOrReplaceChild("float_l_emitter", CubeListBuilder.create()
                .texOffs(0, 52).addBox(-4F, -4F, -10F, 9F, 9F, 12F)
                .texOffs(100, 52).addBox(-1F, 4F, -17F, 2F, 2F, 10F)
                .texOffs(100, 52).addBox(-5F, -3F, -17F, 2F, 2F, 10F)
                .texOffs(100, 52).addBox(3F, -4F, -17F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 4F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_l_emitter_orb = p_float_l_emitter.addOrReplaceChild("float_l_emitter_orb", CubeListBuilder.create()
                .texOffs(124, 52).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(148, 52).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_jet_r = p_core.addOrReplaceChild("jet_r", CubeListBuilder.create()
                .texOffs(68, 52).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(-8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_r = p_jet_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(42, 52).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_jet_l = p_core.addOrReplaceChild("jet_l", CubeListBuilder.create()
                .texOffs(68, 52).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_l = p_jet_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(42, 52).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_halo = p_core.addOrReplaceChild("halo", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -48F, 20F, 0F, 0F, 0F));
        PartDefinition p_halo_s0 = p_halo.addOrReplaceChild("halo_s0", CubeListBuilder.create()
                .texOffs(62, 80).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(18F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_halo_s1 = p_halo.addOrReplaceChild("halo_s1", CubeListBuilder.create()
                .texOffs(96, 80).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(13F, 13F, 0F, 0F, 0F, 2.3562F));
        PartDefinition p_halo_s2 = p_halo.addOrReplaceChild("halo_s2", CubeListBuilder.create()
                .texOffs(62, 80).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 3.1416F));
        PartDefinition p_halo_s3 = p_halo.addOrReplaceChild("halo_s3", CubeListBuilder.create()
                .texOffs(96, 80).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(-13F, 13F, 0F, 0F, 0F, 3.927F));
        PartDefinition p_halo_s4 = p_halo.addOrReplaceChild("halo_s4", CubeListBuilder.create()
                .texOffs(62, 80).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(-18F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_halo_s5 = p_halo.addOrReplaceChild("halo_s5", CubeListBuilder.create()
                .texOffs(96, 80).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(-13F, -13F, 0F, 0F, 0F, 5.4978F));
        PartDefinition p_halo_s6 = p_halo.addOrReplaceChild("halo_s6", CubeListBuilder.create()
                .texOffs(62, 80).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -18F, 0F, 0F, 0F, 6.2832F));
        PartDefinition p_halo_s7 = p_halo.addOrReplaceChild("halo_s7", CubeListBuilder.create()
                .texOffs(96, 80).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(13F, -13F, 0F, 0F, 0F, 7.0686F));
        PartDefinition p_antenna = p_core.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(230, 0).addBox(0F, -24F, 0F, 1F, 24F, 1F)
                .texOffs(140, 80).addBox(-1F, -25F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -40F, 4F, -0.2F, 0F, 0.15F));
        return LayerDefinition.create(mesh, 256, 128);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HOVER).parts("core", "core", "core/head").walkRate(0F)
                .arm("core/float_r", null, -1, true)
                .arm("core/float_l", null, 1, true)
                .spin("core/hand_h", 2, 0.01F, 0)
                .spin("core/hand_m", 2, 0.12F, 0)
                .spin("core/gear", 2, -0.05F, 0)
                .spin("core/ring0", 2, 0.05F, 2)
                .spin("core/ring1", 2, -0.07F, 2)
                .spin("core/ring2", 2, 0.09F, 2)
                .spin("core/halo", 2, 0.03F, 0)
                .spin("core/float_r/float_r_emitter/float_r_emitter_orb", 2, 0.25F, 0)
                .spin("core/float_l/float_l_emitter/float_l_emitter_orb", 2, 0.25F, 0)
                .sway("core/antenna", 2, 0.08F, 0F)
                .flame("core/jet_r/flame_r")
                .flame("core/jet_l/flame_l")
                .primary(Rig.MountKind.ARM, "core/float_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "core/float_l", null, null, null);
    }
}
