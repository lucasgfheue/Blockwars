package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Heliograph (espejo). */
@SuppressWarnings("unused")
public final class M_espejo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("espejo"), "main");

    private M_espejo() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_core = root.addOrReplaceChild("core", CubeListBuilder.create()
                .texOffs(0, 58).addBox(-22F, -26F, -22F, 44F, 12F, 44F)
                .texOffs(0, 114).addBox(-26F, -23F, -14F, 52F, 6F, 28F)
                .texOffs(0, 0).addBox(-14F, -23F, -26F, 28F, 6F, 52F)
                .texOffs(0, 148).addBox(-14F, -30F, -14F, 28F, 4F, 28F)
                .texOffs(0, 180).addBox(-8F, -36F, -10F, 16F, 6F, 16F)
                .texOffs(0, 212).addBox(-8F, -22F, -23F, 16F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -13F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_core.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 202).addBox(-3F, -4F, -3F, 6F, 4F, 6F),
                PartPose.offsetAndRotation(0F, -36F, 0F, 0F, 0F, 0F));
        PartDefinition p_ring0 = p_core.addOrReplaceChild("ring0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 1.5708F, 0F, 0F));
        PartDefinition p_ring0_s0 = p_ring0.addOrReplaceChild("ring0_s0", CubeListBuilder.create()
                .texOffs(136, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(34F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring0_s1 = p_ring0.addOrReplaceChild("ring0_s1", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(31F, 15F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring0_s2 = p_ring0.addOrReplaceChild("ring0_s2", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(21F, 27F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring0_s3 = p_ring0.addOrReplaceChild("ring0_s3", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(8F, 33F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring0_s4 = p_ring0.addOrReplaceChild("ring0_s4", CubeListBuilder.create()
                .texOffs(136, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, 33F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring0_s5 = p_ring0.addOrReplaceChild("ring0_s5", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-21F, 27F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring0_s6 = p_ring0.addOrReplaceChild("ring0_s6", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-31F, 15F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring0_s7 = p_ring0.addOrReplaceChild("ring0_s7", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-34F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring0_s8 = p_ring0.addOrReplaceChild("ring0_s8", CubeListBuilder.create()
                .texOffs(136, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-31F, -15F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring0_s9 = p_ring0.addOrReplaceChild("ring0_s9", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-21F, -27F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring0_s10 = p_ring0.addOrReplaceChild("ring0_s10", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, -33F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring0_s11 = p_ring0.addOrReplaceChild("ring0_s11", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(8F, -33F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring0_s12 = p_ring0.addOrReplaceChild("ring0_s12", CubeListBuilder.create()
                .texOffs(136, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(21F, -27F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring0_s13 = p_ring0.addOrReplaceChild("ring0_s13", CubeListBuilder.create()
                .texOffs(178, 202).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(31F, -15F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring1 = p_core.addOrReplaceChild("ring1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0.4F, 0.3F, 0F));
        PartDefinition p_ring1_s0 = p_ring1.addOrReplaceChild("ring1_s0", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(40F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring1_s1 = p_ring1.addOrReplaceChild("ring1_s1", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(36F, 17F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring1_s2 = p_ring1.addOrReplaceChild("ring1_s2", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(25F, 31F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring1_s3 = p_ring1.addOrReplaceChild("ring1_s3", CubeListBuilder.create()
                .texOffs(88, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(9F, 39F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring1_s4 = p_ring1.addOrReplaceChild("ring1_s4", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-9F, 39F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring1_s5 = p_ring1.addOrReplaceChild("ring1_s5", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-25F, 31F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring1_s6 = p_ring1.addOrReplaceChild("ring1_s6", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-36F, 17F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring1_s7 = p_ring1.addOrReplaceChild("ring1_s7", CubeListBuilder.create()
                .texOffs(88, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-40F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring1_s8 = p_ring1.addOrReplaceChild("ring1_s8", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-36F, -17F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring1_s9 = p_ring1.addOrReplaceChild("ring1_s9", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-25F, -31F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring1_s10 = p_ring1.addOrReplaceChild("ring1_s10", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-9F, -39F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring1_s11 = p_ring1.addOrReplaceChild("ring1_s11", CubeListBuilder.create()
                .texOffs(88, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(9F, -39F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring1_s12 = p_ring1.addOrReplaceChild("ring1_s12", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(25F, -31F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring1_s13 = p_ring1.addOrReplaceChild("ring1_s13", CubeListBuilder.create()
                .texOffs(40, 202).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(36F, -17F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_float_r = p_core.addOrReplaceChild("float_r", CubeListBuilder.create()
                .texOffs(112, 148).addBox(-5F, -7F, -6F, 10F, 14F, 12F)
                .texOffs(220, 202).addBox(-3F, 7F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(-38F, -20F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter = p_float_r.addOrReplaceChild("float_r_emitter", CubeListBuilder.create()
                .texOffs(64, 180).addBox(-4F, -4F, -10F, 9F, 9F, 12F)
                .texOffs(158, 180).addBox(-1F, 4F, -17F, 2F, 2F, 10F)
                .texOffs(158, 180).addBox(-5F, -3F, -17F, 2F, 2F, 10F)
                .texOffs(158, 180).addBox(3F, -4F, -17F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 4F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter_orb = p_float_r_emitter.addOrReplaceChild("float_r_emitter_orb", CubeListBuilder.create()
                .texOffs(182, 180).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(230, 180).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_float_l = p_core.addOrReplaceChild("float_l", CubeListBuilder.create()
                .texOffs(112, 148).mirror().addBox(-5F, -7F, -6F, 10F, 14F, 12F).mirror(false)
                .texOffs(220, 202).addBox(-3F, 7F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(38F, -20F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_l_emitter = p_float_l.addOrReplaceChild("float_l_emitter", CubeListBuilder.create()
                .texOffs(64, 180).addBox(-4F, -4F, -10F, 9F, 9F, 12F)
                .texOffs(158, 180).addBox(-1F, 4F, -17F, 2F, 2F, 10F)
                .texOffs(158, 180).addBox(-5F, -3F, -17F, 2F, 2F, 10F)
                .texOffs(158, 180).addBox(3F, -4F, -17F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 4F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_l_emitter_orb = p_float_l_emitter.addOrReplaceChild("float_l_emitter_orb", CubeListBuilder.create()
                .texOffs(182, 180).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(230, 180).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_jet_r = p_core.addOrReplaceChild("jet_r", CubeListBuilder.create()
                .texOffs(126, 180).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(-8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_r = p_jet_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(106, 180).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_jet_l = p_core.addOrReplaceChild("jet_l", CubeListBuilder.create()
                .texOffs(126, 180).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_l = p_jet_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(106, 180).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_dish_mast = p_core.addOrReplaceChild("dish_mast", CubeListBuilder.create()
                .texOffs(206, 148).addBox(-2F, -20F, -2F, 5F, 20F, 5F),
                PartPose.offsetAndRotation(0F, -36F, 20F, 0F, 0F, 0F));
        PartDefinition p_dish = p_dish_mast.addOrReplaceChild("dish", CubeListBuilder.create()
                .texOffs(176, 58).addBox(-16F, -16F, -2F, 32F, 32F, 3F)
                .texOffs(156, 148).addBox(-11F, -11F, -4F, 22F, 22F, 3F)
                .texOffs(206, 180).addBox(-1F, -1F, -11F, 2F, 2F, 10F)
                .texOffs(24, 202).addBox(-2F, -2F, -14F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, -20F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_antenna = p_core.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(226, 148).addBox(0F, -24F, 0F, 1F, 24F, 1F)
                .texOffs(34, 212).addBox(-1F, -25F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -40F, 4F, -0.2F, 0F, 0.15F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HOVER).parts("core", "core", "core/head").walkRate(0F)
                .arm("core/float_r", null, -1, true)
                .arm("core/float_l", null, 1, true)
                .spin("core/ring0", 2, 0.05F, 2)
                .spin("core/ring1", 2, -0.07F, 2)
                .spin("core/dish_mast", 1, 0.02F, 0)
                .spin("core/float_r/float_r_emitter/float_r_emitter_orb", 2, 0.25F, 0)
                .spin("core/float_l/float_l_emitter/float_l_emitter_orb", 2, 0.25F, 0)
                .sway("core/antenna", 2, 0.08F, 0F)
                .flame("core/jet_r/flame_r")
                .flame("core/jet_l/flame_l")
                .primary(Rig.MountKind.ARM, "core/float_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "core/float_l", null, null, null);
    }
}
