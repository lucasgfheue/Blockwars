package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Gale (vendaval). */
@SuppressWarnings("unused")
public final class M_vendaval {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("vendaval"), "main");

    private M_vendaval() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 79).addBox(-10F, -5F, -8F, 21F, 10F, 15F)
                .texOffs(60, 104).addBox(-11F, -4F, -9F, 23F, 5F, 17F)
                .texOffs(0, 178).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(182, 0).addBox(-3F, 0F, -3F, 7F, 29F, 7F)
                .texOffs(144, 79).addBox(-4F, 2F, -6F, 9F, 21F, 4F)
                .texOffs(170, 79).addBox(-4F, 2F, -3F, 2F, 18F, 7F),
                PartPose.offsetAndRotation(-9F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(28, 0).addBox(-4F, 0F, -4F, 9F, 30F, 9F)
                .texOffs(122, 165).addBox(-3F, -5F, -7F, 7F, 8F, 4F)
                .texOffs(0, 147).addBox(-2F, 9F, 4F, 5F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(208, 165).addBox(-2F, -1F, -2F, 5F, 4F, 5F)
                .texOffs(0, 104).addBox(-7F, 3F, -10F, 13F, 6F, 17F)
                .texOffs(46, 178).addBox(-6F, 5F, -11F, 11F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 30F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(182, 0).mirror().addBox(-3F, 0F, -3F, 7F, 29F, 7F).mirror(false)
                .texOffs(144, 79).mirror().addBox(-4F, 2F, -6F, 9F, 21F, 4F).mirror(false)
                .texOffs(170, 79).mirror().addBox(2F, 2F, -3F, 2F, 18F, 7F).mirror(false),
                PartPose.offsetAndRotation(9F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(28, 0).mirror().addBox(-4F, 0F, -4F, 9F, 30F, 9F).mirror(false)
                .texOffs(122, 165).mirror().addBox(-3F, -5F, -7F, 7F, 8F, 4F).mirror(false)
                .texOffs(0, 147).mirror().addBox(-2F, 9F, 4F, 5F, 15F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(208, 165).mirror().addBox(-2F, -1F, -2F, 5F, 4F, 5F).mirror(false)
                .texOffs(0, 104).mirror().addBox(-7F, 3F, -10F, 13F, 6F, 17F).mirror(false)
                .texOffs(46, 178).mirror().addBox(-6F, 5F, -11F, 11F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 30F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(140, 104).addBox(-9F, -10F, -6F, 17F, 10F, 11F)
                .texOffs(0, 49).addBox(-12F, -20F, -8F, 25F, 13F, 17F)
                .texOffs(64, 0).addBox(-19F, -31F, -11F, 38F, 15F, 21F)
                .texOffs(80, 127).addBox(-11F, -32F, -7F, 23F, 4F, 15F)
                .texOffs(202, 147).addBox(-10F, -28F, -14F, 19F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(42, 165).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(138, 49).addBox(-7F, -15F, -8F, 13F, 11F, 15F)
                .texOffs(154, 147).addBox(-6F, -16F, -6F, 11F, 1F, 13F)
                .texOffs(70, 178).addBox(-6F, -11F, -8F, 11F, 3F, 1F)
                .texOffs(94, 178).addBox(-5F, -7F, -8F, 10F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -32F, -2F, 0F, 0F, 0F));
        PartDefinition p_crest = p_head.addOrReplaceChild("crest", CubeListBuilder.create()
                .texOffs(228, 104).addBox(-1F, -15F, -3F, 2F, 15F, 6F)
                .texOffs(144, 165).addBox(0F, -13F, -4F, 1F, 11F, 1F),
                PartPose.offsetAndRotation(0F, -15F, -2F, -0.8F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(240, 79).addBox(0F, -23F, 0F, 1F, 23F, 1F)
                .texOffs(116, 178).addBox(-1F, -24F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -11F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(0, 127).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(188, 79).addBox(-8F, -9F, -7F, 13F, 11F, 13F)
                .texOffs(194, 127).addBox(-8F, -5F, -7F, 14F, 4F, 14F)
                .texOffs(112, 79).addBox(-4F, 2F, -4F, 8F, 17F, 8F),
                PartPose.offsetAndRotation(-25F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(72, 79).addBox(-5F, 0F, -5F, 10F, 15F, 10F)
                .texOffs(0, 165).addBox(-5F, 14F, -6F, 10F, 2F, 11F),
                PartPose.offsetAndRotation(0F, 18F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_emitter = p_forearm_r.addOrReplaceChild("forearm_r_emitter", CubeListBuilder.create()
                .texOffs(40, 127).addBox(-4F, -4F, -10F, 9F, 9F, 11F)
                .texOffs(74, 165).addBox(-1F, 4F, -16F, 2F, 2F, 10F)
                .texOffs(74, 165).addBox(-5F, -3F, -16F, 2F, 2F, 10F)
                .texOffs(74, 165).addBox(3F, -3F, -16F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 20F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_emitter_orb = p_forearm_r_emitter.addOrReplaceChild("forearm_r_emitter_orb", CubeListBuilder.create()
                .texOffs(98, 165).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(148, 165).addBox(-1F, -4F, -1F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -14F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(0, 127).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(188, 79).mirror().addBox(-6F, -9F, -7F, 13F, 11F, 13F).mirror(false)
                .texOffs(194, 127).mirror().addBox(-6F, -5F, -7F, 14F, 4F, 14F).mirror(false)
                .texOffs(112, 79).mirror().addBox(-4F, 2F, -4F, 8F, 17F, 8F).mirror(false),
                PartPose.offsetAndRotation(25F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(72, 79).mirror().addBox(-5F, 0F, -5F, 10F, 15F, 10F).mirror(false)
                .texOffs(0, 165).mirror().addBox(-5F, 14F, -6F, 10F, 2F, 11F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_gun = p_forearm_l.addOrReplaceChild("forearm_l_gun", CubeListBuilder.create()
                .texOffs(84, 49).addBox(-4F, -4F, -17F, 8F, 9F, 19F)
                .texOffs(16, 147).addBox(-3F, -6F, -15F, 6F, 2F, 15F)
                .texOffs(188, 165).addBox(-2F, 3F, -3F, 4F, 4F, 6F),
                PartPose.offsetAndRotation(0F, 20F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_barrel = p_forearm_l_gun.addOrReplaceChild("forearm_l_gun_barrel", CubeListBuilder.create()
                .texOffs(156, 127).addBox(-2F, -2F, -15F, 4F, 4F, 15F)
                .texOffs(228, 165).addBox(-3F, -3F, -17F, 6F, 6F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -17F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_flash = p_forearm_l_gun_barrel.addOrReplaceChild("forearm_l_gun_flash", CubeListBuilder.create()
                .texOffs(58, 147).addBox(-3F, -3F, -11F, 6F, 6F, 11F)
                .texOffs(14, 178).addBox(-7F, -1F, -3F, 13F, 2F, 3F)
                .texOffs(144, 147).addBox(-1F, -7F, -3F, 2F, 13F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -17F, 0F, 0F, 0F));
        PartDefinition p_wing0_r = p_torso.addOrReplaceChild("wing0_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-1F, -38F, -2F, 3F, 38F, 11F)
                .texOffs(92, 147).addBox(-2F, -38F, -2F, 4F, 4F, 12F)
                .texOffs(210, 0).addBox(0F, -35F, 9F, 1F, 32F, 1F),
                PartPose.offsetAndRotation(-6F, -32F, 12F, 0.4F, -0.35F, -0.65F));
        PartDefinition p_wing0_l = p_torso.addOrReplaceChild("wing0_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-1F, -38F, -2F, 3F, 38F, 11F).mirror(false)
                .texOffs(92, 147).mirror().addBox(-2F, -38F, -2F, 4F, 4F, 12F).mirror(false)
                .texOffs(210, 0).mirror().addBox(0F, -35F, 9F, 1F, 32F, 1F).mirror(false),
                PartPose.offsetAndRotation(6F, -32F, 12F, 0.4F, 0.35F, 0.65F));
        PartDefinition p_thr_r = p_torso.addOrReplaceChild("thr_r", CubeListBuilder.create()
                .texOffs(196, 104).addBox(-4F, -7F, -4F, 8F, 13F, 8F)
                .texOffs(160, 165).addBox(-3F, 7F, -3F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(-11F, -21F, 14F, 0.35F, 0F, 0F));
        PartDefinition p_flame_r = p_thr_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(124, 147).addBox(-2F, 0F, -2F, 5F, 11F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition p_thr_l = p_torso.addOrReplaceChild("thr_l", CubeListBuilder.create()
                .texOffs(196, 104).addBox(-4F, -7F, -4F, 8F, 13F, 8F)
                .texOffs(160, 165).addBox(-3F, 7F, -3F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(11F, -21F, 14F, 0.35F, 0F, 0F));
        PartDefinition p_flame_l = p_thr_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(124, 147).addBox(-2F, 0F, -2F, 5F, 11F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3474F)
                .legLengths(14.725F, 15.2F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .wing("hips/torso/wing0_r", -1)
                .wing("hips/torso/wing0_l", 1)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
