package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Gale (vendaval). */
@SuppressWarnings("unused")
public final class M_vendaval {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("vendaval"), "main");

    private M_vendaval() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-44,0,0,0,0/0,79,-10,-5,-8,21,10,15/60,104,-11,-4,-9,23,5,17/0,178,-3,-2,-10,6,6,1;thigh_r,-1,-9,-44,0,0,0,0/"
                + "182,0,-3,0,-3,7,29,7/144,79,-4,2,-6,9,21,4/170,79,-4,2,-3,2,18,7;shin_r,1,0,29,0,0,0,0/28,0,-4,0,-4,9,30,9/"
                + "122,165,-3,-5,-7,7,8,4/0,147,-2,9,4,5,15,3;foot_r,2,0,30,0,0,0,0/208,165,-2,-1,-2,5,4,5/0,104,-7,3,-10,13,6,17/"
                + "46,178,-6,5,-11,11,3,1;thigh_l,-1,9,-44,0,0,0,0/!182,0,-3,0,-3,7,29,7/!144,79,-4,2,-6,9,21,4/!170,79,2,2,-3,2,18,7;"
                + "shin_l,4,0,29,0,0,0,0/!28,0,-4,0,-4,9,30,9/!122,165,-3,-5,-7,7,8,4/!0,147,-2,9,4,5,15,3;foot_l,5,0,30,0,0,0,0/"
                + "!208,165,-2,-1,-2,5,4,5/!0,104,-7,3,-10,13,6,17/!46,178,-6,5,-11,11,3,1;torso,0,0,-5,0,0,0,0/140,104,-9,-10,-6,17,10,11/"
                + "0,49,-12,-20,-8,25,13,17/64,0,-19,-31,-11,38,15,21/80,127,-11,-32,-7,23,4,15/202,147,-10,-28,-14,19,10,3;"
                + "head,7,0,-32,-2,0,0,0/42,165,-4,-4,-4,8,4,8/138,49,-7,-15,-8,13,11,15/154,147,-6,-16,-6,11,1,13/70,178,-6,-11,-8,11,3,1/"
                + "94,178,-5,-7,-8,10,3,1;crest,8,0,-15,-2,-0.8,0,0/228,104,-1,-15,-3,2,15,6/144,165,0,-13,-4,1,11,1;antenna,8,5,-11,4,-0.2,0,0.15/"
                + "240,79,0,-23,0,1,23,1/116,178,-1,-24,-1,2,2,2;shoulder_r,7,-25,-26,0,0,0,0/0,127,-5,-5,-5,10,10,10/188,79,-8,-9,-7,13,11,13/"
                + "194,127,-8,-5,-7,14,4,14/112,79,-4,2,-4,8,17,8;forearm_r,11,0,18,0,-0.25,0,0/72,79,-5,0,-5,10,15,10/0,165,-5,14,-6,10,2,11;"
                + "forearm_r_emitter,12,0,20,-2,0,0,0/40,127,-4,-4,-10,9,9,11/74,165,-1,4,-16,2,2,10/74,165,-5,-3,-16,2,2,10/"
                + "74,165,3,-3,-16,2,2,10;forearm_r_emitter_orb,13,0,0,-14,0.7854,0.7854,0/98,165,-3,-3,-3,6,6,6/148,165,-1,-4,-1,3,8,3;"
                + "shoulder_l,7,25,-26,0,0,0,0/!0,127,-5,-5,-5,10,10,10/!188,79,-6,-9,-7,13,11,13/!194,127,-6,-5,-7,14,4,14/"
                + "!112,79,-4,2,-4,8,17,8;forearm_l,15,0,18,0,-0.25,0,0/!72,79,-5,0,-5,10,15,10/!0,165,-5,14,-6,10,2,11;"
                + "forearm_l_gun,16,0,20,-2,0,0,0/84,49,-4,-4,-17,8,9,19/16,147,-3,-6,-15,6,2,15/188,165,-2,3,-3,4,4,6;forearm_l_gun_barrel,17,0,-1,-17,0,0,0/"
                + "156,127,-2,-2,-15,4,4,15/228,165,-3,-3,-17,6,6,3;forearm_l_gun_flash,18,0,0,-17,0,0,0/58,147,-3,-3,-11,6,6,11/"
                + "14,178,-7,-1,-3,13,2,3/144,147,-1,-7,-3,2,13,3;wing0_r,7,-6,-32,12,0.4,-0.35,-0.65/0,0,-1,-38,-2,3,38,11/"
                + "92,147,-2,-38,-2,4,4,12/210,0,0,-35,9,1,32,1;wing0_l,7,6,-32,12,0.4,0.35,0.65/!0,0,-1,-38,-2,3,38,11/"
                + "!92,147,-2,-38,-2,4,4,12/!210,0,0,-35,9,1,32,1;thr_r,7,-11,-21,14,0.35,0,0/196,104,-4,-7,-4,8,13,8/160,165,-3,7,-3,7,3,7;"
                + "flame_r,22,0,10,0,0,0,0/124,147,-2,0,-2,5,11,5;thr_l,7,11,-21,14,0.35,0,0/196,104,-4,-7,-4,8,13,8/160,165,-3,7,-3,7,3,7;"
                + "flame_l,24,0,10,0,0,0,0/124,147,-2,0,-2,5,11,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3474F)
                .legLengths(14.725F, 15.2F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .wing("hips/torso/wing0_r", -1)
                .wing("hips/torso/wing0_l", 1)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
