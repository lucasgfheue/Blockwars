package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Executioner (verdugo). */
@SuppressWarnings("unused")
public final class M_verdugo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("verdugo"), "main");

    private M_verdugo() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-29,0,0,0,0/218,62,-16,-6,-9,33,11,18/82,98,-18,-5,-10,35,6,20/132,143,-3,-2,-11,7,7,1;thigh_r,-1,-14,-29,0,0,0,0/"
                + "0,62,-8,0,-8,15,21,15/444,98,-9,2,-11,18,15,4/380,62,-9,2,-8,2,13,15;shin_r,1,0,21,0,0,0,0/314,0,-9,0,-9,18,22,18/"
                + "0,143,-8,-6,-12,15,9,4/330,125,-7,7,9,13,11,3;foot_r,2,0,22,0,0,0,0/246,125,-5,-1,-5,11,4,11/386,0,-12,3,-18,24,7,30/"
                + "174,143,-11,6,-19,22,3,1;thigh_l,-1,14,-29,0,0,0,0/!0,62,-8,0,-8,15,21,15/!444,98,-9,2,-11,18,15,4/!380,62,7,2,-8,2,13,15;"
                + "shin_l,4,0,21,0,0,0,0/!314,0,-9,0,-9,18,22,18/!0,143,-8,-6,-12,15,9,4/!330,125,-7,7,9,13,11,3;foot_l,5,0,22,0,0,0,0/"
                + "!246,125,-5,-1,-5,11,4,11/!386,0,-12,3,-18,24,7,30/!174,143,-11,6,-19,22,3,1;torso,0,0,-6,0,0,0,0/414,62,-13,-11,-8,27,11,16/"
                + "126,0,-24,-40,-13,48,31,26/0,125,-17,-33,-14,34,17,1/192,98,-18,-38,-11,36,4,21/374,125,-15,-26,13,29,12,1;"
                + "tspike_r0,7,-22,-37,4,0.5,0,-0.5/362,125,-2,-11,-2,3,11,3;tspike_r1,7,-22,-37,11,0.5,0,-0.5/362,125,-2,-11,-2,3,11,3;"
                + "tspike_l0,7,22,-37,4,0.5,0,0.5/362,125,-2,-11,-2,3,11,3;tspike_l1,7,22,-37,11,0.5,0,0.5/362,125,-2,-11,-2,3,11,3;"
                + "head,7,0,-40,-2,0,0,0/38,143,-4,-4,-4,9,4,9/320,62,-8,-19,-8,15,13,15/164,143,-6,-15,-8,4,4,1/164,143,2,-15,-8,4,4,1/"
                + "244,143,-5,-14,-9,2,2,1/244,143,3,-14,-9,2,2,1;jaw,12,0,-6,-2,0,0,0/96,125,-7,0,-9,13,4,13/220,143,-6,-1,-9,11,2,1;"
                + "xhorn_r,12,-8,-13,2,0.5,-0.6,0/74,143,-1,-1,0,2,2,11;xhorn_l,12,8,-13,2,0.5,0.6,0/!74,143,-1,-1,0,2,2,11;"
                + "shoulder_r,7,-31,-32,0,0,0,0/306,98,-6,-6,-6,11,11,11/106,62,-11,-11,-10,18,11,20/378,98,-10,-12,-9,15,1,18/"
                + "182,62,-4,2,-4,9,22,9;sspike_r0,16,-4,-11,-4,0,0,-0.3/362,125,-2,-11,-2,3,11,3;sspike_r4,16,-4,-11,4,0,0,-0.3/"
                + "362,125,-2,-11,-2,3,11,3;forearm_r,16,0,23,0,-0.25,0,0/60,62,-6,0,-6,11,20,12/148,125,-6,19,-7,12,2,13;"
                + "forearm_r_saw,19,0,25,-2,0,0,0/0,98,-4,-4,-15,9,9,18/290,125,-3,-6,-13,7,1,13;forearm_r_saw_disc,20,0,0,-20,0,0,0/"
                + "0,0,-1,-15,-15,2,31,31/70,125,-2,-4,-4,4,9,9;forearm_r_saw_disc2,21,0,0,0,0.7854,0,0/66,0,-1,-14,-14,1,29,29;"
                + "shoulder_l,7,31,-32,0,0,0,0/!306,98,-6,-6,-6,11,11,11/!106,62,-7,-11,-10,18,11,20/!378,98,-6,-12,-9,15,1,18/"
                + "!182,62,-4,2,-4,9,22,9;sspike_l0,23,4,-11,-4,0,0,0.3/!362,125,-2,-11,-2,3,11,3;sspike_l4,23,4,-11,4,0,0,0.3/"
                + "!362,125,-2,-11,-2,3,11,3;forearm_l,23,0,23,0,-0.25,0,0/!60,62,-6,0,-6,11,20,12/!148,125,-6,19,-7,12,2,13;"
                + "forearm_l_saw,26,0,25,-2,0,0,0/0,98,-4,-4,-15,9,9,18/290,125,-3,-6,-13,7,1,13;forearm_l_saw_disc,27,0,0,-20,0,0,0/"
                + "0,0,-1,-15,-15,2,31,31/70,125,-2,-4,-4,4,9,9;forearm_l_saw_disc2,28,0,0,0,0.7854,0,0/66,0,-1,-14,-14,1,29,29;"
                + "exhaust,7,12,-40,20,0,0,0/274,0,-5,-33,-5,10,35,10/434,125,-6,-8,-6,11,2,11/434,125,-6,-25,-6,11,2,11/"
                + "198,125,-6,-36,-6,12,3,12;flame_exh,30,0,-35,0,3.1416,0,0/350,98,-3,0,-3,7,13,7;stack_r,7,-15,-35,18,-0.15,0,0.1/"
                + "54,98,-3,-19,-3,7,20,7/100,143,-4,-20,-4,8,2,8/148,143,-2,-21,-2,4,1,4;stack_l,7,15,-35,18,-0.15,0,-0.1/"
                + "54,98,-3,-19,-3,7,20,7/100,143,-4,-20,-4,8,2,8/148,143,-2,-21,-2,4,1,4");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(10.45F, 11F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_saw/forearm_r_saw_disc", 0, 0.8F, 3)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_saw/forearm_l_saw_disc", 0, 0.8F, 3)
                .flame("hips/torso/exhaust/flame_exh")
                .jaw("hips/torso/head/jaw")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .primaryTwin(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
