package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Executioner (verdugo). */
@SuppressWarnings("unused")
public final class M_verdugo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("verdugo"), "main");

    private M_verdugo() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(218, 62).addBox(-16F, -6F, -9F, 33F, 11F, 18F)
                .texOffs(82, 98).addBox(-18F, -5F, -10F, 35F, 6F, 20F)
                .texOffs(132, 143).addBox(-3F, -2F, -11F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(0, 62).addBox(-8F, 0F, -8F, 15F, 21F, 15F)
                .texOffs(444, 98).addBox(-9F, 2F, -11F, 18F, 15F, 4F)
                .texOffs(380, 62).addBox(-9F, 2F, -8F, 2F, 13F, 15F),
                PartPose.offsetAndRotation(-14F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(314, 0).addBox(-9F, 0F, -9F, 18F, 22F, 18F)
                .texOffs(0, 143).addBox(-8F, -6F, -12F, 15F, 9F, 4F)
                .texOffs(330, 125).addBox(-7F, 7F, 9F, 13F, 11F, 3F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(246, 125).addBox(-5F, -1F, -5F, 11F, 4F, 11F)
                .texOffs(386, 0).addBox(-12F, 3F, -18F, 24F, 7F, 30F)
                .texOffs(174, 143).addBox(-11F, 6F, -19F, 22F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(0, 62).mirror().addBox(-8F, 0F, -8F, 15F, 21F, 15F).mirror(false)
                .texOffs(444, 98).mirror().addBox(-9F, 2F, -11F, 18F, 15F, 4F).mirror(false)
                .texOffs(380, 62).mirror().addBox(7F, 2F, -8F, 2F, 13F, 15F).mirror(false),
                PartPose.offsetAndRotation(14F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(314, 0).mirror().addBox(-9F, 0F, -9F, 18F, 22F, 18F).mirror(false)
                .texOffs(0, 143).mirror().addBox(-8F, -6F, -12F, 15F, 9F, 4F).mirror(false)
                .texOffs(330, 125).mirror().addBox(-7F, 7F, 9F, 13F, 11F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(246, 125).mirror().addBox(-5F, -1F, -5F, 11F, 4F, 11F).mirror(false)
                .texOffs(386, 0).mirror().addBox(-12F, 3F, -18F, 24F, 7F, 30F).mirror(false)
                .texOffs(174, 143).mirror().addBox(-11F, 6F, -19F, 22F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(414, 62).addBox(-13F, -11F, -8F, 27F, 11F, 16F)
                .texOffs(126, 0).addBox(-24F, -40F, -13F, 48F, 31F, 26F)
                .texOffs(0, 125).addBox(-17F, -33F, -14F, 34F, 17F, 1F)
                .texOffs(192, 98).addBox(-18F, -38F, -11F, 36F, 4F, 21F)
                .texOffs(374, 125).addBox(-15F, -26F, 13F, 29F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(362, 125).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(-22F, -37F, 4F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(362, 125).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(-22F, -37F, 11F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(362, 125).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(22F, -37F, 4F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(362, 125).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(22F, -37F, 11F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(38, 143).addBox(-4F, -4F, -4F, 9F, 4F, 9F)
                .texOffs(320, 62).addBox(-8F, -19F, -8F, 15F, 13F, 15F)
                .texOffs(164, 143).addBox(-6F, -15F, -8F, 4F, 4F, 1F)
                .texOffs(164, 143).addBox(2F, -15F, -8F, 4F, 4F, 1F)
                .texOffs(244, 143).addBox(-5F, -14F, -9F, 2F, 2F, 1F)
                .texOffs(244, 143).addBox(3F, -14F, -9F, 2F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -40F, -2F, 0F, 0F, 0F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(96, 125).addBox(-7F, 0F, -9F, 13F, 4F, 13F)
                .texOffs(220, 143).addBox(-6F, -1F, -9F, 11F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -6F, -2F, 0F, 0F, 0F));
        PartDefinition p_xhorn_r = p_head.addOrReplaceChild("xhorn_r", CubeListBuilder.create()
                .texOffs(74, 143).addBox(-1F, -1F, 0F, 2F, 2F, 11F),
                PartPose.offsetAndRotation(-8F, -13F, 2F, 0.5F, -0.6F, 0F));
        PartDefinition p_xhorn_l = p_head.addOrReplaceChild("xhorn_l", CubeListBuilder.create()
                .texOffs(74, 143).mirror().addBox(-1F, -1F, 0F, 2F, 2F, 11F).mirror(false),
                PartPose.offsetAndRotation(8F, -13F, 2F, 0.5F, 0.6F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(306, 98).addBox(-6F, -6F, -6F, 11F, 11F, 11F)
                .texOffs(106, 62).addBox(-11F, -11F, -10F, 18F, 11F, 20F)
                .texOffs(378, 98).addBox(-10F, -12F, -9F, 15F, 1F, 18F)
                .texOffs(182, 62).addBox(-4F, 2F, -4F, 9F, 22F, 9F),
                PartPose.offsetAndRotation(-31F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_r0 = p_shoulder_r.addOrReplaceChild("sspike_r0", CubeListBuilder.create()
                .texOffs(362, 125).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(-4F, -11F, -4F, 0F, 0F, -0.3F));
        PartDefinition p_sspike_r4 = p_shoulder_r.addOrReplaceChild("sspike_r4", CubeListBuilder.create()
                .texOffs(362, 125).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(-4F, -11F, 4F, 0F, 0F, -0.3F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(60, 62).addBox(-6F, 0F, -6F, 11F, 20F, 12F)
                .texOffs(148, 125).addBox(-6F, 19F, -7F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_saw = p_forearm_r.addOrReplaceChild("forearm_r_saw", CubeListBuilder.create()
                .texOffs(0, 98).addBox(-4F, -4F, -15F, 9F, 9F, 18F)
                .texOffs(290, 125).addBox(-3F, -6F, -13F, 7F, 1F, 13F),
                PartPose.offsetAndRotation(0F, 25F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_saw_disc = p_forearm_r_saw.addOrReplaceChild("forearm_r_saw_disc", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-1F, -15F, -15F, 2F, 31F, 31F)
                .texOffs(70, 125).addBox(-2F, -4F, -4F, 4F, 9F, 9F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_saw_disc2 = p_forearm_r_saw_disc.addOrReplaceChild("forearm_r_saw_disc2", CubeListBuilder.create()
                .texOffs(66, 0).addBox(-1F, -14F, -14F, 1F, 29F, 29F),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0.7854F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(306, 98).mirror().addBox(-6F, -6F, -6F, 11F, 11F, 11F).mirror(false)
                .texOffs(106, 62).mirror().addBox(-7F, -11F, -10F, 18F, 11F, 20F).mirror(false)
                .texOffs(378, 98).mirror().addBox(-6F, -12F, -9F, 15F, 1F, 18F).mirror(false)
                .texOffs(182, 62).mirror().addBox(-4F, 2F, -4F, 9F, 22F, 9F).mirror(false),
                PartPose.offsetAndRotation(31F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_l0 = p_shoulder_l.addOrReplaceChild("sspike_l0", CubeListBuilder.create()
                .texOffs(362, 125).mirror().addBox(-2F, -11F, -2F, 3F, 11F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -11F, -4F, 0F, 0F, 0.3F));
        PartDefinition p_sspike_l4 = p_shoulder_l.addOrReplaceChild("sspike_l4", CubeListBuilder.create()
                .texOffs(362, 125).mirror().addBox(-2F, -11F, -2F, 3F, 11F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -11F, 4F, 0F, 0F, 0.3F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(60, 62).mirror().addBox(-6F, 0F, -6F, 11F, 20F, 12F).mirror(false)
                .texOffs(148, 125).mirror().addBox(-6F, 19F, -7F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_saw = p_forearm_l.addOrReplaceChild("forearm_l_saw", CubeListBuilder.create()
                .texOffs(0, 98).addBox(-4F, -4F, -15F, 9F, 9F, 18F)
                .texOffs(290, 125).addBox(-3F, -6F, -13F, 7F, 1F, 13F),
                PartPose.offsetAndRotation(0F, 25F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_saw_disc = p_forearm_l_saw.addOrReplaceChild("forearm_l_saw_disc", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-1F, -15F, -15F, 2F, 31F, 31F)
                .texOffs(70, 125).addBox(-2F, -4F, -4F, 4F, 9F, 9F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_saw_disc2 = p_forearm_l_saw_disc.addOrReplaceChild("forearm_l_saw_disc2", CubeListBuilder.create()
                .texOffs(66, 0).addBox(-1F, -14F, -14F, 1F, 29F, 29F),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0.7854F, 0F, 0F));
        PartDefinition p_exhaust = p_torso.addOrReplaceChild("exhaust", CubeListBuilder.create()
                .texOffs(274, 0).addBox(-5F, -33F, -5F, 10F, 35F, 10F)
                .texOffs(434, 125).addBox(-6F, -8F, -6F, 11F, 2F, 11F)
                .texOffs(434, 125).addBox(-6F, -25F, -6F, 11F, 2F, 11F)
                .texOffs(198, 125).addBox(-6F, -36F, -6F, 12F, 3F, 12F),
                PartPose.offsetAndRotation(12F, -40F, 20F, 0F, 0F, 0F));
        PartDefinition p_flame_exh = p_exhaust.addOrReplaceChild("flame_exh", CubeListBuilder.create()
                .texOffs(350, 98).addBox(-3F, 0F, -3F, 7F, 13F, 7F),
                PartPose.offsetAndRotation(0F, -35F, 0F, 3.1416F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(54, 98).addBox(-3F, -19F, -3F, 7F, 20F, 7F)
                .texOffs(100, 143).addBox(-4F, -20F, -4F, 8F, 2F, 8F)
                .texOffs(148, 143).addBox(-2F, -21F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-15F, -35F, 18F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(54, 98).addBox(-3F, -19F, -3F, 7F, 20F, 7F)
                .texOffs(100, 143).addBox(-4F, -20F, -4F, 8F, 2F, 8F)
                .texOffs(148, 143).addBox(-2F, -21F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(15F, -35F, 18F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(10.45F, 11F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_saw/forearm_r_saw_disc", 0, 0.8F, 3)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_saw/forearm_l_saw_disc", 0, 0.8F, 3)
                .flame("hips/torso/exhaust/flame_exh")
                .jaw("hips/torso/head/jaw")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .primaryTwin(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
