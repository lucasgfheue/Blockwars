package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Foreman (capataz). */
@SuppressWarnings("unused")
public final class M_capataz {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("capataz"), "main");

    private M_capataz() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-29,0,0,0,0/316,57,-16,-6,-9,33,11,18/164,92,-18,-5,-10,35,6,20/38,158,-3,-2,-11,7,7,1;skirt0,0,0,0,-10,-0.15,0,0/"
                + "418,119,-14,0,-1,29,15,2;skirt1,0,0,0,10,0.15,0,0/418,119,-14,0,-1,29,15,2;thigh_r,-1,-14,-29,0,0,0,0/"
                + "388,0,-8,0,-8,15,21,15/222,119,-9,2,-11,18,15,4/418,57,-9,2,-8,2,13,15;shin_r,3,0,21,0,0,0,0/148,0,-9,0,-9,18,22,18/"
                + "400,141,-8,-6,-12,15,9,4/162,158,-2,-3,-13,3,3,1/280,141,-7,7,9,13,11,3;foot_r,4,0,22,0,0,0,0/150,141,-5,-1,-5,11,4,11/"
                + "236,0,-12,3,-18,24,7,30/116,158,-11,6,-19,22,3,1;thigh_l,-1,14,-29,0,0,0,0/!388,0,-8,0,-8,15,21,15/!222,119,-9,2,-11,18,15,4/"
                + "!418,57,7,2,-8,2,13,15;shin_l,6,0,21,0,0,0,0/!148,0,-9,0,-9,18,22,18/!400,141,-8,-6,-12,15,9,4/!162,158,-2,-3,-13,3,3,1/"
                + "!280,141,-7,7,9,13,11,3;foot_l,7,0,22,0,0,0,0/!150,141,-5,-1,-5,11,4,11/!236,0,-12,3,-18,24,7,30/!116,158,-11,6,-19,22,3,1;"
                + "torso,0,0,-6,0,0,0,0/0,92,-13,-11,-8,27,11,16/0,0,-24,-40,-13,48,31,26/266,119,-17,-33,-14,34,17,1/274,92,-18,-38,-11,36,4,21/"
                + "340,141,-15,-26,13,29,12,1;head,9,0,-40,-2,0,0,0/0,141,-7,-4,-7,13,4,13/0,57,-11,-20,-9,22,15,20/0,158,-9,-18,-10,18,9,1/"
                + "88,119,-12,-18,-6,1,9,13/88,119,11,-18,-6,1,9,13/388,92,-12,-21,-9,23,1,21/170,158,-11,-6,-10,22,2,1/"
                + "216,158,-9,-22,-8,2,1,2/216,158,7,-22,-8,2,1,2;shoulder_r,9,-31,-32,0,0,0,0/0,119,-6,-6,-6,11,11,11/204,57,-11,-11,-10,18,11,20/"
                + "156,119,-10,-12,-9,15,1,18/280,57,-4,2,-4,9,22,9;forearm_r,11,0,23,0,-0.25,0,0/158,57,-6,0,-6,11,20,12/"
                + "100,141,-6,19,-7,12,2,13;forearm_r_hammer,12,0,23,-2,-1.2,0,0/220,0,-2,-4,-2,4,35,4/84,57,-8,26,-11,15,13,22/"
                + "86,92,-8,31,-12,16,4,23/438,141,-7,28,-12,13,11,1;shoulder_l,9,31,-32,0,0,0,0/!0,119,-6,-6,-6,11,11,11/"
                + "!204,57,-7,-11,-10,18,11,20/!156,119,-6,-12,-9,15,1,18/!280,57,-4,2,-4,9,22,9;forearm_l,14,0,23,0,-0.25,0,0/"
                + "!158,57,-6,0,-6,11,20,12/!100,141,-6,19,-7,12,2,13;forearm_l_torch,15,0,25,-2,0,0,0/44,119,-4,-4,-11,9,9,13/"
                + "336,119,-3,3,-3,7,7,11/242,141,-4,6,-4,7,2,12;forearm_l_torch_barrel,16,0,0,-11,0,0,0/372,119,-2,-2,-15,3,3,15/"
                + "54,158,-3,-3,-18,6,6,2/224,158,-1,-1,-19,2,2,1;forearm_l_torch_flash,17,0,0,-19,0,0,0/116,119,-3,-3,-13,7,7,13/"
                + "70,158,-8,-1,-4,15,2,3/408,119,-1,-8,-4,2,15,3;beacon,9,-15,-44,13,0,0,0/466,141,-2,-1,-2,4,7,4/312,141,-3,-7,-3,7,7,7;"
                + "beacon_spin,19,0,-3,0,0,0,0/106,158,-2,-2,-4,4,4,1/106,158,-2,-2,3,4,4,1;tank,9,0,-22,20,0,0,1.5708/344,0,-6,-13,-6,11,26,11/"
                + "194,141,-6,-13,-6,12,2,12/194,141,-6,11,-6,12,2,12/52,141,-6,-2,-6,12,4,12");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(10.45F, 11F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_torch/forearm_l_torch_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_torch/forearm_l_torch_barrel/forearm_l_torch_flash", null);
    }
}
