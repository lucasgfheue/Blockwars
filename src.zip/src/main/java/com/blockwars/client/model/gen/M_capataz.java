package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Foreman (capataz). */
@SuppressWarnings("unused")
public final class M_capataz {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("capataz"), "main");

    private M_capataz() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(316, 57).addBox(-16F, -6F, -9F, 33F, 11F, 18F)
                .texOffs(164, 92).addBox(-18F, -5F, -10F, 35F, 6F, 20F)
                .texOffs(38, 158).addBox(-3F, -2F, -11F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt0 = p_hips.addOrReplaceChild("skirt0", CubeListBuilder.create()
                .texOffs(418, 119).addBox(-14F, 0F, -1F, 29F, 15F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -10F, -0.15F, 0F, 0F));
        PartDefinition p_skirt1 = p_hips.addOrReplaceChild("skirt1", CubeListBuilder.create()
                .texOffs(418, 119).addBox(-14F, 0F, -1F, 29F, 15F, 2F),
                PartPose.offsetAndRotation(0F, 0F, 10F, 0.15F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(388, 0).addBox(-8F, 0F, -8F, 15F, 21F, 15F)
                .texOffs(222, 119).addBox(-9F, 2F, -11F, 18F, 15F, 4F)
                .texOffs(418, 57).addBox(-9F, 2F, -8F, 2F, 13F, 15F),
                PartPose.offsetAndRotation(-14F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(148, 0).addBox(-9F, 0F, -9F, 18F, 22F, 18F)
                .texOffs(400, 141).addBox(-8F, -6F, -12F, 15F, 9F, 4F)
                .texOffs(162, 158).addBox(-2F, -3F, -13F, 3F, 3F, 1F)
                .texOffs(280, 141).addBox(-7F, 7F, 9F, 13F, 11F, 3F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(150, 141).addBox(-5F, -1F, -5F, 11F, 4F, 11F)
                .texOffs(236, 0).addBox(-12F, 3F, -18F, 24F, 7F, 30F)
                .texOffs(116, 158).addBox(-11F, 6F, -19F, 22F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(388, 0).mirror().addBox(-8F, 0F, -8F, 15F, 21F, 15F).mirror(false)
                .texOffs(222, 119).mirror().addBox(-9F, 2F, -11F, 18F, 15F, 4F).mirror(false)
                .texOffs(418, 57).mirror().addBox(7F, 2F, -8F, 2F, 13F, 15F).mirror(false),
                PartPose.offsetAndRotation(14F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(148, 0).mirror().addBox(-9F, 0F, -9F, 18F, 22F, 18F).mirror(false)
                .texOffs(400, 141).mirror().addBox(-8F, -6F, -12F, 15F, 9F, 4F).mirror(false)
                .texOffs(162, 158).mirror().addBox(-2F, -3F, -13F, 3F, 3F, 1F).mirror(false)
                .texOffs(280, 141).mirror().addBox(-7F, 7F, 9F, 13F, 11F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(150, 141).mirror().addBox(-5F, -1F, -5F, 11F, 4F, 11F).mirror(false)
                .texOffs(236, 0).mirror().addBox(-12F, 3F, -18F, 24F, 7F, 30F).mirror(false)
                .texOffs(116, 158).mirror().addBox(-11F, 6F, -19F, 22F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 92).addBox(-13F, -11F, -8F, 27F, 11F, 16F)
                .texOffs(0, 0).addBox(-24F, -40F, -13F, 48F, 31F, 26F)
                .texOffs(266, 119).addBox(-17F, -33F, -14F, 34F, 17F, 1F)
                .texOffs(274, 92).addBox(-18F, -38F, -11F, 36F, 4F, 21F)
                .texOffs(340, 141).addBox(-15F, -26F, 13F, 29F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 141).addBox(-7F, -4F, -7F, 13F, 4F, 13F)
                .texOffs(0, 57).addBox(-11F, -20F, -9F, 22F, 15F, 20F)
                .texOffs(0, 158).addBox(-9F, -18F, -10F, 18F, 9F, 1F)
                .texOffs(88, 119).addBox(-12F, -18F, -6F, 1F, 9F, 13F)
                .texOffs(88, 119).addBox(11F, -18F, -6F, 1F, 9F, 13F)
                .texOffs(388, 92).addBox(-12F, -21F, -9F, 23F, 1F, 21F)
                .texOffs(170, 158).addBox(-11F, -6F, -10F, 22F, 2F, 1F)
                .texOffs(216, 158).addBox(-9F, -22F, -8F, 2F, 1F, 2F)
                .texOffs(216, 158).addBox(7F, -22F, -8F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -40F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(0, 119).addBox(-6F, -6F, -6F, 11F, 11F, 11F)
                .texOffs(204, 57).addBox(-11F, -11F, -10F, 18F, 11F, 20F)
                .texOffs(156, 119).addBox(-10F, -12F, -9F, 15F, 1F, 18F)
                .texOffs(280, 57).addBox(-4F, 2F, -4F, 9F, 22F, 9F),
                PartPose.offsetAndRotation(-31F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(158, 57).addBox(-6F, 0F, -6F, 11F, 20F, 12F)
                .texOffs(100, 141).addBox(-6F, 19F, -7F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_hammer = p_forearm_r.addOrReplaceChild("forearm_r_hammer", CubeListBuilder.create()
                .texOffs(220, 0).addBox(-2F, -4F, -2F, 4F, 35F, 4F)
                .texOffs(84, 57).addBox(-8F, 26F, -11F, 15F, 13F, 22F)
                .texOffs(86, 92).addBox(-8F, 31F, -12F, 16F, 4F, 23F)
                .texOffs(438, 141).addBox(-7F, 28F, -12F, 13F, 11F, 1F),
                PartPose.offsetAndRotation(0F, 23F, -2F, -1.2F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(0, 119).mirror().addBox(-6F, -6F, -6F, 11F, 11F, 11F).mirror(false)
                .texOffs(204, 57).mirror().addBox(-7F, -11F, -10F, 18F, 11F, 20F).mirror(false)
                .texOffs(156, 119).mirror().addBox(-6F, -12F, -9F, 15F, 1F, 18F).mirror(false)
                .texOffs(280, 57).mirror().addBox(-4F, 2F, -4F, 9F, 22F, 9F).mirror(false),
                PartPose.offsetAndRotation(31F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(158, 57).mirror().addBox(-6F, 0F, -6F, 11F, 20F, 12F).mirror(false)
                .texOffs(100, 141).mirror().addBox(-6F, 19F, -7F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_torch = p_forearm_l.addOrReplaceChild("forearm_l_torch", CubeListBuilder.create()
                .texOffs(44, 119).addBox(-4F, -4F, -11F, 9F, 9F, 13F)
                .texOffs(336, 119).addBox(-3F, 3F, -3F, 7F, 7F, 11F)
                .texOffs(242, 141).addBox(-4F, 6F, -4F, 7F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 25F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_torch_barrel = p_forearm_l_torch.addOrReplaceChild("forearm_l_torch_barrel", CubeListBuilder.create()
                .texOffs(372, 119).addBox(-2F, -2F, -15F, 3F, 3F, 15F)
                .texOffs(54, 158).addBox(-3F, -3F, -18F, 6F, 6F, 2F)
                .texOffs(224, 158).addBox(-1F, -1F, -19F, 2F, 2F, 1F),
                PartPose.offsetAndRotation(0F, 0F, -11F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_torch_flash = p_forearm_l_torch_barrel.addOrReplaceChild("forearm_l_torch_flash", CubeListBuilder.create()
                .texOffs(116, 119).addBox(-3F, -3F, -13F, 7F, 7F, 13F)
                .texOffs(70, 158).addBox(-8F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(408, 119).addBox(-1F, -8F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -19F, 0F, 0F, 0F));
        PartDefinition p_beacon = p_torso.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(466, 141).addBox(-2F, -1F, -2F, 4F, 7F, 4F)
                .texOffs(312, 141).addBox(-3F, -7F, -3F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(-15F, -44F, 13F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(106, 158).addBox(-2F, -2F, -4F, 4F, 4F, 1F)
                .texOffs(106, 158).addBox(-2F, -2F, 3F, 4F, 4F, 1F),
                PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0F));
        PartDefinition p_tank = p_torso.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(344, 0).addBox(-6F, -13F, -6F, 11F, 26F, 11F)
                .texOffs(194, 141).addBox(-6F, -13F, -6F, 12F, 2F, 12F)
                .texOffs(194, 141).addBox(-6F, 11F, -6F, 12F, 2F, 12F)
                .texOffs(52, 141).addBox(-6F, -2F, -6F, 12F, 4F, 12F),
                PartPose.offsetAndRotation(0F, -22F, 20F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(10.45F, 11F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_torch/forearm_l_torch_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_torch/forearm_l_torch_barrel/forearm_l_torch_flash", null);
    }
}
