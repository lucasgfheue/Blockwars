package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Thunderhead (cumulonimbo). */
@SuppressWarnings("unused")
public final class M_cumulonimbo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("cumulonimbo"), "main");

    private M_cumulonimbo() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_core = root.addOrReplaceChild("core", CubeListBuilder.create()
                .texOffs(0, 64).addBox(-24F, -29F, -24F, 48F, 13F, 48F)
                .texOffs(0, 125).addBox(-29F, -25F, -15F, 57F, 7F, 31F)
                .texOffs(0, 0).addBox(-15F, -25F, -29F, 31F, 7F, 57F)
                .texOffs(0, 163).addBox(-15F, -33F, -15F, 31F, 4F, 31F)
                .texOffs(176, 163).addBox(-9F, -40F, -11F, 18F, 7F, 18F)
                .texOffs(12, 238).addBox(-9F, -24F, -25F, 18F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -16F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_core.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(36, 220).addBox(-3F, -4F, -3F, 7F, 4F, 7F),
                PartPose.offsetAndRotation(0F, -40F, 0F, 0F, 0F, 0F));
        PartDefinition p_ring0 = p_core.addOrReplaceChild("ring0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -26F, 0F, 1.5708F, 0F, 0F));
        PartDefinition p_ring0_s0 = p_ring0.addOrReplaceChild("ring0_s0", CubeListBuilder.create()
                .texOffs(162, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(37F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring0_s1 = p_ring0.addOrReplaceChild("ring0_s1", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(34F, 16F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring0_s2 = p_ring0.addOrReplaceChild("ring0_s2", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(23F, 29F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring0_s3 = p_ring0.addOrReplaceChild("ring0_s3", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(8F, 36F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring0_s4 = p_ring0.addOrReplaceChild("ring0_s4", CubeListBuilder.create()
                .texOffs(162, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, 36F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring0_s5 = p_ring0.addOrReplaceChild("ring0_s5", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-23F, 29F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring0_s6 = p_ring0.addOrReplaceChild("ring0_s6", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-34F, 16F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring0_s7 = p_ring0.addOrReplaceChild("ring0_s7", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-37F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring0_s8 = p_ring0.addOrReplaceChild("ring0_s8", CubeListBuilder.create()
                .texOffs(162, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-34F, -16F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring0_s9 = p_ring0.addOrReplaceChild("ring0_s9", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-23F, -29F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring0_s10 = p_ring0.addOrReplaceChild("ring0_s10", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, -36F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring0_s11 = p_ring0.addOrReplaceChild("ring0_s11", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(8F, -36F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring0_s12 = p_ring0.addOrReplaceChild("ring0_s12", CubeListBuilder.create()
                .texOffs(162, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(23F, -29F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring0_s13 = p_ring0.addOrReplaceChild("ring0_s13", CubeListBuilder.create()
                .texOffs(208, 231).addBox(-9F, -2F, -2F, 19F, 3F, 4F),
                PartPose.offsetAndRotation(34F, -16F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring1 = p_core.addOrReplaceChild("ring1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -26F, 0F, 0.4F, 0.3F, 0F));
        PartDefinition p_ring1_s0 = p_ring1.addOrReplaceChild("ring1_s0", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(44F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring1_s1 = p_ring1.addOrReplaceChild("ring1_s1", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(40F, 19F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring1_s2 = p_ring1.addOrReplaceChild("ring1_s2", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(27F, 34F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring1_s3 = p_ring1.addOrReplaceChild("ring1_s3", CubeListBuilder.create()
                .texOffs(110, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(10F, 43F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring1_s4 = p_ring1.addOrReplaceChild("ring1_s4", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(-10F, 43F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring1_s5 = p_ring1.addOrReplaceChild("ring1_s5", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(-27F, 34F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring1_s6 = p_ring1.addOrReplaceChild("ring1_s6", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(-40F, 19F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring1_s7 = p_ring1.addOrReplaceChild("ring1_s7", CubeListBuilder.create()
                .texOffs(110, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(-44F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring1_s8 = p_ring1.addOrReplaceChild("ring1_s8", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(-40F, -19F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring1_s9 = p_ring1.addOrReplaceChild("ring1_s9", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(-27F, -34F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring1_s10 = p_ring1.addOrReplaceChild("ring1_s10", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(-10F, -43F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring1_s11 = p_ring1.addOrReplaceChild("ring1_s11", CubeListBuilder.create()
                .texOffs(110, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(10F, -43F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring1_s12 = p_ring1.addOrReplaceChild("ring1_s12", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(27F, -34F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring1_s13 = p_ring1.addOrReplaceChild("ring1_s13", CubeListBuilder.create()
                .texOffs(58, 231).addBox(-11F, -2F, -2F, 22F, 3F, 4F),
                PartPose.offsetAndRotation(40F, -19F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring2 = p_core.addOrReplaceChild("ring2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -26F, 0F, 1.5708F, 0.6F, 0F));
        PartDefinition p_ring2_s0 = p_ring2.addOrReplaceChild("ring2_s0", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(51F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring2_s1 = p_ring2.addOrReplaceChild("ring2_s1", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(46F, 22F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring2_s2 = p_ring2.addOrReplaceChild("ring2_s2", CubeListBuilder.create()
                .texOffs(0, 231).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(32F, 40F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring2_s3 = p_ring2.addOrReplaceChild("ring2_s3", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(11F, 49F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring2_s4 = p_ring2.addOrReplaceChild("ring2_s4", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(-11F, 49F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring2_s5 = p_ring2.addOrReplaceChild("ring2_s5", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(-32F, 40F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring2_s6 = p_ring2.addOrReplaceChild("ring2_s6", CubeListBuilder.create()
                .texOffs(0, 231).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(-46F, 22F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring2_s7 = p_ring2.addOrReplaceChild("ring2_s7", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(-51F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring2_s8 = p_ring2.addOrReplaceChild("ring2_s8", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(-46F, -22F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring2_s9 = p_ring2.addOrReplaceChild("ring2_s9", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(-32F, -40F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring2_s10 = p_ring2.addOrReplaceChild("ring2_s10", CubeListBuilder.create()
                .texOffs(0, 231).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(-11F, -49F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring2_s11 = p_ring2.addOrReplaceChild("ring2_s11", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(11F, -49F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring2_s12 = p_ring2.addOrReplaceChild("ring2_s12", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(32F, -40F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring2_s13 = p_ring2.addOrReplaceChild("ring2_s13", CubeListBuilder.create()
                .texOffs(150, 220).addBox(-12F, -2F, -2F, 25F, 3F, 4F),
                PartPose.offsetAndRotation(46F, -22F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_float_r = p_core.addOrReplaceChild("float_r", CubeListBuilder.create()
                .texOffs(124, 163).addBox(-6F, -8F, -7F, 11F, 15F, 13F)
                .texOffs(106, 220).addBox(-3F, 8F, -3F, 7F, 1F, 7F),
                PartPose.offsetAndRotation(-42F, -22F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_tesla = p_float_r.addOrReplaceChild("float_r_tesla", CubeListBuilder.create()
                .texOffs(0, 198).addBox(-4F, -4F, -11F, 9F, 9F, 13F)
                .texOffs(148, 198).addBox(-6F, -6F, -14F, 11F, 11F, 2F)
                .texOffs(0, 238).addBox(-2F, -2F, -16F, 4F, 4F, 2F)
                .texOffs(174, 198).addBox(-5F, -5F, -19F, 10F, 10F, 2F)
                .texOffs(0, 238).addBox(-2F, -2F, -21F, 4F, 4F, 2F)
                .texOffs(64, 220).addBox(-4F, -4F, -23F, 9F, 9F, 2F)
                .texOffs(0, 238).addBox(-2F, -2F, -25F, 4F, 4F, 2F)
                .texOffs(86, 220).addBox(-4F, -4F, -28F, 8F, 8F, 2F)
                .texOffs(0, 238).addBox(-2F, -2F, -30F, 4F, 4F, 2F),
                PartPose.offsetAndRotation(0F, 4F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_tesla_orb = p_float_r_tesla.addOrReplaceChild("float_r_tesla_orb", CubeListBuilder.create()
                .texOffs(84, 198).addBox(-3F, -3F, -3F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(0F, 0F, -34F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_float_l = p_core.addOrReplaceChild("float_l", CubeListBuilder.create()
                .texOffs(124, 163).mirror().addBox(-6F, -8F, -7F, 11F, 15F, 13F).mirror(false)
                .texOffs(106, 220).addBox(-3F, 8F, -3F, 7F, 1F, 7F),
                PartPose.offsetAndRotation(42F, -22F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_l_tesla = p_float_l.addOrReplaceChild("float_l_tesla", CubeListBuilder.create()
                .texOffs(0, 198).addBox(-4F, -4F, -11F, 9F, 9F, 13F)
                .texOffs(148, 198).addBox(-6F, -6F, -14F, 11F, 11F, 2F)
                .texOffs(0, 238).addBox(-2F, -2F, -16F, 4F, 4F, 2F)
                .texOffs(174, 198).addBox(-5F, -5F, -19F, 10F, 10F, 2F)
                .texOffs(0, 238).addBox(-2F, -2F, -21F, 4F, 4F, 2F)
                .texOffs(64, 220).addBox(-4F, -4F, -23F, 9F, 9F, 2F)
                .texOffs(0, 238).addBox(-2F, -2F, -25F, 4F, 4F, 2F)
                .texOffs(86, 220).addBox(-4F, -4F, -28F, 8F, 8F, 2F)
                .texOffs(0, 238).addBox(-2F, -2F, -30F, 4F, 4F, 2F),
                PartPose.offsetAndRotation(0F, 4F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_l_tesla_orb = p_float_l_tesla.addOrReplaceChild("float_l_tesla_orb", CubeListBuilder.create()
                .texOffs(84, 198).addBox(-3F, -3F, -3F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(0F, 0F, -34F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_jet_r = p_core.addOrReplaceChild("jet_r", CubeListBuilder.create()
                .texOffs(112, 198).addBox(-4F, -2F, -4F, 9F, 4F, 9F),
                PartPose.offsetAndRotation(-9F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_r = p_jet_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(60, 198).addBox(-3F, 0F, -3F, 6F, 13F, 6F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_jet_l = p_core.addOrReplaceChild("jet_l", CubeListBuilder.create()
                .texOffs(112, 198).addBox(-4F, -2F, -4F, 9F, 4F, 9F),
                PartPose.offsetAndRotation(9F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_l = p_jet_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(60, 198).addBox(-3F, 0F, -3F, 6F, 13F, 6F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_coil_r = p_core.addOrReplaceChild("coil_r", CubeListBuilder.create()
                .texOffs(44, 198).addBox(-2F, -13F, -2F, 4F, 18F, 4F)
                .texOffs(198, 198).addBox(-4F, -6F, -4F, 9F, 2F, 9F)
                .texOffs(0, 220).addBox(-4F, -11F, -4F, 9F, 2F, 9F)
                .texOffs(198, 198).addBox(-4F, -16F, -4F, 9F, 2F, 9F)
                .texOffs(134, 220).addBox(-2F, -22F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, -35F, 20F, 0F, 0F, 0F));
        PartDefinition p_coil_l = p_core.addOrReplaceChild("coil_l", CubeListBuilder.create()
                .texOffs(44, 198).addBox(-2F, -13F, -2F, 4F, 18F, 4F)
                .texOffs(198, 198).addBox(-4F, -6F, -4F, 9F, 2F, 9F)
                .texOffs(0, 220).addBox(-4F, -11F, -4F, 9F, 2F, 9F)
                .texOffs(198, 198).addBox(-4F, -16F, -4F, 9F, 2F, 9F)
                .texOffs(134, 220).addBox(-2F, -22F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(9F, -35F, 20F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_core.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(172, 163).addBox(-1F, -26F, -1F, 1F, 26F, 1F)
                .texOffs(50, 238).addBox(-1F, -28F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(7F, -44F, 4F, -0.2F, 0F, 0.15F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HOVER).parts("core", "core", "core/head").walkRate(0F)
                .arm("core/float_r", null, -1, true)
                .arm("core/float_l", null, 1, true)
                .spin("core/ring0", 2, 0.05F, 2)
                .spin("core/ring1", 2, -0.07F, 2)
                .spin("core/ring2", 2, 0.09F, 2)
                .spin("core/float_r/float_r_tesla/float_r_tesla_orb", 1, 0.4F, 0)
                .spin("core/float_l/float_l_tesla/float_l_tesla_orb", 1, 0.4F, 0)
                .sway("core/antenna", 2, 0.08F, 0F)
                .flame("core/jet_r/flame_r")
                .flame("core/jet_l/flame_l")
                .primary(Rig.MountKind.ARM, "core/float_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "core/float_l", null, null, null);
    }
}
