package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Scavenger (carronero). */
@SuppressWarnings("unused")
public final class M_carronero {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("carronero"), "main");

    private M_carronero() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 97).addBox(-37F, -36F, -32F, 75F, 15F, 64F)
                .texOffs(122, 176).addBox(-20F, -40F, -20F, 40F, 4F, 45F)
                .texOffs(278, 97).addBox(-20F, -22F, -30F, 40F, 18F, 60F)
                .texOffs(142, 331).addBox(-35F, -32F, -33F, 70F, 7F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-9F, -11F, -37F, 18F, 22F, 75F)
                .texOffs(186, 0).addBox(-10F, -16F, -38F, 20F, 6F, 77F),
                PartPose.offsetAndRotation(-29F, -11F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(310, 282).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(284, 331).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -26F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(310, 282).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(284, 331).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(310, 282).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(284, 331).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(310, 282).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(284, 331).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 26F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-9F, -11F, -37F, 18F, 22F, 75F).mirror(false)
                .texOffs(186, 0).mirror().addBox(-10F, -16F, -38F, 20F, 6F, 77F).mirror(false),
                PartPose.offsetAndRotation(29F, -11F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(310, 282).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(284, 331).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -26F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(310, 282).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(284, 331).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(310, 282).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(284, 331).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(310, 282).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(284, 331).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 26F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hull.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(176, 282).addBox(-11F, -11F, -7F, 22F, 11F, 15F)
                .texOffs(0, 249).addBox(-18F, -18F, -12F, 36F, 9F, 24F)
                .texOffs(120, 249).addBox(-12F, -27F, -6F, 24F, 16F, 15F)
                .texOffs(164, 282).addBox(-19F, -33F, -12F, 3F, 26F, 3F)
                .texOffs(164, 282).addBox(-19F, -33F, 8F, 3F, 26F, 3F)
                .texOffs(164, 282).addBox(16F, -33F, -12F, 3F, 26F, 3F)
                .texOffs(164, 282).addBox(16F, -33F, 8F, 3F, 26F, 3F)
                .texOffs(310, 331).addBox(-20F, -35F, -12F, 40F, 3F, 3F)
                .texOffs(310, 331).addBox(-20F, -35F, 8F, 40F, 3F, 3F)
                .texOffs(274, 249).addBox(-21F, -32F, -13F, 42F, 4F, 26F)
                .texOffs(390, 311).addBox(-15F, -26F, -10F, 30F, 14F, 1F)
                .texOffs(0, 346).addBox(-14F, -35F, -14F, 4F, 2F, 1F)
                .texOffs(0, 346).addBox(10F, -35F, -14F, 4F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -37F, 4F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(48, 331).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(-18F, -33F, 4F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(48, 331).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(-18F, -33F, 11F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(48, 331).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(18F, -33F, 4F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(48, 331).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(18F, -33F, 11F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(292, 311).addBox(-7F, -4F, -7F, 13F, 4F, 13F)
                .texOffs(428, 176).addBox(-11F, -20F, -9F, 22F, 15F, 20F)
                .texOffs(104, 331).addBox(-9F, -18F, -10F, 18F, 9F, 1F)
                .texOffs(470, 282).addBox(-12F, -18F, -6F, 1F, 9F, 13F)
                .texOffs(470, 282).addBox(11F, -18F, -6F, 1F, 9F, 13F)
                .texOffs(338, 282).addBox(-12F, -21F, -9F, 23F, 1F, 21F)
                .texOffs(432, 331).addBox(-11F, -6F, -10F, 22F, 2F, 1F)
                .texOffs(10, 346).addBox(-9F, -22F, -8F, 2F, 1F, 2F)
                .texOffs(10, 346).addBox(7F, -22F, -8F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -35F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(426, 282).addBox(-6F, -6F, -6F, 11F, 11F, 11F)
                .texOffs(198, 249).addBox(-11F, -11F, -10F, 18F, 11F, 20F)
                .texOffs(68, 311).addBox(-10F, -12F, -9F, 15F, 1F, 18F)
                .texOffs(128, 282).addBox(-4F, 2F, -4F, 9F, 20F, 9F),
                PartPose.offsetAndRotation(-26F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_r0 = p_shoulder_r.addOrReplaceChild("sspike_r0", CubeListBuilder.create()
                .texOffs(48, 331).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(-4F, -11F, -4F, 0F, 0F, -0.3F));
        PartDefinition p_sspike_r4 = p_shoulder_r.addOrReplaceChild("sspike_r4", CubeListBuilder.create()
                .texOffs(48, 331).addBox(-2F, -11F, -2F, 3F, 11F, 3F),
                PartPose.offsetAndRotation(-4F, -11F, 4F, 0F, 0F, -0.3F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(410, 249).addBox(-6F, 0F, -6F, 11F, 18F, 12F)
                .texOffs(452, 311).addBox(-6F, 17F, -7F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_claw = p_forearm_r.addOrReplaceChild("forearm_r_claw", CubeListBuilder.create()
                .texOffs(172, 311).addBox(-6F, -1F, -6F, 11F, 7F, 11F),
                PartPose.offsetAndRotation(0F, 21F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_claw_f0 = p_forearm_r_claw.addOrReplaceChild("forearm_r_claw_f0", CubeListBuilder.create()
                .texOffs(344, 311).addBox(-2F, 0F, -2F, 3F, 13F, 4F)
                .texOffs(296, 331).addBox(-2F, 13F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(-4F, 6F, -2F, 0F, 0F, 0.25F));
        PartDefinition p_forearm_r_claw_f1 = p_forearm_r_claw.addOrReplaceChild("forearm_r_claw_f1", CubeListBuilder.create()
                .texOffs(344, 311).addBox(-2F, 0F, -2F, 3F, 13F, 4F)
                .texOffs(296, 331).addBox(-2F, 13F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(4F, 6F, -2F, 0F, 0F, -0.25F));
        PartDefinition p_forearm_r_claw_f2 = p_forearm_r_claw.addOrReplaceChild("forearm_r_claw_f2", CubeListBuilder.create()
                .texOffs(344, 311).addBox(-2F, 0F, -2F, 3F, 13F, 4F)
                .texOffs(296, 331).addBox(-2F, 13F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(0F, 6F, 4F, 0.25F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(426, 282).mirror().addBox(-6F, -6F, -6F, 11F, 11F, 11F).mirror(false)
                .texOffs(198, 249).mirror().addBox(-7F, -11F, -10F, 18F, 11F, 20F).mirror(false)
                .texOffs(68, 311).mirror().addBox(-6F, -12F, -9F, 15F, 1F, 18F).mirror(false)
                .texOffs(128, 282).mirror().addBox(-4F, 2F, -4F, 9F, 20F, 9F).mirror(false),
                PartPose.offsetAndRotation(26F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_l0 = p_shoulder_l.addOrReplaceChild("sspike_l0", CubeListBuilder.create()
                .texOffs(48, 331).mirror().addBox(-2F, -11F, -2F, 3F, 11F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -11F, -4F, 0F, 0F, 0.3F));
        PartDefinition p_sspike_l4 = p_shoulder_l.addOrReplaceChild("sspike_l4", CubeListBuilder.create()
                .texOffs(48, 331).mirror().addBox(-2F, -11F, -2F, 3F, 11F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -11F, 4F, 0F, 0F, 0.3F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(410, 249).mirror().addBox(-6F, 0F, -6F, 11F, 18F, 12F).mirror(false)
                .texOffs(452, 311).mirror().addBox(-6F, 17F, -7F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_mortar = p_forearm_l.addOrReplaceChild("forearm_l_mortar", CubeListBuilder.create()
                .texOffs(250, 282).addBox(-8F, -6F, -8F, 15F, 11F, 15F),
                PartPose.offsetAndRotation(0F, 21F, -2F, -0.55F, 0F, 0F));
        PartDefinition p_forearm_l_mortar_barrel = p_forearm_l_mortar.addOrReplaceChild("forearm_l_mortar_barrel", CubeListBuilder.create()
                .texOffs(292, 176).addBox(-7F, -7F, -35F, 13F, 13F, 35F)
                .texOffs(358, 311).addBox(-7F, -7F, -32F, 14F, 14F, 2F)
                .texOffs(134, 311).addBox(-8F, -8F, -38F, 15F, 15F, 4F),
                PartPose.offsetAndRotation(0F, -4F, -4F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_mortar_flash = p_forearm_l_mortar_barrel.addOrReplaceChild("forearm_l_mortar_flash", CubeListBuilder.create()
                .texOffs(0, 311).addBox(-3F, -3F, -13F, 7F, 7F, 13F)
                .texOffs(396, 331).addBox(-8F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(216, 311).addBox(-1F, -8F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -37F, 0F, 0F, 0F));
        PartDefinition p_cargo0 = p_torso.addOrReplaceChild("cargo0", CubeListBuilder.create()
                .texOffs(0, 282).addBox(-8F, -7F, -8F, 17F, 14F, 15F)
                .texOffs(478, 331).addBox(-7F, -1F, -8F, 14F, 2F, 1F)
                .texOffs(226, 311).addBox(-9F, -8F, -8F, 17F, 1F, 16F),
                PartPose.offsetAndRotation(-9F, -24F, 21F, 0F, 0F, 0F));
        PartDefinition p_cargo1 = p_torso.addOrReplaceChild("cargo1", CubeListBuilder.create()
                .texOffs(0, 282).addBox(-8F, -7F, -8F, 17F, 14F, 15F)
                .texOffs(478, 331).addBox(-7F, -1F, -8F, 14F, 2F, 1F)
                .texOffs(226, 311).addBox(-9F, -8F, -8F, 17F, 1F, 16F),
                PartPose.offsetAndRotation(9F, -24F, 21F, 0F, 0F, 0F));
        PartDefinition p_cargo2 = p_torso.addOrReplaceChild("cargo2", CubeListBuilder.create()
                .texOffs(64, 282).addBox(-8F, -7F, -8F, 17F, 14F, 15F)
                .texOffs(478, 331).addBox(-7F, -1F, -8F, 14F, 2F, 1F)
                .texOffs(226, 311).addBox(-9F, -8F, -8F, 17F, 1F, 16F),
                PartPose.offsetAndRotation(0F, -40F, 21F, 0F, 0F, 0F));
        PartDefinition p_exhaust = p_torso.addOrReplaceChild("exhaust", CubeListBuilder.create()
                .texOffs(388, 176).addBox(-5F, -33F, -5F, 10F, 35F, 10F)
                .texOffs(60, 331).addBox(-6F, -8F, -6F, 11F, 2F, 11F)
                .texOffs(60, 331).addBox(-6F, -25F, -6F, 11F, 2F, 11F)
                .texOffs(0, 331).addBox(-6F, -36F, -6F, 12F, 3F, 12F),
                PartPose.offsetAndRotation(10F, -35F, 19F, 0F, 0F, 0F));
        PartDefinition p_flame_exh = p_exhaust.addOrReplaceChild("flame_exh", CubeListBuilder.create()
                .texOffs(40, 311).addBox(-3F, 0F, -3F, 7F, 13F, 7F),
                PartPose.offsetAndRotation(0F, -35F, 0F, 3.1416F, 0F, 0F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(0, 176).addBox(-1F, -7F, -30F, 1F, 13F, 60F),
                PartPose.offsetAndRotation(-39F, -20F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(0, 176).mirror().addBox(-1F, -7F, -30F, 1F, 13F, 60F).mirror(false),
                PartPose.offsetAndRotation(39F, -20F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/torso", "hull/torso/head").walkRate(0F)
                .arm("hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r", -1, false)
                .arm("hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l", 1, false)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .flame("hull/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l/forearm_l_mortar/forearm_l_mortar_barrel", "hull/torso/shoulder_l/forearm_l/forearm_l_mortar/forearm_l_mortar_barrel/forearm_l_mortar_flash", null)
                .secondary(Rig.MountKind.ARM, "hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l/forearm_l_mortar/forearm_l_mortar_barrel", "hull/torso/shoulder_l/forearm_l/forearm_l_mortar/forearm_l_mortar_barrel/forearm_l_mortar_flash", null);
    }
}
