package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Rolling Mill (laminador). */
@SuppressWarnings("unused")
public final class M_laminador {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("laminador"), "main");

    private M_laminador() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hull,-1,0,22,0,0,0,0/0,101,-39,-38,-33,78,16,66/0,260,-21,-41,-21,41,5,47/288,101,-21,-23,-31,41,18,63/"
                + "0,385,-37,-33,-34,74,7,1;tread_r,0,-30,-12,0,0,0,0/0,0,-9,-12,-39,18,23,78/192,0,-10,-17,-40,21,6,80;"
                + "wheel_r0,1,-10,2,-28,0,0,0/330,312,-1,-7,-7,1,14,14/408,369,-1,-2,-2,2,5,5;wheel_r1,1,-10,2,-9,0,0,0/"
                + "330,312,-1,-7,-7,1,14,14/408,369,-1,-2,-2,2,5,5;wheel_r2,1,-10,2,9,0,0,0/330,312,-1,-7,-7,1,14,14/408,369,-1,-2,-2,2,5,5;"
                + "wheel_r3,1,-10,2,28,0,0,0/330,312,-1,-7,-7,1,14,14/408,369,-1,-2,-2,2,5,5;tread_l,0,30,-12,0,0,0,0/!0,0,-9,-12,-39,18,23,78/"
                + "!192,0,-10,-17,-40,21,6,80;wheel_l0,6,10,2,-28,0,0,0/!330,312,-1,-7,-7,1,14,14/!408,369,-1,-2,-2,2,5,5;"
                + "wheel_l1,6,10,2,-9,0,0,0/!330,312,-1,-7,-7,1,14,14/!408,369,-1,-2,-2,2,5,5;wheel_l2,6,10,2,9,0,0,0/!330,312,-1,-7,-7,1,14,14/"
                + "!408,369,-1,-2,-2,2,5,5;wheel_l3,6,10,2,28,0,0,0/!330,312,-1,-7,-7,1,14,14/!408,369,-1,-2,-2,2,5,5;torso,0,0,-39,5,0,0,0/"
                + "360,312,-11,-12,-8,23,12,15/258,183,-17,-37,-13,33,28,25/216,260,-21,-33,-10,41,21,20/0,344,-21,-15,-11,43,3,22/"
                + "0,344,-21,-26,-11,43,3,22/150,385,-13,-22,-14,7,7,1/338,385,4,-19,-14,9,5,1/178,344,-12,-36,-9,25,5,18/"
                + "312,369,-12,-24,13,25,11,1;head,11,0,-37,-2,0,0,0/276,369,-5,-5,-5,9,5,9/338,260,-8,-21,-9,16,16,18/468,344,-9,-21,-10,17,16,1/"
                + "358,385,-6,-14,-10,12,2,1/392,385,-5,-13,-11,9,1,1/190,369,-2,-22,-5,5,1,14;shoulder_r,11,-28,-29,0,0,0,0/"
                + "130,344,-6,-6,-6,12,12,12/406,260,-12,-12,-10,18,12,21/334,344,-10,-13,-9,16,1,18/294,312,-5,2,-5,9,21,9;"
                + "forearm_r,13,0,22,0,-0.25,0,0/0,312,-6,0,-6,12,19,13/0,369,-6,17,-7,13,2,14;forearm_r_saw,14,0,24,-2,0,0,0/"
                + "436,312,-5,-5,-16,9,9,18/148,369,-3,-6,-14,7,1,14;forearm_r_saw_disc,15,0,0,-21,0,0,0/128,183,-1,-16,-16,2,32,32/"
                + "440,344,-2,-5,-5,5,9,9;forearm_r_saw_disc2,16,0,0,0,0.7854,0,0/196,183,-1,-15,-15,1,30,30;shoulder_l,11,28,-29,0,0,0,0/"
                + "!130,344,-6,-6,-6,12,12,12/!406,260,-7,-12,-10,18,12,21/!334,344,-6,-13,-9,16,1,18/!294,312,-5,2,-5,9,21,9;"
                + "forearm_l,18,0,22,0,-0.25,0,0/!0,312,-6,0,-6,12,19,13/!0,369,-6,17,-7,13,2,14;forearm_l_flamer,19,0,24,-2,0,0,0/"
                + "234,312,-5,-5,-17,9,9,21/264,344,-3,5,-7,7,7,14/106,369,-4,7,-7,7,2,14;forearm_l_flamer_barrel,20,0,-1,-18,0,0,0/"
                + "402,344,-2,-2,-14,5,5,14/388,369,-3,-3,-17,7,7,3/384,385,-1,3,-16,2,1,2;exhaust,11,10,-37,20,0,0,0/176,260,-5,-34,-5,10,37,10/"
                + "228,369,-6,-8,-6,12,2,12/228,369,-6,-26,-6,12,2,12/54,369,-6,-37,-6,13,3,13;flame_exh,22,0,-37,0,3.1416,0,0/"
                + "306,344,-3,0,-3,7,14,7;plow,0,0,-14,-44,0.15,0,0/50,312,-44,-13,-2,87,25,5/166,385,-43,-13,-3,85,5,1/"
                + "364,369,-34,10,-6,5,5,7/364,369,-18,10,-6,5,5,7/364,369,-2,10,-6,5,5,7/364,369,14,10,-6,5,5,7/364,369,30,10,-6,5,5,7;"
                + "skirt_r,0,-41,-21,0,0,0,0/0,183,-1,-7,-31,1,14,63;skirt_l,0,41,-21,0,0,0,0/!0,183,-1,-7,-31,1,14,63");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/torso", "hull/torso/head").walkRate(0F)
                .arm("hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r", -1, false)
                .arm("hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l", 1, false)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/torso/shoulder_r/forearm_r/forearm_r_saw/forearm_r_saw_disc", 0, 0.8F, 3)
                .flame("hull/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hull/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l/forearm_l_flamer/forearm_l_flamer_barrel", null, null);
    }
}
