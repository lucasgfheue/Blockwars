package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Rolling Mill (laminador). */
@SuppressWarnings("unused")
public final class M_laminador {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("laminador"), "main");

    private M_laminador() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 101).addBox(-39F, -38F, -33F, 78F, 16F, 66F)
                .texOffs(0, 260).addBox(-21F, -41F, -21F, 41F, 5F, 47F)
                .texOffs(288, 101).addBox(-21F, -23F, -31F, 41F, 18F, 63F)
                .texOffs(0, 385).addBox(-37F, -33F, -34F, 74F, 7F, 1F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-9F, -12F, -39F, 18F, 23F, 78F)
                .texOffs(192, 0).addBox(-10F, -17F, -40F, 21F, 6F, 80F),
                PartPose.offsetAndRotation(-30F, -12F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(330, 312).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(408, 369).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, -28F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(330, 312).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(408, 369).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(330, 312).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(408, 369).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(330, 312).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(408, 369).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, 28F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-9F, -12F, -39F, 18F, 23F, 78F).mirror(false)
                .texOffs(192, 0).mirror().addBox(-10F, -17F, -40F, 21F, 6F, 80F).mirror(false),
                PartPose.offsetAndRotation(30F, -12F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(330, 312).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(408, 369).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, -28F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(330, 312).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(408, 369).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(330, 312).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(408, 369).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(330, 312).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(408, 369).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, 28F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hull.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(360, 312).addBox(-11F, -12F, -8F, 23F, 12F, 15F)
                .texOffs(258, 183).addBox(-17F, -37F, -13F, 33F, 28F, 25F)
                .texOffs(216, 260).addBox(-21F, -33F, -10F, 41F, 21F, 20F)
                .texOffs(0, 344).addBox(-21F, -15F, -11F, 43F, 3F, 22F)
                .texOffs(0, 344).addBox(-21F, -26F, -11F, 43F, 3F, 22F)
                .texOffs(150, 385).addBox(-13F, -22F, -14F, 7F, 7F, 1F)
                .texOffs(338, 385).addBox(4F, -19F, -14F, 9F, 5F, 1F)
                .texOffs(178, 344).addBox(-12F, -36F, -9F, 25F, 5F, 18F)
                .texOffs(312, 369).addBox(-12F, -24F, 13F, 25F, 11F, 1F),
                PartPose.offsetAndRotation(0F, -39F, 5F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(276, 369).addBox(-5F, -5F, -5F, 9F, 5F, 9F)
                .texOffs(338, 260).addBox(-8F, -21F, -9F, 16F, 16F, 18F)
                .texOffs(468, 344).addBox(-9F, -21F, -10F, 17F, 16F, 1F)
                .texOffs(358, 385).addBox(-6F, -14F, -10F, 12F, 2F, 1F)
                .texOffs(392, 385).addBox(-5F, -13F, -11F, 9F, 1F, 1F)
                .texOffs(190, 369).addBox(-2F, -22F, -5F, 5F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -37F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(130, 344).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(406, 260).addBox(-12F, -12F, -10F, 18F, 12F, 21F)
                .texOffs(334, 344).addBox(-10F, -13F, -9F, 16F, 1F, 18F)
                .texOffs(294, 312).addBox(-5F, 2F, -5F, 9F, 21F, 9F),
                PartPose.offsetAndRotation(-28F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(0, 312).addBox(-6F, 0F, -6F, 12F, 19F, 13F)
                .texOffs(0, 369).addBox(-6F, 17F, -7F, 13F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 22F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_saw = p_forearm_r.addOrReplaceChild("forearm_r_saw", CubeListBuilder.create()
                .texOffs(436, 312).addBox(-5F, -5F, -16F, 9F, 9F, 18F)
                .texOffs(148, 369).addBox(-3F, -6F, -14F, 7F, 1F, 14F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_saw_disc = p_forearm_r_saw.addOrReplaceChild("forearm_r_saw_disc", CubeListBuilder.create()
                .texOffs(128, 183).addBox(-1F, -16F, -16F, 2F, 32F, 32F)
                .texOffs(440, 344).addBox(-2F, -5F, -5F, 5F, 9F, 9F),
                PartPose.offsetAndRotation(0F, 0F, -21F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_saw_disc2 = p_forearm_r_saw_disc.addOrReplaceChild("forearm_r_saw_disc2", CubeListBuilder.create()
                .texOffs(196, 183).addBox(-1F, -15F, -15F, 1F, 30F, 30F),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0.7854F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(130, 344).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(406, 260).mirror().addBox(-7F, -12F, -10F, 18F, 12F, 21F).mirror(false)
                .texOffs(334, 344).mirror().addBox(-6F, -13F, -9F, 16F, 1F, 18F).mirror(false)
                .texOffs(294, 312).mirror().addBox(-5F, 2F, -5F, 9F, 21F, 9F).mirror(false),
                PartPose.offsetAndRotation(28F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(0, 312).mirror().addBox(-6F, 0F, -6F, 12F, 19F, 13F).mirror(false)
                .texOffs(0, 369).mirror().addBox(-6F, 17F, -7F, 13F, 2F, 14F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_flamer = p_forearm_l.addOrReplaceChild("forearm_l_flamer", CubeListBuilder.create()
                .texOffs(234, 312).addBox(-5F, -5F, -17F, 9F, 9F, 21F)
                .texOffs(264, 344).addBox(-3F, 5F, -7F, 7F, 7F, 14F)
                .texOffs(106, 369).addBox(-4F, 7F, -7F, 7F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_flamer_barrel = p_forearm_l_flamer.addOrReplaceChild("forearm_l_flamer_barrel", CubeListBuilder.create()
                .texOffs(402, 344).addBox(-2F, -2F, -14F, 5F, 5F, 14F)
                .texOffs(388, 369).addBox(-3F, -3F, -17F, 7F, 7F, 3F)
                .texOffs(384, 385).addBox(-1F, 3F, -16F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -1F, -18F, 0F, 0F, 0F));
        PartDefinition p_exhaust = p_torso.addOrReplaceChild("exhaust", CubeListBuilder.create()
                .texOffs(176, 260).addBox(-5F, -34F, -5F, 10F, 37F, 10F)
                .texOffs(228, 369).addBox(-6F, -8F, -6F, 12F, 2F, 12F)
                .texOffs(228, 369).addBox(-6F, -26F, -6F, 12F, 2F, 12F)
                .texOffs(54, 369).addBox(-6F, -37F, -6F, 13F, 3F, 13F),
                PartPose.offsetAndRotation(10F, -37F, 20F, 0F, 0F, 0F));
        PartDefinition p_flame_exh = p_exhaust.addOrReplaceChild("flame_exh", CubeListBuilder.create()
                .texOffs(306, 344).addBox(-3F, 0F, -3F, 7F, 14F, 7F),
                PartPose.offsetAndRotation(0F, -37F, 0F, 3.1416F, 0F, 0F));
        PartDefinition p_plow = p_hull.addOrReplaceChild("plow", CubeListBuilder.create()
                .texOffs(50, 312).addBox(-44F, -13F, -2F, 87F, 25F, 5F)
                .texOffs(166, 385).addBox(-43F, -13F, -3F, 85F, 5F, 1F)
                .texOffs(364, 369).addBox(-34F, 10F, -6F, 5F, 5F, 7F)
                .texOffs(364, 369).addBox(-18F, 10F, -6F, 5F, 5F, 7F)
                .texOffs(364, 369).addBox(-2F, 10F, -6F, 5F, 5F, 7F)
                .texOffs(364, 369).addBox(14F, 10F, -6F, 5F, 5F, 7F)
                .texOffs(364, 369).addBox(30F, 10F, -6F, 5F, 5F, 7F),
                PartPose.offsetAndRotation(0F, -14F, -44F, 0.15F, 0F, 0F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(0, 183).addBox(-1F, -7F, -31F, 1F, 14F, 63F),
                PartPose.offsetAndRotation(-41F, -21F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(0, 183).mirror().addBox(-1F, -7F, -31F, 1F, 14F, 63F).mirror(false),
                PartPose.offsetAndRotation(41F, -21F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/torso", "hull/torso/head").walkRate(0F)
                .arm("hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r", -1, false)
                .arm("hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l", 1, false)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/torso/shoulder_r/forearm_r/forearm_r_saw/forearm_r_saw_disc", 0, 0.8F, 3)
                .flame("hull/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hull/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l/forearm_l_flamer/forearm_l_flamer_barrel", null, null);
    }
}
