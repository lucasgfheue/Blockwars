package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Revenant (revenant). */
@SuppressWarnings("unused")
public final class M_revenant {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("revenant"), "main");

    private M_revenant() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(60, 71).addBox(-13F, -5F, -8F, 25F, 10F, 17F)
                .texOffs(144, 71).addBox(-14F, -5F, -9F, 27F, 5F, 19F)
                .texOffs(214, 159).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(190, 0).addBox(-5F, 0F, -5F, 10F, 23F, 10F)
                .texOffs(160, 99).addBox(-6F, 2F, -8F, 13F, 16F, 4F)
                .texOffs(0, 99).addBox(-6F, 2F, -5F, 2F, 14F, 10F),
                PartPose.offsetAndRotation(-10F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(20, 0).addBox(-6F, 0F, -6F, 13F, 24F, 13F)
                .texOffs(78, 159).addBox(-5F, -5F, -9F, 10F, 8F, 4F)
                .texOffs(220, 141).addBox(-4F, 7F, 6F, 8F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(154, 159).addBox(-4F, -1F, -4F, 7F, 4F, 7F)
                .texOffs(172, 40).addBox(-9F, 3F, -13F, 18F, 6F, 22F)
                .texOffs(34, 173).addBox(-8F, 5F, -14F, 16F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(190, 0).mirror().addBox(-5F, 0F, -5F, 10F, 23F, 10F).mirror(false)
                .texOffs(160, 99).mirror().addBox(-6F, 2F, -8F, 13F, 16F, 4F).mirror(false)
                .texOffs(0, 99).mirror().addBox(4F, 2F, -5F, 2F, 14F, 10F).mirror(false),
                PartPose.offsetAndRotation(10F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(20, 0).mirror().addBox(-6F, 0F, -6F, 13F, 24F, 13F).mirror(false)
                .texOffs(78, 159).mirror().addBox(-5F, -5F, -9F, 10F, 8F, 4F).mirror(false)
                .texOffs(220, 141).mirror().addBox(-4F, 7F, 6F, 8F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(154, 159).mirror().addBox(-4F, -1F, -4F, 7F, 4F, 7F).mirror(false)
                .texOffs(172, 40).mirror().addBox(-9F, 3F, -13F, 18F, 6F, 22F).mirror(false)
                .texOffs(34, 173).mirror().addBox(-8F, 5F, -14F, 16F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(148, 40).addBox(-3F, -23F, -3F, 6F, 23F, 6F)
                .texOffs(166, 123).addBox(-10F, -13F, -8F, 21F, 3F, 15F)
                .texOffs(86, 123).addBox(-12F, -19F, -8F, 25F, 3F, 15F)
                .texOffs(0, 123).addBox(-14F, -26F, -8F, 28F, 3F, 15F)
                .texOffs(72, 0).addBox(-19F, -37F, -10F, 38F, 15F, 21F)
                .texOffs(24, 99).addBox(-9F, -22F, -5F, 17F, 13F, 9F)
                .texOffs(194, 159).addBox(-4F, -29F, -12F, 8F, 8F, 2F)
                .texOffs(0, 159).addBox(-6F, -32F, -11F, 13F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(34, 159).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-17F, -36F, 4F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(34, 159).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-17F, -36F, 10F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(34, 159).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(17F, -36F, 4F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(34, 159).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(17F, -36F, 10F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(46, 159).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(0, 71).addBox(-7F, -18F, -7F, 15F, 13F, 15F)
                .texOffs(24, 173).addBox(-6F, -15F, -8F, 4F, 4F, 1F)
                .texOffs(24, 173).addBox(2F, -15F, -8F, 4F, 4F, 1F)
                .texOffs(90, 173).addBox(-5F, -14F, -8F, 2F, 2F, 1F)
                .texOffs(90, 173).addBox(3F, -14F, -8F, 2F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -38F, -2F, 0F, 0F, 0F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(64, 141).addBox(-6F, 0F, -8F, 13F, 4F, 13F)
                .texOffs(68, 173).addBox(-5F, -1F, -8F, 10F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -5F, -2F, 0F, 0F, 0F));
        PartDefinition p_xhorn_r = p_head.addOrReplaceChild("xhorn_r", CubeListBuilder.create()
                .texOffs(106, 159).addBox(-1F, -1F, 0F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(-7F, -13F, 2F, 0.5F, -0.6F, 0F));
        PartDefinition p_xhorn_l = p_head.addOrReplaceChild("xhorn_l", CubeListBuilder.create()
                .texOffs(106, 159).mirror().addBox(-1F, -1F, 0F, 2F, 2F, 10F).mirror(false),
                PartPose.offsetAndRotation(7F, -13F, 2F, 0.5F, 0.6F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(120, 99).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(44, 40).addBox(-10F, -10F, -9F, 17F, 10F, 19F)
                .texOffs(0, 141).addBox(-9F, -12F, -8F, 15F, 1F, 17F)
                .texOffs(116, 40).addBox(-4F, 2F, -4F, 8F, 21F, 8F),
                PartPose.offsetAndRotation(-25F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_r0 = p_shoulder_r.addOrReplaceChild("sspike_r0", CubeListBuilder.create()
                .texOffs(34, 159).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-4F, -10F, -4F, 0F, 0F, -0.3F));
        PartDefinition p_sspike_r4 = p_shoulder_r.addOrReplaceChild("sspike_r4", CubeListBuilder.create()
                .texOffs(34, 159).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-4F, -10F, 4F, 0F, 0F, -0.3F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(0, 40).addBox(-5F, 0F, -6F, 10F, 19F, 12F)
                .texOffs(170, 141).addBox(-6F, 18F, -6F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 22F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_emitter = p_forearm_r.addOrReplaceChild("forearm_r_emitter", CubeListBuilder.create()
                .texOffs(76, 99).addBox(-5F, -5F, -10F, 9F, 9F, 13F)
                .texOffs(106, 159).addBox(-1F, 4F, -18F, 2F, 2F, 10F)
                .texOffs(106, 159).addBox(-6F, -4F, -18F, 2F, 2F, 10F)
                .texOffs(106, 159).addBox(3F, -4F, -18F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_emitter_orb = p_forearm_r_emitter.addOrReplaceChild("forearm_r_emitter_orb", CubeListBuilder.create()
                .texOffs(130, 159).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(182, 159).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -16F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(120, 99).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(44, 40).mirror().addBox(-6F, -10F, -9F, 17F, 10F, 19F).mirror(false)
                .texOffs(0, 141).mirror().addBox(-5F, -12F, -8F, 15F, 1F, 17F).mirror(false)
                .texOffs(116, 40).mirror().addBox(-4F, 2F, -4F, 8F, 21F, 8F).mirror(false),
                PartPose.offsetAndRotation(25F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_l0 = p_shoulder_l.addOrReplaceChild("sspike_l0", CubeListBuilder.create()
                .texOffs(34, 159).mirror().addBox(-2F, -10F, -2F, 3F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -10F, -4F, 0F, 0F, 0.3F));
        PartDefinition p_sspike_l4 = p_shoulder_l.addOrReplaceChild("sspike_l4", CubeListBuilder.create()
                .texOffs(34, 159).mirror().addBox(-2F, -10F, -2F, 3F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -10F, 4F, 0F, 0F, 0.3F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(0, 40).mirror().addBox(-5F, 0F, -6F, 10F, 19F, 12F).mirror(false)
                .texOffs(170, 141).mirror().addBox(-6F, 18F, -6F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_claw = p_forearm_l.addOrReplaceChild("forearm_l_claw", CubeListBuilder.create()
                .texOffs(130, 141).addBox(-5F, -1F, -5F, 10F, 6F, 10F),
                PartPose.offsetAndRotation(0F, 22F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_claw_f0 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f0", CubeListBuilder.create()
                .texOffs(116, 141).addBox(-2F, 0F, -2F, 3F, 13F, 4F)
                .texOffs(228, 159).addBox(-2F, 12F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(-4F, 5F, -2F, 0F, 0F, 0.25F));
        PartDefinition p_forearm_l_claw_f1 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f1", CubeListBuilder.create()
                .texOffs(116, 141).addBox(-2F, 0F, -2F, 3F, 13F, 4F)
                .texOffs(228, 159).addBox(-2F, 12F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(4F, 5F, -2F, 0F, 0F, -0.25F));
        PartDefinition p_forearm_l_claw_f2 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f2", CubeListBuilder.create()
                .texOffs(116, 141).addBox(-2F, 0F, -2F, 3F, 13F, 4F)
                .texOffs(228, 159).addBox(-2F, 12F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(0F, 5F, 4F, 0.25F, 0F, 0F));
        PartDefinition p_cape0 = p_torso.addOrReplaceChild("cape0", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4F, 0F, 0F, 8F, 38F, 2F)
                .texOffs(0, 173).addBox(-5F, 36F, -1F, 9F, 2F, 3F)
                .texOffs(28, 159).addBox(-1F, 6F, 2F, 2F, 13F, 1F),
                PartPose.offsetAndRotation(-8F, -34F, 13F, 0.12F, 0F, -0.08F));
        PartDefinition p_cape1 = p_torso.addOrReplaceChild("cape1", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4F, 0F, 0F, 8F, 38F, 2F)
                .texOffs(0, 173).addBox(-5F, 36F, -1F, 9F, 2F, 3F)
                .texOffs(28, 159).addBox(-1F, 6F, 2F, 2F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -34F, 13F, 0.12F, 0F, 0F));
        PartDefinition p_cape2 = p_torso.addOrReplaceChild("cape2", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4F, 0F, 0F, 8F, 38F, 2F)
                .texOffs(0, 173).addBox(-5F, 36F, -1F, 9F, 2F, 3F)
                .texOffs(28, 159).addBox(-1F, 6F, 2F, 2F, 13F, 1F),
                PartPose.offsetAndRotation(8F, -34F, 13F, 0.12F, 0F, 0.08F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3143F)
                .legLengths(11.55F, 12.075F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .sway("hips/torso/cape0", 0, 0.06F, 0F)
                .sway("hips/torso/cape1", 0, 0.06F, 1.1F)
                .sway("hips/torso/cape2", 0, 0.06F, 2.2F)
                .jaw("hips/torso/head/jaw")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
