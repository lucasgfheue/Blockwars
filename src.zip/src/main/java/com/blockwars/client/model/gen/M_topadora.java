package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Dozer (topadora). */
@SuppressWarnings("unused")
public final class M_topadora {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("topadora"), "main");

    private M_topadora() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 92).addBox(-36F, -35F, -30F, 71F, 15F, 61F)
                .texOffs(122, 168).addBox(-19F, -38F, -19F, 38F, 4F, 43F)
                .texOffs(264, 92).addBox(-19F, -21F, -29F, 38F, 17F, 57F)
                .texOffs(158, 262).addBox(-34F, -30F, -31F, 67F, 6F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-8F, -10F, -36F, 17F, 21F, 71F)
                .texOffs(176, 0).addBox(-9F, -16F, -37F, 19F, 5F, 74F),
                PartPose.offsetAndRotation(-27F, -10F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(254, 216).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(146, 262).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -25F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(254, 216).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(146, 262).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -8F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(254, 216).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(146, 262).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 8F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(254, 216).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(146, 262).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 25F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-8F, -10F, -36F, 17F, 21F, 71F).mirror(false)
                .texOffs(176, 0).mirror().addBox(-9F, -16F, -37F, 19F, 5F, 74F).mirror(false),
                PartPose.offsetAndRotation(27F, -10F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(254, 216).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(146, 262).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -25F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(254, 216).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(146, 262).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -8F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(254, 216).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(146, 262).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 8F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(254, 216).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(146, 262).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 25F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hull.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(310, 216).addBox(-10F, -10F, -7F, 21F, 10F, 14F)
                .texOffs(0, 168).addBox(-19F, -34F, -12F, 38F, 25F, 23F)
                .texOffs(294, 243).addBox(-13F, -28F, -13F, 26F, 14F, 1F)
                .texOffs(380, 216).addBox(-14F, -33F, -9F, 28F, 4F, 18F)
                .texOffs(32, 262).addBox(-11F, -22F, 12F, 23F, 10F, 1F),
                PartPose.offsetAndRotation(0F, -36F, 4F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(486, 243).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-17F, -32F, 4F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(486, 243).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-17F, -32F, 10F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(486, 243).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(17F, -32F, 4F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(486, 243).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(17F, -32F, 10F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 262).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(324, 168).addBox(-7F, -17F, -8F, 15F, 13F, 17F)
                .texOffs(150, 243).addBox(-6F, -18F, -6F, 13F, 1F, 15F)
                .texOffs(482, 262).addBox(-6F, -12F, -9F, 13F, 3F, 1F)
                .texOffs(0, 274).addBox(-5F, -8F, -9F, 10F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -34F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(282, 216).addBox(-1F, -25F, -1F, 1F, 25F, 1F)
                .texOffs(22, 274).addBox(-1F, -26F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(472, 216).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(388, 168).addBox(-10F, -10F, -9F, 17F, 10F, 19F)
                .texOffs(38, 243).addBox(-9F, -12F, -8F, 15F, 1F, 17F)
                .texOffs(222, 216).addBox(-4F, 2F, -4F, 8F, 19F, 8F),
                PartPose.offsetAndRotation(-25F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_r0 = p_shoulder_r.addOrReplaceChild("sspike_r0", CubeListBuilder.create()
                .texOffs(486, 243).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-4F, -10F, -4F, 0F, 0F, -0.3F));
        PartDefinition p_sspike_r4 = p_shoulder_r.addOrReplaceChild("sspike_r4", CubeListBuilder.create()
                .texOffs(486, 243).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-4F, -10F, 4F, 0F, 0F, -0.3F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(460, 168).addBox(-5F, 0F, -6F, 10F, 17F, 12F)
                .texOffs(348, 243).addBox(-6F, 16F, -6F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 20F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_flamer = p_forearm_r.addOrReplaceChild("forearm_r_flamer", CubeListBuilder.create()
                .texOffs(168, 216).addBox(-4F, -4F, -16F, 8F, 8F, 19F)
                .texOffs(0, 243).addBox(-3F, 4F, -6F, 6F, 6F, 13F)
                .texOffs(398, 243).addBox(-3F, 6F, -7F, 7F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 22F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_flamer_barrel = p_forearm_r_flamer.addOrReplaceChild("forearm_r_flamer_barrel", CubeListBuilder.create()
                .texOffs(102, 243).addBox(-2F, -2F, -13F, 4F, 4F, 13F)
                .texOffs(128, 262).addBox(-3F, -3F, -15F, 6F, 6F, 3F)
                .texOffs(30, 274).addBox(-1F, 3F, -15F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -1F, -17F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(472, 216).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(388, 168).mirror().addBox(-6F, -10F, -9F, 17F, 10F, 19F).mirror(false)
                .texOffs(38, 243).mirror().addBox(-5F, -12F, -8F, 15F, 1F, 17F).mirror(false)
                .texOffs(222, 216).mirror().addBox(-4F, 2F, -4F, 8F, 19F, 8F).mirror(false),
                PartPose.offsetAndRotation(25F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_l0 = p_shoulder_l.addOrReplaceChild("sspike_l0", CubeListBuilder.create()
                .texOffs(486, 243).mirror().addBox(-2F, -10F, -2F, 3F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -10F, -4F, 0F, 0F, 0.3F));
        PartDefinition p_sspike_l4 = p_shoulder_l.addOrReplaceChild("sspike_l4", CubeListBuilder.create()
                .texOffs(486, 243).mirror().addBox(-2F, -10F, -2F, 3F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -10F, 4F, 0F, 0F, 0.3F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(460, 168).mirror().addBox(-5F, 0F, -6F, 10F, 17F, 12F).mirror(false)
                .texOffs(348, 243).mirror().addBox(-6F, 16F, -6F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_claw = p_forearm_l.addOrReplaceChild("forearm_l_claw", CubeListBuilder.create()
                .texOffs(254, 243).addBox(-5F, -1F, -5F, 10F, 6F, 10F),
                PartPose.offsetAndRotation(0F, 20F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_claw_f0 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f0", CubeListBuilder.create()
                .texOffs(136, 243).addBox(-2F, 0F, -2F, 3F, 13F, 4F)
                .texOffs(294, 262).addBox(-2F, 12F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(-4F, 5F, -2F, 0F, 0F, 0.25F));
        PartDefinition p_forearm_l_claw_f1 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f1", CubeListBuilder.create()
                .texOffs(136, 243).addBox(-2F, 0F, -2F, 3F, 13F, 4F)
                .texOffs(294, 262).addBox(-2F, 12F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(4F, 5F, -2F, 0F, 0F, -0.25F));
        PartDefinition p_forearm_l_claw_f2 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f2", CubeListBuilder.create()
                .texOffs(136, 243).addBox(-2F, 0F, -2F, 3F, 13F, 4F)
                .texOffs(294, 262).addBox(-2F, 12F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(0F, 5F, 4F, 0.25F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(286, 216).addBox(-3F, -18F, -3F, 6F, 19F, 6F)
                .texOffs(100, 262).addBox(-4F, -19F, -4F, 7F, 2F, 7F)
                .texOffs(466, 262).addBox(-2F, -20F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-11F, -29F, 16F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(286, 216).addBox(-3F, -18F, -3F, 6F, 19F, 6F)
                .texOffs(100, 262).addBox(-4F, -19F, -4F, 7F, 2F, 7F)
                .texOffs(466, 262).addBox(-2F, -20F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(11F, -29F, 16F, -0.15F, 0F, -0.1F));
        PartDefinition p_tank = p_torso.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(284, 168).addBox(-5F, -13F, -5F, 10F, 25F, 10F)
                .texOffs(438, 243).addBox(-6F, -13F, -6F, 12F, 2F, 12F)
                .texOffs(438, 243).addBox(-6F, 10F, -6F, 12F, 2F, 12F)
                .texOffs(206, 243).addBox(-6F, -2F, -6F, 12F, 4F, 12F),
                PartPose.offsetAndRotation(0F, -17F, 18F, 0F, 0F, 1.5708F));
        PartDefinition p_plow = p_hull.addOrReplaceChild("plow", CubeListBuilder.create()
                .texOffs(0, 216).addBox(-40F, -12F, -2F, 80F, 23F, 4F)
                .texOffs(308, 262).addBox(-39F, -12F, -3F, 78F, 4F, 1F)
                .texOffs(80, 262).addBox(-32F, 9F, -5F, 4F, 4F, 6F)
                .texOffs(80, 262).addBox(-17F, 9F, -5F, 4F, 4F, 6F)
                .texOffs(80, 262).addBox(-2F, 9F, -5F, 4F, 4F, 6F)
                .texOffs(80, 262).addBox(13F, 9F, -5F, 4F, 4F, 6F)
                .texOffs(80, 262).addBox(27F, 9F, -5F, 4F, 4F, 6F),
                PartPose.offsetAndRotation(0F, -13F, -40F, 0.15F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/torso", "hull/torso/head").walkRate(0F)
                .arm("hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r", -1, false)
                .arm("hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l", 1, false)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .sway("hull/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r/forearm_r_flamer/forearm_r_flamer_barrel", null, null)
                .secondary(Rig.MountKind.ARM, "hull/torso/shoulder_l", null, null, null);
    }
}
