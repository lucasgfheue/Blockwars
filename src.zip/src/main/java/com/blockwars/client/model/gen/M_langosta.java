package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Locust (langosta). */
@SuppressWarnings("unused")
public final class M_langosta {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("langosta"), "main");

    private M_langosta() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "body,-1,0,10,0,0,0,0/0,60,-18,-18,-24,36,18,32;abdomen,0,0,-10,8,-0.25,0,0/0,0,-16,-16,0,32,24,36/34,110,-12,-17,4,24,1,28/"
                + "84,169,-6,-8,36,12,8,1;hip_r0,-1,-18,10,-20,0,-0.5,0;leg_r0,2,0,-8,0,0,0,2.15/0,110,-4,0,-4,8,26,9/152,145,-5,-1,-6,10,6,11;"
                + "shin_r0,3,0,26,0,0,0,-1.75/136,60,-3,0,-3,6,38,6/124,145,-4,5,-4,7,13,7/128,169,-2,35,-2,4,4,4;hip_l0,-1,18,10,-20,0,0.5,0;"
                + "leg_l0,5,0,-8,0,0,0,-2.15/!0,110,-4,0,-4,8,26,9/!152,145,-5,-1,-6,10,6,11;shin_l0,6,0,26,0,0,0,1.75/!136,60,-3,0,-3,6,38,6/"
                + "!124,145,-4,5,-4,7,13,7/!128,169,-2,35,-2,4,4,4;hip_r1,-1,-18,10,-8,0,0,0;leg_r1,8,0,-8,0,0,0,2.15/0,110,-4,0,-4,8,26,9/"
                + "152,145,-5,-1,-6,10,6,11;shin_r1,9,0,26,0,0,0,-1.75/136,60,-3,0,-3,6,38,6/124,145,-4,5,-4,7,13,7/128,169,-2,35,-2,4,4,4;"
                + "hip_l1,-1,18,10,-8,0,0,0;leg_l1,11,0,-8,0,0,0,-2.15/!0,110,-4,0,-4,8,26,9/!152,145,-5,-1,-6,10,6,11;shin_l1,12,0,26,0,0,0,1.75/"
                + "!136,60,-3,0,-3,6,38,6/!124,145,-4,5,-4,7,13,7/!128,169,-2,35,-2,4,4,4;hip_r2,-1,-18,10,4,0,0.5,0;leg_r2,14,0,-8,0,0,0,2.15/"
                + "0,110,-4,0,-4,8,26,9/152,145,-5,-1,-6,10,6,11;shin_r2,15,0,26,0,0,0,-1.75/136,60,-3,0,-3,6,38,6/124,145,-4,5,-4,7,13,7/"
                + "128,169,-2,35,-2,4,4,4;hip_l2,-1,18,10,4,0,-0.5,0;leg_l2,17,0,-8,0,0,0,-2.15/!0,110,-4,0,-4,8,26,9/!152,145,-5,-1,-6,10,6,11;"
                + "shin_l2,18,0,26,0,0,0,1.75/!136,60,-3,0,-3,6,38,6/!124,145,-4,5,-4,7,13,7/!128,169,-2,35,-2,4,4,4;head,0,0,-10,-24,0,0,0/"
                + "52,169,-4,-4,-4,8,4,8/72,145,-6,-14,-6,12,10,14/110,169,-4,-13,-7,8,8,1/144,169,-2,-11,-8,4,4,1/0,169,-4,-15,-5,8,1,12;"
                + "antenna,20,5,-12,4,-0.2,0,0.15/226,110,0,-24,0,1,24,1/154,169,-1,-25,-1,2,2,2;turret,0,0,-20,-2,0,0,0/"
                + "0,145,-9,-6,-9,18,6,18;turret_pod,22,0,-10,-4,0,0,0/160,60,-10,-16,-12,20,16,24/138,110,-10,-17,-12,20,1,24/"
                + "194,145,-9,-15,-13,18,14,1;body_pod,0,0,-18,26,0,0,0/160,60,-10,-16,-12,20,16,24/138,110,-10,-17,-12,20,1,24/"
                + "194,145,-9,-15,-13,18,14,1;bspike0,0,0,-20,-12,0.5,0,0/40,169,-2,-10,-2,3,10,3;bspike1,0,0,-20,0,0.5,0,0/"
                + "40,169,-2,-10,-2,3,10,3;bspike2,0,0,-20,12,0.5,0,0/40,169,-2,-10,-2,3,10,3");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.5F)
                .legLengths(13F, 19F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/abdomen", 0, 0.04F, 0F)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.POD, "body/body_pod", null, null, null)
                .secondary(Rig.MountKind.POD, "body/body_pod", null, null, null);
    }
}
