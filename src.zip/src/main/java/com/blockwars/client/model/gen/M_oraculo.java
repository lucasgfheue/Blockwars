package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Oracle (oraculo). */
@SuppressWarnings("unused")
public final class M_oraculo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("oraculo"), "main");

    private M_oraculo() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_core = root.addOrReplaceChild("core", CubeListBuilder.create()
                .texOffs(0, 52).addBox(-14F, -34F, -14F, 28F, 20F, 28F)
                .texOffs(0, 0).addBox(-12F, -38F, -12F, 24F, 28F, 24F)
                .texOffs(96, 0).addBox(-10F, -40F, -10F, 20F, 32F, 20F)
                .texOffs(112, 52).addBox(-10F, -34F, -15F, 20F, 20F, 1F)
                .texOffs(186, 52).addBox(-6F, -30F, -16F, 12F, 12F, 1F)
                .texOffs(184, 100).addBox(-2F, -26F, -16F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_core.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 100).addBox(-3F, -4F, -3F, 6F, 4F, 6F),
                PartPose.offsetAndRotation(0F, -40F, 0F, 0F, 0F, 0F));
        PartDefinition p_ring0 = p_core.addOrReplaceChild("ring0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 1.5708F, 0F, 0F));
        PartDefinition p_ring0_s0 = p_ring0.addOrReplaceChild("ring0_s0", CubeListBuilder.create()
                .texOffs(108, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(28F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring0_s1 = p_ring0.addOrReplaceChild("ring0_s1", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(25F, 12F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring0_s2 = p_ring0.addOrReplaceChild("ring0_s2", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(17F, 22F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring0_s3 = p_ring0.addOrReplaceChild("ring0_s3", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(6F, 27F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring0_s4 = p_ring0.addOrReplaceChild("ring0_s4", CubeListBuilder.create()
                .texOffs(108, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-6F, 27F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring0_s5 = p_ring0.addOrReplaceChild("ring0_s5", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-17F, 22F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring0_s6 = p_ring0.addOrReplaceChild("ring0_s6", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-25F, 12F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring0_s7 = p_ring0.addOrReplaceChild("ring0_s7", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-28F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring0_s8 = p_ring0.addOrReplaceChild("ring0_s8", CubeListBuilder.create()
                .texOffs(108, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-25F, -12F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring0_s9 = p_ring0.addOrReplaceChild("ring0_s9", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-17F, -22F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring0_s10 = p_ring0.addOrReplaceChild("ring0_s10", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(-6F, -27F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring0_s11 = p_ring0.addOrReplaceChild("ring0_s11", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(6F, -27F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring0_s12 = p_ring0.addOrReplaceChild("ring0_s12", CubeListBuilder.create()
                .texOffs(108, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(17F, -22F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring0_s13 = p_ring0.addOrReplaceChild("ring0_s13", CubeListBuilder.create()
                .texOffs(146, 100).addBox(-7F, -2F, -2F, 15F, 3F, 4F),
                PartPose.offsetAndRotation(25F, -12F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring1 = p_core.addOrReplaceChild("ring1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0.4F, 0.3F, 0F));
        PartDefinition p_ring1_s0 = p_ring1.addOrReplaceChild("ring1_s0", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(34F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring1_s1 = p_ring1.addOrReplaceChild("ring1_s1", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(31F, 15F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring1_s2 = p_ring1.addOrReplaceChild("ring1_s2", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(21F, 27F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring1_s3 = p_ring1.addOrReplaceChild("ring1_s3", CubeListBuilder.create()
                .texOffs(66, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(8F, 33F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring1_s4 = p_ring1.addOrReplaceChild("ring1_s4", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, 33F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring1_s5 = p_ring1.addOrReplaceChild("ring1_s5", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-21F, 27F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring1_s6 = p_ring1.addOrReplaceChild("ring1_s6", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-31F, 15F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring1_s7 = p_ring1.addOrReplaceChild("ring1_s7", CubeListBuilder.create()
                .texOffs(66, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-34F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring1_s8 = p_ring1.addOrReplaceChild("ring1_s8", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-31F, -15F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring1_s9 = p_ring1.addOrReplaceChild("ring1_s9", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-21F, -27F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring1_s10 = p_ring1.addOrReplaceChild("ring1_s10", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, -33F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring1_s11 = p_ring1.addOrReplaceChild("ring1_s11", CubeListBuilder.create()
                .texOffs(66, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(8F, -33F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring1_s12 = p_ring1.addOrReplaceChild("ring1_s12", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(21F, -27F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring1_s13 = p_ring1.addOrReplaceChild("ring1_s13", CubeListBuilder.create()
                .texOffs(24, 100).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(31F, -15F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_jet_r = p_core.addOrReplaceChild("jet_r", CubeListBuilder.create()
                .texOffs(212, 52).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(-8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_r = p_jet_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(154, 52).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_jet_l = p_core.addOrReplaceChild("jet_l", CubeListBuilder.create()
                .texOffs(212, 52).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_l = p_jet_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(154, 52).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_halo = p_core.addOrReplaceChild("halo", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -48F, 20F, 0F, 0F, 0F));
        PartDefinition p_halo_s0 = p_halo.addOrReplaceChild("halo_s0", CubeListBuilder.create()
                .texOffs(196, 100).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(18F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_halo_s1 = p_halo.addOrReplaceChild("halo_s1", CubeListBuilder.create()
                .texOffs(0, 110).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(13F, 13F, 0F, 0F, 0F, 2.3562F));
        PartDefinition p_halo_s2 = p_halo.addOrReplaceChild("halo_s2", CubeListBuilder.create()
                .texOffs(196, 100).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 3.1416F));
        PartDefinition p_halo_s3 = p_halo.addOrReplaceChild("halo_s3", CubeListBuilder.create()
                .texOffs(0, 110).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(-13F, 13F, 0F, 0F, 0F, 3.927F));
        PartDefinition p_halo_s4 = p_halo.addOrReplaceChild("halo_s4", CubeListBuilder.create()
                .texOffs(196, 100).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(-18F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_halo_s5 = p_halo.addOrReplaceChild("halo_s5", CubeListBuilder.create()
                .texOffs(0, 110).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(-13F, -13F, 0F, 0F, 0F, 5.4978F));
        PartDefinition p_halo_s6 = p_halo.addOrReplaceChild("halo_s6", CubeListBuilder.create()
                .texOffs(196, 100).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -18F, 0F, 0F, 0F, 6.2832F));
        PartDefinition p_halo_s7 = p_halo.addOrReplaceChild("halo_s7", CubeListBuilder.create()
                .texOffs(0, 110).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(13F, -13F, 0F, 0F, 0F, 7.0686F));
        PartDefinition p_hspike0 = p_core.addOrReplaceChild("hspike0", CubeListBuilder.create()
                .texOffs(174, 52).addBox(-2F, -14F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(10F, -24F, 10F, 0F, -0.7854F, 1.5708F));
        PartDefinition p_hspike1 = p_core.addOrReplaceChild("hspike1", CubeListBuilder.create()
                .texOffs(174, 52).addBox(-2F, -14F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-10F, -24F, 10F, 0F, -2.3562F, 1.5708F));
        PartDefinition p_hspike2 = p_core.addOrReplaceChild("hspike2", CubeListBuilder.create()
                .texOffs(174, 52).addBox(-2F, -14F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-10F, -24F, -10F, 0F, -3.927F, 1.5708F));
        PartDefinition p_hspike3 = p_core.addOrReplaceChild("hspike3", CubeListBuilder.create()
                .texOffs(174, 52).addBox(-2F, -14F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(10F, -24F, -10F, 0F, -5.4978F, 1.5708F));
        return LayerDefinition.create(mesh, 256, 128);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HOVER).parts("core", "core", "core/head").walkRate(0F)
                .spin("core/ring0", 2, 0.05F, 2)
                .spin("core/ring1", 2, -0.07F, 2)
                .spin("core/halo", 2, 0.03F, 0)
                .flame("core/jet_r/flame_r")
                .flame("core/jet_l/flame_l")
                .primary(Rig.MountKind.BODY, "core", null, null, null)
                .secondary(Rig.MountKind.BODY, "core", null, null, null);
    }
}
