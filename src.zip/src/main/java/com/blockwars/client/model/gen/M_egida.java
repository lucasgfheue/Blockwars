package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Aegis (egida). */
@SuppressWarnings("unused")
public final class M_egida {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("egida"), "main");

    private M_egida() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_core = root.addOrReplaceChild("core", CubeListBuilder.create()
                .texOffs(302, 0).addBox(-22F, -26F, -22F, 44F, 12F, 44F)
                .texOffs(0, 80).addBox(-26F, -23F, -14F, 52F, 6F, 28F)
                .texOffs(142, 0).addBox(-14F, -23F, -26F, 28F, 6F, 52F)
                .texOffs(160, 80).addBox(-14F, -30F, -14F, 28F, 4F, 28F)
                .texOffs(316, 80).addBox(-8F, -36F, -10F, 16F, 6F, 16F)
                .texOffs(366, 114).addBox(-8F, -22F, -23F, 16F, 3F, 1F)
                .texOffs(474, 80).addBox(-3F, -15F, -3F, 6F, 6F, 6F),
                PartPose.offsetAndRotation(0F, -13F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_core.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(60, 114).addBox(-3F, -4F, -3F, 6F, 4F, 6F),
                PartPose.offsetAndRotation(0F, -36F, 0F, 0F, 0F, 0F));
        PartDefinition p_ring0 = p_core.addOrReplaceChild("ring0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 1.5708F, 0F, 0F));
        PartDefinition p_ring0_s0 = p_ring0.addOrReplaceChild("ring0_s0", CubeListBuilder.create()
                .texOffs(190, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(34F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring0_s1 = p_ring0.addOrReplaceChild("ring0_s1", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(31F, 15F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring0_s2 = p_ring0.addOrReplaceChild("ring0_s2", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(21F, 27F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring0_s3 = p_ring0.addOrReplaceChild("ring0_s3", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(8F, 33F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring0_s4 = p_ring0.addOrReplaceChild("ring0_s4", CubeListBuilder.create()
                .texOffs(190, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, 33F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring0_s5 = p_ring0.addOrReplaceChild("ring0_s5", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-21F, 27F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring0_s6 = p_ring0.addOrReplaceChild("ring0_s6", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-31F, 15F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring0_s7 = p_ring0.addOrReplaceChild("ring0_s7", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-34F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring0_s8 = p_ring0.addOrReplaceChild("ring0_s8", CubeListBuilder.create()
                .texOffs(190, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-31F, -15F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring0_s9 = p_ring0.addOrReplaceChild("ring0_s9", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-21F, -27F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring0_s10 = p_ring0.addOrReplaceChild("ring0_s10", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(-8F, -33F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring0_s11 = p_ring0.addOrReplaceChild("ring0_s11", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(8F, -33F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring0_s12 = p_ring0.addOrReplaceChild("ring0_s12", CubeListBuilder.create()
                .texOffs(190, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(21F, -27F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring0_s13 = p_ring0.addOrReplaceChild("ring0_s13", CubeListBuilder.create()
                .texOffs(232, 114).addBox(-9F, -2F, -2F, 17F, 3F, 4F),
                PartPose.offsetAndRotation(31F, -15F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring1 = p_core.addOrReplaceChild("ring1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0.4F, 0.3F, 0F));
        PartDefinition p_ring1_s0 = p_ring1.addOrReplaceChild("ring1_s0", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(40F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring1_s1 = p_ring1.addOrReplaceChild("ring1_s1", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(36F, 17F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring1_s2 = p_ring1.addOrReplaceChild("ring1_s2", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(25F, 31F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring1_s3 = p_ring1.addOrReplaceChild("ring1_s3", CubeListBuilder.create()
                .texOffs(142, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(9F, 39F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring1_s4 = p_ring1.addOrReplaceChild("ring1_s4", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-9F, 39F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring1_s5 = p_ring1.addOrReplaceChild("ring1_s5", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-25F, 31F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring1_s6 = p_ring1.addOrReplaceChild("ring1_s6", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-36F, 17F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring1_s7 = p_ring1.addOrReplaceChild("ring1_s7", CubeListBuilder.create()
                .texOffs(142, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-40F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring1_s8 = p_ring1.addOrReplaceChild("ring1_s8", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-36F, -17F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring1_s9 = p_ring1.addOrReplaceChild("ring1_s9", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-25F, -31F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring1_s10 = p_ring1.addOrReplaceChild("ring1_s10", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(-9F, -39F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring1_s11 = p_ring1.addOrReplaceChild("ring1_s11", CubeListBuilder.create()
                .texOffs(142, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(9F, -39F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring1_s12 = p_ring1.addOrReplaceChild("ring1_s12", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(25F, -31F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring1_s13 = p_ring1.addOrReplaceChild("ring1_s13", CubeListBuilder.create()
                .texOffs(94, 114).addBox(-10F, -2F, -2F, 20F, 3F, 4F),
                PartPose.offsetAndRotation(36F, -17F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_float_r = p_core.addOrReplaceChild("float_r", CubeListBuilder.create()
                .texOffs(272, 80).addBox(-5F, -7F, -6F, 10F, 14F, 12F)
                .texOffs(274, 114).addBox(-3F, 7F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(-38F, -20F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter = p_float_r.addOrReplaceChild("float_r_emitter", CubeListBuilder.create()
                .texOffs(380, 80).addBox(-4F, -4F, -10F, 9F, 9F, 12F)
                .texOffs(0, 114).addBox(-1F, 4F, -17F, 2F, 2F, 10F)
                .texOffs(0, 114).addBox(-5F, -3F, -17F, 2F, 2F, 10F)
                .texOffs(0, 114).addBox(3F, -4F, -17F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 4F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter_orb = p_float_r_emitter.addOrReplaceChild("float_r_emitter_orb", CubeListBuilder.create()
                .texOffs(24, 114).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(48, 114).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_float_l = p_core.addOrReplaceChild("float_l", CubeListBuilder.create()
                .texOffs(272, 80).mirror().addBox(-5F, -7F, -6F, 10F, 14F, 12F).mirror(false)
                .texOffs(274, 114).addBox(-3F, 7F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(38F, -20F, -4F, 0F, 0F, 0F));
        PartDefinition p_float_l_shield = p_float_l.addOrReplaceChild("float_l_shield", CubeListBuilder.create()
                .texOffs(70, 0).addBox(-2F, -22F, -16F, 4F, 44F, 32F)
                .texOffs(0, 0).addBox(2F, -23F, -17F, 1F, 46F, 34F)
                .texOffs(478, 0).addBox(2F, -14F, -4F, 1F, 28F, 8F)
                .texOffs(84, 114).addBox(3F, -14F, -2F, 1F, 4F, 4F),
                PartPose.offsetAndRotation(7F, -10F, -6F, 0F, 0F, 0F));
        PartDefinition p_jet_r = p_core.addOrReplaceChild("jet_r", CubeListBuilder.create()
                .texOffs(442, 80).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(-8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_r = p_jet_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(422, 80).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_jet_l = p_core.addOrReplaceChild("jet_l", CubeListBuilder.create()
                .texOffs(442, 80).addBox(-4F, -2F, -4F, 8F, 4F, 8F),
                PartPose.offsetAndRotation(8F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_l = p_jet_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(422, 80).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_halo = p_core.addOrReplaceChild("halo", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -48F, 20F, 0F, 0F, 0F));
        PartDefinition p_halo_s0 = p_halo.addOrReplaceChild("halo_s0", CubeListBuilder.create()
                .texOffs(298, 114).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(18F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_halo_s1 = p_halo.addOrReplaceChild("halo_s1", CubeListBuilder.create()
                .texOffs(332, 114).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(13F, 13F, 0F, 0F, 0F, 2.3562F));
        PartDefinition p_halo_s2 = p_halo.addOrReplaceChild("halo_s2", CubeListBuilder.create()
                .texOffs(298, 114).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 3.1416F));
        PartDefinition p_halo_s3 = p_halo.addOrReplaceChild("halo_s3", CubeListBuilder.create()
                .texOffs(332, 114).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(-13F, 13F, 0F, 0F, 0F, 3.927F));
        PartDefinition p_halo_s4 = p_halo.addOrReplaceChild("halo_s4", CubeListBuilder.create()
                .texOffs(298, 114).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(-18F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_halo_s5 = p_halo.addOrReplaceChild("halo_s5", CubeListBuilder.create()
                .texOffs(332, 114).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(-13F, -13F, 0F, 0F, 0F, 5.4978F));
        PartDefinition p_halo_s6 = p_halo.addOrReplaceChild("halo_s6", CubeListBuilder.create()
                .texOffs(298, 114).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -18F, 0F, 0F, 0F, 6.2832F));
        PartDefinition p_halo_s7 = p_halo.addOrReplaceChild("halo_s7", CubeListBuilder.create()
                .texOffs(332, 114).addBox(-8F, -2F, -1F, 15F, 3F, 2F),
                PartPose.offsetAndRotation(13F, -13F, 0F, 0F, 0F, 7.0686F));
        return LayerDefinition.create(mesh, 512, 128);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HOVER).parts("core", "core", "core/head").walkRate(0F)
                .arm("core/float_r", null, -1, true)
                .arm("core/float_l", null, 1, true)
                .spin("core/ring0", 2, 0.05F, 2)
                .spin("core/ring1", 2, -0.07F, 2)
                .spin("core/halo", 2, 0.03F, 0)
                .spin("core/float_r/float_r_emitter/float_r_emitter_orb", 2, 0.25F, 0)
                .flame("core/jet_r/flame_r")
                .flame("core/jet_l/flame_l")
                .primary(Rig.MountKind.ARM, "core/float_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "core/float_r", null, null, null);
    }
}
