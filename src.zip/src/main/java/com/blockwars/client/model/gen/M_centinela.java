package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Sentinel (centinela). */
@SuppressWarnings("unused")
public final class M_centinela {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("centinela"), "main");

    private M_centinela() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 92).addBox(-36F, -35F, -30F, 71F, 15F, 61F)
                .texOffs(238, 168).addBox(-19F, -38F, -19F, 38F, 4F, 43F)
                .texOffs(264, 92).addBox(-19F, -21F, -29F, 38F, 17F, 57F)
                .texOffs(296, 293).addBox(-34F, -30F, -31F, 67F, 6F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-8F, -10F, -36F, 17F, 21F, 71F)
                .texOffs(176, 0).addBox(-9F, -16F, -37F, 19F, 5F, 74F),
                PartPose.offsetAndRotation(-27F, -10F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(336, 238).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(284, 293).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -25F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(336, 238).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(284, 293).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -8F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(336, 238).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(284, 293).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 8F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(336, 238).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(284, 293).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 25F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-8F, -10F, -36F, 17F, 21F, 71F).mirror(false)
                .texOffs(176, 0).mirror().addBox(-9F, -16F, -37F, 19F, 5F, 74F).mirror(false),
                PartPose.offsetAndRotation(27F, -10F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(336, 238).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(284, 293).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -25F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(336, 238).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(284, 293).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -8F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(336, 238).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(284, 293).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 8F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(336, 238).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(284, 293).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 25F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hull.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(428, 238).addBox(-10F, -10F, -7F, 21F, 10F, 14F)
                .texOffs(116, 168).addBox(-19F, -34F, -12F, 38F, 25F, 23F)
                .texOffs(434, 270).addBox(-13F, -28F, -13F, 26F, 14F, 1F)
                .texOffs(46, 270).addBox(-14F, -33F, -9F, 28F, 4F, 18F)
                .texOffs(208, 293).addBox(-11F, -22F, 12F, 23F, 10F, 1F),
                PartPose.offsetAndRotation(0F, -36F, 4F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(152, 293).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(0, 238).addBox(-7F, -19F, -8F, 15F, 15F, 17F)
                .texOffs(380, 270).addBox(-8F, -19F, -9F, 16F, 15F, 1F)
                .texOffs(0, 308).addBox(-5F, -13F, -9F, 10F, 2F, 1F)
                .texOffs(22, 308).addBox(-4F, -12F, -10F, 8F, 1F, 1F)
                .texOffs(92, 293).addBox(-2F, -20F, -4F, 4F, 1F, 13F),
                PartPose.offsetAndRotation(0F, -34F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(364, 238).addBox(-1F, -25F, -1F, 1F, 25F, 1F)
                .texOffs(484, 293).addBox(-1F, -26F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(138, 270).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(188, 238).addBox(-10F, -10F, -9F, 17F, 10F, 19F)
                .texOffs(216, 270).addBox(-9F, -12F, -8F, 15F, 1F, 17F)
                .texOffs(304, 238).addBox(-4F, 2F, -4F, 8F, 19F, 8F),
                PartPose.offsetAndRotation(-25F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(260, 238).addBox(-5F, 0F, -6F, 10F, 17F, 12F)
                .texOffs(0, 293).addBox(-6F, 16F, -6F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 20F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_cannon = p_forearm_r.addOrReplaceChild("forearm_r_cannon", CubeListBuilder.create()
                .texOffs(400, 168).addBox(-7F, -7F, -21F, 15F, 15F, 25F)
                .texOffs(280, 270).addBox(-5F, -8F, -17F, 10F, 1F, 17F)
                .texOffs(368, 238).addBox(7F, -4F, -17F, 1F, 8F, 17F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_barrel = p_forearm_r_cannon.addOrReplaceChild("forearm_r_cannon_barrel", CubeListBuilder.create()
                .texOffs(64, 238).addBox(-4F, -4F, -25F, 7F, 7F, 25F)
                .texOffs(334, 270).addBox(-6F, -6F, -29F, 12F, 12F, 6F),
                PartPose.offsetAndRotation(0F, 0F, -21F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_flash = p_forearm_r_cannon_barrel.addOrReplaceChild("forearm_r_cannon_flash", CubeListBuilder.create()
                .texOffs(178, 270).addBox(-3F, -3F, -13F, 6F, 6F, 13F)
                .texOffs(432, 293).addBox(-7F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(370, 270).addBox(-1F, -7F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -29F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(138, 270).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(188, 238).mirror().addBox(-6F, -10F, -9F, 17F, 10F, 19F).mirror(false)
                .texOffs(216, 270).mirror().addBox(-5F, -12F, -8F, 15F, 1F, 17F).mirror(false)
                .texOffs(304, 238).mirror().addBox(-4F, 2F, -4F, 8F, 19F, 8F).mirror(false),
                PartPose.offsetAndRotation(25F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(260, 238).mirror().addBox(-5F, 0F, -6F, 10F, 17F, 12F).mirror(false)
                .texOffs(0, 293).mirror().addBox(-6F, 16F, -6F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_gatling = p_forearm_l.addOrReplaceChild("forearm_l_gatling", CubeListBuilder.create()
                .texOffs(128, 238).addBox(-6F, -6F, -15F, 13F, 13F, 17F)
                .texOffs(50, 293).addBox(-4F, -8F, -13F, 8F, 2F, 13F)
                .texOffs(414, 270).addBox(6F, -4F, -8F, 2F, 8F, 8F),
                PartPose.offsetAndRotation(0F, 22F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gatling_barrel = p_forearm_l_gatling.addOrReplaceChild("forearm_l_gatling_barrel", CubeListBuilder.create()
                .texOffs(0, 270).addBox(3F, -1F, -21F, 2F, 2F, 21F)
                .texOffs(0, 270).addBox(1F, 2F, -21F, 2F, 2F, 21F)
                .texOffs(0, 270).addBox(-3F, 2F, -21F, 2F, 2F, 21F)
                .texOffs(0, 270).addBox(-5F, -1F, -21F, 2F, 2F, 21F)
                .texOffs(0, 270).addBox(-3F, -4F, -21F, 2F, 2F, 21F)
                .texOffs(0, 270).addBox(1F, -4F, -21F, 2F, 2F, 21F)
                .texOffs(126, 293).addBox(-5F, -5F, -4F, 10F, 10F, 3F)
                .texOffs(184, 293).addBox(-5F, -5F, -18F, 10F, 10F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gatling_flash = p_forearm_l_gatling_barrel.addOrReplaceChild("forearm_l_gatling_flash", CubeListBuilder.create()
                .texOffs(178, 270).addBox(-3F, -3F, -13F, 6F, 6F, 13F)
                .texOffs(432, 293).addBox(-7F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(370, 270).addBox(-1F, -7F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -21F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(404, 238).addBox(-3F, -18F, -3F, 6F, 19F, 6F)
                .texOffs(256, 293).addBox(-4F, -19F, -4F, 7F, 2F, 7F)
                .texOffs(468, 293).addBox(-2F, -20F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-11F, -29F, 16F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(404, 238).addBox(-3F, -18F, -3F, 6F, 19F, 6F)
                .texOffs(256, 293).addBox(-4F, -19F, -4F, 7F, 2F, 7F)
                .texOffs(468, 293).addBox(-2F, -20F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(11F, -29F, 16F, -0.15F, 0F, -0.1F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(0, 168).addBox(-1F, -6F, -29F, 1F, 13F, 57F),
                PartPose.offsetAndRotation(-37F, -19F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(0, 168).mirror().addBox(-1F, -6F, -29F, 1F, 13F, 57F).mirror(false),
                PartPose.offsetAndRotation(37F, -19F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/torso", "hull/torso/head").walkRate(0F)
                .arm("hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r", -1, false)
                .arm("hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l", 1, false)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel", 2, 1.2F, 3)
                .sway("hull/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hull/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel", "hull/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel/forearm_l_gatling_flash", null);
    }
}
