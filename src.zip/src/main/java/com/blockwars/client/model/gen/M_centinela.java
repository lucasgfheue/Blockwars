package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Sentinel (centinela). */
@SuppressWarnings("unused")
public final class M_centinela {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("centinela"), "main");

    private M_centinela() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hull,-1,0,23,0,0,0,0/0,92,-36,-35,-30,71,15,61/238,168,-19,-38,-19,38,4,43/264,92,-19,-21,-29,38,17,57/"
                + "296,293,-34,-30,-31,67,6,1;tread_r,0,-27,-10,0,0,0,0/0,0,-8,-10,-36,17,21,71/176,0,-9,-16,-37,19,5,74;"
                + "wheel_r0,1,-9,2,-25,0,0,0/336,238,-1,-6,-6,1,13,13/284,293,-1,-2,-2,2,4,4;wheel_r1,1,-9,2,-8,0,0,0/336,238,-1,-6,-6,1,13,13/"
                + "284,293,-1,-2,-2,2,4,4;wheel_r2,1,-9,2,8,0,0,0/336,238,-1,-6,-6,1,13,13/284,293,-1,-2,-2,2,4,4;wheel_r3,1,-9,2,25,0,0,0/"
                + "336,238,-1,-6,-6,1,13,13/284,293,-1,-2,-2,2,4,4;tread_l,0,27,-10,0,0,0,0/!0,0,-8,-10,-36,17,21,71/!176,0,-9,-16,-37,19,5,74;"
                + "wheel_l0,6,9,2,-25,0,0,0/!336,238,-1,-6,-6,1,13,13/!284,293,-1,-2,-2,2,4,4;wheel_l1,6,9,2,-8,0,0,0/!336,238,-1,-6,-6,1,13,13/"
                + "!284,293,-1,-2,-2,2,4,4;wheel_l2,6,9,2,8,0,0,0/!336,238,-1,-6,-6,1,13,13/!284,293,-1,-2,-2,2,4,4;wheel_l3,6,9,2,25,0,0,0/"
                + "!336,238,-1,-6,-6,1,13,13/!284,293,-1,-2,-2,2,4,4;torso,0,0,-36,4,0,0,0/428,238,-10,-10,-7,21,10,14/116,168,-19,-34,-12,38,25,23/"
                + "434,270,-13,-28,-13,26,14,1/46,270,-14,-33,-9,28,4,18/208,293,-11,-22,12,23,10,1;head,11,0,-34,-2,0,0,0/"
                + "152,293,-4,-4,-4,8,4,8/0,238,-7,-19,-8,15,15,17/380,270,-8,-19,-9,16,15,1/0,308,-5,-13,-9,10,2,1/22,308,-4,-12,-10,8,1,1/"
                + "92,293,-2,-20,-4,4,1,13;antenna,12,5,-13,4,-0.2,0,0.15/364,238,-1,-25,-1,1,25,1/484,293,-1,-26,-1,2,2,2;"
                + "shoulder_r,11,-25,-26,0,0,0,0/138,270,-5,-5,-5,10,10,10/188,238,-10,-10,-9,17,10,19/216,270,-9,-12,-8,15,1,17/"
                + "304,238,-4,2,-4,8,19,8;forearm_r,14,0,20,0,-0.25,0,0/260,238,-5,0,-6,10,17,12/0,293,-6,16,-6,12,2,13;"
                + "forearm_r_cannon,15,0,23,-2,0,0,0/400,168,-7,-7,-21,15,15,25/280,270,-5,-8,-17,10,1,17/368,238,7,-4,-17,1,8,17;"
                + "forearm_r_cannon_barrel,16,0,0,-21,0,0,0/64,238,-4,-4,-25,7,7,25/334,270,-6,-6,-29,12,12,6;forearm_r_cannon_flash,17,0,0,-29,0,0,0/"
                + "178,270,-3,-3,-13,6,6,13/432,293,-7,-1,-4,15,2,3/370,270,-1,-7,-4,2,15,3;shoulder_l,11,25,-26,0,0,0,0/"
                + "!138,270,-5,-5,-5,10,10,10/!188,238,-6,-10,-9,17,10,19/!216,270,-5,-12,-8,15,1,17/!304,238,-4,2,-4,8,19,8;"
                + "forearm_l,19,0,20,0,-0.25,0,0/!260,238,-5,0,-6,10,17,12/!0,293,-6,16,-6,12,2,13;forearm_l_gatling,20,0,22,-2,0,0,0/"
                + "128,238,-6,-6,-15,13,13,17/50,293,-4,-8,-13,8,2,13/414,270,6,-4,-8,2,8,8;forearm_l_gatling_barrel,21,0,0,-15,0,0,0/"
                + "0,270,3,-1,-21,2,2,21/0,270,1,2,-21,2,2,21/0,270,-3,2,-21,2,2,21/0,270,-5,-1,-21,2,2,21/0,270,-3,-4,-21,2,2,21/"
                + "0,270,1,-4,-21,2,2,21/126,293,-5,-5,-4,10,10,3/184,293,-5,-5,-18,10,10,2;forearm_l_gatling_flash,22,0,0,-21,0,0,0/"
                + "178,270,-3,-3,-13,6,6,13/432,293,-7,-1,-4,15,2,3/370,270,-1,-7,-4,2,15,3;stack_r,11,-11,-29,16,-0.15,0,0.1/"
                + "404,238,-3,-18,-3,6,19,6/256,293,-4,-19,-4,7,2,7/468,293,-2,-20,-2,4,1,4;stack_l,11,11,-29,16,-0.15,0,-0.1/"
                + "404,238,-3,-18,-3,6,19,6/256,293,-4,-19,-4,7,2,7/468,293,-2,-20,-2,4,1,4;skirt_r,0,-37,-19,0,0,0,0/0,168,-1,-6,-29,1,13,57;"
                + "skirt_l,0,37,-19,0,0,0,0/!0,168,-1,-6,-29,1,13,57");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/torso", "hull/torso/head").walkRate(0F)
                .arm("hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r", -1, false)
                .arm("hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l", 1, false)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel", 2, 1.2F, 3)
                .sway("hull/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hull/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel", "hull/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel/forearm_l_gatling_flash", null);
    }
}
