package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Scrapjaw (mandibula). */
@SuppressWarnings("unused")
public final class M_mandibula {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("mandibula"), "main");

    private M_mandibula() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 125).addBox(-15F, -5F, -8F, 30F, 10F, 16F)
                .texOffs(0, 175).addBox(-16F, -4F, -9F, 32F, 5F, 18F)
                .texOffs(168, 229).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(0, 92).addBox(-7F, 0F, -7F, 14F, 19F, 14F)
                .texOffs(0, 198).addBox(-8F, 2F, -10F, 16F, 13F, 4F)
                .texOffs(200, 125).addBox(-8F, 2F, -7F, 2F, 11F, 14F),
                PartPose.offsetAndRotation(-13F, -24F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(0, 56).addBox(-8F, 0F, -8F, 16F, 20F, 16F)
                .texOffs(54, 229).addBox(-7F, -5F, -11F, 14F, 8F, 4F)
                .texOffs(202, 215).addBox(-6F, 6F, 8F, 12F, 10F, 3F),
                PartPose.offsetAndRotation(0F, 19F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(46, 215).addBox(-5F, -1F, -5F, 10F, 4F, 10F)
                .texOffs(64, 56).addBox(-11F, 3F, -16F, 22F, 6F, 28F)
                .texOffs(208, 229).addBox(-10F, 5F, -18F, 20F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(0, 92).mirror().addBox(-7F, 0F, -7F, 14F, 19F, 14F).mirror(false)
                .texOffs(0, 198).mirror().addBox(-8F, 2F, -10F, 16F, 13F, 4F).mirror(false)
                .texOffs(200, 125).mirror().addBox(6F, 2F, -7F, 2F, 11F, 14F).mirror(false),
                PartPose.offsetAndRotation(13F, -24F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(0, 56).mirror().addBox(-8F, 0F, -8F, 16F, 20F, 16F).mirror(false)
                .texOffs(54, 229).mirror().addBox(-7F, -5F, -11F, 14F, 8F, 4F).mirror(false)
                .texOffs(202, 215).mirror().addBox(-6F, 6F, 8F, 12F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 19F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(46, 215).mirror().addBox(-5F, -1F, -5F, 10F, 4F, 10F).mirror(false)
                .texOffs(64, 56).mirror().addBox(-11F, 3F, -16F, 22F, 6F, 28F).mirror(false)
                .texOffs(208, 229).mirror().addBox(-10F, 5F, -18F, 20F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 151).addBox(-12F, -10F, -7F, 24F, 10F, 14F)
                .texOffs(60, 0).addBox(-22F, -36F, -12F, 44F, 28F, 24F)
                .texOffs(40, 198).addBox(-15F, -30F, -13F, 31F, 15F, 1F)
                .texOffs(148, 151).addBox(-16F, -35F, -10F, 33F, 4F, 19F)
                .texOffs(0, 229).addBox(-13F, -23F, 12F, 26F, 11F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(232, 215).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-20F, -34F, 4F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(232, 215).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-20F, -34F, 10F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(232, 215).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(20F, -34F, 4F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(232, 215).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(20F, -34F, 10F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(90, 229).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(92, 125).addBox(-7F, -17F, -7F, 14F, 12F, 14F)
                .texOffs(198, 229).addBox(-6F, -14F, -8F, 4F, 4F, 1F)
                .texOffs(198, 229).addBox(2F, -14F, -8F, 4F, 4F, 1F)
                .texOffs(38, 241).addBox(-4F, -13F, -8F, 2F, 2F, 1F)
                .texOffs(38, 241).addBox(2F, -13F, -8F, 2F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -36F, -2F, 0F, 0F, 0F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(104, 198).addBox(-6F, 0F, -8F, 12F, 4F, 12F)
                .texOffs(8, 241).addBox(-5F, -1F, -8F, 10F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -5F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(232, 125).addBox(0F, -24F, 0F, 1F, 24F, 1F)
                .texOffs(0, 241).addBox(-1F, -25F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -12F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(100, 175).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(98, 92).addBox(-10F, -10F, -9F, 16F, 10F, 18F)
                .texOffs(176, 175).addBox(-9F, -11F, -8F, 14F, 1F, 16F)
                .texOffs(166, 92).addBox(-4F, 2F, -4F, 8F, 20F, 8F),
                PartPose.offsetAndRotation(-28F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_r0 = p_shoulder_r.addOrReplaceChild("sspike_r0", CubeListBuilder.create()
                .texOffs(232, 215).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-4F, -10F, -4F, 0F, 0F, -0.3F));
        PartDefinition p_sspike_r4 = p_shoulder_r.addOrReplaceChild("sspike_r4", CubeListBuilder.create()
                .texOffs(232, 215).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-4F, -10F, 4F, 0F, 0F, -0.3F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(56, 92).addBox(-5F, 0F, -6F, 10F, 18F, 11F)
                .texOffs(0, 215).addBox(-6F, 17F, -6F, 11F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_saw = p_forearm_r.addOrReplaceChild("forearm_r_saw", CubeListBuilder.create()
                .texOffs(76, 151).addBox(-4F, -4F, -14F, 8F, 8F, 16F)
                .texOffs(166, 215).addBox(-3F, -5F, -12F, 6F, 1F, 12F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_saw_disc = p_forearm_r_saw.addOrReplaceChild("forearm_r_saw_disc", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-1F, -14F, -14F, 2F, 28F, 28F)
                .texOffs(184, 198).addBox(-2F, -4F, -4F, 4F, 8F, 8F),
                PartPose.offsetAndRotation(0F, 0F, -18F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_saw_disc2 = p_forearm_r_saw_disc.addOrReplaceChild("forearm_r_saw_disc2", CubeListBuilder.create()
                .texOffs(196, 0).addBox(0F, -13F, -13F, 1F, 26F, 26F),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0.7854F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(100, 175).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(98, 92).mirror().addBox(-6F, -10F, -9F, 16F, 10F, 18F).mirror(false)
                .texOffs(176, 175).mirror().addBox(-5F, -11F, -8F, 14F, 1F, 16F).mirror(false)
                .texOffs(166, 92).mirror().addBox(-4F, 2F, -4F, 8F, 20F, 8F).mirror(false),
                PartPose.offsetAndRotation(28F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_l0 = p_shoulder_l.addOrReplaceChild("sspike_l0", CubeListBuilder.create()
                .texOffs(232, 215).mirror().addBox(-2F, -10F, -2F, 3F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -10F, -4F, 0F, 0F, 0.3F));
        PartDefinition p_sspike_l4 = p_shoulder_l.addOrReplaceChild("sspike_l4", CubeListBuilder.create()
                .texOffs(232, 215).mirror().addBox(-2F, -10F, -2F, 3F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(4F, -10F, 4F, 0F, 0F, 0.3F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(56, 92).mirror().addBox(-5F, 0F, -6F, 10F, 18F, 11F).mirror(false)
                .texOffs(0, 215).mirror().addBox(-6F, 17F, -6F, 11F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_flamer = p_forearm_l.addOrReplaceChild("forearm_l_flamer", CubeListBuilder.create()
                .texOffs(148, 125).addBox(-4F, -4F, -15F, 8F, 8F, 18F)
                .texOffs(140, 175).addBox(-3F, 4F, -6F, 6F, 6F, 12F)
                .texOffs(86, 215).addBox(-3F, 6F, -6F, 6F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_flamer_barrel = p_forearm_l_flamer.addOrReplaceChild("forearm_l_flamer_barrel", CubeListBuilder.create()
                .texOffs(152, 198).addBox(-2F, -2F, -12F, 4F, 4F, 12F)
                .texOffs(150, 229).addBox(-3F, -3F, -14F, 6F, 6F, 3F)
                .texOffs(30, 241).addBox(-1F, 3F, -14F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -1F, -16F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(124, 151).addBox(-3F, -17F, -3F, 6F, 18F, 6F)
                .texOffs(122, 229).addBox(-4F, -18F, -4F, 7F, 2F, 7F)
                .texOffs(182, 229).addBox(-2F, -19F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-13F, -32F, 16F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(124, 151).addBox(-3F, -17F, -3F, 6F, 18F, 6F)
                .texOffs(122, 229).addBox(-4F, -18F, -4F, 7F, 2F, 7F)
                .texOffs(182, 229).addBox(-2F, -19F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(13F, -32F, 16F, -0.15F, 0F, -0.1F));
        PartDefinition p_tank = p_torso.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(164, 56).addBox(-5F, -12F, -5F, 10F, 24F, 10F)
                .texOffs(122, 215).addBox(-6F, -12F, -6F, 11F, 2F, 11F)
                .texOffs(122, 215).addBox(-6F, 10F, -6F, 11F, 2F, 11F)
                .texOffs(208, 198).addBox(-6F, -2F, -6F, 11F, 4F, 11F),
                PartPose.offsetAndRotation(0F, -20F, 18F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(9.5F, 10F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_saw/forearm_r_saw_disc", 0, 0.8F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .jaw("hips/torso/head/jaw")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_flamer/forearm_l_flamer_barrel", null, null);
    }
}
