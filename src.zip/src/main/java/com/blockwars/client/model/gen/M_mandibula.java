package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Scrapjaw (mandibula). */
@SuppressWarnings("unused")
public final class M_mandibula {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("mandibula"), "main");

    private M_mandibula() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-24,0,0,0,0/0,125,-15,-5,-8,30,10,16/0,175,-16,-4,-9,32,5,18/168,229,-3,-2,-10,6,6,1;thigh_r,-1,-13,-24,0,0,0,0/"
                + "0,92,-7,0,-7,14,19,14/0,198,-8,2,-10,16,13,4/200,125,-8,2,-7,2,11,14;shin_r,1,0,19,0,0,0,0/0,56,-8,0,-8,16,20,16/"
                + "54,229,-7,-5,-11,14,8,4/202,215,-6,6,8,12,10,3;foot_r,2,0,20,0,0,0,0/46,215,-5,-1,-5,10,4,10/64,56,-11,3,-16,22,6,28/"
                + "208,229,-10,5,-18,20,3,1;thigh_l,-1,13,-24,0,0,0,0/!0,92,-7,0,-7,14,19,14/!0,198,-8,2,-10,16,13,4/!200,125,6,2,-7,2,11,14;"
                + "shin_l,4,0,19,0,0,0,0/!0,56,-8,0,-8,16,20,16/!54,229,-7,-5,-11,14,8,4/!202,215,-6,6,8,12,10,3;foot_l,5,0,20,0,0,0,0/"
                + "!46,215,-5,-1,-5,10,4,10/!64,56,-11,3,-16,22,6,28/!208,229,-10,5,-18,20,3,1;torso,0,0,-5,0,0,0,0/0,151,-12,-10,-7,24,10,14/"
                + "60,0,-22,-36,-12,44,28,24/40,198,-15,-30,-13,31,15,1/148,151,-16,-35,-10,33,4,19/0,229,-13,-23,12,26,11,1;"
                + "tspike_r0,7,-20,-34,4,0.5,0,-0.5/232,215,-2,-10,-2,3,10,3;tspike_r1,7,-20,-34,10,0.5,0,-0.5/232,215,-2,-10,-2,3,10,3;"
                + "tspike_l0,7,20,-34,4,0.5,0,0.5/232,215,-2,-10,-2,3,10,3;tspike_l1,7,20,-34,10,0.5,0,0.5/232,215,-2,-10,-2,3,10,3;"
                + "head,7,0,-36,-2,0,0,0/90,229,-4,-4,-4,8,4,8/92,125,-7,-17,-7,14,12,14/198,229,-6,-14,-8,4,4,1/198,229,2,-14,-8,4,4,1/"
                + "38,241,-4,-13,-8,2,2,1/38,241,2,-13,-8,2,2,1;jaw,12,0,-5,-2,0,0,0/104,198,-6,0,-8,12,4,12/8,241,-5,-1,-8,10,2,1;"
                + "antenna,12,5,-12,4,-0.2,0,0.15/232,125,0,-24,0,1,24,1/0,241,-1,-25,-1,2,2,2;shoulder_r,7,-28,-29,0,0,0,0/"
                + "100,175,-5,-5,-5,10,10,10/98,92,-10,-10,-9,16,10,18/176,175,-9,-11,-8,14,1,16/166,92,-4,2,-4,8,20,8;sspike_r0,15,-4,-10,-4,0,0,-0.3/"
                + "232,215,-2,-10,-2,3,10,3;sspike_r4,15,-4,-10,4,0,0,-0.3/232,215,-2,-10,-2,3,10,3;forearm_r,15,0,21,0,-0.25,0,0/"
                + "56,92,-5,0,-6,10,18,11/0,215,-6,17,-6,11,2,12;forearm_r_saw,18,0,23,-2,0,0,0/76,151,-4,-4,-14,8,8,16/"
                + "166,215,-3,-5,-12,6,1,12;forearm_r_saw_disc,19,0,0,-18,0,0,0/0,0,-1,-14,-14,2,28,28/184,198,-2,-4,-4,4,8,8;"
                + "forearm_r_saw_disc2,20,0,0,0,0.7854,0,0/196,0,0,-13,-13,1,26,26;shoulder_l,7,28,-29,0,0,0,0/!100,175,-5,-5,-5,10,10,10/"
                + "!98,92,-6,-10,-9,16,10,18/!176,175,-5,-11,-8,14,1,16/!166,92,-4,2,-4,8,20,8;sspike_l0,22,4,-10,-4,0,0,0.3/"
                + "!232,215,-2,-10,-2,3,10,3;sspike_l4,22,4,-10,4,0,0,0.3/!232,215,-2,-10,-2,3,10,3;forearm_l,22,0,21,0,-0.25,0,0/"
                + "!56,92,-5,0,-6,10,18,11/!0,215,-6,17,-6,11,2,12;forearm_l_flamer,25,0,23,-2,0,0,0/148,125,-4,-4,-15,8,8,18/"
                + "140,175,-3,4,-6,6,6,12/86,215,-3,6,-6,6,2,12;forearm_l_flamer_barrel,26,0,-1,-16,0,0,0/152,198,-2,-2,-12,4,4,12/"
                + "150,229,-3,-3,-14,6,6,3/30,241,-1,3,-14,2,1,2;stack_r,7,-13,-32,16,-0.15,0,0.1/124,151,-3,-17,-3,6,18,6/"
                + "122,229,-4,-18,-4,7,2,7/182,229,-2,-19,-2,4,1,4;stack_l,7,13,-32,16,-0.15,0,-0.1/124,151,-3,-17,-3,6,18,6/"
                + "122,229,-4,-18,-4,7,2,7/182,229,-2,-19,-2,4,1,4;tank,7,0,-20,18,0,0,1.5708/164,56,-5,-12,-5,10,24,10/"
                + "122,215,-6,-12,-6,11,2,11/122,215,-6,10,-6,11,2,11/208,198,-6,-2,-6,11,4,11");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(9.5F, 10F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_saw/forearm_r_saw_disc", 0, 0.8F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .jaw("hips/torso/head/jaw")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_flamer/forearm_l_flamer_barrel", null, null);
    }
}
