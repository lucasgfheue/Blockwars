package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Specter (espectro). */
@SuppressWarnings("unused")
public final class M_espectro {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("espectro"), "main");

    private M_espectro() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-44,0,0,0,0/58,89,-10,-5,-8,21,10,15/108,118,-11,-4,-9,23,5,17/62,175,-3,-2,-10,6,6,1;thigh_r,-1,-9,-44,0,0,0,0/"
                + "118,53,-3,0,-3,7,29,7/202,89,-4,2,-6,9,21,4/228,89,-4,2,-3,2,18,7;shin_r,1,0,29,0,0,0,0/192,0,-4,0,-4,9,30,9/"
                + "186,162,-3,-5,-7,7,8,4/148,141,-2,9,4,5,15,3;foot_r,2,0,30,0,0,0,0/24,175,-2,-1,-2,5,4,5/0,118,-7,3,-10,13,6,17/"
                + "146,175,-6,5,-11,11,3,1;thigh_l,-1,9,-44,0,0,0,0/!118,53,-3,0,-3,7,29,7/!202,89,-4,2,-6,9,21,4/!228,89,2,2,-3,2,18,7;"
                + "shin_l,4,0,29,0,0,0,0/!192,0,-4,0,-4,9,30,9/!186,162,-3,-5,-7,7,8,4/!148,141,-2,9,4,5,15,3;foot_l,5,0,30,0,0,0,0/"
                + "!24,175,-2,-1,-2,5,4,5/!0,118,-7,3,-10,13,6,17/!146,175,-6,5,-11,11,3,1;torso,0,0,-5,0,0,0,0/188,118,-9,-10,-6,17,10,11/"
                + "146,53,-12,-20,-8,25,13,17/0,53,-19,-31,-11,38,15,21/72,141,-11,-32,-7,23,4,15/0,162,-10,-28,-14,19,10,3;"
                + "head,7,0,-32,-2,0,0,0/124,162,-4,-4,-4,8,4,8/60,118,-6,-13,-6,11,10,13/44,175,-4,-12,-7,8,8,1/136,175,-2,-10,-7,4,4,1/"
                + "86,162,-4,-14,-5,8,1,11;antenna,8,5,-11,4,-0.2,0,0.15/246,89,0,-23,0,1,23,1/170,175,-1,-24,-1,2,2,2;shoulder_r,7,-25,-26,0,0,0,0/"
                + "32,141,-5,-5,-5,10,10,10/170,89,-4,2,-4,8,17,8;forearm_r,10,0,18,0,-0.25,0,0/130,89,-5,0,-5,10,15,10/"
                + "44,162,-5,14,-6,10,2,11;forearm_r_rail,11,0,20,-2,0,0,0/0,89,-5,-5,-15,10,10,19/156,162,-2,-6,-10,4,1,11;"
                + "forearm_r_rail_barrel,12,0,0,-13,0,0,0/18,0,-5,-3,-42,3,6,42/18,0,2,-3,-42,3,6,42/108,0,-1,-1,-41,2,2,40/"
                + "0,175,-5,-4,-43,10,8,2;forearm_r_rail_flash,13,0,0,-44,0,0,0/164,141,-3,-3,-11,6,6,11/104,175,-7,-1,-3,13,2,3/"
                + "218,141,-1,-7,-3,2,13,3;shoulder_l,7,25,-26,0,0,0,0/!32,141,-5,-5,-5,10,10,10/!170,89,-4,2,-4,8,17,8;"
                + "forearm_l,15,0,18,0,-0.25,0,0/!130,89,-5,0,-5,10,15,10/!44,162,-5,14,-6,10,2,11;forearm_l_blade,16,0,18,-2,-1.15,0,0/"
                + "208,162,-1,-6,-1,3,8,3/76,175,-5,1,-2,10,2,4/0,0,-1,3,-3,2,46,7;thr_r,7,-11,-21,14,0.35,0,0/0,141,-4,-7,-4,8,13,8/"
                + "220,162,-3,7,-3,7,3,7;flame_r,18,0,10,0,0,0,0/198,141,-2,0,-2,5,11,5;thr_l,7,11,-21,14,0.35,0,0/0,141,-4,-7,-4,8,13,8/"
                + "220,162,-3,7,-3,7,3,7;flame_l,20,0,10,0,0,0,0/198,141,-2,0,-2,5,11,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3474F)
                .legLengths(14.725F, 15.2F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel/forearm_r_rail_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
