package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Specter (espectro). */
@SuppressWarnings("unused")
public final class M_espectro {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("espectro"), "main");

    private M_espectro() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(58, 89).addBox(-10F, -5F, -8F, 21F, 10F, 15F)
                .texOffs(108, 118).addBox(-11F, -4F, -9F, 23F, 5F, 17F)
                .texOffs(62, 175).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(118, 53).addBox(-3F, 0F, -3F, 7F, 29F, 7F)
                .texOffs(202, 89).addBox(-4F, 2F, -6F, 9F, 21F, 4F)
                .texOffs(228, 89).addBox(-4F, 2F, -3F, 2F, 18F, 7F),
                PartPose.offsetAndRotation(-9F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(192, 0).addBox(-4F, 0F, -4F, 9F, 30F, 9F)
                .texOffs(186, 162).addBox(-3F, -5F, -7F, 7F, 8F, 4F)
                .texOffs(148, 141).addBox(-2F, 9F, 4F, 5F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(24, 175).addBox(-2F, -1F, -2F, 5F, 4F, 5F)
                .texOffs(0, 118).addBox(-7F, 3F, -10F, 13F, 6F, 17F)
                .texOffs(146, 175).addBox(-6F, 5F, -11F, 11F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 30F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(118, 53).mirror().addBox(-3F, 0F, -3F, 7F, 29F, 7F).mirror(false)
                .texOffs(202, 89).mirror().addBox(-4F, 2F, -6F, 9F, 21F, 4F).mirror(false)
                .texOffs(228, 89).mirror().addBox(2F, 2F, -3F, 2F, 18F, 7F).mirror(false),
                PartPose.offsetAndRotation(9F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(192, 0).mirror().addBox(-4F, 0F, -4F, 9F, 30F, 9F).mirror(false)
                .texOffs(186, 162).mirror().addBox(-3F, -5F, -7F, 7F, 8F, 4F).mirror(false)
                .texOffs(148, 141).mirror().addBox(-2F, 9F, 4F, 5F, 15F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(24, 175).mirror().addBox(-2F, -1F, -2F, 5F, 4F, 5F).mirror(false)
                .texOffs(0, 118).mirror().addBox(-7F, 3F, -10F, 13F, 6F, 17F).mirror(false)
                .texOffs(146, 175).mirror().addBox(-6F, 5F, -11F, 11F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 30F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(188, 118).addBox(-9F, -10F, -6F, 17F, 10F, 11F)
                .texOffs(146, 53).addBox(-12F, -20F, -8F, 25F, 13F, 17F)
                .texOffs(0, 53).addBox(-19F, -31F, -11F, 38F, 15F, 21F)
                .texOffs(72, 141).addBox(-11F, -32F, -7F, 23F, 4F, 15F)
                .texOffs(0, 162).addBox(-10F, -28F, -14F, 19F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(124, 162).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(60, 118).addBox(-6F, -13F, -6F, 11F, 10F, 13F)
                .texOffs(44, 175).addBox(-4F, -12F, -7F, 8F, 8F, 1F)
                .texOffs(136, 175).addBox(-2F, -10F, -7F, 4F, 4F, 1F)
                .texOffs(86, 162).addBox(-4F, -14F, -5F, 8F, 1F, 11F),
                PartPose.offsetAndRotation(0F, -32F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(246, 89).addBox(0F, -23F, 0F, 1F, 23F, 1F)
                .texOffs(170, 175).addBox(-1F, -24F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -11F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(32, 141).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(170, 89).addBox(-4F, 2F, -4F, 8F, 17F, 8F),
                PartPose.offsetAndRotation(-25F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(130, 89).addBox(-5F, 0F, -5F, 10F, 15F, 10F)
                .texOffs(44, 162).addBox(-5F, 14F, -6F, 10F, 2F, 11F),
                PartPose.offsetAndRotation(0F, 18F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_rail = p_forearm_r.addOrReplaceChild("forearm_r_rail", CubeListBuilder.create()
                .texOffs(0, 89).addBox(-5F, -5F, -15F, 10F, 10F, 19F)
                .texOffs(156, 162).addBox(-2F, -6F, -10F, 4F, 1F, 11F),
                PartPose.offsetAndRotation(0F, 20F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_rail_barrel = p_forearm_r_rail.addOrReplaceChild("forearm_r_rail_barrel", CubeListBuilder.create()
                .texOffs(18, 0).addBox(-5F, -3F, -42F, 3F, 6F, 42F)
                .texOffs(18, 0).addBox(2F, -3F, -42F, 3F, 6F, 42F)
                .texOffs(108, 0).addBox(-1F, -1F, -41F, 2F, 2F, 40F)
                .texOffs(0, 175).addBox(-5F, -4F, -43F, 10F, 8F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -13F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_rail_flash = p_forearm_r_rail_barrel.addOrReplaceChild("forearm_r_rail_flash", CubeListBuilder.create()
                .texOffs(164, 141).addBox(-3F, -3F, -11F, 6F, 6F, 11F)
                .texOffs(104, 175).addBox(-7F, -1F, -3F, 13F, 2F, 3F)
                .texOffs(218, 141).addBox(-1F, -7F, -3F, 2F, 13F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -44F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(32, 141).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(170, 89).mirror().addBox(-4F, 2F, -4F, 8F, 17F, 8F).mirror(false),
                PartPose.offsetAndRotation(25F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(130, 89).mirror().addBox(-5F, 0F, -5F, 10F, 15F, 10F).mirror(false)
                .texOffs(44, 162).mirror().addBox(-5F, 14F, -6F, 10F, 2F, 11F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_blade = p_forearm_l.addOrReplaceChild("forearm_l_blade", CubeListBuilder.create()
                .texOffs(208, 162).addBox(-1F, -6F, -1F, 3F, 8F, 3F)
                .texOffs(76, 175).addBox(-5F, 1F, -2F, 10F, 2F, 4F)
                .texOffs(0, 0).addBox(-1F, 3F, -3F, 2F, 46F, 7F),
                PartPose.offsetAndRotation(0F, 18F, -2F, -1.15F, 0F, 0F));
        PartDefinition p_thr_r = p_torso.addOrReplaceChild("thr_r", CubeListBuilder.create()
                .texOffs(0, 141).addBox(-4F, -7F, -4F, 8F, 13F, 8F)
                .texOffs(220, 162).addBox(-3F, 7F, -3F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(-11F, -21F, 14F, 0.35F, 0F, 0F));
        PartDefinition p_flame_r = p_thr_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(198, 141).addBox(-2F, 0F, -2F, 5F, 11F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition p_thr_l = p_torso.addOrReplaceChild("thr_l", CubeListBuilder.create()
                .texOffs(0, 141).addBox(-4F, -7F, -4F, 8F, 13F, 8F)
                .texOffs(220, 162).addBox(-3F, 7F, -3F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(11F, -21F, 14F, 0.35F, 0F, 0F));
        PartDefinition p_flame_l = p_thr_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(198, 141).addBox(-2F, 0F, -2F, 5F, 11F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3474F)
                .legLengths(14.725F, 15.2F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel/forearm_r_rail_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
