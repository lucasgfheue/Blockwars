package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Great Shovel (pala). */
@SuppressWarnings("unused")
public final class M_pala {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("pala"), "main");

    private M_pala() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 106).addBox(-41F, -40F, -35F, 82F, 17F, 69F)
                .texOffs(172, 276).addBox(-22F, -43F, -22F, 43F, 5F, 49F)
                .texOffs(0, 192).addBox(-22F, -24F, -33F, 43F, 19F, 65F)
                .texOffs(0, 426).addBox(-38F, -35F, -36F, 77F, 7F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-10F, -12F, -41F, 19F, 24F, 82F)
                .texOffs(202, 0).addBox(-11F, -18F, -42F, 22F, 6F, 84F),
                PartPose.offsetAndRotation(-31F, -12F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(154, 375).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(388, 405).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, -29F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(154, 375).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(388, 405).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, -10F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(154, 375).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(388, 405).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, 10F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(154, 375).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(388, 405).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, 29F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-10F, -12F, -41F, 19F, 24F, 82F).mirror(false)
                .texOffs(202, 0).mirror().addBox(-11F, -18F, -42F, 22F, 6F, 84F).mirror(false),
                PartPose.offsetAndRotation(31F, -12F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(154, 375).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(388, 405).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, -29F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(154, 375).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(388, 405).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, -10F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(154, 375).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(388, 405).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, 10F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(154, 375).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(388, 405).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, 29F, 0F, 0F, 0F));
        PartDefinition p_turret = p_hull.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(0, 276).addBox(-22F, -17F, -22F, 43F, 17F, 43F)
                .texOffs(0, 375).addBox(-17F, -18F, -12F, 34F, 1F, 29F)
                .texOffs(234, 405).addBox(-14F, -13F, 22F, 29F, 10F, 1F),
                PartPose.offsetAndRotation(0F, -41F, 5F, 0F, 0F, 0F));
        PartDefinition p_head = p_turret.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(106, 405).addBox(-7F, -5F, -7F, 14F, 5F, 14F)
                .texOffs(0, 336).addBox(-12F, -22F, -10F, 24F, 17F, 22F)
                .texOffs(294, 405).addBox(-10F, -19F, -10F, 19F, 10F, 1F)
                .texOffs(356, 375).addBox(-13F, -19F, -6F, 1F, 10F, 14F)
                .texOffs(356, 375).addBox(12F, -19F, -6F, 1F, 10F, 14F)
                .texOffs(212, 375).addBox(-13F, -23F, -10F, 25F, 1F, 23F)
                .texOffs(238, 426).addBox(-12F, -7F, -10F, 24F, 2F, 1F)
                .texOffs(288, 426).addBox(-10F, -24F, -8F, 2F, 1F, 2F)
                .texOffs(288, 426).addBox(7F, -24F, -8F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(12F, -17F, 7F, 0F, 0F, 0F));
        PartDefinition p_boom = p_turret.addOrReplaceChild("boom", CubeListBuilder.create()
                .texOffs(356, 276).addBox(-6F, -8F, -36F, 12F, 12F, 38F)
                .texOffs(92, 336).addBox(-7F, -10F, -35F, 13F, 1F, 36F)
                .texOffs(330, 336).addBox(-2F, 5F, -26F, 5F, 5F, 29F),
                PartPose.offsetAndRotation(-7F, -12F, -19F, -0.5F, 0F, 0F));
        PartDefinition p_boom_stick = p_boom.addOrReplaceChild("boom_stick", CubeListBuilder.create()
                .texOffs(190, 336).addBox(-5F, -5F, -25F, 10F, 10F, 26F),
                PartPose.offsetAndRotation(0F, 0F, -36F, 1.1F, 0F, 0F));
        PartDefinition p_boom_stick_bucket = p_boom_stick.addOrReplaceChild("boom_stick_bucket", CubeListBuilder.create()
                .texOffs(184, 375).addBox(-4F, -2F, -4F, 7F, 19F, 7F),
                PartPose.offsetAndRotation(0F, 0F, -24F, -0.4F, 0F, 0F));
        PartDefinition p_boom_stick_bucket_bk = p_boom_stick_bucket.addOrReplaceChild("boom_stick_bucket_bk", CubeListBuilder.create()
                .texOffs(398, 336).addBox(-12F, 0F, -14F, 24F, 14F, 19F)
                .texOffs(386, 375).addBox(-13F, -1F, -15F, 25F, 2F, 20F)
                .texOffs(156, 426).addBox(-10F, 13F, -14F, 2F, 5F, 2F)
                .texOffs(156, 426).addBox(-4F, 13F, -14F, 2F, 5F, 2F)
                .texOffs(156, 426).addBox(2F, 13F, -14F, 2F, 5F, 2F)
                .texOffs(156, 426).addBox(8F, 13F, -14F, 2F, 5F, 2F),
                PartPose.offsetAndRotation(0F, 17F, -2F, 0.6F, 0F, 0F));
        PartDefinition p_turret_gun = p_turret.addOrReplaceChild("turret_gun", CubeListBuilder.create()
                .texOffs(262, 336).addBox(-5F, -5F, -22F, 10F, 11F, 24F)
                .texOffs(0, 405).addBox(-4F, -8F, -19F, 7F, 2F, 19F)
                .texOffs(190, 405).addBox(-2F, 4F, -4F, 5F, 5F, 7F),
                PartPose.offsetAndRotation(14F, -7F, -19F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_barrel = p_turret_gun.addOrReplaceChild("turret_gun_barrel", CubeListBuilder.create()
                .texOffs(308, 375).addBox(-2F, -2F, -19F, 5F, 5F, 19F)
                .texOffs(334, 405).addBox(-4F, -4F, -21F, 7F, 7F, 4F),
                PartPose.offsetAndRotation(0F, -1F, -22F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_flash = p_turret_gun_barrel.addOrReplaceChild("turret_gun_flash", CubeListBuilder.create()
                .texOffs(52, 405).addBox(-4F, -4F, -14F, 7F, 7F, 14F)
                .texOffs(164, 426).addBox(-8F, -1F, -4F, 17F, 2F, 4F)
                .texOffs(94, 405).addBox(-1F, -8F, -4F, 2F, 17F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -22F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_turret.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(126, 375).addBox(-4F, -20F, -4F, 7F, 22F, 7F)
                .texOffs(356, 405).addBox(-4F, -22F, -4F, 8F, 2F, 8F)
                .texOffs(206, 426).addBox(-2F, -23F, -2F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(-13F, -14F, 26F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_turret.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(126, 375).addBox(-4F, -20F, -4F, 7F, 22F, 7F)
                .texOffs(356, 405).addBox(-4F, -22F, -4F, 8F, 2F, 8F)
                .texOffs(206, 426).addBox(-2F, -23F, -2F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(13F, -14F, 26F, -0.15F, 0F, -0.1F));
        PartDefinition p_beacon = p_turret.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(214, 405).addBox(-2F, -1F, -2F, 5F, 7F, 5F)
                .texOffs(162, 405).addBox(-4F, -7F, -4F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(-13F, -24F, 22F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(226, 426).addBox(-2F, -2F, -4F, 5F, 5F, 1F)
                .texOffs(226, 426).addBox(-2F, -2F, 3F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(216, 192).addBox(-1F, -7F, -33F, 1F, 14F, 65F),
                PartPose.offsetAndRotation(-43F, -22F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(216, 192).mirror().addBox(-1F, -7F, -33F, 1F, 14F, 65F).mirror(false),
                PartPose.offsetAndRotation(43F, -22F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/turret/beacon/beacon_spin", 1, 0.35F, 0)
                .primary(Rig.MountKind.BODY, "hull/turret/boom", null, null, null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
