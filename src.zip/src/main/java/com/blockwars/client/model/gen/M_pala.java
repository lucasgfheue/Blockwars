package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Great Shovel (pala). */
@SuppressWarnings("unused")
public final class M_pala {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("pala"), "main");

    private M_pala() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hull,-1,0,24,0,0,0,0/0,106,-41,-40,-35,82,17,69/172,276,-22,-43,-22,43,5,49/0,192,-22,-24,-33,43,19,65/"
                + "0,426,-38,-35,-36,77,7,1;tread_r,0,-31,-12,0,0,0,0/0,0,-10,-12,-41,19,24,82/202,0,-11,-18,-42,22,6,84;"
                + "wheel_r0,1,-10,2,-29,0,0,0/154,375,-1,-7,-7,1,14,14/388,405,-1,-2,-2,2,5,5;wheel_r1,1,-10,2,-10,0,0,0/"
                + "154,375,-1,-7,-7,1,14,14/388,405,-1,-2,-2,2,5,5;wheel_r2,1,-10,2,10,0,0,0/154,375,-1,-7,-7,1,14,14/388,405,-1,-2,-2,2,5,5;"
                + "wheel_r3,1,-10,2,29,0,0,0/154,375,-1,-7,-7,1,14,14/388,405,-1,-2,-2,2,5,5;tread_l,0,31,-12,0,0,0,0/!0,0,-10,-12,-41,19,24,82/"
                + "!202,0,-11,-18,-42,22,6,84;wheel_l0,6,10,2,-29,0,0,0/!154,375,-1,-7,-7,1,14,14/!388,405,-1,-2,-2,2,5,5;"
                + "wheel_l1,6,10,2,-10,0,0,0/!154,375,-1,-7,-7,1,14,14/!388,405,-1,-2,-2,2,5,5;wheel_l2,6,10,2,10,0,0,0/"
                + "!154,375,-1,-7,-7,1,14,14/!388,405,-1,-2,-2,2,5,5;wheel_l3,6,10,2,29,0,0,0/!154,375,-1,-7,-7,1,14,14/"
                + "!388,405,-1,-2,-2,2,5,5;turret,0,0,-41,5,0,0,0/0,276,-22,-17,-22,43,17,43/0,375,-17,-18,-12,34,1,29/234,405,-14,-13,22,29,10,1;"
                + "head,11,12,-17,7,0,0,0/106,405,-7,-5,-7,14,5,14/0,336,-12,-22,-10,24,17,22/294,405,-10,-19,-10,19,10,1/"
                + "356,375,-13,-19,-6,1,10,14/356,375,12,-19,-6,1,10,14/212,375,-13,-23,-10,25,1,23/238,426,-12,-7,-10,24,2,1/"
                + "288,426,-10,-24,-8,2,1,2/288,426,7,-24,-8,2,1,2;boom,11,-7,-12,-19,-0.5,0,0/356,276,-6,-8,-36,12,12,38/"
                + "92,336,-7,-10,-35,13,1,36/330,336,-2,5,-26,5,5,29;boom_stick,13,0,0,-36,1.1,0,0/190,336,-5,-5,-25,10,10,26;"
                + "boom_stick_bucket,14,0,0,-24,-0.4,0,0/184,375,-4,-2,-4,7,19,7;boom_stick_bucket_bk,15,0,17,-2,0.6,0,0/"
                + "398,336,-12,0,-14,24,14,19/386,375,-13,-1,-15,25,2,20/156,426,-10,13,-14,2,5,2/156,426,-4,13,-14,2,5,2/"
                + "156,426,2,13,-14,2,5,2/156,426,8,13,-14,2,5,2;turret_gun,11,14,-7,-19,0,0,0/262,336,-5,-5,-22,10,11,24/"
                + "0,405,-4,-8,-19,7,2,19/190,405,-2,4,-4,5,5,7;turret_gun_barrel,17,0,-1,-22,0,0,0/308,375,-2,-2,-19,5,5,19/"
                + "334,405,-4,-4,-21,7,7,4;turret_gun_flash,18,0,0,-22,0,0,0/52,405,-4,-4,-14,7,7,14/164,426,-8,-1,-4,17,2,4/"
                + "94,405,-1,-8,-4,2,17,4;stack_r,11,-13,-14,26,-0.15,0,0.1/126,375,-4,-20,-4,7,22,7/356,405,-4,-22,-4,8,2,8/"
                + "206,426,-2,-23,-2,5,1,5;stack_l,11,13,-14,26,-0.15,0,-0.1/126,375,-4,-20,-4,7,22,7/356,405,-4,-22,-4,8,2,8/"
                + "206,426,-2,-23,-2,5,1,5;beacon,11,-13,-24,22,0,0,0/214,405,-2,-1,-2,5,7,5/162,405,-4,-7,-4,7,7,7;beacon_spin,22,0,-4,0,0,0,0/"
                + "226,426,-2,-2,-4,5,5,1/226,426,-2,-2,3,5,5,1;skirt_r,0,-43,-22,0,0,0,0/216,192,-1,-7,-33,1,14,65;skirt_l,0,43,-22,0,0,0,0/"
                + "!216,192,-1,-7,-33,1,14,65");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/turret/beacon/beacon_spin", 1, 0.35F, 0)
                .primary(Rig.MountKind.BODY, "hull/turret/boom", null, null, null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
