package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Howitzer (obus). */
@SuppressWarnings("unused")
public final class M_obus {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("obus"), "main");

    private M_obus() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "body,-1,0,-21,0,0,0,0/0,0,-20,-31,-33,40,31,66/212,0,-16,-34,-28,32,3,56/0,161,-16,-18,-34,32,4,1/384,139,-12,-22,33,24,12,1;"
                + "leg_fr,-1,-23,-21,-24,0,0,0.12/0,97,-9,-2,-10,18,22,20/268,97,-10,-6,-11,20,9,22;shin_fr,1,0,18,0,0,0,-0.12/"
                + "76,97,-7,0,-7,13,20,13/358,139,-6,2,-9,11,12,2;foot_fr,2,0,20,0,0,0,0/180,97,-10,0,-14,20,7,24/102,161,-9,3,-15,18,3,1;"
                + "leg_fl,-1,23,-21,-24,0,0,-0.12/!0,97,-9,-2,-10,18,22,20/!268,97,-10,-6,-11,20,9,22;shin_fl,4,0,18,0,0,0,0.12/"
                + "!76,97,-7,0,-7,13,20,13/!358,139,-6,2,-9,11,12,2;foot_fl,5,0,20,0,0,0,0/!180,97,-10,0,-14,20,7,24/!102,161,-9,3,-15,18,3,1;"
                + "leg_br,-1,-23,-21,24,0,0,0.12/0,97,-9,-2,-10,18,22,20/268,97,-10,-6,-11,20,9,22;shin_br,7,0,18,0,0,0,-0.12/"
                + "76,97,-7,0,-7,13,20,13/358,139,-6,2,-9,11,12,2;foot_br,8,0,20,0,0,0,0/180,97,-10,0,-14,20,7,24/102,161,-9,3,-15,18,3,1;"
                + "leg_bl,-1,23,-21,24,0,0,-0.12/!0,97,-9,-2,-10,18,22,20/!268,97,-10,-6,-11,20,9,22;shin_bl,10,0,18,0,0,0,0.12/"
                + "!76,97,-7,0,-7,13,20,13/!358,139,-6,2,-9,11,12,2;foot_bl,11,0,20,0,0,0,0/!180,97,-10,0,-14,20,7,24/!102,161,-9,3,-15,18,3,1;"
                + "head,0,0,-18,-35,0,0,0/434,139,-4,-2,-4,9,2,9/0,139,-8,-11,-7,15,9,13/470,139,-7,-10,-7,13,7,1/140,161,-6,-8,-8,3,3,1/"
                + "140,161,-2,-8,-8,3,3,1/140,161,3,-8,-8,3,3,1/298,139,-8,-12,-7,16,1,14;antenna,13,6,-13,4,-0.2,0,0.15/"
                + "436,97,-1,-26,-1,1,26,1/148,161,-1,-28,-1,2,2,2;turret,0,0,-33,-4,0,0,0/352,97,-10,-7,-11,20,7,22/96,139,-8,-8,-9,15,1,18;"
                + "turret_mortar,15,0,-11,-4,-0.55,0,0/440,97,-8,-6,-8,15,11,15;turret_mortar_barrel,16,0,-4,-4,0,0,0/388,0,-7,-7,-35,13,13,35/"
                + "266,139,-7,-7,-32,14,14,2/162,139,-8,-8,-38,15,15,4;turret_mortar_flash,17,0,0,-37,0,0,0/56,139,-3,-3,-13,7,7,13/"
                + "66,161,-8,-1,-4,15,2,3/200,139,-1,-8,-4,2,15,3;drum,0,0,-18,40,0,0,1.5708/128,97,-7,-10,-7,13,20,13/210,139,-7,-1,-7,14,2,14");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.3636F)
                .legLengths(8.8F, 9.9F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_mortar/turret_mortar_barrel", "body/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_mortar/turret_mortar_barrel", "body/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null);
    }
}
