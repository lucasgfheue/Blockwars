package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Howitzer (obus). */
@SuppressWarnings("unused")
public final class M_obus {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("obus"), "main");

    private M_obus() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-20F, -31F, -33F, 40F, 31F, 66F)
                .texOffs(212, 0).addBox(-16F, -34F, -28F, 32F, 3F, 56F)
                .texOffs(0, 161).addBox(-16F, -18F, -34F, 32F, 4F, 1F)
                .texOffs(384, 139).addBox(-12F, -22F, 33F, 24F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -21F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create()
                .texOffs(0, 97).addBox(-9F, -2F, -10F, 18F, 22F, 20F)
                .texOffs(268, 97).addBox(-10F, -6F, -11F, 20F, 9F, 22F),
                PartPose.offsetAndRotation(-23F, -21F, -24F, 0F, 0F, 0.12F));
        PartDefinition p_shin_fr = p_leg_fr.addOrReplaceChild("shin_fr", CubeListBuilder.create()
                .texOffs(76, 97).addBox(-7F, 0F, -7F, 13F, 20F, 13F)
                .texOffs(358, 139).addBox(-6F, 2F, -9F, 11F, 12F, 2F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_fr = p_shin_fr.addOrReplaceChild("foot_fr", CubeListBuilder.create()
                .texOffs(180, 97).addBox(-10F, 0F, -14F, 20F, 7F, 24F)
                .texOffs(102, 161).addBox(-9F, 3F, -15F, 18F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create()
                .texOffs(0, 97).mirror().addBox(-9F, -2F, -10F, 18F, 22F, 20F).mirror(false)
                .texOffs(268, 97).mirror().addBox(-10F, -6F, -11F, 20F, 9F, 22F).mirror(false),
                PartPose.offsetAndRotation(23F, -21F, -24F, 0F, 0F, -0.12F));
        PartDefinition p_shin_fl = p_leg_fl.addOrReplaceChild("shin_fl", CubeListBuilder.create()
                .texOffs(76, 97).mirror().addBox(-7F, 0F, -7F, 13F, 20F, 13F).mirror(false)
                .texOffs(358, 139).mirror().addBox(-6F, 2F, -9F, 11F, 12F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_fl = p_shin_fl.addOrReplaceChild("foot_fl", CubeListBuilder.create()
                .texOffs(180, 97).mirror().addBox(-10F, 0F, -14F, 20F, 7F, 24F).mirror(false)
                .texOffs(102, 161).mirror().addBox(-9F, 3F, -15F, 18F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create()
                .texOffs(0, 97).addBox(-9F, -2F, -10F, 18F, 22F, 20F)
                .texOffs(268, 97).addBox(-10F, -6F, -11F, 20F, 9F, 22F),
                PartPose.offsetAndRotation(-23F, -21F, 24F, 0F, 0F, 0.12F));
        PartDefinition p_shin_br = p_leg_br.addOrReplaceChild("shin_br", CubeListBuilder.create()
                .texOffs(76, 97).addBox(-7F, 0F, -7F, 13F, 20F, 13F)
                .texOffs(358, 139).addBox(-6F, 2F, -9F, 11F, 12F, 2F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_br = p_shin_br.addOrReplaceChild("foot_br", CubeListBuilder.create()
                .texOffs(180, 97).addBox(-10F, 0F, -14F, 20F, 7F, 24F)
                .texOffs(102, 161).addBox(-9F, 3F, -15F, 18F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create()
                .texOffs(0, 97).mirror().addBox(-9F, -2F, -10F, 18F, 22F, 20F).mirror(false)
                .texOffs(268, 97).mirror().addBox(-10F, -6F, -11F, 20F, 9F, 22F).mirror(false),
                PartPose.offsetAndRotation(23F, -21F, 24F, 0F, 0F, -0.12F));
        PartDefinition p_shin_bl = p_leg_bl.addOrReplaceChild("shin_bl", CubeListBuilder.create()
                .texOffs(76, 97).mirror().addBox(-7F, 0F, -7F, 13F, 20F, 13F).mirror(false)
                .texOffs(358, 139).mirror().addBox(-6F, 2F, -9F, 11F, 12F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_bl = p_shin_bl.addOrReplaceChild("foot_bl", CubeListBuilder.create()
                .texOffs(180, 97).mirror().addBox(-10F, 0F, -14F, 20F, 7F, 24F).mirror(false)
                .texOffs(102, 161).mirror().addBox(-9F, 3F, -15F, 18F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(434, 139).addBox(-4F, -2F, -4F, 9F, 2F, 9F)
                .texOffs(0, 139).addBox(-8F, -11F, -7F, 15F, 9F, 13F)
                .texOffs(470, 139).addBox(-7F, -10F, -7F, 13F, 7F, 1F)
                .texOffs(140, 161).addBox(-6F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(140, 161).addBox(-2F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(140, 161).addBox(3F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(298, 139).addBox(-8F, -12F, -7F, 16F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -18F, -35F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(436, 97).addBox(-1F, -26F, -1F, 1F, 26F, 1F)
                .texOffs(148, 161).addBox(-1F, -28F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(352, 97).addBox(-10F, -7F, -11F, 20F, 7F, 22F)
                .texOffs(96, 139).addBox(-8F, -8F, -9F, 15F, 1F, 18F),
                PartPose.offsetAndRotation(0F, -33F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_mortar = p_turret.addOrReplaceChild("turret_mortar", CubeListBuilder.create()
                .texOffs(440, 97).addBox(-8F, -6F, -8F, 15F, 11F, 15F),
                PartPose.offsetAndRotation(0F, -11F, -4F, -0.55F, 0F, 0F));
        PartDefinition p_turret_mortar_barrel = p_turret_mortar.addOrReplaceChild("turret_mortar_barrel", CubeListBuilder.create()
                .texOffs(388, 0).addBox(-7F, -7F, -35F, 13F, 13F, 35F)
                .texOffs(266, 139).addBox(-7F, -7F, -32F, 14F, 14F, 2F)
                .texOffs(162, 139).addBox(-8F, -8F, -38F, 15F, 15F, 4F),
                PartPose.offsetAndRotation(0F, -4F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_mortar_flash = p_turret_mortar_barrel.addOrReplaceChild("turret_mortar_flash", CubeListBuilder.create()
                .texOffs(56, 139).addBox(-3F, -3F, -13F, 7F, 7F, 13F)
                .texOffs(66, 161).addBox(-8F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(200, 139).addBox(-1F, -8F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -37F, 0F, 0F, 0F));
        PartDefinition p_drum = p_body.addOrReplaceChild("drum", CubeListBuilder.create()
                .texOffs(128, 97).addBox(-7F, -10F, -7F, 13F, 20F, 13F)
                .texOffs(210, 139).addBox(-7F, -1F, -7F, 14F, 2F, 14F),
                PartPose.offsetAndRotation(0F, -18F, 40F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.3636F)
                .legLengths(8.8F, 9.9F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_mortar/turret_mortar_barrel", "body/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_mortar/turret_mortar_barrel", "body/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null);
    }
}
