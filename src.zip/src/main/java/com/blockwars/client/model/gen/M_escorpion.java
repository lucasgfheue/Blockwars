package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Scorpion (escorpion). */
@SuppressWarnings("unused")
public final class M_escorpion {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("escorpion"), "main");

    private M_escorpion() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "body,-1,0,8,0,0,0,0/0,0,-27,-17,-21,55,17,42/0,111,-23,-19,-17,46,3,34/118,198,-21,-12,-22,42,6,1;hip_r0,-1,-27,8,-13,0,-0.5,0;"
                + "leg_r0,1,0,-8,0,0,0,2.15/160,111,-4,0,-5,8,27,9/38,179,-5,-1,-6,10,6,12;shin_r0,2,0,27,0,0,0,-1.75/190,59,-3,0,-3,6,40,6/"
                + "198,148,-4,5,-4,7,14,7/102,198,-2,37,-2,4,4,4;hip_l0,-1,27,8,-13,0,0.5,0;leg_l0,4,0,-8,0,0,0,-2.15/!160,111,-4,0,-5,8,27,9/"
                + "!38,179,-5,-1,-6,10,6,12;shin_l0,5,0,27,0,0,0,1.75/!190,59,-3,0,-3,6,40,6/!198,148,-4,5,-4,7,14,7/!102,198,-2,37,-2,4,4,4;"
                + "hip_r1,-1,-27,8,0,0,0,0;leg_r1,7,0,-8,0,0,0,2.15/160,111,-4,0,-5,8,27,9/38,179,-5,-1,-6,10,6,12;shin_r1,8,0,27,0,0,0,-1.75/"
                + "190,59,-3,0,-3,6,40,6/198,148,-4,5,-4,7,14,7/102,198,-2,37,-2,4,4,4;hip_l1,-1,27,8,0,0,0,0;leg_l1,10,0,-8,0,0,0,-2.15/"
                + "!160,111,-4,0,-5,8,27,9/!38,179,-5,-1,-6,10,6,12;shin_l1,11,0,27,0,0,0,1.75/!190,59,-3,0,-3,6,40,6/!198,148,-4,5,-4,7,14,7/"
                + "!102,198,-2,37,-2,4,4,4;hip_r2,-1,-27,8,13,0,0.5,0;leg_r2,13,0,-8,0,0,0,2.15/160,111,-4,0,-5,8,27,9/38,179,-5,-1,-6,10,6,12;"
                + "shin_r2,14,0,27,0,0,0,-1.75/190,59,-3,0,-3,6,40,6/198,148,-4,5,-4,7,14,7/102,198,-2,37,-2,4,4,4;hip_l2,-1,27,8,13,0,-0.5,0;"
                + "leg_l2,16,0,-8,0,0,0,-2.15/!160,111,-4,0,-5,8,27,9/!38,179,-5,-1,-6,10,6,12;shin_l2,17,0,27,0,0,0,1.75/"
                + "!190,59,-3,0,-3,6,40,6/!198,148,-4,5,-4,7,14,7/!102,198,-2,37,-2,4,4,4;head,0,0,-10,-21,0,0,0/46,198,-4,-2,-4,8,2,8/"
                + "142,148,-7,-10,-6,15,8,13/204,198,-6,-9,-7,13,6,1/36,212,-6,-8,-8,3,3,1/36,212,-2,-8,-8,3,3,1/36,212,3,-8,-8,3,3,1/"
                + "140,179,-8,-12,-7,16,1,14;antenna,19,5,-13,4,-0.2,0,0.15/62,148,-1,-25,-1,1,25,1/44,212,-1,-26,-1,2,2,2;"
                + "turret,0,0,-21,-2,0,0,0/66,148,-9,-6,-9,19,6,19;turret_rail,21,0,-8,-4,0,0,0/0,148,-5,-5,-17,10,10,21/"
                + "0,198,-2,-6,-10,4,1,13;turret_rail_barrel,22,0,0,-15,0,0,0/0,59,-5,-3,-46,3,6,46/0,59,2,-3,-46,3,6,46/"
                + "98,59,-1,-1,-45,2,2,44/78,198,-5,-4,-47,10,8,2;turret_rail_flash,23,0,0,-48,0,0,0/0,179,-3,-3,-13,6,6,13/"
                + "0,212,-7,-1,-4,15,2,3/82,179,-1,-7,-4,2,15,3;tank,0,0,-4,23,0,0,1.5708/194,111,-5,-13,-5,10,25,10/200,179,-6,-13,-6,12,2,12/"
                + "200,179,-6,10,-6,12,2,12/92,179,-6,-2,-6,12,4,12;bspike0,0,0,-21,-13,0.5,0,0/34,198,-2,-10,-2,3,10,3;"
                + "bspike1,0,0,-21,0,0.5,0,0/34,198,-2,-10,-2,3,10,3;bspike2,0,0,-21,13,0.5,0,0/34,198,-2,-10,-2,3,10,3");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4762F)
                .legLengths(13.65F, 19.95F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_rail/turret_rail_barrel", "body/turret/turret_rail/turret_rail_barrel/turret_rail_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_rail/turret_rail_barrel", "body/turret/turret_rail/turret_rail_barrel/turret_rail_flash", null);
    }
}
