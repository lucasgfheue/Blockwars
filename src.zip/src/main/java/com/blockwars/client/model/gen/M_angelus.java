package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for ANGELUS · Orbital Uplink (angelus). */
@SuppressWarnings("unused")
public final class M_angelus {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("angelus"), "main");

    private M_angelus() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-22F, -35F, -38F, 45F, 35F, 75F)
                .texOffs(240, 0).addBox(-18F, -38F, -32F, 36F, 4F, 64F)
                .texOffs(192, 190).addBox(-18F, -20F, -39F, 36F, 5F, 1F)
                .texOffs(414, 157).addBox(-13F, -24F, 38F, 27F, 14F, 1F),
                PartPose.offsetAndRotation(0F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create()
                .texOffs(0, 110).addBox(-10F, -2F, -11F, 20F, 25F, 22F)
                .texOffs(332, 110).addBox(-11F, -6F, -12F, 22F, 10F, 25F),
                PartPose.offsetAndRotation(-26F, -26F, -28F, 0F, 0F, 0.12F));
        PartDefinition p_shin_fr = p_leg_fr.addOrReplaceChild("shin_fr", CubeListBuilder.create()
                .texOffs(172, 110).addBox(-8F, 0F, -8F, 15F, 22F, 15F)
                .texOffs(470, 157).addBox(-6F, 2F, -10F, 12F, 13F, 2F),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_fr = p_shin_fr.addOrReplaceChild("foot_fr", CubeListBuilder.create()
                .texOffs(232, 110).addBox(-11F, 0F, -16F, 22F, 8F, 28F)
                .texOffs(278, 190).addBox(-10F, 3F, -18F, 20F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create()
                .texOffs(0, 110).mirror().addBox(-10F, -2F, -11F, 20F, 25F, 22F).mirror(false)
                .texOffs(332, 110).mirror().addBox(-11F, -6F, -12F, 22F, 10F, 25F).mirror(false),
                PartPose.offsetAndRotation(26F, -26F, -28F, 0F, 0F, -0.12F));
        PartDefinition p_shin_fl = p_leg_fl.addOrReplaceChild("shin_fl", CubeListBuilder.create()
                .texOffs(172, 110).mirror().addBox(-8F, 0F, -8F, 15F, 22F, 15F).mirror(false)
                .texOffs(470, 157).mirror().addBox(-6F, 2F, -10F, 12F, 13F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_fl = p_shin_fl.addOrReplaceChild("foot_fl", CubeListBuilder.create()
                .texOffs(232, 110).mirror().addBox(-11F, 0F, -16F, 22F, 8F, 28F).mirror(false)
                .texOffs(278, 190).mirror().addBox(-10F, 3F, -18F, 20F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create()
                .texOffs(0, 110).addBox(-10F, -2F, -11F, 20F, 25F, 22F)
                .texOffs(332, 110).addBox(-11F, -6F, -12F, 22F, 10F, 25F),
                PartPose.offsetAndRotation(-26F, -26F, 28F, 0F, 0F, 0.12F));
        PartDefinition p_shin_br = p_leg_br.addOrReplaceChild("shin_br", CubeListBuilder.create()
                .texOffs(172, 110).addBox(-8F, 0F, -8F, 15F, 22F, 15F)
                .texOffs(470, 157).addBox(-6F, 2F, -10F, 12F, 13F, 2F),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_br = p_shin_br.addOrReplaceChild("foot_br", CubeListBuilder.create()
                .texOffs(232, 110).addBox(-11F, 0F, -16F, 22F, 8F, 28F)
                .texOffs(278, 190).addBox(-10F, 3F, -18F, 20F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create()
                .texOffs(0, 110).mirror().addBox(-10F, -2F, -11F, 20F, 25F, 22F).mirror(false)
                .texOffs(332, 110).mirror().addBox(-11F, -6F, -12F, 22F, 10F, 25F).mirror(false),
                PartPose.offsetAndRotation(26F, -26F, 28F, 0F, 0F, -0.12F));
        PartDefinition p_shin_bl = p_leg_bl.addOrReplaceChild("shin_bl", CubeListBuilder.create()
                .texOffs(172, 110).mirror().addBox(-8F, 0F, -8F, 15F, 22F, 15F).mirror(false)
                .texOffs(470, 157).mirror().addBox(-6F, 2F, -10F, 12F, 13F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_bl = p_shin_bl.addOrReplaceChild("foot_bl", CubeListBuilder.create()
                .texOffs(232, 110).mirror().addBox(-11F, 0F, -16F, 22F, 8F, 28F).mirror(false)
                .texOffs(278, 190).mirror().addBox(-10F, 3F, -18F, 20F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -21F, -40F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(182, 157).addBox(-1F, -30F, -1F, 1F, 30F, 1F)
                .texOffs(320, 190).addBox(-1F, -31F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -15F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(0, 157).addBox(-11F, -8F, -12F, 22F, 8F, 25F)
                .texOffs(258, 157).addBox(-9F, -9F, -10F, 18F, 1F, 20F),
                PartPose.offsetAndRotation(0F, -38F, -5F, 0F, 0F, 0F));
        PartDefinition p_turret_emitter = p_turret.addOrReplaceChild("turret_emitter", CubeListBuilder.create()
                .texOffs(186, 157).addBox(-6F, -6F, -12F, 11F, 11F, 15F)
                .texOffs(0, 190).addBox(-1F, 5F, -21F, 2F, 2F, 12F)
                .texOffs(0, 190).addBox(-7F, -4F, -21F, 2F, 2F, 12F)
                .texOffs(0, 190).addBox(4F, -4F, -21F, 2F, 2F, 12F),
                PartPose.offsetAndRotation(0F, -10F, -5F, 0F, 0F, 0F));
        PartDefinition p_turret_emitter_orb = p_turret_emitter.addOrReplaceChild("turret_emitter_orb", CubeListBuilder.create()
                .texOffs(334, 157).addBox(-4F, -4F, -4F, 8F, 8F, 8F)
                .texOffs(56, 190).addBox(-2F, -5F, -2F, 4F, 10F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -19F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_dish_mast = p_body.addOrReplaceChild("dish_mast", CubeListBuilder.create()
                .texOffs(158, 157).addBox(-3F, -25F, -3F, 6F, 25F, 6F),
                PartPose.offsetAndRotation(0F, -35F, 45F, 0F, 0F, 0F));
        PartDefinition p_dish = p_dish_mast.addOrReplaceChild("dish", CubeListBuilder.create()
                .texOffs(84, 110).addBox(-20F, -20F, -2F, 40F, 40F, 4F)
                .texOffs(94, 157).addBox(-14F, -14F, -4F, 28F, 28F, 4F)
                .texOffs(28, 190).addBox(-1F, -1F, -14F, 2F, 2F, 12F)
                .texOffs(172, 190).addBox(-2F, -2F, -18F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(0F, -25F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_beacon = p_body.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(72, 190).addBox(-2F, -1F, -2F, 5F, 8F, 5F)
                .texOffs(366, 157).addBox(-4F, -8F, -4F, 8F, 8F, 8F),
                PartPose.offsetAndRotation(-13F, -40F, 38F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(266, 190).addBox(-2F, -2F, -5F, 5F, 5F, 1F)
                .texOffs(266, 190).addBox(-2F, -2F, 3F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        PartDefinition p_coil_r = p_body.addOrReplaceChild("coil_r", CubeListBuilder.create()
                .texOffs(238, 157).addBox(-2F, -15F, -2F, 5F, 20F, 5F)
                .texOffs(92, 190).addBox(-5F, -6F, -5F, 10F, 2F, 10F)
                .texOffs(132, 190).addBox(-5F, -12F, -5F, 10F, 2F, 10F)
                .texOffs(92, 190).addBox(-5F, -19F, -5F, 10F, 2F, 10F)
                .texOffs(172, 190).addBox(-2F, -25F, -2F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(-13F, -30F, 42F, 0F, 0F, 0F));
        PartDefinition p_coil_l = p_body.addOrReplaceChild("coil_l", CubeListBuilder.create()
                .texOffs(238, 157).addBox(-2F, -15F, -2F, 5F, 20F, 5F)
                .texOffs(92, 190).addBox(-5F, -6F, -5F, 10F, 2F, 10F)
                .texOffs(132, 190).addBox(-5F, -12F, -5F, 10F, 2F, 10F)
                .texOffs(92, 190).addBox(-5F, -19F, -5F, 10F, 2F, 10F)
                .texOffs(172, 190).addBox(-2F, -25F, -2F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(13F, -30F, 42F, 0F, 0F, 0F));
        PartDefinition p_bspike0 = p_body.addOrReplaceChild("bspike0", CubeListBuilder.create()
                .texOffs(398, 157).addBox(-2F, -12F, -2F, 4F, 12F, 4F),
                PartPose.offsetAndRotation(0F, -38F, -20F, 0.5F, 0F, 0F));
        PartDefinition p_bspike1 = p_body.addOrReplaceChild("bspike1", CubeListBuilder.create()
                .texOffs(398, 157).addBox(-2F, -12F, -2F, 4F, 12F, 4F),
                PartPose.offsetAndRotation(0F, -38F, 0F, 0.5F, 0F, 0F));
        PartDefinition p_bspike2 = p_body.addOrReplaceChild("bspike2", CubeListBuilder.create()
                .texOffs(398, 157).addBox(-2F, -12F, -2F, 4F, 12F, 4F),
                PartPose.offsetAndRotation(0F, -38F, 20F, 0.5F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.32F)
                .legLengths(10F, 11.25F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .spin("body/dish_mast", 1, 0.02F, 0)
                .spin("body/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("body/turret/turret_emitter/turret_emitter_orb", 2, 0.25F, 0)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", null, null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", null, null, null);
    }
}
