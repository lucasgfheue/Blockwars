package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for ANGELUS · Orbital Uplink (angelus). */
@SuppressWarnings("unused")
public final class M_angelus {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("angelus"), "main");

    private M_angelus() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "body,-1,0,-26,0,0,0,0/0,0,-22,-35,-38,45,35,75/240,0,-18,-38,-32,36,4,64/192,190,-18,-20,-39,36,5,1/414,157,-13,-24,38,27,14,1;"
                + "leg_fr,-1,-26,-26,-28,0,0,0.12/0,110,-10,-2,-11,20,25,22/332,110,-11,-6,-12,22,10,25;shin_fr,1,0,20,0,0,0,-0.12/"
                + "172,110,-8,0,-8,15,22,15/470,157,-6,2,-10,12,13,2;foot_fr,2,0,22,0,0,0,0/232,110,-11,0,-16,22,8,28/278,190,-10,3,-18,20,4,1;"
                + "leg_fl,-1,26,-26,-28,0,0,-0.12/!0,110,-10,-2,-11,20,25,22/!332,110,-11,-6,-12,22,10,25;shin_fl,4,0,20,0,0,0,0.12/"
                + "!172,110,-8,0,-8,15,22,15/!470,157,-6,2,-10,12,13,2;foot_fl,5,0,22,0,0,0,0/!232,110,-11,0,-16,22,8,28/"
                + "!278,190,-10,3,-18,20,4,1;leg_br,-1,-26,-26,28,0,0,0.12/0,110,-10,-2,-11,20,25,22/332,110,-11,-6,-12,22,10,25;"
                + "shin_br,7,0,20,0,0,0,-0.12/172,110,-8,0,-8,15,22,15/470,157,-6,2,-10,12,13,2;foot_br,8,0,22,0,0,0,0/232,110,-11,0,-16,22,8,28/"
                + "278,190,-10,3,-18,20,4,1;leg_bl,-1,26,-26,28,0,0,-0.12/!0,110,-10,-2,-11,20,25,22/!332,110,-11,-6,-12,22,10,25;"
                + "shin_bl,10,0,20,0,0,0,0.12/!172,110,-8,0,-8,15,22,15/!470,157,-6,2,-10,12,13,2;foot_bl,11,0,22,0,0,0,0/"
                + "!232,110,-11,0,-16,22,8,28/!278,190,-10,3,-18,20,4,1;head,0,0,-21,-40,0,0,0;antenna,13,6,-15,5,-0.2,0,0.15/"
                + "182,157,-1,-30,-1,1,30,1/320,190,-1,-31,-1,2,2,2;turret,0,0,-38,-5,0,0,0/0,157,-11,-8,-12,22,8,25/258,157,-9,-9,-10,18,1,20;"
                + "turret_emitter,15,0,-10,-5,0,0,0/186,157,-6,-6,-12,11,11,15/0,190,-1,5,-21,2,2,12/0,190,-7,-4,-21,2,2,12/"
                + "0,190,4,-4,-21,2,2,12;turret_emitter_orb,16,0,0,-19,0.7854,0.7854,0/334,157,-4,-4,-4,8,8,8/56,190,-2,-5,-2,4,10,4;"
                + "dish_mast,0,0,-35,45,0,0,0/158,157,-3,-25,-3,6,25,6;dish,18,0,-25,0,-0.6,0,0/84,110,-20,-20,-2,40,40,4/"
                + "94,157,-14,-14,-4,28,28,4/28,190,-1,-1,-14,2,2,12/172,190,-2,-2,-18,5,5,5;beacon,0,-13,-40,38,0,0,0/72,190,-2,-1,-2,5,8,5/"
                + "366,157,-4,-8,-4,8,8,8;beacon_spin,20,0,-4,0,0,0,0/266,190,-2,-2,-5,5,5,1/266,190,-2,-2,3,5,5,1;coil_r,0,-13,-30,42,0,0,0/"
                + "238,157,-2,-15,-2,5,20,5/92,190,-5,-6,-5,10,2,10/132,190,-5,-12,-5,10,2,10/92,190,-5,-19,-5,10,2,10/172,190,-2,-25,-2,5,5,5;"
                + "coil_l,0,13,-30,42,0,0,0/238,157,-2,-15,-2,5,20,5/92,190,-5,-6,-5,10,2,10/132,190,-5,-12,-5,10,2,10/92,190,-5,-19,-5,10,2,10/"
                + "172,190,-2,-25,-2,5,5,5;bspike0,0,0,-38,-20,0.5,0,0/398,157,-2,-12,-2,4,12,4;bspike1,0,0,-38,0,0.5,0,0/"
                + "398,157,-2,-12,-2,4,12,4;bspike2,0,0,-38,20,0.5,0,0/398,157,-2,-12,-2,4,12,4");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.32F)
                .legLengths(10F, 11.25F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .spin("body/dish_mast", 1, 0.02F, 0)
                .spin("body/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("body/turret/turret_emitter/turret_emitter_orb", 2, 0.25F, 0)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", null, null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", null, null, null);
    }
}
