package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Glacier (glaciar). */
@SuppressWarnings("unused")
public final class M_glaciar {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("glaciar"), "main");

    private M_glaciar() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-31,0,0,0,0/278,96,-17,-6,-9,34,12,18/114,129,-18,-5,-10,37,6,21/126,176,-3,-2,-12,7,7,1;thigh_r,-1,-15,-31,0,0,0,0/"
                + "114,57,-8,0,-8,16,22,16/426,129,-9,2,-12,18,15,5/382,96,-9,2,-8,2,13,16;shin_r,1,0,22,0,0,0,0/378,0,-9,0,-9,18,23,18/"
                + "372,157,-8,-6,-13,16,9,5/296,157,-7,7,9,14,12,3;foot_r,2,0,23,0,0,0,0/252,157,-6,-1,-6,11,5,11/0,57,-13,3,-19,25,7,32/"
                + "180,176,-12,6,-20,23,3,1;thigh_l,-1,15,-31,0,0,0,0/!114,57,-8,0,-8,16,22,16/!426,129,-9,2,-12,18,15,5/"
                + "!382,96,7,2,-8,2,13,16;shin_l,4,0,22,0,0,0,0/!378,0,-9,0,-9,18,23,18/!372,157,-8,-6,-13,16,9,5/!296,157,-7,7,9,14,12,3;"
                + "foot_l,5,0,23,0,0,0,0/!252,157,-6,-1,-6,11,5,11/!0,57,-13,3,-19,25,7,32/!180,176,-12,6,-20,23,3,1;torso,0,0,-6,0,0,0,0/"
                + "182,96,-14,-12,-10,29,12,19/142,0,-24,-39,-13,48,30,26/0,0,-19,-37,-16,39,25,32/300,57,-25,-27,-14,49,6,27/"
                + "0,129,-17,-41,-11,34,5,23/84,176,-5,-32,-18,9,9,2/330,157,-7,-34,-17,14,14,1;tspike_r0,7,-22,-39,5,0.5,0,-0.5/"
                + "360,157,-2,-12,-2,3,12,3;tspike_r1,7,-22,-39,12,0.5,0,-0.5/360,157,-2,-12,-2,3,12,3;tspike_l0,7,22,-39,5,0.5,0,0.5/"
                + "360,157,-2,-12,-2,3,12,3;tspike_l1,7,22,-39,12,0.5,0,0.5/360,157,-2,-12,-2,3,12,3;head,7,0,-41,-2,0,0,0/"
                + "414,157,-5,-5,-5,9,5,9/78,96,-8,-18,-9,16,14,18/138,157,-7,-20,-7,14,1,16/228,176,-7,-13,-10,14,3,1/258,176,-6,-9,-10,12,3,1;"
                + "shoulder_r,7,-31,-33,0,0,0,0/268,129,-6,-6,-6,12,12,12/0,96,-12,-12,-10,18,12,21/0,157,-10,-13,-9,16,1,18/"
                + "146,96,-5,2,-5,9,23,9;forearm_r,13,0,24,0,-0.25,0,0/250,57,-6,0,-6,12,21,13/198,157,-6,20,-7,13,2,14;"
                + "forearm_r_emitter,14,0,26,-2,0,0,0/316,129,-5,-5,-12,10,10,14/450,157,-1,5,-20,2,2,12/450,157,-6,-4,-20,2,2,12/"
                + "450,157,4,-4,-20,2,2,12;forearm_r_emitter_orb,15,0,0,-17,0.7854,0.7854,0/478,157,-3,-3,-3,7,7,7/0,176,-2,-5,-2,3,9,3;"
                + "shoulder_l,7,31,-33,0,0,0,0/!268,129,-6,-6,-6,12,12,12/!0,96,-7,-12,-10,18,12,21/!0,157,-6,-13,-9,16,1,18/"
                + "!146,96,-5,2,-5,9,23,9;forearm_l,17,0,24,0,-0.25,0,0/!250,57,-6,0,-6,12,21,13/!198,157,-6,20,-7,13,2,14;"
                + "forearm_l_cannon,18,0,28,-2,0,0,0/290,0,-8,-8,-23,16,16,28/68,157,-6,-9,-18,12,1,18/230,129,8,-5,-18,1,9,18;"
                + "forearm_l_cannon_barrel,19,0,0,-23,0,0,0/178,57,-4,-4,-28,8,8,28/472,129,-6,-6,-32,13,13,7;forearm_l_cannon_flash,20,0,0,-32,0,0,0/"
                + "384,129,-3,-3,-14,7,7,14/142,176,-8,-1,-4,16,2,3/128,157,-1,-8,-4,2,16,3;coil_r,7,-14,-37,21,0,0,0/364,129,-2,-14,-2,5,18,5/"
                + "12,176,-5,-6,-5,9,2,9/48,176,-5,-12,-5,9,2,9/12,176,-5,-17,-5,9,2,9/106,176,-2,-23,-2,5,5,5;coil_l,7,14,-37,21,0,0,0/"
                + "364,129,-2,-14,-2,5,18,5/12,176,-5,-6,-5,9,2,9/48,176,-5,-12,-5,9,2,9/12,176,-5,-17,-5,9,2,9/106,176,-2,-23,-2,5,5,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.287F)
                .legLengths(10.925F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_cannon/forearm_l_cannon_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_cannon/forearm_l_cannon_barrel/forearm_l_cannon_flash", null);
    }
}
