package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Glacier (glaciar). */
@SuppressWarnings("unused")
public final class M_glaciar {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("glaciar"), "main");

    private M_glaciar() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(278, 96).addBox(-17F, -6F, -9F, 34F, 12F, 18F)
                .texOffs(114, 129).addBox(-18F, -5F, -10F, 37F, 6F, 21F)
                .texOffs(126, 176).addBox(-3F, -2F, -12F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(114, 57).addBox(-8F, 0F, -8F, 16F, 22F, 16F)
                .texOffs(426, 129).addBox(-9F, 2F, -12F, 18F, 15F, 5F)
                .texOffs(382, 96).addBox(-9F, 2F, -8F, 2F, 13F, 16F),
                PartPose.offsetAndRotation(-15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(378, 0).addBox(-9F, 0F, -9F, 18F, 23F, 18F)
                .texOffs(372, 157).addBox(-8F, -6F, -13F, 16F, 9F, 5F)
                .texOffs(296, 157).addBox(-7F, 7F, 9F, 14F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(252, 157).addBox(-6F, -1F, -6F, 11F, 5F, 11F)
                .texOffs(0, 57).addBox(-13F, 3F, -19F, 25F, 7F, 32F)
                .texOffs(180, 176).addBox(-12F, 6F, -20F, 23F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(114, 57).mirror().addBox(-8F, 0F, -8F, 16F, 22F, 16F).mirror(false)
                .texOffs(426, 129).mirror().addBox(-9F, 2F, -12F, 18F, 15F, 5F).mirror(false)
                .texOffs(382, 96).mirror().addBox(7F, 2F, -8F, 2F, 13F, 16F).mirror(false),
                PartPose.offsetAndRotation(15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(378, 0).mirror().addBox(-9F, 0F, -9F, 18F, 23F, 18F).mirror(false)
                .texOffs(372, 157).mirror().addBox(-8F, -6F, -13F, 16F, 9F, 5F).mirror(false)
                .texOffs(296, 157).mirror().addBox(-7F, 7F, 9F, 14F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(252, 157).mirror().addBox(-6F, -1F, -6F, 11F, 5F, 11F).mirror(false)
                .texOffs(0, 57).mirror().addBox(-13F, 3F, -19F, 25F, 7F, 32F).mirror(false)
                .texOffs(180, 176).mirror().addBox(-12F, 6F, -20F, 23F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(182, 96).addBox(-14F, -12F, -10F, 29F, 12F, 19F)
                .texOffs(142, 0).addBox(-24F, -39F, -13F, 48F, 30F, 26F)
                .texOffs(0, 0).addBox(-19F, -37F, -16F, 39F, 25F, 32F)
                .texOffs(300, 57).addBox(-25F, -27F, -14F, 49F, 6F, 27F)
                .texOffs(0, 129).addBox(-17F, -41F, -11F, 34F, 5F, 23F)
                .texOffs(84, 176).addBox(-5F, -32F, -18F, 9F, 9F, 2F)
                .texOffs(330, 157).addBox(-7F, -34F, -17F, 14F, 14F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(360, 157).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-22F, -39F, 5F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(360, 157).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-22F, -39F, 12F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(360, 157).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(22F, -39F, 5F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(360, 157).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(22F, -39F, 12F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(414, 157).addBox(-5F, -5F, -5F, 9F, 5F, 9F)
                .texOffs(78, 96).addBox(-8F, -18F, -9F, 16F, 14F, 18F)
                .texOffs(138, 157).addBox(-7F, -20F, -7F, 14F, 1F, 16F)
                .texOffs(228, 176).addBox(-7F, -13F, -10F, 14F, 3F, 1F)
                .texOffs(258, 176).addBox(-6F, -9F, -10F, 12F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -41F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(268, 129).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(0, 96).addBox(-12F, -12F, -10F, 18F, 12F, 21F)
                .texOffs(0, 157).addBox(-10F, -13F, -9F, 16F, 1F, 18F)
                .texOffs(146, 96).addBox(-5F, 2F, -5F, 9F, 23F, 9F),
                PartPose.offsetAndRotation(-31F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(250, 57).addBox(-6F, 0F, -6F, 12F, 21F, 13F)
                .texOffs(198, 157).addBox(-6F, 20F, -7F, 13F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_emitter = p_forearm_r.addOrReplaceChild("forearm_r_emitter", CubeListBuilder.create()
                .texOffs(316, 129).addBox(-5F, -5F, -12F, 10F, 10F, 14F)
                .texOffs(450, 157).addBox(-1F, 5F, -20F, 2F, 2F, 12F)
                .texOffs(450, 157).addBox(-6F, -4F, -20F, 2F, 2F, 12F)
                .texOffs(450, 157).addBox(4F, -4F, -20F, 2F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 26F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_emitter_orb = p_forearm_r_emitter.addOrReplaceChild("forearm_r_emitter_orb", CubeListBuilder.create()
                .texOffs(478, 157).addBox(-3F, -3F, -3F, 7F, 7F, 7F)
                .texOffs(0, 176).addBox(-2F, -5F, -2F, 3F, 9F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -17F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(268, 129).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(0, 96).mirror().addBox(-7F, -12F, -10F, 18F, 12F, 21F).mirror(false)
                .texOffs(0, 157).mirror().addBox(-6F, -13F, -9F, 16F, 1F, 18F).mirror(false)
                .texOffs(146, 96).mirror().addBox(-5F, 2F, -5F, 9F, 23F, 9F).mirror(false),
                PartPose.offsetAndRotation(31F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(250, 57).mirror().addBox(-6F, 0F, -6F, 12F, 21F, 13F).mirror(false)
                .texOffs(198, 157).mirror().addBox(-6F, 20F, -7F, 13F, 2F, 14F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_cannon = p_forearm_l.addOrReplaceChild("forearm_l_cannon", CubeListBuilder.create()
                .texOffs(290, 0).addBox(-8F, -8F, -23F, 16F, 16F, 28F)
                .texOffs(68, 157).addBox(-6F, -9F, -18F, 12F, 1F, 18F)
                .texOffs(230, 129).addBox(8F, -5F, -18F, 1F, 9F, 18F),
                PartPose.offsetAndRotation(0F, 28F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_cannon_barrel = p_forearm_l_cannon.addOrReplaceChild("forearm_l_cannon_barrel", CubeListBuilder.create()
                .texOffs(178, 57).addBox(-4F, -4F, -28F, 8F, 8F, 28F)
                .texOffs(472, 129).addBox(-6F, -6F, -32F, 13F, 13F, 7F),
                PartPose.offsetAndRotation(0F, 0F, -23F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_cannon_flash = p_forearm_l_cannon_barrel.addOrReplaceChild("forearm_l_cannon_flash", CubeListBuilder.create()
                .texOffs(384, 129).addBox(-3F, -3F, -14F, 7F, 7F, 14F)
                .texOffs(142, 176).addBox(-8F, -1F, -4F, 16F, 2F, 3F)
                .texOffs(128, 157).addBox(-1F, -8F, -4F, 2F, 16F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -32F, 0F, 0F, 0F));
        PartDefinition p_coil_r = p_torso.addOrReplaceChild("coil_r", CubeListBuilder.create()
                .texOffs(364, 129).addBox(-2F, -14F, -2F, 5F, 18F, 5F)
                .texOffs(12, 176).addBox(-5F, -6F, -5F, 9F, 2F, 9F)
                .texOffs(48, 176).addBox(-5F, -12F, -5F, 9F, 2F, 9F)
                .texOffs(12, 176).addBox(-5F, -17F, -5F, 9F, 2F, 9F)
                .texOffs(106, 176).addBox(-2F, -23F, -2F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(-14F, -37F, 21F, 0F, 0F, 0F));
        PartDefinition p_coil_l = p_torso.addOrReplaceChild("coil_l", CubeListBuilder.create()
                .texOffs(364, 129).addBox(-2F, -14F, -2F, 5F, 18F, 5F)
                .texOffs(12, 176).addBox(-5F, -6F, -5F, 9F, 2F, 9F)
                .texOffs(48, 176).addBox(-5F, -12F, -5F, 9F, 2F, 9F)
                .texOffs(12, 176).addBox(-5F, -17F, -5F, 9F, 2F, 9F)
                .texOffs(106, 176).addBox(-2F, -23F, -2F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(14F, -37F, 21F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.287F)
                .legLengths(10.925F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_cannon/forearm_l_cannon_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_cannon/forearm_l_cannon_barrel/forearm_l_cannon_flash", null);
    }
}
