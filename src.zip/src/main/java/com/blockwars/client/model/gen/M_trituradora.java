package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Grinder (trituradora). */
@SuppressWarnings("unused")
public final class M_trituradora {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("trituradora"), "main");

    private M_trituradora() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 88).addBox(-34F, -33F, -29F, 68F, 14F, 58F)
                .texOffs(144, 160).addBox(-18F, -36F, -18F, 36F, 4F, 41F)
                .texOffs(252, 88).addBox(-18F, -20F, -27F, 36F, 16F, 54F)
                .texOffs(124, 234).addBox(-32F, -29F, -30F, 64F, 6F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-8F, -10F, -34F, 16F, 20F, 68F)
                .texOffs(168, 0).addBox(-9F, -15F, -35F, 18F, 5F, 70F),
                PartPose.offsetAndRotation(-26F, -10F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(0, 210).addBox(0F, -6F, -6F, 1F, 12F, 12F)
                .texOffs(112, 234).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-8F, 2F, -24F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(0, 210).addBox(0F, -6F, -6F, 1F, 12F, 12F)
                .texOffs(112, 234).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-8F, 2F, -8F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(0, 210).addBox(0F, -6F, -6F, 1F, 12F, 12F)
                .texOffs(112, 234).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-8F, 2F, 8F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(0, 210).addBox(0F, -6F, -6F, 1F, 12F, 12F)
                .texOffs(112, 234).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-8F, 2F, 24F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-8F, -10F, -34F, 16F, 20F, 68F).mirror(false)
                .texOffs(168, 0).mirror().addBox(-9F, -15F, -35F, 18F, 5F, 70F).mirror(false),
                PartPose.offsetAndRotation(26F, -10F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(0, 210).mirror().addBox(0F, -6F, -6F, 1F, 12F, 12F).mirror(false)
                .texOffs(112, 234).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(8F, 2F, -24F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(0, 210).mirror().addBox(0F, -6F, -6F, 1F, 12F, 12F).mirror(false)
                .texOffs(112, 234).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(8F, 2F, -8F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(0, 210).mirror().addBox(0F, -6F, -6F, 1F, 12F, 12F).mirror(false)
                .texOffs(112, 234).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(8F, 2F, 8F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(0, 210).mirror().addBox(0F, -6F, -6F, 1F, 12F, 12F).mirror(false)
                .texOffs(112, 234).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(8F, 2F, 24F, 0F, 0F, 0F));
        PartDefinition p_turret = p_hull.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(0, 160).addBox(-18F, -14F, -18F, 36F, 14F, 36F)
                .texOffs(354, 160).addBox(-14F, -15F, -10F, 28F, 1F, 24F)
                .texOffs(0, 234).addBox(-12F, -11F, 18F, 24F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -34F, 4F, 0F, 0F, 0F));
        PartDefinition p_head = p_turret.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(428, 210).addBox(-4F, -2F, -4F, 8F, 2F, 8F)
                .texOffs(94, 210).addBox(-7F, -10F, -6F, 14F, 8F, 12F)
                .texOffs(254, 234).addBox(-6F, -9F, -7F, 12F, 6F, 1F)
                .texOffs(330, 234).addBox(-6F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(330, 234).addBox(-2F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(330, 234).addBox(2F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(346, 210).addBox(-8F, -11F, -6F, 15F, 1F, 13F),
                PartPose.offsetAndRotation(10F, -14F, 6F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(458, 160).addBox(0F, -24F, 0F, 1F, 24F, 1F)
                .texOffs(338, 234).addBox(-1F, -25F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -12F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_drillmount = p_hull.addOrReplaceChild("drillmount", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -14F, -34F, 0F, 0F, 0F));
        PartDefinition p_drillmount_drill = p_drillmount.addOrReplaceChild("drillmount_drill", CubeListBuilder.create()
                .texOffs(462, 160).addBox(-6F, -6F, -10F, 12F, 12F, 12F),
                PartPose.offsetAndRotation(0F, 2F, -2F, 0F, 0F, 0F));
        PartDefinition p_drillmount_drill_bit = p_drillmount_drill.addOrReplaceChild("drillmount_drill_bit", CubeListBuilder.create()
                .texOffs(50, 210).addBox(-7F, -7F, -8F, 14F, 14F, 8F)
                .texOffs(186, 210).addBox(-6F, -6F, -16F, 11F, 11F, 8F)
                .texOffs(314, 210).addBox(-4F, -4F, -24F, 8F, 8F, 8F)
                .texOffs(402, 210).addBox(-2F, -2F, -32F, 5F, 5F, 8F)
                .texOffs(96, 234).addBox(-1F, -1F, -39F, 2F, 2F, 6F),
                PartPose.offsetAndRotation(0F, 0F, -10F, 0F, 0F, 0F));
        PartDefinition p_turret_gun = p_turret.addOrReplaceChild("turret_gun", CubeListBuilder.create()
                .texOffs(298, 160).addBox(-4F, -4F, -18F, 8F, 9F, 20F)
                .texOffs(224, 210).addBox(-3F, -6F, -16F, 6F, 2F, 16F)
                .texOffs(460, 210).addBox(-2F, 4F, -3F, 4F, 4F, 6F),
                PartPose.offsetAndRotation(-10F, -6F, -18F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_barrel = p_turret_gun.addOrReplaceChild("turret_gun_barrel", CubeListBuilder.create()
                .texOffs(146, 210).addBox(-2F, -2F, -16F, 4F, 4F, 16F)
                .texOffs(78, 234).addBox(-3F, -3F, -18F, 6F, 6F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -18F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_flash = p_turret_gun_barrel.addOrReplaceChild("turret_gun_flash", CubeListBuilder.create()
                .texOffs(268, 210).addBox(-3F, -3F, -12F, 6F, 6F, 12F)
                .texOffs(280, 234).addBox(-7F, -1F, -4F, 14F, 2F, 3F)
                .texOffs(304, 210).addBox(-1F, -7F, -4F, 2F, 14F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -18F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_turret.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(26, 210).addBox(-3F, -17F, -3F, 6F, 18F, 6F)
                .texOffs(50, 234).addBox(-4F, -18F, -4F, 7F, 2F, 7F)
                .texOffs(314, 234).addBox(-2F, -19F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-11F, -12F, 22F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_turret.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(26, 210).addBox(-3F, -17F, -3F, 6F, 18F, 6F)
                .texOffs(50, 234).addBox(-4F, -18F, -4F, 7F, 2F, 7F)
                .texOffs(314, 234).addBox(-2F, -19F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(11F, -12F, 22F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/drillmount/drillmount_drill/drillmount_drill_bit", 2, 0.9F, 3)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "hull/drillmount", null, null, null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
