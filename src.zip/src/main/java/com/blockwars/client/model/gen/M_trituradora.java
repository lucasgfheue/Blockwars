package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Grinder (trituradora). */
@SuppressWarnings("unused")
public final class M_trituradora {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("trituradora"), "main");

    private M_trituradora() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hull,-1,0,24,0,0,0,0/0,88,-34,-33,-29,68,14,58/144,160,-18,-36,-18,36,4,41/252,88,-18,-20,-27,36,16,54/"
                + "124,234,-32,-29,-30,64,6,1;tread_r,0,-26,-10,0,0,0,0/0,0,-8,-10,-34,16,20,68/168,0,-9,-15,-35,18,5,70;"
                + "wheel_r0,1,-8,2,-24,0,0,0/0,210,0,-6,-6,1,12,12/112,234,-1,-2,-2,2,4,4;wheel_r1,1,-8,2,-8,0,0,0/0,210,0,-6,-6,1,12,12/"
                + "112,234,-1,-2,-2,2,4,4;wheel_r2,1,-8,2,8,0,0,0/0,210,0,-6,-6,1,12,12/112,234,-1,-2,-2,2,4,4;wheel_r3,1,-8,2,24,0,0,0/"
                + "0,210,0,-6,-6,1,12,12/112,234,-1,-2,-2,2,4,4;tread_l,0,26,-10,0,0,0,0/!0,0,-8,-10,-34,16,20,68/!168,0,-9,-15,-35,18,5,70;"
                + "wheel_l0,6,8,2,-24,0,0,0/!0,210,0,-6,-6,1,12,12/!112,234,-1,-2,-2,2,4,4;wheel_l1,6,8,2,-8,0,0,0/!0,210,0,-6,-6,1,12,12/"
                + "!112,234,-1,-2,-2,2,4,4;wheel_l2,6,8,2,8,0,0,0/!0,210,0,-6,-6,1,12,12/!112,234,-1,-2,-2,2,4,4;wheel_l3,6,8,2,24,0,0,0/"
                + "!0,210,0,-6,-6,1,12,12/!112,234,-1,-2,-2,2,4,4;turret,0,0,-34,4,0,0,0/0,160,-18,-14,-18,36,14,36/354,160,-14,-15,-10,28,1,24/"
                + "0,234,-12,-11,18,24,8,1;head,11,10,-14,6,0,0,0/428,210,-4,-2,-4,8,2,8/94,210,-7,-10,-6,14,8,12/254,234,-6,-9,-7,12,6,1/"
                + "330,234,-6,-8,-8,3,3,1/330,234,-2,-8,-8,3,3,1/330,234,2,-8,-8,3,3,1/346,210,-8,-11,-6,15,1,13;antenna,12,5,-12,4,-0.2,0,0.15/"
                + "458,160,0,-24,0,1,24,1/338,234,-1,-25,-1,2,2,2;drillmount,0,0,-14,-34,0,0,0;drillmount_drill,14,0,2,-2,0,0,0/"
                + "462,160,-6,-6,-10,12,12,12;drillmount_drill_bit,15,0,0,-10,0,0,0/50,210,-7,-7,-8,14,14,8/186,210,-6,-6,-16,11,11,8/"
                + "314,210,-4,-4,-24,8,8,8/402,210,-2,-2,-32,5,5,8/96,234,-1,-1,-39,2,2,6;turret_gun,11,-10,-6,-18,0,0,0/"
                + "298,160,-4,-4,-18,8,9,20/224,210,-3,-6,-16,6,2,16/460,210,-2,4,-3,4,4,6;turret_gun_barrel,17,0,-1,-18,0,0,0/"
                + "146,210,-2,-2,-16,4,4,16/78,234,-3,-3,-18,6,6,3;turret_gun_flash,18,0,0,-18,0,0,0/268,210,-3,-3,-12,6,6,12/"
                + "280,234,-7,-1,-4,14,2,3/304,210,-1,-7,-4,2,14,3;stack_r,11,-11,-12,22,-0.15,0,0.1/26,210,-3,-17,-3,6,18,6/"
                + "50,234,-4,-18,-4,7,2,7/314,234,-2,-19,-2,4,1,4;stack_l,11,11,-12,22,-0.15,0,-0.1/26,210,-3,-17,-3,6,18,6/"
                + "50,234,-4,-18,-4,7,2,7/314,234,-2,-19,-2,4,1,4");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/drillmount/drillmount_drill/drillmount_drill_bit", 2, 0.9F, 3)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "hull/drillmount", null, null, null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
