package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Simoom (simun). */
@SuppressWarnings("unused")
public final class M_simun {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("simun"), "main");

    private M_simun() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(48, 62).addBox(-11F, -4F, -7F, 22F, 9F, 14F)
                .texOffs(0, 87).addBox(-12F, -4F, -8F, 23F, 4F, 16F)
                .texOffs(32, 154).addBox(-3F, -2F, -9F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -19F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = p_hips.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(112, 0).addBox(-5F, 0F, -5F, 11F, 22F, 11F)
                .texOffs(28, 62).addBox(-6F, 3F, -4F, 1F, 15F, 9F),
                PartPose.offsetAndRotation(-13F, 0F, 0F, -0.55F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(156, 0).addBox(-4F, 0F, -4F, 8F, 25F, 8F)
                .texOffs(0, 107).addBox(-5F, -4F, -5F, 11F, 7F, 11F)
                .texOffs(220, 107).addBox(-3F, 4F, 4F, 6F, 15F, 2F),
                PartPose.offsetAndRotation(0F, 20F, 0F, 1.15F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(78, 34).addBox(-7F, 0F, -13F, 14F, 5F, 22F)
                .texOffs(86, 154).addBox(-6F, 2F, -14F, 13F, 3F, 1F)
                .texOffs(180, 141).addBox(-3F, 0F, 7F, 5F, 4F, 7F),
                PartPose.offsetAndRotation(0F, 25F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_thigh_l = p_hips.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(112, 0).mirror().addBox(-5F, 0F, -5F, 11F, 22F, 11F).mirror(false)
                .texOffs(28, 62).mirror().addBox(5F, 3F, -4F, 1F, 15F, 9F).mirror(false),
                PartPose.offsetAndRotation(13F, 0F, 0F, -0.55F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(156, 0).mirror().addBox(-4F, 0F, -4F, 8F, 25F, 8F).mirror(false)
                .texOffs(0, 107).mirror().addBox(-5F, -4F, -5F, 11F, 7F, 11F).mirror(false)
                .texOffs(220, 107).mirror().addBox(-3F, 4F, 4F, 6F, 15F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, 1.15F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(78, 34).mirror().addBox(-7F, 0F, -13F, 14F, 5F, 22F).mirror(false)
                .texOffs(86, 154).mirror().addBox(-6F, 2F, -14F, 13F, 3F, 1F).mirror(false)
                .texOffs(180, 141).mirror().addBox(-3F, 0F, 7F, 5F, 4F, 7F).mirror(false),
                PartPose.offsetAndRotation(0F, 25F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(78, 87).addBox(-8F, -9F, -5F, 16F, 9F, 11F)
                .texOffs(0, 34).addBox(-12F, -19F, -8F, 23F, 12F, 16F)
                .texOffs(0, 0).addBox(-18F, -29F, -11F, 36F, 14F, 20F)
                .texOffs(160, 87).addBox(-11F, -31F, -7F, 22F, 4F, 14F)
                .texOffs(34, 141).addBox(-9F, -27F, -13F, 18F, 9F, 3F),
                PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(152, 141).addBox(-4F, -4F, -4F, 7F, 4F, 7F)
                .texOffs(170, 62).addBox(-5F, -13F, -5F, 11F, 9F, 13F)
                .texOffs(0, 154).addBox(-4F, -12F, -6F, 7F, 7F, 1F)
                .texOffs(76, 154).addBox(-2F, -10F, -7F, 4F, 4F, 1F)
                .texOffs(116, 141).addBox(-4F, -14F, -4F, 7F, 1F, 11F),
                PartPose.offsetAndRotation(0F, -31F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(166, 62).addBox(0F, -22F, 0F, 1F, 22F, 1F)
                .texOffs(114, 154).addBox(-1F, -22F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(4F, -11F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(44, 107).addBox(-4F, -4F, -4F, 9F, 9F, 9F)
                .texOffs(0, 62).addBox(-4F, 2F, -4F, 7F, 18F, 7F),
                PartPose.offsetAndRotation(-23F, -24F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(200, 34).addBox(-4F, 0F, -5F, 9F, 16F, 10F)
                .texOffs(198, 125).addBox(-5F, 15F, -5F, 10F, 2F, 11F),
                PartPose.offsetAndRotation(0F, 19F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_flamer = p_forearm_r.addOrReplaceChild("forearm_r_flamer", CubeListBuilder.create()
                .texOffs(120, 62).addBox(-4F, -4F, -14F, 7F, 7F, 16F)
                .texOffs(38, 125).addBox(-3F, 4F, -5F, 5F, 5F, 11F)
                .texOffs(0, 141).addBox(-3F, 5F, -6F, 6F, 2F, 11F),
                PartPose.offsetAndRotation(0F, 21F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_flamer_barrel = p_forearm_r_flamer.addOrReplaceChild("forearm_r_flamer_barrel", CubeListBuilder.create()
                .texOffs(112, 125).addBox(-2F, -2F, -11F, 4F, 4F, 11F)
                .texOffs(16, 154).addBox(-3F, -3F, -13F, 5F, 5F, 3F)
                .texOffs(122, 154).addBox(-1F, 2F, -13F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -1F, -14F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(44, 107).mirror().addBox(-4F, -4F, -4F, 9F, 9F, 9F).mirror(false)
                .texOffs(0, 62).mirror().addBox(-4F, 2F, -4F, 7F, 18F, 7F).mirror(false),
                PartPose.offsetAndRotation(23F, -24F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(200, 34).mirror().addBox(-4F, 0F, -5F, 9F, 16F, 10F).mirror(false)
                .texOffs(198, 125).mirror().addBox(-5F, 15F, -5F, 10F, 2F, 11F).mirror(false),
                PartPose.offsetAndRotation(0F, 19F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_gun = p_forearm_l.addOrReplaceChild("forearm_l_gun", CubeListBuilder.create()
                .texOffs(150, 34).addBox(-4F, -4F, -16F, 7F, 8F, 18F)
                .texOffs(0, 125).addBox(-3F, -6F, -14F, 5F, 2F, 14F)
                .texOffs(228, 141).addBox(-2F, 3F, -3F, 4F, 4F, 5F),
                PartPose.offsetAndRotation(0F, 21F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_barrel = p_forearm_l_gun.addOrReplaceChild("forearm_l_gun_barrel", CubeListBuilder.create()
                .texOffs(80, 107).addBox(-2F, -2F, -14F, 4F, 4F, 14F)
                .texOffs(16, 154).addBox(-3F, -3F, -16F, 5F, 5F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -16F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_flash = p_forearm_l_gun_barrel.addOrReplaceChild("forearm_l_gun_flash", CubeListBuilder.create()
                .texOffs(70, 125).addBox(-3F, -3F, -11F, 5F, 5F, 11F)
                .texOffs(44, 154).addBox(-6F, -1F, -3F, 13F, 2F, 3F)
                .texOffs(102, 125).addBox(-1F, -6F, -3F, 2F, 13F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -16F, 0F, 0F, 0F));
        PartDefinition p_thr_r = p_torso.addOrReplaceChild("thr_r", CubeListBuilder.create()
                .texOffs(132, 87).addBox(-4F, -6F, -4F, 7F, 13F, 7F)
                .texOffs(204, 141).addBox(-3F, 6F, -3F, 6F, 3F, 6F),
                PartPose.offsetAndRotation(-10F, -20F, 14F, 0.35F, 0F, 0F));
        PartDefinition p_flame_r = p_thr_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(142, 125).addBox(-2F, 0F, -2F, 4F, 11F, 4F),
                PartPose.offsetAndRotation(0F, 9F, 0F, 0F, 0F, 0F));
        PartDefinition p_thr_l = p_torso.addOrReplaceChild("thr_l", CubeListBuilder.create()
                .texOffs(132, 87).addBox(-4F, -6F, -4F, 7F, 13F, 7F)
                .texOffs(204, 141).addBox(-3F, 6F, -3F, 6F, 3F, 6F),
                PartPose.offsetAndRotation(10F, -20F, 14F, 0.35F, 0F, 0F));
        PartDefinition p_flame_l = p_thr_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(142, 125).addBox(-2F, 0F, -2F, 4F, 11F, 4F),
                PartPose.offsetAndRotation(0F, 9F, 0F, 0F, 0F, 0F));
        PartDefinition p_tank = p_torso.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(188, 0).addBox(-4F, -11F, -4F, 9F, 22F, 9F)
                .texOffs(76, 141).addBox(-5F, -11F, -5F, 10F, 2F, 10F)
                .texOffs(76, 141).addBox(-5F, 9F, -5F, 10F, 2F, 10F)
                .texOffs(158, 125).addBox(-5F, -2F, -5F, 10F, 4F, 10F),
                PartPose.offsetAndRotation(0F, -16F, 15F, 0F, 0F, 1.5708F));
        PartDefinition p_tail0 = p_hips.addOrReplaceChild("tail0", CubeListBuilder.create()
                .texOffs(116, 107).addBox(-3F, -3F, -1F, 5F, 5F, 13F),
                PartPose.offsetAndRotation(0F, 2F, 8F, 0.5F, 0F, 0F));
        PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create()
                .texOffs(152, 107).addBox(-2F, -2F, -1F, 4F, 4F, 13F),
                PartPose.offsetAndRotation(0F, 0F, 12F, 0.2F, 0F, 0F));
        PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create()
                .texOffs(186, 107).addBox(-2F, -2F, -1F, 4F, 4F, 13F),
                PartPose.offsetAndRotation(0F, 0F, 12F, 0.2F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.REVERSE).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3333F)
                .legLengths(10.8F, 12.6F)
                .leg("hips/thigh_r", "hips/thigh_r/shin_r", "hips/thigh_r/shin_r/foot_r", -1, 0F, 1)
                .leg("hips/thigh_l", "hips/thigh_l/shin_l", "hips/thigh_l/shin_l/foot_l", 1, 3.1416F, 1)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/tail0", 1, 0.12F, 0F)
                .sway("hips/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("hips/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_flamer/forearm_r_flamer_barrel", null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
