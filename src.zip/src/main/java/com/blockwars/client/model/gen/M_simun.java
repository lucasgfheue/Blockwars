package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Simoom (simun). */
@SuppressWarnings("unused")
public final class M_simun {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("simun"), "main");

    private M_simun() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-19,0,0,0,0/48,62,-11,-4,-7,22,9,14/0,87,-12,-4,-8,23,4,16/32,154,-3,-2,-9,5,5,1;thigh_r,0,-13,0,0,-0.55,0,0/"
                + "112,0,-5,0,-5,11,22,11/28,62,-6,3,-4,1,15,9;shin_r,1,0,20,0,1.15,0,0/156,0,-4,0,-4,8,25,8/0,107,-5,-4,-5,11,7,11/"
                + "220,107,-3,4,4,6,15,2;foot_r,2,0,25,0,-0.6,0,0/78,34,-7,0,-13,14,5,22/86,154,-6,2,-14,13,3,1/180,141,-3,0,7,5,4,7;"
                + "thigh_l,0,13,0,0,-0.55,0,0/!112,0,-5,0,-5,11,22,11/!28,62,5,3,-4,1,15,9;shin_l,4,0,20,0,1.15,0,0/!156,0,-4,0,-4,8,25,8/"
                + "!0,107,-5,-4,-5,11,7,11/!220,107,-3,4,4,6,15,2;foot_l,5,0,25,0,-0.6,0,0/!78,34,-7,0,-13,14,5,22/!86,154,-6,2,-14,13,3,1/"
                + "!180,141,-3,0,7,5,4,7;torso,0,0,-4,0,0,0,0/78,87,-8,-9,-5,16,9,11/0,34,-12,-19,-8,23,12,16/0,0,-18,-29,-11,36,14,20/"
                + "160,87,-11,-31,-7,22,4,14/34,141,-9,-27,-13,18,9,3;head,7,0,-31,-2,0,0,0/152,141,-4,-4,-4,7,4,7/170,62,-5,-13,-5,11,9,13/"
                + "0,154,-4,-12,-6,7,7,1/76,154,-2,-10,-7,4,4,1/116,141,-4,-14,-4,7,1,11;antenna,8,4,-11,4,-0.2,0,0.15/166,62,0,-22,0,1,22,1/"
                + "114,154,-1,-22,-1,2,2,2;shoulder_r,7,-23,-24,0,0,0,0/44,107,-4,-4,-4,9,9,9/0,62,-4,2,-4,7,18,7;forearm_r,10,0,19,0,-0.25,0,0/"
                + "200,34,-4,0,-5,9,16,10/198,125,-5,15,-5,10,2,11;forearm_r_flamer,11,0,21,-2,0,0,0/120,62,-4,-4,-14,7,7,16/"
                + "38,125,-3,4,-5,5,5,11/0,141,-3,5,-6,6,2,11;forearm_r_flamer_barrel,12,0,-1,-14,0,0,0/112,125,-2,-2,-11,4,4,11/"
                + "16,154,-3,-3,-13,5,5,3/122,154,-1,2,-13,2,1,2;shoulder_l,7,23,-24,0,0,0,0/!44,107,-4,-4,-4,9,9,9/!0,62,-4,2,-4,7,18,7;"
                + "forearm_l,14,0,19,0,-0.25,0,0/!200,34,-4,0,-5,9,16,10/!198,125,-5,15,-5,10,2,11;forearm_l_gun,15,0,21,-2,0,0,0/"
                + "150,34,-4,-4,-16,7,8,18/0,125,-3,-6,-14,5,2,14/228,141,-2,3,-3,4,4,5;forearm_l_gun_barrel,16,0,-1,-16,0,0,0/"
                + "80,107,-2,-2,-14,4,4,14/16,154,-3,-3,-16,5,5,3;forearm_l_gun_flash,17,0,0,-16,0,0,0/70,125,-3,-3,-11,5,5,11/"
                + "44,154,-6,-1,-3,13,2,3/102,125,-1,-6,-3,2,13,3;thr_r,7,-10,-20,14,0.35,0,0/132,87,-4,-6,-4,7,13,7/204,141,-3,6,-3,6,3,6;"
                + "flame_r,19,0,9,0,0,0,0/142,125,-2,0,-2,4,11,4;thr_l,7,10,-20,14,0.35,0,0/132,87,-4,-6,-4,7,13,7/204,141,-3,6,-3,6,3,6;"
                + "flame_l,21,0,9,0,0,0,0/142,125,-2,0,-2,4,11,4;tank,7,0,-16,15,0,0,1.5708/188,0,-4,-11,-4,9,22,9/76,141,-5,-11,-5,10,2,10/"
                + "76,141,-5,9,-5,10,2,10/158,125,-5,-2,-5,10,4,10;tail0,0,0,2,8,0.5,0,0/116,107,-3,-3,-1,5,5,13;tail1,24,0,0,12,0.2,0,0/"
                + "152,107,-2,-2,-1,4,4,13;tail2,25,0,0,12,0.2,0,0/186,107,-2,-2,-1,4,4,13");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.REVERSE).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3333F)
                .legLengths(10.8F, 12.6F)
                .leg("hips/thigh_r", "hips/thigh_r/shin_r", "hips/thigh_r/shin_r/foot_r", -1, 0F, 1)
                .leg("hips/thigh_l", "hips/thigh_l/shin_l", "hips/thigh_l/shin_l/foot_l", 1, 3.1416F, 1)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/tail0", 1, 0.12F, 0F)
                .sway("hips/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("hips/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_flamer/forearm_r_flamer_barrel", null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
