package com.blockwars.client.model.gen;

import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/** Generated registry of the 40 mecha models. */
public final class GenModels {
    public record Def(String id, ModelLayerLocation layer, Supplier<LayerDefinition> layerDefinition, Supplier<Rig> rig) {}

    public static final Map<String, Def> ALL = new LinkedHashMap<>();

    private GenModels() {}

    private static void put(Def d) {
        ALL.put(d.id(), d);
    }

    public static Def get(String id) {
        return ALL.get(id);
    }

    static {
        put(new Def("baluarte", M_baluarte.LAYER, M_baluarte::createBodyLayer, M_baluarte::rig));
        put(new Def("avispon", M_avispon.LAYER, M_avispon::createBodyLayer, M_avispon::rig));
        put(new Def("obus", M_obus.LAYER, M_obus::createBodyLayer, M_obus::rig));
        put(new Def("centinela", M_centinela.LAYER, M_centinela::createBodyLayer, M_centinela::rig));
        put(new Def("coloso", M_coloso.LAYER, M_coloso::createBodyLayer, M_coloso::rig));
        put(new Def("lancero", M_lancero.LAYER, M_lancero::createBodyLayer, M_lancero::rig));
        put(new Def("serafin", M_serafin.LAYER, M_serafin::createBodyLayer, M_serafin::rig));
        put(new Def("valquiria", M_valquiria.LAYER, M_valquiria::createBodyLayer, M_valquiria::rig));
        put(new Def("prisma", M_prisma.LAYER, M_prisma::createBodyLayer, M_prisma::rig));
        put(new Def("espectro", M_espectro.LAYER, M_espectro::createBodyLayer, M_espectro::rig));
        put(new Def("nova", M_nova.LAYER, M_nova::createBodyLayer, M_nova::rig));
        put(new Def("egida", M_egida.LAYER, M_egida::createBodyLayer, M_egida::rig));
        put(new Def("mandibula", M_mandibula.LAYER, M_mandibula::createBodyLayer, M_mandibula::rig));
        put(new Def("cascabel", M_cascabel.LAYER, M_cascabel::createBodyLayer, M_cascabel::rig));
        put(new Def("trituradora", M_trituradora.LAYER, M_trituradora::createBodyLayer, M_trituradora::rig));
        put(new Def("tetano", M_tetano.LAYER, M_tetano::createBodyLayer, M_tetano::rig));
        put(new Def("topadora", M_topadora.LAYER, M_topadora::createBodyLayer, M_topadora::rig));
        put(new Def("forjamagma", M_forjamagma.LAYER, M_forjamagma::createBodyLayer, M_forjamagma::rig));
        put(new Def("yunque", M_yunque.LAYER, M_yunque::createBodyLayer, M_yunque::rig));
        put(new Def("ceniza", M_ceniza.LAYER, M_ceniza::createBodyLayer, M_ceniza::rig));
        put(new Def("glaciar", M_glaciar.LAYER, M_glaciar::createBodyLayer, M_glaciar::rig));
        put(new Def("ventisca", M_ventisca.LAYER, M_ventisca::createBodyLayer, M_ventisca::rig));
        put(new Def("yeti", M_yeti.LAYER, M_yeti::createBodyLayer, M_yeti::rig));
        put(new Def("lomoespino", M_lomoespino.LAYER, M_lomoespino::createBodyLayer, M_lomoespino::rig));
        put(new Def("madreespora", M_madreespora.LAYER, M_madreespora::createBodyLayer, M_madreespora::rig));
        put(new Def("mantis", M_mantis.LAYER, M_mantis::createBodyLayer, M_mantis::rig));
        put(new Def("revenant", M_revenant.LAYER, M_revenant::createBodyLayer, M_revenant::rig));
        put(new Def("oraculo", M_oraculo.LAYER, M_oraculo::createBodyLayer, M_oraculo::rig));
        put(new Def("penitente", M_penitente.LAYER, M_penitente::createBodyLayer, M_penitente::rig));
        put(new Def("llamatormentas", M_llamatormentas.LAYER, M_llamatormentas::createBodyLayer, M_llamatormentas::rig));
        put(new Def("cumulonimbo", M_cumulonimbo.LAYER, M_cumulonimbo::createBodyLayer, M_cumulonimbo::rig));
        put(new Def("vendaval", M_vendaval.LAYER, M_vendaval::createBodyLayer, M_vendaval::rig));
        put(new Def("rompeolas", M_rompeolas.LAYER, M_rompeolas::createBodyLayer, M_rompeolas::rig));
        put(new Def("cronos", M_cronos.LAYER, M_cronos::createBodyLayer, M_cronos::rig));
        put(new Def("espejismo", M_espejismo.LAYER, M_espejismo::createBodyLayer, M_espejismo::rig));
        put(new Def("titan", M_titan.LAYER, M_titan::createBodyLayer, M_titan::rig));
        put(new Def("colmena", M_colmena.LAYER, M_colmena::createBodyLayer, M_colmena::rig));
        put(new Def("peregrino", M_peregrino.LAYER, M_peregrino::createBodyLayer, M_peregrino::rig));
        put(new Def("helios", M_helios.LAYER, M_helios::createBodyLayer, M_helios::rig));
        put(new Def("eclipse", M_eclipse.LAYER, M_eclipse::createBodyLayer, M_eclipse::rig));
    }
}
