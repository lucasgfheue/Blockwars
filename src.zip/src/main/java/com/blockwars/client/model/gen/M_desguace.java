package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Breaker (desguace). */
@SuppressWarnings("unused")
public final class M_desguace {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("desguace"), "main");

    private M_desguace() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "body,-1,0,8,0,0,0,0/0,0,-27,-17,-21,55,17,42/0,59,-23,-19,-17,46,3,34/0,193,-21,-12,-22,42,6,1;hip_r0,-1,-27,8,-13,0,-0.5,0;"
                + "leg_r0,1,0,-8,0,0,0,2.15/160,59,-4,0,-5,8,27,9/66,155,-5,-1,-6,10,6,12;shin_r0,2,0,27,0,0,0,-1.75/194,0,-3,0,-3,6,40,6/"
                + "202,130,-4,5,-4,7,14,7/156,176,-2,37,-2,4,4,4;hip_l0,-1,27,8,-13,0,0.5,0;leg_l0,4,0,-8,0,0,0,-2.15/!160,59,-4,0,-5,8,27,9/"
                + "!66,155,-5,-1,-6,10,6,12;shin_l0,5,0,27,0,0,0,1.75/!194,0,-3,0,-3,6,40,6/!202,130,-4,5,-4,7,14,7/!156,176,-2,37,-2,4,4,4;"
                + "hip_r1,-1,-27,8,0,0,0,0;leg_r1,7,0,-8,0,0,0,2.15/160,59,-4,0,-5,8,27,9/66,155,-5,-1,-6,10,6,12;shin_r1,8,0,27,0,0,0,-1.75/"
                + "194,0,-3,0,-3,6,40,6/202,130,-4,5,-4,7,14,7/156,176,-2,37,-2,4,4,4;hip_l1,-1,27,8,0,0,0,0;leg_l1,10,0,-8,0,0,0,-2.15/"
                + "!160,59,-4,0,-5,8,27,9/!66,155,-5,-1,-6,10,6,12;shin_l1,11,0,27,0,0,0,1.75/!194,0,-3,0,-3,6,40,6/!202,130,-4,5,-4,7,14,7/"
                + "!156,176,-2,37,-2,4,4,4;hip_r2,-1,-27,8,13,0,0.5,0;leg_r2,13,0,-8,0,0,0,2.15/160,59,-4,0,-5,8,27,9/66,155,-5,-1,-6,10,6,12;"
                + "shin_r2,14,0,27,0,0,0,-1.75/194,0,-3,0,-3,6,40,6/202,130,-4,5,-4,7,14,7/156,176,-2,37,-2,4,4,4;hip_l2,-1,27,8,13,0,-0.5,0;"
                + "leg_l2,16,0,-8,0,0,0,-2.15/!160,59,-4,0,-5,8,27,9/!66,155,-5,-1,-6,10,6,12;shin_l2,17,0,27,0,0,0,1.75/"
                + "!194,0,-3,0,-3,6,40,6/!202,130,-4,5,-4,7,14,7/!156,176,-2,37,-2,4,4,4;head,0,0,-10,-21,0,0,0/0,176,-6,-4,-6,13,4,13/"
                + "0,96,-10,-19,-8,21,15,19/120,176,-8,-17,-9,17,8,1/0,155,-11,-17,-5,1,8,13/0,155,10,-17,-5,1,8,13/76,130,-11,-20,-9,22,1,20/"
                + "144,193,-10,-6,-9,21,2,1/214,193,-8,-21,-7,2,1,2/214,193,6,-21,-7,2,1,2;antenna,19,5,-13,4,-0.2,0,0.15/"
                + "196,96,-1,-25,-1,1,25,1/136,193,-1,-26,-1,2,2,2;turret,0,0,-21,-2,0,0,0/0,130,-9,-6,-9,19,6,19;turret_torch,21,0,-8,-4,0,0,0/"
                + "160,130,-4,-4,-10,8,8,13/52,176,-3,3,-3,6,6,10/84,176,-3,5,-3,7,2,11;turret_torch_barrel,22,0,0,-10,0,0,0/"
                + "110,155,-2,-2,-15,3,3,15/86,193,-3,-3,-17,5,5,2/222,193,-1,-1,-18,2,2,1;turret_torch_flash,23,0,0,-18,0,0,0/"
                + "28,155,-3,-3,-13,6,6,13/100,193,-7,-1,-4,15,2,3/146,155,-1,-7,-4,2,15,3;cargo0,0,-7,-10,25,0,0,0/80,96,-7,-7,-7,14,14,15/"
                + "188,193,-6,-1,-8,12,2,1/156,155,-7,-8,-8,15,1,16;cargo1,0,7,-10,25,0,0,0/80,96,-7,-7,-7,14,14,15/188,193,-6,-1,-8,12,2,1/"
                + "156,155,-7,-8,-8,15,1,16;cargo2,0,0,-25,25,0,0,0/138,96,-7,-7,-7,14,14,15/188,193,-6,-1,-8,12,2,1/156,155,-7,-8,-8,15,1,16");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4762F)
                .legLengths(13.65F, 19.95F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_torch/turret_torch_barrel", "body/turret/turret_torch/turret_torch_barrel/turret_torch_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_torch/turret_torch_barrel", "body/turret/turret_torch/turret_torch_barrel/turret_torch_flash", null);
    }
}
