package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Breaker (desguace). */
@SuppressWarnings("unused")
public final class M_desguace {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("desguace"), "main");

    private M_desguace() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-27F, -17F, -21F, 55F, 17F, 42F)
                .texOffs(0, 59).addBox(-23F, -19F, -17F, 46F, 3F, 34F)
                .texOffs(0, 193).addBox(-21F, -12F, -22F, 42F, 6F, 1F),
                PartPose.offsetAndRotation(0F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_hip_r0 = root.addOrReplaceChild("hip_r0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-27F, 8F, -13F, 0F, -0.5F, 0F));
        PartDefinition p_leg_r0 = p_hip_r0.addOrReplaceChild("leg_r0", CubeListBuilder.create()
                .texOffs(160, 59).addBox(-4F, 0F, -5F, 8F, 27F, 9F)
                .texOffs(66, 155).addBox(-5F, -1F, -6F, 10F, 6F, 12F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r0 = p_leg_r0.addOrReplaceChild("shin_r0", CubeListBuilder.create()
                .texOffs(194, 0).addBox(-3F, 0F, -3F, 6F, 40F, 6F)
                .texOffs(202, 130).addBox(-4F, 5F, -4F, 7F, 14F, 7F)
                .texOffs(156, 176).addBox(-2F, 37F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l0 = root.addOrReplaceChild("hip_l0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(27F, 8F, -13F, 0F, 0.5F, 0F));
        PartDefinition p_leg_l0 = p_hip_l0.addOrReplaceChild("leg_l0", CubeListBuilder.create()
                .texOffs(160, 59).mirror().addBox(-4F, 0F, -5F, 8F, 27F, 9F).mirror(false)
                .texOffs(66, 155).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l0 = p_leg_l0.addOrReplaceChild("shin_l0", CubeListBuilder.create()
                .texOffs(194, 0).mirror().addBox(-3F, 0F, -3F, 6F, 40F, 6F).mirror(false)
                .texOffs(202, 130).mirror().addBox(-4F, 5F, -4F, 7F, 14F, 7F).mirror(false)
                .texOffs(156, 176).mirror().addBox(-2F, 37F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r1 = root.addOrReplaceChild("hip_r1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-27F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_r1 = p_hip_r1.addOrReplaceChild("leg_r1", CubeListBuilder.create()
                .texOffs(160, 59).addBox(-4F, 0F, -5F, 8F, 27F, 9F)
                .texOffs(66, 155).addBox(-5F, -1F, -6F, 10F, 6F, 12F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r1 = p_leg_r1.addOrReplaceChild("shin_r1", CubeListBuilder.create()
                .texOffs(194, 0).addBox(-3F, 0F, -3F, 6F, 40F, 6F)
                .texOffs(202, 130).addBox(-4F, 5F, -4F, 7F, 14F, 7F)
                .texOffs(156, 176).addBox(-2F, 37F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l1 = root.addOrReplaceChild("hip_l1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(27F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_l1 = p_hip_l1.addOrReplaceChild("leg_l1", CubeListBuilder.create()
                .texOffs(160, 59).mirror().addBox(-4F, 0F, -5F, 8F, 27F, 9F).mirror(false)
                .texOffs(66, 155).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l1 = p_leg_l1.addOrReplaceChild("shin_l1", CubeListBuilder.create()
                .texOffs(194, 0).mirror().addBox(-3F, 0F, -3F, 6F, 40F, 6F).mirror(false)
                .texOffs(202, 130).mirror().addBox(-4F, 5F, -4F, 7F, 14F, 7F).mirror(false)
                .texOffs(156, 176).mirror().addBox(-2F, 37F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r2 = root.addOrReplaceChild("hip_r2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-27F, 8F, 13F, 0F, 0.5F, 0F));
        PartDefinition p_leg_r2 = p_hip_r2.addOrReplaceChild("leg_r2", CubeListBuilder.create()
                .texOffs(160, 59).addBox(-4F, 0F, -5F, 8F, 27F, 9F)
                .texOffs(66, 155).addBox(-5F, -1F, -6F, 10F, 6F, 12F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r2 = p_leg_r2.addOrReplaceChild("shin_r2", CubeListBuilder.create()
                .texOffs(194, 0).addBox(-3F, 0F, -3F, 6F, 40F, 6F)
                .texOffs(202, 130).addBox(-4F, 5F, -4F, 7F, 14F, 7F)
                .texOffs(156, 176).addBox(-2F, 37F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l2 = root.addOrReplaceChild("hip_l2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(27F, 8F, 13F, 0F, -0.5F, 0F));
        PartDefinition p_leg_l2 = p_hip_l2.addOrReplaceChild("leg_l2", CubeListBuilder.create()
                .texOffs(160, 59).mirror().addBox(-4F, 0F, -5F, 8F, 27F, 9F).mirror(false)
                .texOffs(66, 155).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l2 = p_leg_l2.addOrReplaceChild("shin_l2", CubeListBuilder.create()
                .texOffs(194, 0).mirror().addBox(-3F, 0F, -3F, 6F, 40F, 6F).mirror(false)
                .texOffs(202, 130).mirror().addBox(-4F, 5F, -4F, 7F, 14F, 7F).mirror(false)
                .texOffs(156, 176).mirror().addBox(-2F, 37F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 176).addBox(-6F, -4F, -6F, 13F, 4F, 13F)
                .texOffs(0, 96).addBox(-10F, -19F, -8F, 21F, 15F, 19F)
                .texOffs(120, 176).addBox(-8F, -17F, -9F, 17F, 8F, 1F)
                .texOffs(0, 155).addBox(-11F, -17F, -5F, 1F, 8F, 13F)
                .texOffs(0, 155).addBox(10F, -17F, -5F, 1F, 8F, 13F)
                .texOffs(76, 130).addBox(-11F, -20F, -9F, 22F, 1F, 20F)
                .texOffs(144, 193).addBox(-10F, -6F, -9F, 21F, 2F, 1F)
                .texOffs(214, 193).addBox(-8F, -21F, -7F, 2F, 1F, 2F)
                .texOffs(214, 193).addBox(6F, -21F, -7F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -10F, -21F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(196, 96).addBox(-1F, -25F, -1F, 1F, 25F, 1F)
                .texOffs(136, 193).addBox(-1F, -26F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(0, 130).addBox(-9F, -6F, -9F, 19F, 6F, 19F),
                PartPose.offsetAndRotation(0F, -21F, -2F, 0F, 0F, 0F));
        PartDefinition p_turret_torch = p_turret.addOrReplaceChild("turret_torch", CubeListBuilder.create()
                .texOffs(160, 130).addBox(-4F, -4F, -10F, 8F, 8F, 13F)
                .texOffs(52, 176).addBox(-3F, 3F, -3F, 6F, 6F, 10F)
                .texOffs(84, 176).addBox(-3F, 5F, -3F, 7F, 2F, 11F),
                PartPose.offsetAndRotation(0F, -8F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_torch_barrel = p_turret_torch.addOrReplaceChild("turret_torch_barrel", CubeListBuilder.create()
                .texOffs(110, 155).addBox(-2F, -2F, -15F, 3F, 3F, 15F)
                .texOffs(86, 193).addBox(-3F, -3F, -17F, 5F, 5F, 2F)
                .texOffs(222, 193).addBox(-1F, -1F, -18F, 2F, 2F, 1F),
                PartPose.offsetAndRotation(0F, 0F, -10F, 0F, 0F, 0F));
        PartDefinition p_turret_torch_flash = p_turret_torch_barrel.addOrReplaceChild("turret_torch_flash", CubeListBuilder.create()
                .texOffs(28, 155).addBox(-3F, -3F, -13F, 6F, 6F, 13F)
                .texOffs(100, 193).addBox(-7F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(146, 155).addBox(-1F, -7F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -18F, 0F, 0F, 0F));
        PartDefinition p_cargo0 = p_body.addOrReplaceChild("cargo0", CubeListBuilder.create()
                .texOffs(80, 96).addBox(-7F, -7F, -7F, 14F, 14F, 15F)
                .texOffs(188, 193).addBox(-6F, -1F, -8F, 12F, 2F, 1F)
                .texOffs(156, 155).addBox(-7F, -8F, -8F, 15F, 1F, 16F),
                PartPose.offsetAndRotation(-7F, -10F, 25F, 0F, 0F, 0F));
        PartDefinition p_cargo1 = p_body.addOrReplaceChild("cargo1", CubeListBuilder.create()
                .texOffs(80, 96).addBox(-7F, -7F, -7F, 14F, 14F, 15F)
                .texOffs(188, 193).addBox(-6F, -1F, -8F, 12F, 2F, 1F)
                .texOffs(156, 155).addBox(-7F, -8F, -8F, 15F, 1F, 16F),
                PartPose.offsetAndRotation(7F, -10F, 25F, 0F, 0F, 0F));
        PartDefinition p_cargo2 = p_body.addOrReplaceChild("cargo2", CubeListBuilder.create()
                .texOffs(138, 96).addBox(-7F, -7F, -7F, 14F, 14F, 15F)
                .texOffs(188, 193).addBox(-6F, -1F, -8F, 12F, 2F, 1F)
                .texOffs(156, 155).addBox(-7F, -8F, -8F, 15F, 1F, 16F),
                PartPose.offsetAndRotation(0F, -25F, 25F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4762F)
                .legLengths(13.65F, 19.95F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_torch/turret_torch_barrel", "body/turret/turret_torch/turret_torch_barrel/turret_torch_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_torch/turret_torch_barrel", "body/turret/turret_torch/turret_torch_barrel/turret_torch_flash", null);
    }
}
