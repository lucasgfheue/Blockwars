package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Smokestack (humo). */
@SuppressWarnings("unused")
public final class M_humo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("humo"), "main");

    private M_humo() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-30,0,0,0,0/356,50,-12,-5,-8,24,10,16/230,79,-13,-4,-9,26,5,18/158,124,-3,-2,-10,6,6,1;thigh_r,-1,-10,-30,0,0,0,0/"
                + "412,0,-5,0,-5,10,22,10/60,105,-6,2,-8,12,15,4/374,79,-6,2,-5,2,13,10;shin_r,1,0,22,0,0,0,0/324,0,-6,0,-6,12,23,12/"
                + "40,124,-5,-5,-9,10,8,4/316,105,-4,7,6,8,12,3;foot_r,2,0,23,0,0,0,0/68,124,-4,-1,-4,7,4,7/280,50,-8,3,-13,17,6,21/"
                + "222,124,-8,5,-14,15,3,1;thigh_l,-1,10,-30,0,0,0,0/!412,0,-5,0,-5,10,22,10/!60,105,-6,2,-8,12,15,4/!374,79,4,2,-5,2,13,10;"
                + "shin_l,4,0,22,0,0,0,0/!324,0,-6,0,-6,12,23,12/!40,124,-5,-5,-9,10,8,4/!316,105,-4,7,6,8,12,3;foot_l,5,0,23,0,0,0,0/"
                + "!68,124,-4,-1,-4,7,4,7/!280,50,-8,3,-13,17,6,21/!222,124,-8,5,-14,15,3,1;torso,0,0,-5,0,0,0,0/200,50,-11,-10,-8,23,10,17/"
                + "116,0,-19,-34,-11,38,26,22/0,0,-15,-32,-14,30,22,28/0,50,-20,-24,-12,39,5,24/56,79,-13,-36,-10,27,4,20;"
                + "head,7,0,-36,-2,0,0,0/384,105,-5,-4,-5,10,4,10/438,79,-8,-6,-8,16,3,16/318,79,-7,-16,-7,14,9,14/0,124,-5,-18,-5,10,2,10/"
                + "142,124,-2,-12,-2,4,4,4;antenna,8,5,-12,4,-0.2,0,0.15/52,79,0,-24,0,1,24,1/254,124,-1,-25,-1,2,2,2;shoulder_r,7,-25,-29,0,0,0,0/"
                + "398,79,-5,-5,-5,10,10,10/436,50,-8,-9,-7,14,12,14/0,105,-8,-5,-8,15,4,15/168,50,-4,2,-4,8,20,8;forearm_r,10,0,21,0,-0.25,0,0/"
                + "126,50,-5,0,-6,10,18,11/338,105,-6,17,-6,11,2,12;forearm_r_flamer,11,0,23,-2,0,0,0/0,79,-4,-4,-15,8,8,18/"
                + "92,105,-3,4,-6,6,6,12/424,105,-3,6,-6,6,2,12;forearm_r_flamer_barrel,12,0,-1,-16,0,0,0/210,105,-2,-2,-12,4,4,12/"
                + "124,124,-3,-3,-14,6,6,3/262,124,-1,3,-14,2,1,2;shoulder_l,7,25,-29,0,0,0,0/!398,79,-5,-5,-5,10,10,10/"
                + "!436,50,-6,-9,-7,14,12,14/!0,105,-6,-5,-8,15,4,15/!168,50,-4,2,-4,8,20,8;forearm_l,14,0,21,0,-0.25,0,0/"
                + "!126,50,-5,0,-6,10,18,11/!338,105,-6,17,-6,11,2,12;forearm_l_mortar,15,0,21,-2,-0.55,0,0/150,79,-7,-5,-7,14,10,14;"
                + "forearm_l_mortar_barrel,16,0,-4,-4,0,0,0/236,0,-6,-6,-32,12,12,32/286,105,-6,-6,-29,13,13,2/128,105,-7,-7,-35,14,14,4;"
                + "forearm_l_mortar_flash,17,0,0,-34,0,0,0/164,105,-3,-3,-12,6,6,12/172,124,-7,-1,-4,14,2,3/200,105,-1,-7,-4,2,14,3;"
                + "tank,7,0,-20,20,0,0,1.5708/372,0,-5,-12,-5,10,24,10/460,105,-6,-12,-6,11,2,11/460,105,-6,10,-6,11,2,11/"
                + "242,105,-6,-2,-6,11,4,11;stack_r,7,-11,-32,18,-0.15,0,0.1/206,79,-3,-17,-3,6,18,6/96,124,-4,-18,-4,7,2,7/"
                + "206,124,-2,-19,-2,4,1,4;stack_l,7,11,-32,18,-0.15,0,-0.1/206,79,-3,-17,-3,6,18,6/96,124,-4,-18,-4,7,2,7/"
                + "206,124,-2,-19,-2,4,1,4");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_flamer/forearm_r_flamer_barrel", null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_mortar/forearm_l_mortar_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_mortar/forearm_l_mortar_barrel/forearm_l_mortar_flash", null);
    }
}
