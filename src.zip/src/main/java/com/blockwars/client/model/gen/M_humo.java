package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Smokestack (humo). */
@SuppressWarnings("unused")
public final class M_humo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("humo"), "main");

    private M_humo() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(356, 50).addBox(-12F, -5F, -8F, 24F, 10F, 16F)
                .texOffs(230, 79).addBox(-13F, -4F, -9F, 26F, 5F, 18F)
                .texOffs(158, 124).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(412, 0).addBox(-5F, 0F, -5F, 10F, 22F, 10F)
                .texOffs(60, 105).addBox(-6F, 2F, -8F, 12F, 15F, 4F)
                .texOffs(374, 79).addBox(-6F, 2F, -5F, 2F, 13F, 10F),
                PartPose.offsetAndRotation(-10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(324, 0).addBox(-6F, 0F, -6F, 12F, 23F, 12F)
                .texOffs(40, 124).addBox(-5F, -5F, -9F, 10F, 8F, 4F)
                .texOffs(316, 105).addBox(-4F, 7F, 6F, 8F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(68, 124).addBox(-4F, -1F, -4F, 7F, 4F, 7F)
                .texOffs(280, 50).addBox(-8F, 3F, -13F, 17F, 6F, 21F)
                .texOffs(222, 124).addBox(-8F, 5F, -14F, 15F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(412, 0).mirror().addBox(-5F, 0F, -5F, 10F, 22F, 10F).mirror(false)
                .texOffs(60, 105).mirror().addBox(-6F, 2F, -8F, 12F, 15F, 4F).mirror(false)
                .texOffs(374, 79).mirror().addBox(4F, 2F, -5F, 2F, 13F, 10F).mirror(false),
                PartPose.offsetAndRotation(10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(324, 0).mirror().addBox(-6F, 0F, -6F, 12F, 23F, 12F).mirror(false)
                .texOffs(40, 124).mirror().addBox(-5F, -5F, -9F, 10F, 8F, 4F).mirror(false)
                .texOffs(316, 105).mirror().addBox(-4F, 7F, 6F, 8F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(68, 124).mirror().addBox(-4F, -1F, -4F, 7F, 4F, 7F).mirror(false)
                .texOffs(280, 50).mirror().addBox(-8F, 3F, -13F, 17F, 6F, 21F).mirror(false)
                .texOffs(222, 124).mirror().addBox(-8F, 5F, -14F, 15F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(200, 50).addBox(-11F, -10F, -8F, 23F, 10F, 17F)
                .texOffs(116, 0).addBox(-19F, -34F, -11F, 38F, 26F, 22F)
                .texOffs(0, 0).addBox(-15F, -32F, -14F, 30F, 22F, 28F)
                .texOffs(0, 50).addBox(-20F, -24F, -12F, 39F, 5F, 24F)
                .texOffs(56, 79).addBox(-13F, -36F, -10F, 27F, 4F, 20F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(384, 105).addBox(-5F, -4F, -5F, 10F, 4F, 10F)
                .texOffs(438, 79).addBox(-8F, -6F, -8F, 16F, 3F, 16F)
                .texOffs(318, 79).addBox(-7F, -16F, -7F, 14F, 9F, 14F)
                .texOffs(0, 124).addBox(-5F, -18F, -5F, 10F, 2F, 10F)
                .texOffs(142, 124).addBox(-2F, -12F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, -36F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(52, 79).addBox(0F, -24F, 0F, 1F, 24F, 1F)
                .texOffs(254, 124).addBox(-1F, -25F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -12F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(398, 79).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(436, 50).addBox(-8F, -9F, -7F, 14F, 12F, 14F)
                .texOffs(0, 105).addBox(-8F, -5F, -8F, 15F, 4F, 15F)
                .texOffs(168, 50).addBox(-4F, 2F, -4F, 8F, 20F, 8F),
                PartPose.offsetAndRotation(-25F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(126, 50).addBox(-5F, 0F, -6F, 10F, 18F, 11F)
                .texOffs(338, 105).addBox(-6F, 17F, -6F, 11F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_flamer = p_forearm_r.addOrReplaceChild("forearm_r_flamer", CubeListBuilder.create()
                .texOffs(0, 79).addBox(-4F, -4F, -15F, 8F, 8F, 18F)
                .texOffs(92, 105).addBox(-3F, 4F, -6F, 6F, 6F, 12F)
                .texOffs(424, 105).addBox(-3F, 6F, -6F, 6F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_flamer_barrel = p_forearm_r_flamer.addOrReplaceChild("forearm_r_flamer_barrel", CubeListBuilder.create()
                .texOffs(210, 105).addBox(-2F, -2F, -12F, 4F, 4F, 12F)
                .texOffs(124, 124).addBox(-3F, -3F, -14F, 6F, 6F, 3F)
                .texOffs(262, 124).addBox(-1F, 3F, -14F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -1F, -16F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(398, 79).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(436, 50).mirror().addBox(-6F, -9F, -7F, 14F, 12F, 14F).mirror(false)
                .texOffs(0, 105).mirror().addBox(-6F, -5F, -8F, 15F, 4F, 15F).mirror(false)
                .texOffs(168, 50).mirror().addBox(-4F, 2F, -4F, 8F, 20F, 8F).mirror(false),
                PartPose.offsetAndRotation(25F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(126, 50).mirror().addBox(-5F, 0F, -6F, 10F, 18F, 11F).mirror(false)
                .texOffs(338, 105).mirror().addBox(-6F, 17F, -6F, 11F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_mortar = p_forearm_l.addOrReplaceChild("forearm_l_mortar", CubeListBuilder.create()
                .texOffs(150, 79).addBox(-7F, -5F, -7F, 14F, 10F, 14F),
                PartPose.offsetAndRotation(0F, 21F, -2F, -0.55F, 0F, 0F));
        PartDefinition p_forearm_l_mortar_barrel = p_forearm_l_mortar.addOrReplaceChild("forearm_l_mortar_barrel", CubeListBuilder.create()
                .texOffs(236, 0).addBox(-6F, -6F, -32F, 12F, 12F, 32F)
                .texOffs(286, 105).addBox(-6F, -6F, -29F, 13F, 13F, 2F)
                .texOffs(128, 105).addBox(-7F, -7F, -35F, 14F, 14F, 4F),
                PartPose.offsetAndRotation(0F, -4F, -4F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_mortar_flash = p_forearm_l_mortar_barrel.addOrReplaceChild("forearm_l_mortar_flash", CubeListBuilder.create()
                .texOffs(164, 105).addBox(-3F, -3F, -12F, 6F, 6F, 12F)
                .texOffs(172, 124).addBox(-7F, -1F, -4F, 14F, 2F, 3F)
                .texOffs(200, 105).addBox(-1F, -7F, -4F, 2F, 14F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -34F, 0F, 0F, 0F));
        PartDefinition p_tank = p_torso.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(372, 0).addBox(-5F, -12F, -5F, 10F, 24F, 10F)
                .texOffs(460, 105).addBox(-6F, -12F, -6F, 11F, 2F, 11F)
                .texOffs(460, 105).addBox(-6F, 10F, -6F, 11F, 2F, 11F)
                .texOffs(242, 105).addBox(-6F, -2F, -6F, 11F, 4F, 11F),
                PartPose.offsetAndRotation(0F, -20F, 20F, 0F, 0F, 1.5708F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(206, 79).addBox(-3F, -17F, -3F, 6F, 18F, 6F)
                .texOffs(96, 124).addBox(-4F, -18F, -4F, 7F, 2F, 7F)
                .texOffs(206, 124).addBox(-2F, -19F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-11F, -32F, 18F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(206, 79).addBox(-3F, -17F, -3F, 6F, 18F, 6F)
                .texOffs(96, 124).addBox(-4F, -18F, -4F, 7F, 2F, 7F)
                .texOffs(206, 124).addBox(-2F, -19F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(11F, -32F, 18F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_flamer/forearm_r_flamer_barrel", null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_mortar/forearm_l_mortar_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_mortar/forearm_l_mortar_barrel/forearm_l_mortar_flash", null);
    }
}
