package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Auger (barrena). */
@SuppressWarnings("unused")
public final class M_barrena {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("barrena"), "main");

    private M_barrena() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hull,-1,0,24,0,0,0,0/0,97,-37,-36,-32,75,15,64/282,176,-20,-40,-20,40,4,45/278,97,-20,-22,-30,40,18,60/"
                + "146,306,-35,-32,-33,70,7,1;tread_r,0,-29,-11,0,0,0,0/0,0,-9,-11,-37,18,22,75/186,0,-10,-16,-38,20,6,77;"
                + "wheel_r0,1,-9,2,-26,0,0,0/316,249,-1,-7,-7,1,13,13/288,306,-1,-2,-2,2,4,4;wheel_r1,1,-9,2,-9,0,0,0/316,249,-1,-7,-7,1,13,13/"
                + "288,306,-1,-2,-2,2,4,4;wheel_r2,1,-9,2,9,0,0,0/316,249,-1,-7,-7,1,13,13/288,306,-1,-2,-2,2,4,4;wheel_r3,1,-9,2,26,0,0,0/"
                + "316,249,-1,-7,-7,1,13,13/288,306,-1,-2,-2,2,4,4;tread_l,0,29,-11,0,0,0,0/!0,0,-9,-11,-37,18,22,75/!186,0,-10,-16,-38,20,6,77;"
                + "wheel_l0,6,9,2,-26,0,0,0/!316,249,-1,-7,-7,1,13,13/!288,306,-1,-2,-2,2,4,4;wheel_l1,6,9,2,-9,0,0,0/!316,249,-1,-7,-7,1,13,13/"
                + "!288,306,-1,-2,-2,2,4,4;wheel_l2,6,9,2,9,0,0,0/!316,249,-1,-7,-7,1,13,13/!288,306,-1,-2,-2,2,4,4;wheel_l3,6,9,2,26,0,0,0/"
                + "!316,249,-1,-7,-7,1,13,13/!288,306,-1,-2,-2,2,4,4;turret,0,0,-37,4,0,0,0/122,176,-20,-15,-20,40,15,40/"
                + "146,249,-15,-16,-11,31,1,26/16,306,-13,-12,20,26,9,1;head,11,11,-15,7,0,0,0/278,284,-7,-4,-7,13,4,13/"
                + "0,249,-11,-20,-9,22,15,20/70,306,-9,-18,-10,18,9,1/44,284,-12,-18,-6,1,9,13/44,284,11,-18,-6,1,9,13/392,249,-12,-21,-9,23,1,21/"
                + "354,306,-11,-6,-10,22,2,1/400,306,-9,-22,-8,2,1,2/400,306,7,-22,-8,2,1,2;antenna,12,6,-13,4,-0.2,0,0.15/"
                + "260,249,-1,-26,-1,1,26,1/346,306,-1,-28,-1,2,2,2;drillmount,0,0,-15,-37,0,0,0;drillmount_drill,14,0,2,-2,0,0,0/"
                + "264,249,-7,-7,-11,13,13,13;drillmount_drill_bit,15,0,0,-11,0,0,0/344,249,-8,-8,-9,15,15,9/72,284,-6,-6,-18,12,12,9/"
                + "232,284,-4,-4,-26,9,9,9/378,284,-3,-3,-35,6,6,9/128,306,-1,-1,-43,2,2,7;turret_gun,11,-11,-7,-20,0,0,0/"
                + "84,249,-4,-5,-20,9,10,22/114,284,-3,-7,-18,7,2,18/480,284,-2,4,-3,4,4,7;turret_gun_barrel,17,0,-1,-20,0,0,0/"
                + "0,284,-2,-2,-18,4,4,18/108,306,-3,-3,-19,7,7,3;turret_gun_flash,18,0,0,-20,0,0,0/164,284,-3,-3,-13,7,7,13/"
                + "300,306,-8,-1,-4,15,2,3/268,284,-1,-8,-4,2,15,3;exhaust,11,10,-18,26,0,0,0/452,176,-5,-33,-5,10,35,10/"
                + "436,284,-6,-8,-6,11,2,11/436,284,-6,-25,-6,11,2,11/330,284,-6,-36,-6,12,3,12;flame_exh,20,0,-35,0,3.1416,0,0/"
                + "204,284,-3,0,-3,7,13,7;beacon,11,-12,-22,20,0,0,0/0,306,-2,-1,-2,4,7,4/408,284,-3,-7,-3,7,7,7;beacon_spin,22,0,-3,0,0,0,0/"
                + "336,306,-2,-2,-4,4,4,1/336,306,-2,-2,3,4,4,1;skirt_r,0,-39,-20,0,0,0,0/0,176,-1,-7,-30,1,13,60;skirt_l,0,39,-20,0,0,0,0/"
                + "!0,176,-1,-7,-30,1,13,60");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/turret/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hull/drillmount/drillmount_drill/drillmount_drill_bit", 2, 0.9F, 3)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .flame("hull/turret/exhaust/flame_exh")
                .primary(Rig.MountKind.TURRET, "hull/drillmount", null, null, null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
