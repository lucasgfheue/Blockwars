package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Auger (barrena). */
@SuppressWarnings("unused")
public final class M_barrena {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("barrena"), "main");

    private M_barrena() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 97).addBox(-37F, -36F, -32F, 75F, 15F, 64F)
                .texOffs(282, 176).addBox(-20F, -40F, -20F, 40F, 4F, 45F)
                .texOffs(278, 97).addBox(-20F, -22F, -30F, 40F, 18F, 60F)
                .texOffs(146, 306).addBox(-35F, -32F, -33F, 70F, 7F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-9F, -11F, -37F, 18F, 22F, 75F)
                .texOffs(186, 0).addBox(-10F, -16F, -38F, 20F, 6F, 77F),
                PartPose.offsetAndRotation(-29F, -11F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(316, 249).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(288, 306).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -26F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(316, 249).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(288, 306).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(316, 249).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(288, 306).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(316, 249).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(288, 306).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 26F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-9F, -11F, -37F, 18F, 22F, 75F).mirror(false)
                .texOffs(186, 0).mirror().addBox(-10F, -16F, -38F, 20F, 6F, 77F).mirror(false),
                PartPose.offsetAndRotation(29F, -11F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(316, 249).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(288, 306).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -26F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(316, 249).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(288, 306).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(316, 249).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(288, 306).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(316, 249).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(288, 306).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 26F, 0F, 0F, 0F));
        PartDefinition p_turret = p_hull.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(122, 176).addBox(-20F, -15F, -20F, 40F, 15F, 40F)
                .texOffs(146, 249).addBox(-15F, -16F, -11F, 31F, 1F, 26F)
                .texOffs(16, 306).addBox(-13F, -12F, 20F, 26F, 9F, 1F),
                PartPose.offsetAndRotation(0F, -37F, 4F, 0F, 0F, 0F));
        PartDefinition p_head = p_turret.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(278, 284).addBox(-7F, -4F, -7F, 13F, 4F, 13F)
                .texOffs(0, 249).addBox(-11F, -20F, -9F, 22F, 15F, 20F)
                .texOffs(70, 306).addBox(-9F, -18F, -10F, 18F, 9F, 1F)
                .texOffs(44, 284).addBox(-12F, -18F, -6F, 1F, 9F, 13F)
                .texOffs(44, 284).addBox(11F, -18F, -6F, 1F, 9F, 13F)
                .texOffs(392, 249).addBox(-12F, -21F, -9F, 23F, 1F, 21F)
                .texOffs(354, 306).addBox(-11F, -6F, -10F, 22F, 2F, 1F)
                .texOffs(400, 306).addBox(-9F, -22F, -8F, 2F, 1F, 2F)
                .texOffs(400, 306).addBox(7F, -22F, -8F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(11F, -15F, 7F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(260, 249).addBox(-1F, -26F, -1F, 1F, 26F, 1F)
                .texOffs(346, 306).addBox(-1F, -28F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_drillmount = p_hull.addOrReplaceChild("drillmount", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -15F, -37F, 0F, 0F, 0F));
        PartDefinition p_drillmount_drill = p_drillmount.addOrReplaceChild("drillmount_drill", CubeListBuilder.create()
                .texOffs(264, 249).addBox(-7F, -7F, -11F, 13F, 13F, 13F),
                PartPose.offsetAndRotation(0F, 2F, -2F, 0F, 0F, 0F));
        PartDefinition p_drillmount_drill_bit = p_drillmount_drill.addOrReplaceChild("drillmount_drill_bit", CubeListBuilder.create()
                .texOffs(344, 249).addBox(-8F, -8F, -9F, 15F, 15F, 9F)
                .texOffs(72, 284).addBox(-6F, -6F, -18F, 12F, 12F, 9F)
                .texOffs(232, 284).addBox(-4F, -4F, -26F, 9F, 9F, 9F)
                .texOffs(378, 284).addBox(-3F, -3F, -35F, 6F, 6F, 9F)
                .texOffs(128, 306).addBox(-1F, -1F, -43F, 2F, 2F, 7F),
                PartPose.offsetAndRotation(0F, 0F, -11F, 0F, 0F, 0F));
        PartDefinition p_turret_gun = p_turret.addOrReplaceChild("turret_gun", CubeListBuilder.create()
                .texOffs(84, 249).addBox(-4F, -5F, -20F, 9F, 10F, 22F)
                .texOffs(114, 284).addBox(-3F, -7F, -18F, 7F, 2F, 18F)
                .texOffs(480, 284).addBox(-2F, 4F, -3F, 4F, 4F, 7F),
                PartPose.offsetAndRotation(-11F, -7F, -20F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_barrel = p_turret_gun.addOrReplaceChild("turret_gun_barrel", CubeListBuilder.create()
                .texOffs(0, 284).addBox(-2F, -2F, -18F, 4F, 4F, 18F)
                .texOffs(108, 306).addBox(-3F, -3F, -19F, 7F, 7F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -20F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_flash = p_turret_gun_barrel.addOrReplaceChild("turret_gun_flash", CubeListBuilder.create()
                .texOffs(164, 284).addBox(-3F, -3F, -13F, 7F, 7F, 13F)
                .texOffs(300, 306).addBox(-8F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(268, 284).addBox(-1F, -8F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0F, 0F, 0F));
        PartDefinition p_exhaust = p_turret.addOrReplaceChild("exhaust", CubeListBuilder.create()
                .texOffs(452, 176).addBox(-5F, -33F, -5F, 10F, 35F, 10F)
                .texOffs(436, 284).addBox(-6F, -8F, -6F, 11F, 2F, 11F)
                .texOffs(436, 284).addBox(-6F, -25F, -6F, 11F, 2F, 11F)
                .texOffs(330, 284).addBox(-6F, -36F, -6F, 12F, 3F, 12F),
                PartPose.offsetAndRotation(10F, -18F, 26F, 0F, 0F, 0F));
        PartDefinition p_flame_exh = p_exhaust.addOrReplaceChild("flame_exh", CubeListBuilder.create()
                .texOffs(204, 284).addBox(-3F, 0F, -3F, 7F, 13F, 7F),
                PartPose.offsetAndRotation(0F, -35F, 0F, 3.1416F, 0F, 0F));
        PartDefinition p_beacon = p_turret.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(0, 306).addBox(-2F, -1F, -2F, 4F, 7F, 4F)
                .texOffs(408, 284).addBox(-3F, -7F, -3F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(-12F, -22F, 20F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(336, 306).addBox(-2F, -2F, -4F, 4F, 4F, 1F)
                .texOffs(336, 306).addBox(-2F, -2F, 3F, 4F, 4F, 1F),
                PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(0, 176).addBox(-1F, -7F, -30F, 1F, 13F, 60F),
                PartPose.offsetAndRotation(-39F, -20F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(0, 176).mirror().addBox(-1F, -7F, -30F, 1F, 13F, 60F).mirror(false),
                PartPose.offsetAndRotation(39F, -20F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/turret/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hull/drillmount/drillmount_drill/drillmount_drill_bit", 2, 0.9F, 3)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .flame("hull/turret/exhaust/flame_exh")
                .primary(Rig.MountKind.TURRET, "hull/drillmount", null, null, null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
