package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for CALDERA · War Locomotive (caldera). */
@SuppressWarnings("unused")
public final class M_caldera {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("caldera"), "main");

    private M_caldera() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(284, 122).addBox(-20F, -6F, -10F, 39F, 13F, 21F)
                .texOffs(374, 157).addBox(-21F, -6F, -12F, 42F, 6F, 23F)
                .texOffs(360, 238).addBox(-4F, -3F, -13F, 8F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt0 = p_hips.addOrReplaceChild("skirt0", CubeListBuilder.create()
                .texOffs(14, 216).addBox(-17F, 0F, -1F, 34F, 18F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -12F, -0.15F, 0F, 0F));
        PartDefinition p_skirt1 = p_hips.addOrReplaceChild("skirt1", CubeListBuilder.create()
                .texOffs(14, 216).addBox(-17F, 0F, -1F, 34F, 18F, 3F),
                PartPose.offsetAndRotation(0F, 0F, 12F, 0.15F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(266, 75).addBox(-9F, 0F, -9F, 18F, 25F, 18F)
                .texOffs(412, 190).addBox(-10F, 3F, -13F, 21F, 17F, 5F)
                .texOffs(66, 157).addBox(-10F, 3F, -9F, 3F, 15F, 18F),
                PartPose.offsetAndRotation(-17F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(0, 75).addBox(-10F, 0F, -10F, 21F, 26F, 21F)
                .texOffs(208, 238).addBox(-9F, -6F, -14F, 18F, 10F, 5F)
                .texOffs(54, 255).addBox(-2F, -3F, -15F, 4F, 4F, 1F)
                .texOffs(458, 216).addBox(-8F, 8F, 10F, 16F, 13F, 4F),
                PartPose.offsetAndRotation(0F, 25F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(350, 216).addBox(-6F, -1F, -6F, 13F, 5F, 13F)
                .texOffs(84, 75).addBox(-14F, 4F, -21F, 29F, 8F, 36F)
                .texOffs(0, 255).addBox(-13F, 6F, -23F, 26F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(266, 75).mirror().addBox(-9F, 0F, -9F, 18F, 25F, 18F).mirror(false)
                .texOffs(412, 190).mirror().addBox(-10F, 3F, -13F, 21F, 17F, 5F).mirror(false)
                .texOffs(66, 157).mirror().addBox(8F, 3F, -9F, 3F, 15F, 18F).mirror(false),
                PartPose.offsetAndRotation(17F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(0, 75).mirror().addBox(-10F, 0F, -10F, 21F, 26F, 21F).mirror(false)
                .texOffs(208, 238).mirror().addBox(-9F, -6F, -14F, 18F, 10F, 5F).mirror(false)
                .texOffs(54, 255).mirror().addBox(-2F, -3F, -15F, 4F, 4F, 1F).mirror(false)
                .texOffs(458, 216).mirror().addBox(-8F, 8F, 10F, 16F, 13F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 25F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(350, 216).mirror().addBox(-6F, -1F, -6F, 13F, 5F, 13F).mirror(false)
                .texOffs(84, 75).mirror().addBox(-14F, 4F, -21F, 29F, 8F, 36F).mirror(false)
                .texOffs(0, 255).mirror().addBox(-13F, 6F, -23F, 26F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 122).addBox(-16F, -13F, -11F, 31F, 13F, 22F)
                .texOffs(0, 0).addBox(-23F, -49F, -18F, 46F, 39F, 36F)
                .texOffs(164, 0).addBox(-29F, -46F, -15F, 57F, 31F, 29F)
                .texOffs(106, 122).addBox(-29F, -19F, -15F, 58F, 3F, 31F)
                .texOffs(106, 122).addBox(-29F, -35F, -15F, 58F, 3F, 31F)
                .texOffs(378, 238).addBox(-16F, -29F, -20F, 8F, 8F, 1F)
                .texOffs(440, 238).addBox(6F, -25F, -20F, 10F, 5F, 1F)
                .texOffs(184, 157).addBox(-17F, -48F, -13F, 34F, 5F, 25F)
                .texOffs(34, 238).addBox(-17F, -32F, 18F, 34F, 15F, 1F)
                .texOffs(254, 238).addBox(-5F, -39F, -20F, 10F, 10F, 3F)
                .texOffs(0, 238).addBox(-8F, -42F, -19F, 16F, 16F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(350, 216).addBox(-6F, -5F, -6F, 13F, 5F, 13F)
                .texOffs(52, 190).addBox(-10F, -8F, -10F, 21F, 4F, 21F)
                .texOffs(302, 157).addBox(-9F, -20F, -9F, 18F, 12F, 18F)
                .texOffs(104, 238).addBox(-6F, -23F, -6F, 13F, 3F, 13F)
                .texOffs(340, 238).addBox(-3F, -16F, -3F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(0F, -49F, -3F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(0, 190).addBox(-6F, -6F, -6F, 13F, 13F, 13F)
                .texOffs(404, 122).addBox(-10F, -12F, -9F, 18F, 16F, 18F)
                .texOffs(136, 190).addBox(-11F, -6F, -10F, 20F, 5F, 20F)
                .texOffs(472, 75).addBox(-5F, 3F, -5F, 10F, 26F, 10F),
                PartPose.offsetAndRotation(-36F, -40F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(418, 75).addBox(-6F, 0F, -7F, 13F, 23F, 14F)
                .texOffs(130, 216).addBox(-7F, 22F, -8F, 14F, 3F, 16F),
                PartPose.offsetAndRotation(0F, 27F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_cannon = p_forearm_r.addOrReplaceChild("forearm_r_cannon", CubeListBuilder.create()
                .texOffs(384, 0).addBox(-9F, -9F, -26F, 18F, 18F, 31F)
                .texOffs(344, 190).addBox(-6F, -10F, -21F, 13F, 1F, 21F)
                .texOffs(108, 157).addBox(9F, -5F, -21F, 1F, 10F, 21F),
                PartPose.offsetAndRotation(0F, 31F, -3F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_barrel = p_forearm_r_cannon.addOrReplaceChild("forearm_r_cannon_barrel", CubeListBuilder.create()
                .texOffs(338, 75).addBox(-5F, -5F, -31F, 9F, 9F, 31F)
                .texOffs(464, 190).addBox(-7F, -7F, -36F, 14F, 14F, 8F),
                PartPose.offsetAndRotation(0F, 0F, -26F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_flash = p_forearm_r_cannon_barrel.addOrReplaceChild("forearm_r_cannon_flash", CubeListBuilder.create()
                .texOffs(216, 190).addBox(-4F, -4F, -16F, 8F, 8F, 16F)
                .texOffs(396, 238).addBox(-9F, -1F, -5F, 18F, 3F, 4F)
                .texOffs(0, 216).addBox(-1F, -9F, -5F, 3F, 18F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -36F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(0, 190).mirror().addBox(-6F, -6F, -6F, 13F, 13F, 13F).mirror(false)
                .texOffs(404, 122).mirror().addBox(-8F, -12F, -9F, 18F, 16F, 18F).mirror(false)
                .texOffs(136, 190).mirror().addBox(-8F, -6F, -10F, 20F, 5F, 20F).mirror(false)
                .texOffs(472, 75).mirror().addBox(-5F, 3F, -5F, 10F, 26F, 10F).mirror(false),
                PartPose.offsetAndRotation(36F, -40F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(418, 75).mirror().addBox(-6F, 0F, -7F, 13F, 23F, 14F).mirror(false)
                .texOffs(130, 216).mirror().addBox(-7F, 22F, -8F, 14F, 3F, 16F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_flamer = p_forearm_l.addOrReplaceChild("forearm_l_flamer", CubeListBuilder.create()
                .texOffs(0, 157).addBox(-5F, -5F, -20F, 10F, 10F, 23F)
                .texOffs(264, 190).addBox(-4F, 5F, -8F, 8F, 8F, 16F)
                .texOffs(246, 216).addBox(-4F, 8F, -8F, 8F, 3F, 16F),
                PartPose.offsetAndRotation(0F, 30F, -3F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_flamer_barrel = p_forearm_l_flamer.addOrReplaceChild("forearm_l_flamer_barrel", CubeListBuilder.create()
                .texOffs(88, 216).addBox(-3F, -3F, -16F, 5F, 5F, 16F)
                .texOffs(316, 238).addBox(-4F, -4F, -19F, 8F, 8F, 4F)
                .texOffs(64, 255).addBox(-1F, 4F, -18F, 3F, 1F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -21F, 0F, 0F, 0F));
        PartDefinition p_exhaust = p_torso.addOrReplaceChild("exhaust", CubeListBuilder.create()
                .texOffs(336, 0).addBox(-6F, -39F, -6F, 12F, 42F, 12F)
                .texOffs(156, 238).addBox(-6F, -9F, -6F, 13F, 3F, 13F)
                .texOffs(156, 238).addBox(-6F, -30F, -6F, 13F, 3F, 13F)
                .texOffs(294, 216).addBox(-7F, -42F, -7F, 14F, 4F, 14F),
                PartPose.offsetAndRotation(14F, -49F, 26F, 0F, 0F, 0F));
        PartDefinition p_flame_exh = p_exhaust.addOrReplaceChild("flame_exh", CubeListBuilder.create()
                .texOffs(312, 190).addBox(-4F, 0F, -4F, 8F, 16F, 8F),
                PartPose.offsetAndRotation(0F, -42F, 0F, 3.1416F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(152, 157).addBox(-4F, -22F, -4F, 8F, 23F, 8F)
                .texOffs(280, 238).addBox(-5F, -24F, -5F, 9F, 3F, 9F)
                .texOffs(462, 238).addBox(-3F, -25F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(-17F, -44F, 23F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(152, 157).addBox(-4F, -22F, -4F, 8F, 23F, 8F)
                .texOffs(280, 238).addBox(-5F, -24F, -5F, 9F, 3F, 9F)
                .texOffs(462, 238).addBox(-3F, -25F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(17F, -44F, 23F, -0.15F, 0F, -0.1F));
        PartDefinition p_tank = p_torso.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(214, 75).addBox(-6F, -16F, -6F, 13F, 31F, 13F)
                .texOffs(402, 216).addBox(-7F, -16F, -7F, 14F, 3F, 14F)
                .texOffs(402, 216).addBox(-7F, 13F, -7F, 14F, 3F, 14F)
                .texOffs(190, 216).addBox(-7F, -3F, -7F, 14F, 5F, 14F),
                PartPose.offsetAndRotation(0F, -29F, 26F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2538F)
                .legLengths(12.35F, 13F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .flame("hips/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_flamer/forearm_l_flamer_barrel", null, null);
    }
}
