package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for CALDERA · War Locomotive (caldera). */
@SuppressWarnings("unused")
public final class M_caldera {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("caldera"), "main");

    private M_caldera() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hips,-1,0,-39,0,0,0,0/284,122,-20,-6,-10,39,13,21/374,157,-21,-6,-12,42,6,23/360,238,-4,-3,-13,8,8,1;"
                + "skirt0,0,0,0,-12,-0.15,0,0/14,216,-17,0,-1,34,18,3;skirt1,0,0,0,12,0.15,0,0/14,216,-17,0,-1,34,18,3;thigh_r,-1,-17,-39,0,0,0,0/"
                + "266,75,-9,0,-9,18,25,18/412,190,-10,3,-13,21,17,5/66,157,-10,3,-9,3,15,18;shin_r,3,0,25,0,0,0,0/0,75,-10,0,-10,21,26,21/"
                + "208,238,-9,-6,-14,18,10,5/54,255,-2,-3,-15,4,4,1/458,216,-8,8,10,16,13,4;foot_r,4,0,26,0,0,0,0/350,216,-6,-1,-6,13,5,13/"
                + "84,75,-14,4,-21,29,8,36/0,255,-13,6,-23,26,4,1;thigh_l,-1,17,-39,0,0,0,0/!266,75,-9,0,-9,18,25,18/!412,190,-10,3,-13,21,17,5/"
                + "!66,157,8,3,-9,3,15,18;shin_l,6,0,25,0,0,0,0/!0,75,-10,0,-10,21,26,21/!208,238,-9,-6,-14,18,10,5/!54,255,-2,-3,-15,4,4,1/"
                + "!458,216,-8,8,10,16,13,4;foot_l,7,0,26,0,0,0,0/!350,216,-6,-1,-6,13,5,13/!84,75,-14,4,-21,29,8,36/!0,255,-13,6,-23,26,4,1;"
                + "torso,0,0,-6,0,0,0,0/0,122,-16,-13,-11,31,13,22/0,0,-23,-49,-18,46,39,36/164,0,-29,-46,-15,57,31,29/106,122,-29,-19,-15,58,3,31/"
                + "106,122,-29,-35,-15,58,3,31/378,238,-16,-29,-20,8,8,1/440,238,6,-25,-20,10,5,1/184,157,-17,-48,-13,34,5,25/"
                + "34,238,-17,-32,18,34,15,1/254,238,-5,-39,-20,10,10,3/0,238,-8,-42,-19,16,16,1;head,9,0,-49,-3,0,0,0/350,216,-6,-5,-6,13,5,13/"
                + "52,190,-10,-8,-10,21,4,21/302,157,-9,-20,-9,18,12,18/104,238,-6,-23,-6,13,3,13/340,238,-3,-16,-3,5,5,5;"
                + "shoulder_r,9,-36,-40,0,0,0,0/0,190,-6,-6,-6,13,13,13/404,122,-10,-12,-9,18,16,18/136,190,-11,-6,-10,20,5,20/"
                + "472,75,-5,3,-5,10,26,10;forearm_r,11,0,27,0,-0.25,0,0/418,75,-6,0,-7,13,23,14/130,216,-7,22,-8,14,3,16;"
                + "forearm_r_cannon,12,0,31,-3,0,0,0/384,0,-9,-9,-26,18,18,31/344,190,-6,-10,-21,13,1,21/108,157,9,-5,-21,1,10,21;"
                + "forearm_r_cannon_barrel,13,0,0,-26,0,0,0/338,75,-5,-5,-31,9,9,31/464,190,-7,-7,-36,14,14,8;forearm_r_cannon_flash,14,0,0,-36,0,0,0/"
                + "216,190,-4,-4,-16,8,8,16/396,238,-9,-1,-5,18,3,4/0,216,-1,-9,-5,3,18,4;shoulder_l,9,36,-40,0,0,0,0/!0,190,-6,-6,-6,13,13,13/"
                + "!404,122,-8,-12,-9,18,16,18/!136,190,-8,-6,-10,20,5,20/!472,75,-5,3,-5,10,26,10;forearm_l,16,0,27,0,-0.25,0,0/"
                + "!418,75,-6,0,-7,13,23,14/!130,216,-7,22,-8,14,3,16;forearm_l_flamer,17,0,30,-3,0,0,0/0,157,-5,-5,-20,10,10,23/"
                + "264,190,-4,5,-8,8,8,16/246,216,-4,8,-8,8,3,16;forearm_l_flamer_barrel,18,0,-1,-21,0,0,0/88,216,-3,-3,-16,5,5,16/"
                + "316,238,-4,-4,-19,8,8,4/64,255,-1,4,-18,3,1,3;exhaust,9,14,-49,26,0,0,0/336,0,-6,-39,-6,12,42,12/156,238,-6,-9,-6,13,3,13/"
                + "156,238,-6,-30,-6,13,3,13/294,216,-7,-42,-7,14,4,14;flame_exh,20,0,-42,0,3.1416,0,0/312,190,-4,0,-4,8,16,8;"
                + "stack_r,9,-17,-44,23,-0.15,0,0.1/152,157,-4,-22,-4,8,23,8/280,238,-5,-24,-5,9,3,9/462,238,-3,-25,-3,5,1,5;"
                + "stack_l,9,17,-44,23,-0.15,0,-0.1/152,157,-4,-22,-4,8,23,8/280,238,-5,-24,-5,9,3,9/462,238,-3,-25,-3,5,1,5;"
                + "tank,9,0,-29,26,0,0,1.5708/214,75,-6,-16,-6,13,31,13/402,216,-7,-16,-7,14,3,14/402,216,-7,13,-7,14,3,14/"
                + "190,216,-7,-3,-7,14,5,14");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2538F)
                .legLengths(12.35F, 13F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .flame("hips/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_flamer/forearm_l_flamer_barrel", null, null);
    }
}
