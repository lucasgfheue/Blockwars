package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Mole (topo). */
@SuppressWarnings("unused")
public final class M_topo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("topo"), "main");

    private M_topo() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_base = root.addOrReplaceChild("base", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-14F, -24F, -10F, 28F, 24F, 20F)
                .texOffs(190, 131).addBox(-15F, -2F, -7F, 30F, 4F, 14F)
                .texOffs(0, 110).addBox(-12F, -26F, -9F, 24F, 3F, 18F),
                PartPose.offsetAndRotation(0F, 22F, -36F, 0F, 0F, 0F));
        PartDefinition p_snout = p_base.addOrReplaceChild("snout", CubeListBuilder.create()
                .texOffs(96, 0).addBox(-12F, -20F, -22F, 24F, 20F, 24F)
                .texOffs(370, 86).addBox(-10F, -22F, -18F, 20F, 3F, 20F)
                .texOffs(458, 150).addBox(-10F, -8F, -23F, 20F, 8F, 1F)
                .texOffs(330, 166).addBox(-8F, -16F, -23F, 4F, 3F, 1F)
                .texOffs(330, 166).addBox(4F, -16F, -23F, 4F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -20F, -12F, -0.2F, 0F, 0F));
        PartDefinition p_tusk_r = p_snout.addOrReplaceChild("tusk_r", CubeListBuilder.create()
                .texOffs(428, 150).addBox(-2F, -1F, -4F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-10F, -4F, -20F, 0.3F, 0F, -0.3F));
        PartDefinition p_tusk_l = p_snout.addOrReplaceChild("tusk_l", CubeListBuilder.create()
                .texOffs(428, 150).mirror().addBox(-2F, -1F, -4F, 3F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(10F, -4F, -20F, 0.3F, 0F, 0.3F));
        PartDefinition p_jaw = p_snout.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(390, 44).addBox(-10F, 0F, -16F, 20F, 4F, 20F)
                .texOffs(290, 166).addBox(-9F, -2F, -16F, 18F, 2F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -10F, 0F, 0F, 0F));
        PartDefinition p_seg0 = p_base.addOrReplaceChild("seg0", CubeListBuilder.create()
                .texOffs(192, 0).addBox(-14F, -24F, 0F, 28F, 24F, 18F)
                .texOffs(0, 86).addBox(-11F, -21F, -3F, 22F, 18F, 6F)
                .texOffs(84, 110).addBox(-12F, -26F, 1F, 24F, 3F, 16F)
                .texOffs(278, 131).addBox(-15F, -2F, 3F, 30F, 4F, 12F)
                .texOffs(0, 166).addBox(-11F, -14F, 18F, 22F, 4F, 1F)
                .texOffs(440, 150).addBox(-2F, -32F, 6F, 3F, 6F, 6F),
                PartPose.offsetAndRotation(0F, 0F, 10F, 0F, 0F, 0F));
        PartDefinition p_seg1 = p_seg0.addOrReplaceChild("seg1", CubeListBuilder.create()
                .texOffs(284, 0).addBox(-13F, -24F, 0F, 27F, 24F, 18F)
                .texOffs(56, 86).addBox(-10F, -21F, -3F, 21F, 18F, 6F)
                .texOffs(164, 110).addBox(-11F, -26F, 1F, 23F, 3F, 16F)
                .texOffs(362, 131).addBox(-14F, -2F, 3F, 29F, 4F, 12F)
                .texOffs(46, 166).addBox(-10F, -14F, 18F, 21F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 18F, 0F, 0F, 0F));
        PartDefinition p_seg2 = p_seg1.addOrReplaceChild("seg2", CubeListBuilder.create()
                .texOffs(374, 0).addBox(-13F, -24F, 0F, 25F, 24F, 18F)
                .texOffs(110, 86).addBox(-10F, -21F, -3F, 19F, 18F, 6F)
                .texOffs(242, 110).addBox(-11F, -26F, 1F, 21F, 3F, 16F)
                .texOffs(0, 150).addBox(-14F, -2F, 3F, 27F, 4F, 12F)
                .texOffs(90, 166).addBox(-10F, -14F, 18F, 19F, 4F, 1F)
                .texOffs(440, 150).addBox(-2F, -32F, 6F, 3F, 6F, 6F),
                PartPose.offsetAndRotation(0F, 0F, 18F, 0F, 0F, 0F));
        PartDefinition p_seg3 = p_seg2.addOrReplaceChild("seg3", CubeListBuilder.create()
                .texOffs(0, 44).addBox(-12F, -24F, 0F, 24F, 24F, 18F)
                .texOffs(160, 86).addBox(-9F, -21F, -3F, 18F, 18F, 6F)
                .texOffs(316, 110).addBox(-10F, -26F, 1F, 20F, 3F, 16F)
                .texOffs(78, 150).addBox(-13F, -2F, 3F, 26F, 4F, 12F)
                .texOffs(130, 166).addBox(-9F, -14F, 18F, 18F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 18F, 0F, 0F, 0F));
        PartDefinition p_seg4 = p_seg3.addOrReplaceChild("seg4", CubeListBuilder.create()
                .texOffs(84, 44).addBox(-11F, -24F, 0F, 22F, 24F, 18F)
                .texOffs(208, 86).addBox(-8F, -21F, -3F, 16F, 18F, 6F)
                .texOffs(388, 110).addBox(-9F, -26F, 1F, 18F, 3F, 16F)
                .texOffs(154, 150).addBox(-12F, -2F, 3F, 24F, 4F, 12F)
                .texOffs(168, 166).addBox(-8F, -14F, 18F, 16F, 4F, 1F)
                .texOffs(440, 150).addBox(-2F, -32F, 6F, 3F, 6F, 6F),
                PartPose.offsetAndRotation(0F, 0F, 18F, 0F, 0F, 0F));
        PartDefinition p_seg5 = p_seg4.addOrReplaceChild("seg5", CubeListBuilder.create()
                .texOffs(164, 44).addBox(-10F, -24F, 0F, 21F, 24F, 18F)
                .texOffs(252, 86).addBox(-8F, -21F, -3F, 15F, 18F, 6F)
                .texOffs(0, 131).addBox(-8F, -26F, 1F, 17F, 3F, 16F)
                .texOffs(226, 150).addBox(-12F, -2F, 3F, 23F, 4F, 12F)
                .texOffs(202, 166).addBox(-8F, -14F, 18F, 15F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 18F, 0F, 0F, 0F));
        PartDefinition p_seg6 = p_seg5.addOrReplaceChild("seg6", CubeListBuilder.create()
                .texOffs(242, 44).addBox(-10F, -24F, 0F, 20F, 24F, 18F)
                .texOffs(294, 86).addBox(-7F, -21F, -3F, 14F, 18F, 6F)
                .texOffs(66, 131).addBox(-8F, -26F, 1F, 16F, 3F, 16F)
                .texOffs(296, 150).addBox(-11F, -2F, 3F, 22F, 4F, 12F)
                .texOffs(234, 166).addBox(-7F, -14F, 18F, 14F, 4F, 1F)
                .texOffs(440, 150).addBox(-2F, -32F, 6F, 3F, 6F, 6F),
                PartPose.offsetAndRotation(0F, 0F, 18F, 0F, 0F, 0F));
        PartDefinition p_seg7 = p_seg6.addOrReplaceChild("seg7", CubeListBuilder.create()
                .texOffs(318, 44).addBox(-9F, -24F, 0F, 18F, 24F, 18F)
                .texOffs(334, 86).addBox(-6F, -21F, -3F, 12F, 18F, 6F)
                .texOffs(130, 131).addBox(-7F, -26F, 1F, 14F, 3F, 16F)
                .texOffs(364, 150).addBox(-10F, -2F, 3F, 20F, 4F, 12F)
                .texOffs(264, 166).addBox(-6F, -14F, 18F, 12F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 18F, 0F, 0F, 0F));
        PartDefinition p_tailtip = p_seg7.addOrReplaceChild("tailtip", CubeListBuilder.create()
                .texOffs(450, 86).addBox(-4F, -4F, -1F, 8F, 8F, 14F)
                .texOffs(500, 150).addBox(-2F, -2F, 13F, 4F, 4F, 2F),
                PartPose.offsetAndRotation(0F, -8F, 18F, 0.2F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.SERPENT).parts("base", "base", "base/snout").walkRate(0.4F)
                .segment("base/seg0")
                .segment("base/seg0/seg1")
                .segment("base/seg0/seg1/seg2")
                .segment("base/seg0/seg1/seg2/seg3")
                .segment("base/seg0/seg1/seg2/seg3/seg4")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6/seg7")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6/seg7/tailtip")
                .jaw("base/snout/jaw")
                .primary(Rig.MountKind.BODY, "base/snout", null, null, null)
                .secondary(Rig.MountKind.BODY, "base/snout", null, null, null);
    }
}
