package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Mole (topo). */
@SuppressWarnings("unused")
public final class M_topo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("topo"), "main");

    private M_topo() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "base,-1,0,22,-36,0,0,0/0,0,-14,-24,-10,28,24,20/190,131,-15,-2,-7,30,4,14/0,110,-12,-26,-9,24,3,18;snout,0,0,-20,-12,-0.2,0,0/"
                + "96,0,-12,-20,-22,24,20,24/370,86,-10,-22,-18,20,3,20/458,150,-10,-8,-23,20,8,1/330,166,-8,-16,-23,4,3,1/"
                + "330,166,4,-16,-23,4,3,1;tusk_r,1,-10,-4,-20,0.3,0,-0.3/428,150,-2,-1,-4,3,10,3;tusk_l,1,10,-4,-20,0.3,0,0.3/"
                + "!428,150,-2,-1,-4,3,10,3;jaw,1,0,0,-10,0,0,0/390,44,-10,0,-16,20,4,20/290,166,-9,-2,-16,18,2,2;seg0,0,0,0,10,0,0,0/"
                + "192,0,-14,-24,0,28,24,18/0,86,-11,-21,-3,22,18,6/84,110,-12,-26,1,24,3,16/278,131,-15,-2,3,30,4,12/0,166,-11,-14,18,22,4,1/"
                + "440,150,-2,-32,6,3,6,6;seg1,5,0,0,18,0,0,0/284,0,-13,-24,0,27,24,18/56,86,-10,-21,-3,21,18,6/164,110,-11,-26,1,23,3,16/"
                + "362,131,-14,-2,3,29,4,12/46,166,-10,-14,18,21,4,1;seg2,6,0,0,18,0,0,0/374,0,-13,-24,0,25,24,18/110,86,-10,-21,-3,19,18,6/"
                + "242,110,-11,-26,1,21,3,16/0,150,-14,-2,3,27,4,12/90,166,-10,-14,18,19,4,1/440,150,-2,-32,6,3,6,6;seg3,7,0,0,18,0,0,0/"
                + "0,44,-12,-24,0,24,24,18/160,86,-9,-21,-3,18,18,6/316,110,-10,-26,1,20,3,16/78,150,-13,-2,3,26,4,12/130,166,-9,-14,18,18,4,1;"
                + "seg4,8,0,0,18,0,0,0/84,44,-11,-24,0,22,24,18/208,86,-8,-21,-3,16,18,6/388,110,-9,-26,1,18,3,16/154,150,-12,-2,3,24,4,12/"
                + "168,166,-8,-14,18,16,4,1/440,150,-2,-32,6,3,6,6;seg5,9,0,0,18,0,0,0/164,44,-10,-24,0,21,24,18/252,86,-8,-21,-3,15,18,6/"
                + "0,131,-8,-26,1,17,3,16/226,150,-12,-2,3,23,4,12/202,166,-8,-14,18,15,4,1;seg6,10,0,0,18,0,0,0/242,44,-10,-24,0,20,24,18/"
                + "294,86,-7,-21,-3,14,18,6/66,131,-8,-26,1,16,3,16/296,150,-11,-2,3,22,4,12/234,166,-7,-14,18,14,4,1/440,150,-2,-32,6,3,6,6;"
                + "seg7,11,0,0,18,0,0,0/318,44,-9,-24,0,18,24,18/334,86,-6,-21,-3,12,18,6/130,131,-7,-26,1,14,3,16/364,150,-10,-2,3,20,4,12/"
                + "264,166,-6,-14,18,12,4,1;tailtip,12,0,-8,18,0.2,0,0/450,86,-4,-4,-1,8,8,14/500,150,-2,-2,13,4,4,2");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.SERPENT).parts("base", "base", "base/snout").walkRate(0.4F)
                .segment("base/seg0")
                .segment("base/seg0/seg1")
                .segment("base/seg0/seg1/seg2")
                .segment("base/seg0/seg1/seg2/seg3")
                .segment("base/seg0/seg1/seg2/seg3/seg4")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6/seg7")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6/seg7/tailtip")
                .jaw("base/snout/jaw")
                .primary(Rig.MountKind.BODY, "base/snout", null, null, null)
                .secondary(Rig.MountKind.BODY, "base/snout", null, null, null);
    }
}
