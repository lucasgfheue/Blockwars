package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Dune (duna). */
@SuppressWarnings("unused")
public final class M_duna {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("duna"), "main");

    private M_duna() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hull,-1,0,23,0,0,0,0/0,92,-36,-35,-30,71,15,61/268,168,-19,-38,-19,38,4,43/264,92,-19,-21,-29,38,17,57/"
                + "0,287,-34,-30,-31,67,6,1;tread_r,0,-27,-10,0,0,0,0/0,0,-8,-10,-36,17,21,71/176,0,-9,-16,-37,19,5,74;wheel_r0,1,-9,2,-25,0,0,0/"
                + "290,238,-1,-6,-6,1,13,13/448,268,-1,-2,-2,2,4,4;wheel_r1,1,-9,2,-8,0,0,0/290,238,-1,-6,-6,1,13,13/448,268,-1,-2,-2,2,4,4;"
                + "wheel_r2,1,-9,2,8,0,0,0/290,238,-1,-6,-6,1,13,13/448,268,-1,-2,-2,2,4,4;wheel_r3,1,-9,2,25,0,0,0/290,238,-1,-6,-6,1,13,13/"
                + "448,268,-1,-2,-2,2,4,4;tread_l,0,27,-10,0,0,0,0/!0,0,-8,-10,-36,17,21,71/!176,0,-9,-16,-37,19,5,74;wheel_l0,6,9,2,-25,0,0,0/"
                + "!290,238,-1,-6,-6,1,13,13/!448,268,-1,-2,-2,2,4,4;wheel_l1,6,9,2,-8,0,0,0/!290,238,-1,-6,-6,1,13,13/!448,268,-1,-2,-2,2,4,4;"
                + "wheel_l2,6,9,2,8,0,0,0/!290,238,-1,-6,-6,1,13,13/!448,268,-1,-2,-2,2,4,4;wheel_l3,6,9,2,25,0,0,0/!290,238,-1,-6,-6,1,13,13/"
                + "!448,268,-1,-2,-2,2,4,4;turret,0,0,-36,4,0,0,0/116,168,-19,-15,-19,38,15,38/182,238,-15,-16,-10,29,1,25/"
                + "378,268,-13,-12,19,25,8,1;head,11,10,-15,6,0,0,0/310,268,-4,-2,-4,8,2,8/368,238,-7,-10,-6,15,8,13/136,287,-6,-9,-7,13,6,1/"
                + "210,287,-6,-8,-8,3,3,1/210,287,-2,-8,-8,3,3,1/210,287,3,-8,-8,3,3,1/134,268,-8,-12,-7,16,1,14;antenna,12,5,-13,4,-0.2,0,0.15/"
                + "318,238,-1,-25,-1,1,25,1/218,287,-1,-26,-1,2,2,2;turret_gatling,11,0,-6,-17,0,0,0/430,168,-6,-6,-15,13,13,17/"
                + "194,268,-4,-8,-13,8,2,13/114,268,6,-4,-8,2,8,8;turret_gatling_barrel,14,0,0,-15,0,0,0/322,238,3,-1,-21,2,2,21/"
                + "322,238,1,2,-21,2,2,21/322,238,-3,2,-21,2,2,21/322,238,-5,-1,-21,2,2,21/322,238,-3,-4,-21,2,2,21/322,238,1,-4,-21,2,2,21/"
                + "236,268,-5,-5,-4,10,10,3/262,268,-5,-5,-18,10,10,2;turret_gatling_flash,15,0,0,-21,0,0,0/0,268,-3,-3,-13,6,6,13/"
                + "164,287,-7,-1,-4,15,2,3/38,268,-1,-7,-4,2,15,3;turret_gun,11,13,-6,-17,0,0,0/0,238,-4,-5,-19,8,9,21/466,238,-3,-7,-17,6,2,17/"
                + "342,268,-2,4,-3,4,4,6;turret_gun_barrel,17,0,-1,-19,0,0,0/424,238,-2,-2,-17,4,4,17/430,268,-3,-3,-18,6,6,3;"
                + "turret_gun_flash,18,0,0,-19,0,0,0/0,268,-3,-3,-13,6,6,13/164,287,-7,-1,-4,15,2,3/38,268,-1,-7,-4,2,15,3;"
                + "cargo0,11,-8,-6,27,0,0,0/58,238,-8,-7,-7,16,14,15/226,287,-7,-1,-8,14,2,1/48,268,-8,-8,-8,17,1,16;cargo1,11,8,-6,27,0,0,0/"
                + "58,238,-8,-7,-7,16,14,15/226,287,-7,-1,-8,14,2,1/48,268,-8,-8,-8,17,1,16;cargo2,11,0,-21,27,0,0,0/120,238,-8,-7,-7,16,14,15/"
                + "226,287,-7,-1,-8,14,2,1/48,268,-8,-8,-8,17,1,16;beacon,11,-11,-21,19,0,0,0/362,268,-2,-1,-2,4,6,4/286,268,-3,-6,-3,6,6,6;"
                + "beacon_spin,23,0,-3,0,0,0,0/200,287,-2,-2,-4,4,4,1/200,287,-2,-2,3,4,4,1;skirt_r,0,-37,-19,0,0,0,0/0,168,-1,-6,-29,1,13,57;"
                + "skirt_l,0,37,-19,0,0,0,0/!0,168,-1,-6,-29,1,13,57");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/turret/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hull/turret/turret_gatling/turret_gatling_barrel", 2, 1.2F, 3)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gatling/turret_gatling_barrel", "hull/turret/turret_gatling/turret_gatling_barrel/turret_gatling_flash", null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
