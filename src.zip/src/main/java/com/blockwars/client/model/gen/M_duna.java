package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Dune (duna). */
@SuppressWarnings("unused")
public final class M_duna {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("duna"), "main");

    private M_duna() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 92).addBox(-36F, -35F, -30F, 71F, 15F, 61F)
                .texOffs(268, 168).addBox(-19F, -38F, -19F, 38F, 4F, 43F)
                .texOffs(264, 92).addBox(-19F, -21F, -29F, 38F, 17F, 57F)
                .texOffs(0, 287).addBox(-34F, -30F, -31F, 67F, 6F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-8F, -10F, -36F, 17F, 21F, 71F)
                .texOffs(176, 0).addBox(-9F, -16F, -37F, 19F, 5F, 74F),
                PartPose.offsetAndRotation(-27F, -10F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(290, 238).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(448, 268).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -25F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(290, 238).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(448, 268).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -8F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(290, 238).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(448, 268).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 8F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(290, 238).addBox(-1F, -6F, -6F, 1F, 13F, 13F)
                .texOffs(448, 268).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 25F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-8F, -10F, -36F, 17F, 21F, 71F).mirror(false)
                .texOffs(176, 0).mirror().addBox(-9F, -16F, -37F, 19F, 5F, 74F).mirror(false),
                PartPose.offsetAndRotation(27F, -10F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(290, 238).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(448, 268).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -25F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(290, 238).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(448, 268).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -8F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(290, 238).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(448, 268).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 8F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(290, 238).mirror().addBox(-1F, -6F, -6F, 1F, 13F, 13F).mirror(false)
                .texOffs(448, 268).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 25F, 0F, 0F, 0F));
        PartDefinition p_turret = p_hull.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(116, 168).addBox(-19F, -15F, -19F, 38F, 15F, 38F)
                .texOffs(182, 238).addBox(-15F, -16F, -10F, 29F, 1F, 25F)
                .texOffs(378, 268).addBox(-13F, -12F, 19F, 25F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -36F, 4F, 0F, 0F, 0F));
        PartDefinition p_head = p_turret.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(310, 268).addBox(-4F, -2F, -4F, 8F, 2F, 8F)
                .texOffs(368, 238).addBox(-7F, -10F, -6F, 15F, 8F, 13F)
                .texOffs(136, 287).addBox(-6F, -9F, -7F, 13F, 6F, 1F)
                .texOffs(210, 287).addBox(-6F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(210, 287).addBox(-2F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(210, 287).addBox(3F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(134, 268).addBox(-8F, -12F, -7F, 16F, 1F, 14F),
                PartPose.offsetAndRotation(10F, -15F, 6F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(318, 238).addBox(-1F, -25F, -1F, 1F, 25F, 1F)
                .texOffs(218, 287).addBox(-1F, -26F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret_gatling = p_turret.addOrReplaceChild("turret_gatling", CubeListBuilder.create()
                .texOffs(430, 168).addBox(-6F, -6F, -15F, 13F, 13F, 17F)
                .texOffs(194, 268).addBox(-4F, -8F, -13F, 8F, 2F, 13F)
                .texOffs(114, 268).addBox(6F, -4F, -8F, 2F, 8F, 8F),
                PartPose.offsetAndRotation(0F, -6F, -17F, 0F, 0F, 0F));
        PartDefinition p_turret_gatling_barrel = p_turret_gatling.addOrReplaceChild("turret_gatling_barrel", CubeListBuilder.create()
                .texOffs(322, 238).addBox(3F, -1F, -21F, 2F, 2F, 21F)
                .texOffs(322, 238).addBox(1F, 2F, -21F, 2F, 2F, 21F)
                .texOffs(322, 238).addBox(-3F, 2F, -21F, 2F, 2F, 21F)
                .texOffs(322, 238).addBox(-5F, -1F, -21F, 2F, 2F, 21F)
                .texOffs(322, 238).addBox(-3F, -4F, -21F, 2F, 2F, 21F)
                .texOffs(322, 238).addBox(1F, -4F, -21F, 2F, 2F, 21F)
                .texOffs(236, 268).addBox(-5F, -5F, -4F, 10F, 10F, 3F)
                .texOffs(262, 268).addBox(-5F, -5F, -18F, 10F, 10F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0F, 0F, 0F));
        PartDefinition p_turret_gatling_flash = p_turret_gatling_barrel.addOrReplaceChild("turret_gatling_flash", CubeListBuilder.create()
                .texOffs(0, 268).addBox(-3F, -3F, -13F, 6F, 6F, 13F)
                .texOffs(164, 287).addBox(-7F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(38, 268).addBox(-1F, -7F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -21F, 0F, 0F, 0F));
        PartDefinition p_turret_gun = p_turret.addOrReplaceChild("turret_gun", CubeListBuilder.create()
                .texOffs(0, 238).addBox(-4F, -5F, -19F, 8F, 9F, 21F)
                .texOffs(466, 238).addBox(-3F, -7F, -17F, 6F, 2F, 17F)
                .texOffs(342, 268).addBox(-2F, 4F, -3F, 4F, 4F, 6F),
                PartPose.offsetAndRotation(13F, -6F, -17F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_barrel = p_turret_gun.addOrReplaceChild("turret_gun_barrel", CubeListBuilder.create()
                .texOffs(424, 238).addBox(-2F, -2F, -17F, 4F, 4F, 17F)
                .texOffs(430, 268).addBox(-3F, -3F, -18F, 6F, 6F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -19F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_flash = p_turret_gun_barrel.addOrReplaceChild("turret_gun_flash", CubeListBuilder.create()
                .texOffs(0, 268).addBox(-3F, -3F, -13F, 6F, 6F, 13F)
                .texOffs(164, 287).addBox(-7F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(38, 268).addBox(-1F, -7F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -19F, 0F, 0F, 0F));
        PartDefinition p_cargo0 = p_turret.addOrReplaceChild("cargo0", CubeListBuilder.create()
                .texOffs(58, 238).addBox(-8F, -7F, -7F, 16F, 14F, 15F)
                .texOffs(226, 287).addBox(-7F, -1F, -8F, 14F, 2F, 1F)
                .texOffs(48, 268).addBox(-8F, -8F, -8F, 17F, 1F, 16F),
                PartPose.offsetAndRotation(-8F, -6F, 27F, 0F, 0F, 0F));
        PartDefinition p_cargo1 = p_turret.addOrReplaceChild("cargo1", CubeListBuilder.create()
                .texOffs(58, 238).addBox(-8F, -7F, -7F, 16F, 14F, 15F)
                .texOffs(226, 287).addBox(-7F, -1F, -8F, 14F, 2F, 1F)
                .texOffs(48, 268).addBox(-8F, -8F, -8F, 17F, 1F, 16F),
                PartPose.offsetAndRotation(8F, -6F, 27F, 0F, 0F, 0F));
        PartDefinition p_cargo2 = p_turret.addOrReplaceChild("cargo2", CubeListBuilder.create()
                .texOffs(120, 238).addBox(-8F, -7F, -7F, 16F, 14F, 15F)
                .texOffs(226, 287).addBox(-7F, -1F, -8F, 14F, 2F, 1F)
                .texOffs(48, 268).addBox(-8F, -8F, -8F, 17F, 1F, 16F),
                PartPose.offsetAndRotation(0F, -21F, 27F, 0F, 0F, 0F));
        PartDefinition p_beacon = p_turret.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(362, 268).addBox(-2F, -1F, -2F, 4F, 6F, 4F)
                .texOffs(286, 268).addBox(-3F, -6F, -3F, 6F, 6F, 6F),
                PartPose.offsetAndRotation(-11F, -21F, 19F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(200, 287).addBox(-2F, -2F, -4F, 4F, 4F, 1F)
                .texOffs(200, 287).addBox(-2F, -2F, 3F, 4F, 4F, 1F),
                PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(0, 168).addBox(-1F, -6F, -29F, 1F, 13F, 57F),
                PartPose.offsetAndRotation(-37F, -19F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(0, 168).mirror().addBox(-1F, -6F, -29F, 1F, 13F, 57F).mirror(false),
                PartPose.offsetAndRotation(37F, -19F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/turret/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hull/turret/turret_gatling/turret_gatling_barrel", 2, 1.2F, 3)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gatling/turret_gatling_barrel", "hull/turret/turret_gatling/turret_gatling_barrel/turret_gatling_flash", null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
