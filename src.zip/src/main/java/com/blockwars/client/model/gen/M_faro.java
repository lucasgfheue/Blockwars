package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Lighthouse (faro). */
@SuppressWarnings("unused")
public final class M_faro {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("faro"), "main");

    private M_faro() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-70,0,0,0,0/402,65,-14,-6,-10,29,13,21/0,139,-16,-6,-12,31,6,23/406,168,-4,-3,-13,8,8,1;thigh_r,-1,-12,-70,0,0,0,0/"
                + "454,0,-5,0,-5,9,40,9/112,105,-6,3,-8,12,28,5/146,105,-6,3,-5,3,24,9;shin_r,1,0,40,0,0,0,0/308,0,-6,0,-6,12,42,12/"
                + "218,168,-5,-6,-10,9,10,5/338,139,-3,12,6,6,21,4;foot_r,2,0,42,0,0,0,0/362,168,-3,-1,-3,6,5,6/174,105,-9,4,-14,18,8,23/"
                + "0,190,-8,6,-15,16,4,1;thigh_l,-1,12,-70,0,0,0,0/!454,0,-5,0,-5,9,40,9/!112,105,-6,3,-8,12,28,5/!146,105,3,3,-5,3,24,9;"
                + "shin_l,4,0,40,0,0,0,0/!308,0,-6,0,-6,12,42,12/!218,168,-5,-6,-10,9,10,5/!338,139,-3,12,6,6,21,4;foot_l,5,0,42,0,0,0,0/"
                + "!362,168,-3,-1,-3,6,5,6/!174,105,-9,4,-14,18,8,23/!0,190,-8,6,-15,16,4,1;torso,0,0,-6,0,0,0,0/244,65,-15,-13,-11,30,13,22/"
                + "152,0,-25,-44,-15,49,34,29/0,0,-20,-42,-18,40,29,36/80,65,-25,-31,-15,51,6,31/300,105,-17,-47,-13,35,5,25;"
                + "head,7,0,-47,-3,0,0,0;crest,8,0,-21,-3,-0.8,0,0/108,139,-1,-21,-4,3,21,8/118,168,-1,-18,-5,1,16,1;antenna,8,6,-16,5,-0.2,0,0.15/"
                + "170,105,-1,-31,-1,1,31,1/468,168,-1,-32,-1,3,3,3;shoulder_r,7,-32,-38,0,0,0,0/186,139,-6,-6,-6,13,13,13/"
                + "0,105,-10,-12,-9,18,16,18/258,139,-11,-6,-10,20,5,20/72,105,-5,3,-5,10,23,10;forearm_r,11,0,25,0,-0.25,0,0/"
                + "348,65,-6,0,-7,13,21,14/58,168,-7,20,-8,14,3,16;forearm_r_cannon,12,0,29,-3,0,0,0/356,0,-9,-9,-26,18,18,31/"
                + "406,139,-6,-10,-21,13,1,21/256,105,9,-5,-21,1,10,21;forearm_r_cannon_barrel,13,0,0,-26,0,0,0/0,65,-5,-5,-31,9,9,31/"
                + "0,168,-7,-7,-36,14,14,8;forearm_r_cannon_flash,14,0,0,-36,0,0,0/358,139,-4,-4,-16,8,8,16/424,168,-9,-1,-5,18,3,4/"
                + "44,168,-1,-9,-5,3,18,4;shoulder_l,7,32,-38,0,0,0,0/!186,139,-6,-6,-6,13,13,13/!0,105,-8,-12,-9,18,16,18/"
                + "!258,139,-8,-6,-10,20,5,20/!72,105,-5,3,-5,10,23,10;forearm_l,16,0,25,0,-0.25,0,0/!348,65,-6,0,-7,13,21,14/"
                + "!58,168,-7,20,-8,14,3,16;forearm_l_emitter,17,0,27,-3,0,0,0/130,139,-6,-6,-13,12,12,16/122,168,-1,5,-22,3,3,13/"
                + "122,168,-7,-5,-22,3,3,13/122,168,4,-5,-22,3,3,13;forearm_l_emitter_orb,18,0,0,-20,0.7854,0.7854,0/154,168,-4,-4,-4,8,8,8/"
                + "246,168,-2,-5,-2,4,10,4;beacon,7,-15,-52,18,0,0,0/342,168,-3,-1,-3,5,8,5/186,168,-4,-8,-4,8,8,8;beacon_spin,20,0,-4,0,0,0,0/"
                + "480,168,-3,-3,-5,5,5,1/480,168,-3,-3,4,5,5,1;coil_r,7,-15,-42,23,0,0,0/238,139,-3,-16,-3,5,21,5/262,168,-5,-6,-5,10,3,10/"
                + "302,168,-5,-13,-5,10,3,10/262,168,-5,-20,-5,10,3,10/386,168,-3,-26,-3,5,5,5;coil_l,7,15,-42,23,0,0,0/"
                + "238,139,-3,-16,-3,5,21,5/262,168,-5,-6,-5,10,3,10/302,168,-5,-13,-5,10,3,10/262,168,-5,-20,-5,10,3,10/"
                + "386,168,-3,-26,-3,5,5,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2538F)
                .legLengths(20.15F, 20.8F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_emitter/forearm_l_emitter_orb", 2, 0.25F, 0)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
