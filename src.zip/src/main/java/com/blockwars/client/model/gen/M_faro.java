package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Lighthouse (faro). */
@SuppressWarnings("unused")
public final class M_faro {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("faro"), "main");

    private M_faro() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(402, 65).addBox(-14F, -6F, -10F, 29F, 13F, 21F)
                .texOffs(0, 139).addBox(-16F, -6F, -12F, 31F, 6F, 23F)
                .texOffs(406, 168).addBox(-4F, -3F, -13F, 8F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -70F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(454, 0).addBox(-5F, 0F, -5F, 9F, 40F, 9F)
                .texOffs(112, 105).addBox(-6F, 3F, -8F, 12F, 28F, 5F)
                .texOffs(146, 105).addBox(-6F, 3F, -5F, 3F, 24F, 9F),
                PartPose.offsetAndRotation(-12F, -70F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(308, 0).addBox(-6F, 0F, -6F, 12F, 42F, 12F)
                .texOffs(218, 168).addBox(-5F, -6F, -10F, 9F, 10F, 5F)
                .texOffs(338, 139).addBox(-3F, 12F, 6F, 6F, 21F, 4F),
                PartPose.offsetAndRotation(0F, 40F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(362, 168).addBox(-3F, -1F, -3F, 6F, 5F, 6F)
                .texOffs(174, 105).addBox(-9F, 4F, -14F, 18F, 8F, 23F)
                .texOffs(0, 190).addBox(-8F, 6F, -15F, 16F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 42F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(454, 0).mirror().addBox(-5F, 0F, -5F, 9F, 40F, 9F).mirror(false)
                .texOffs(112, 105).mirror().addBox(-6F, 3F, -8F, 12F, 28F, 5F).mirror(false)
                .texOffs(146, 105).mirror().addBox(3F, 3F, -5F, 3F, 24F, 9F).mirror(false),
                PartPose.offsetAndRotation(12F, -70F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(308, 0).mirror().addBox(-6F, 0F, -6F, 12F, 42F, 12F).mirror(false)
                .texOffs(218, 168).mirror().addBox(-5F, -6F, -10F, 9F, 10F, 5F).mirror(false)
                .texOffs(338, 139).mirror().addBox(-3F, 12F, 6F, 6F, 21F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 40F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(362, 168).mirror().addBox(-3F, -1F, -3F, 6F, 5F, 6F).mirror(false)
                .texOffs(174, 105).mirror().addBox(-9F, 4F, -14F, 18F, 8F, 23F).mirror(false)
                .texOffs(0, 190).mirror().addBox(-8F, 6F, -15F, 16F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 42F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(244, 65).addBox(-15F, -13F, -11F, 30F, 13F, 22F)
                .texOffs(152, 0).addBox(-25F, -44F, -15F, 49F, 34F, 29F)
                .texOffs(0, 0).addBox(-20F, -42F, -18F, 40F, 29F, 36F)
                .texOffs(80, 65).addBox(-25F, -31F, -15F, 51F, 6F, 31F)
                .texOffs(300, 105).addBox(-17F, -47F, -13F, 35F, 5F, 25F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -47F, -3F, 0F, 0F, 0F));
        PartDefinition p_crest = p_head.addOrReplaceChild("crest", CubeListBuilder.create()
                .texOffs(108, 139).addBox(-1F, -21F, -4F, 3F, 21F, 8F)
                .texOffs(118, 168).addBox(-1F, -18F, -5F, 1F, 16F, 1F),
                PartPose.offsetAndRotation(0F, -21F, -3F, -0.8F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(170, 105).addBox(-1F, -31F, -1F, 1F, 31F, 1F)
                .texOffs(468, 168).addBox(-1F, -32F, -1F, 3F, 3F, 3F),
                PartPose.offsetAndRotation(6F, -16F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(186, 139).addBox(-6F, -6F, -6F, 13F, 13F, 13F)
                .texOffs(0, 105).addBox(-10F, -12F, -9F, 18F, 16F, 18F)
                .texOffs(258, 139).addBox(-11F, -6F, -10F, 20F, 5F, 20F)
                .texOffs(72, 105).addBox(-5F, 3F, -5F, 10F, 23F, 10F),
                PartPose.offsetAndRotation(-32F, -38F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(348, 65).addBox(-6F, 0F, -7F, 13F, 21F, 14F)
                .texOffs(58, 168).addBox(-7F, 20F, -8F, 14F, 3F, 16F),
                PartPose.offsetAndRotation(0F, 25F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_cannon = p_forearm_r.addOrReplaceChild("forearm_r_cannon", CubeListBuilder.create()
                .texOffs(356, 0).addBox(-9F, -9F, -26F, 18F, 18F, 31F)
                .texOffs(406, 139).addBox(-6F, -10F, -21F, 13F, 1F, 21F)
                .texOffs(256, 105).addBox(9F, -5F, -21F, 1F, 10F, 21F),
                PartPose.offsetAndRotation(0F, 29F, -3F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_barrel = p_forearm_r_cannon.addOrReplaceChild("forearm_r_cannon_barrel", CubeListBuilder.create()
                .texOffs(0, 65).addBox(-5F, -5F, -31F, 9F, 9F, 31F)
                .texOffs(0, 168).addBox(-7F, -7F, -36F, 14F, 14F, 8F),
                PartPose.offsetAndRotation(0F, 0F, -26F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_flash = p_forearm_r_cannon_barrel.addOrReplaceChild("forearm_r_cannon_flash", CubeListBuilder.create()
                .texOffs(358, 139).addBox(-4F, -4F, -16F, 8F, 8F, 16F)
                .texOffs(424, 168).addBox(-9F, -1F, -5F, 18F, 3F, 4F)
                .texOffs(44, 168).addBox(-1F, -9F, -5F, 3F, 18F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -36F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(186, 139).mirror().addBox(-6F, -6F, -6F, 13F, 13F, 13F).mirror(false)
                .texOffs(0, 105).mirror().addBox(-8F, -12F, -9F, 18F, 16F, 18F).mirror(false)
                .texOffs(258, 139).mirror().addBox(-8F, -6F, -10F, 20F, 5F, 20F).mirror(false)
                .texOffs(72, 105).mirror().addBox(-5F, 3F, -5F, 10F, 23F, 10F).mirror(false),
                PartPose.offsetAndRotation(32F, -38F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(348, 65).mirror().addBox(-6F, 0F, -7F, 13F, 21F, 14F).mirror(false)
                .texOffs(58, 168).mirror().addBox(-7F, 20F, -8F, 14F, 3F, 16F).mirror(false),
                PartPose.offsetAndRotation(0F, 25F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_emitter = p_forearm_l.addOrReplaceChild("forearm_l_emitter", CubeListBuilder.create()
                .texOffs(130, 139).addBox(-6F, -6F, -13F, 12F, 12F, 16F)
                .texOffs(122, 168).addBox(-1F, 5F, -22F, 3F, 3F, 13F)
                .texOffs(122, 168).addBox(-7F, -5F, -22F, 3F, 3F, 13F)
                .texOffs(122, 168).addBox(4F, -5F, -22F, 3F, 3F, 13F),
                PartPose.offsetAndRotation(0F, 27F, -3F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_emitter_orb = p_forearm_l_emitter.addOrReplaceChild("forearm_l_emitter_orb", CubeListBuilder.create()
                .texOffs(154, 168).addBox(-4F, -4F, -4F, 8F, 8F, 8F)
                .texOffs(246, 168).addBox(-2F, -5F, -2F, 4F, 10F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_beacon = p_torso.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(342, 168).addBox(-3F, -1F, -3F, 5F, 8F, 5F)
                .texOffs(186, 168).addBox(-4F, -8F, -4F, 8F, 8F, 8F),
                PartPose.offsetAndRotation(-15F, -52F, 18F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(480, 168).addBox(-3F, -3F, -5F, 5F, 5F, 1F)
                .texOffs(480, 168).addBox(-3F, -3F, 4F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        PartDefinition p_coil_r = p_torso.addOrReplaceChild("coil_r", CubeListBuilder.create()
                .texOffs(238, 139).addBox(-3F, -16F, -3F, 5F, 21F, 5F)
                .texOffs(262, 168).addBox(-5F, -6F, -5F, 10F, 3F, 10F)
                .texOffs(302, 168).addBox(-5F, -13F, -5F, 10F, 3F, 10F)
                .texOffs(262, 168).addBox(-5F, -20F, -5F, 10F, 3F, 10F)
                .texOffs(386, 168).addBox(-3F, -26F, -3F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(-15F, -42F, 23F, 0F, 0F, 0F));
        PartDefinition p_coil_l = p_torso.addOrReplaceChild("coil_l", CubeListBuilder.create()
                .texOffs(238, 139).addBox(-3F, -16F, -3F, 5F, 21F, 5F)
                .texOffs(262, 168).addBox(-5F, -6F, -5F, 10F, 3F, 10F)
                .texOffs(302, 168).addBox(-5F, -13F, -5F, 10F, 3F, 10F)
                .texOffs(262, 168).addBox(-5F, -20F, -5F, 10F, 3F, 10F)
                .texOffs(386, 168).addBox(-3F, -26F, -3F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(15F, -42F, 23F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2538F)
                .legLengths(20.15F, 20.8F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_emitter/forearm_l_emitter_orb", 2, 0.25F, 0)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
