package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Yeti (yeti). */
@SuppressWarnings("unused")
public final class M_yeti {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("yeti"), "main");

    private M_yeti() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "body,-1,0,-22,0,0,0,0/154,171,-12,-12,-21,25,12,41/0,95,-21,-30,-28,41,21,55/212,0,-17,-28,-34,33,16,69/"
                + "192,95,-21,-22,-29,43,6,59/0,171,-14,-32,-24,29,5,48/0,0,-19,-29,-34,37,26,69/350,260,-12,-23,34,25,13,1;"
                + "leg_fr,-1,-24,-22,-25,0,0,0.12/374,171,-9,-2,-10,18,23,21/292,224,-10,-6,-12,21,9,23;shin_fr,1,0,18,0,0,0,-0.12/"
                + "72,224,-7,0,-7,14,21,14/402,260,-6,2,-9,12,12,2;foot_fr,2,0,21,0,0,0,0/200,224,-10,0,-15,21,7,25/94,283,-9,3,-16,18,3,1;"
                + "leg_fl,-1,24,-22,-25,0,0,-0.12/!374,171,-9,-2,-10,18,23,21/!292,224,-10,-6,-12,21,9,23;shin_fl,4,0,18,0,0,0,0.12/"
                + "!72,224,-7,0,-7,14,21,14/!402,260,-6,2,-9,12,12,2;foot_fl,5,0,21,0,0,0,0/!200,224,-10,0,-15,21,7,25/!94,283,-9,3,-16,18,3,1;"
                + "leg_br,-1,-24,-22,25,0,0,0.12/374,171,-9,-2,-10,18,23,21/292,224,-10,-6,-12,21,9,23;shin_br,7,0,18,0,0,0,-0.12/"
                + "72,224,-7,0,-7,14,21,14/402,260,-6,2,-9,12,12,2;foot_br,8,0,21,0,0,0,0/200,224,-10,0,-15,21,7,25/94,283,-9,3,-16,18,3,1;"
                + "leg_bl,-1,24,-22,25,0,0,-0.12/!374,171,-9,-2,-10,18,23,21/!292,224,-10,-6,-12,21,9,23;shin_bl,10,0,18,0,0,0,0.12/"
                + "!72,224,-7,0,-7,14,21,14/!402,260,-6,2,-9,12,12,2;foot_bl,11,0,21,0,0,0,0/!200,224,-10,0,-15,21,7,25/"
                + "!94,283,-9,3,-16,18,3,1;head,0,0,-19,-37,0,0,0/128,224,-9,-15,-14,18,16,18/240,260,-7,-9,-22,14,9,9/154,283,-7,-12,-15,3,2,1/"
                + "154,283,3,-12,-15,3,2,1;jaw,13,0,1,-9,0,0,0/286,260,-6,0,-14,12,3,14/132,283,-5,-1,-14,9,1,2;xhorn_r,13,-8,-14,2,0.5,-0.6,0/"
                + "430,260,-1,-1,0,2,2,12;xhorn_l,13,8,-14,2,0.5,0.6,0/!430,260,-1,-1,0,2,2,12;turret,0,0,-34,-5,0,0,0/380,224,-10,-7,-12,21,7,23/"
                + "102,260,-8,-8,-9,16,1,18;turret_cannon,17,0,-8,-5,0,0,0/286,171,-8,-8,-23,16,16,28/170,260,-6,-9,-18,12,1,18/"
                + "468,224,8,-5,-18,1,9,18;turret_cannon_barrel,18,0,0,-23,0,0,0/0,224,-4,-4,-28,8,8,28/62,260,-6,-6,-32,13,13,7;"
                + "turret_cannon_flash,19,0,0,-32,0,0,0/20,260,-3,-3,-14,7,7,14/56,283,-8,-1,-4,16,2,3/230,260,-1,-8,-4,2,16,3;"
                + "coil_r,0,-12,-28,39,0,0,0/0,260,-2,-14,-2,5,18,5/458,260,-5,-6,-5,9,2,9/0,283,-5,-12,-5,9,2,9/458,260,-5,-17,-5,9,2,9/"
                + "36,283,-2,-23,-2,5,5,5;coil_l,0,12,-28,39,0,0,0/0,260,-2,-14,-2,5,18,5/458,260,-5,-6,-5,9,2,9/0,283,-5,-12,-5,9,2,9/"
                + "458,260,-5,-17,-5,9,2,9/36,283,-2,-23,-2,5,5,5;bspike0,0,0,-34,-18,0.5,0,0/338,260,-2,-12,-2,3,12,3;bspike1,0,0,-34,0,0.5,0,0/"
                + "338,260,-2,-12,-2,3,12,3;bspike2,0,0,-34,18,0.5,0,0/338,260,-2,-12,-2,3,12,3");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.3478F)
                .legLengths(9.2F, 10.35F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .jaw("body/head/jaw")
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null);
    }
}
