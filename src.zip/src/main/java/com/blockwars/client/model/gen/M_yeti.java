package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Yeti (yeti). */
@SuppressWarnings("unused")
public final class M_yeti {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("yeti"), "main");

    private M_yeti() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(154, 171).addBox(-12F, -12F, -21F, 25F, 12F, 41F)
                .texOffs(0, 95).addBox(-21F, -30F, -28F, 41F, 21F, 55F)
                .texOffs(212, 0).addBox(-17F, -28F, -34F, 33F, 16F, 69F)
                .texOffs(192, 95).addBox(-21F, -22F, -29F, 43F, 6F, 59F)
                .texOffs(0, 171).addBox(-14F, -32F, -24F, 29F, 5F, 48F)
                .texOffs(0, 0).addBox(-19F, -29F, -34F, 37F, 26F, 69F)
                .texOffs(350, 260).addBox(-12F, -23F, 34F, 25F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -22F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create()
                .texOffs(374, 171).addBox(-9F, -2F, -10F, 18F, 23F, 21F)
                .texOffs(292, 224).addBox(-10F, -6F, -12F, 21F, 9F, 23F),
                PartPose.offsetAndRotation(-24F, -22F, -25F, 0F, 0F, 0.12F));
        PartDefinition p_shin_fr = p_leg_fr.addOrReplaceChild("shin_fr", CubeListBuilder.create()
                .texOffs(72, 224).addBox(-7F, 0F, -7F, 14F, 21F, 14F)
                .texOffs(402, 260).addBox(-6F, 2F, -9F, 12F, 12F, 2F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_fr = p_shin_fr.addOrReplaceChild("foot_fr", CubeListBuilder.create()
                .texOffs(200, 224).addBox(-10F, 0F, -15F, 21F, 7F, 25F)
                .texOffs(94, 283).addBox(-9F, 3F, -16F, 18F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create()
                .texOffs(374, 171).mirror().addBox(-9F, -2F, -10F, 18F, 23F, 21F).mirror(false)
                .texOffs(292, 224).mirror().addBox(-10F, -6F, -12F, 21F, 9F, 23F).mirror(false),
                PartPose.offsetAndRotation(24F, -22F, -25F, 0F, 0F, -0.12F));
        PartDefinition p_shin_fl = p_leg_fl.addOrReplaceChild("shin_fl", CubeListBuilder.create()
                .texOffs(72, 224).mirror().addBox(-7F, 0F, -7F, 14F, 21F, 14F).mirror(false)
                .texOffs(402, 260).mirror().addBox(-6F, 2F, -9F, 12F, 12F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_fl = p_shin_fl.addOrReplaceChild("foot_fl", CubeListBuilder.create()
                .texOffs(200, 224).mirror().addBox(-10F, 0F, -15F, 21F, 7F, 25F).mirror(false)
                .texOffs(94, 283).mirror().addBox(-9F, 3F, -16F, 18F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create()
                .texOffs(374, 171).addBox(-9F, -2F, -10F, 18F, 23F, 21F)
                .texOffs(292, 224).addBox(-10F, -6F, -12F, 21F, 9F, 23F),
                PartPose.offsetAndRotation(-24F, -22F, 25F, 0F, 0F, 0.12F));
        PartDefinition p_shin_br = p_leg_br.addOrReplaceChild("shin_br", CubeListBuilder.create()
                .texOffs(72, 224).addBox(-7F, 0F, -7F, 14F, 21F, 14F)
                .texOffs(402, 260).addBox(-6F, 2F, -9F, 12F, 12F, 2F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_br = p_shin_br.addOrReplaceChild("foot_br", CubeListBuilder.create()
                .texOffs(200, 224).addBox(-10F, 0F, -15F, 21F, 7F, 25F)
                .texOffs(94, 283).addBox(-9F, 3F, -16F, 18F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create()
                .texOffs(374, 171).mirror().addBox(-9F, -2F, -10F, 18F, 23F, 21F).mirror(false)
                .texOffs(292, 224).mirror().addBox(-10F, -6F, -12F, 21F, 9F, 23F).mirror(false),
                PartPose.offsetAndRotation(24F, -22F, 25F, 0F, 0F, -0.12F));
        PartDefinition p_shin_bl = p_leg_bl.addOrReplaceChild("shin_bl", CubeListBuilder.create()
                .texOffs(72, 224).mirror().addBox(-7F, 0F, -7F, 14F, 21F, 14F).mirror(false)
                .texOffs(402, 260).mirror().addBox(-6F, 2F, -9F, 12F, 12F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_bl = p_shin_bl.addOrReplaceChild("foot_bl", CubeListBuilder.create()
                .texOffs(200, 224).mirror().addBox(-10F, 0F, -15F, 21F, 7F, 25F).mirror(false)
                .texOffs(94, 283).mirror().addBox(-9F, 3F, -16F, 18F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(128, 224).addBox(-9F, -15F, -14F, 18F, 16F, 18F)
                .texOffs(240, 260).addBox(-7F, -9F, -22F, 14F, 9F, 9F)
                .texOffs(154, 283).addBox(-7F, -12F, -15F, 3F, 2F, 1F)
                .texOffs(154, 283).addBox(3F, -12F, -15F, 3F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -19F, -37F, 0F, 0F, 0F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(286, 260).addBox(-6F, 0F, -14F, 12F, 3F, 14F)
                .texOffs(132, 283).addBox(-5F, -1F, -14F, 9F, 1F, 2F),
                PartPose.offsetAndRotation(0F, 1F, -9F, 0F, 0F, 0F));
        PartDefinition p_xhorn_r = p_head.addOrReplaceChild("xhorn_r", CubeListBuilder.create()
                .texOffs(430, 260).addBox(-1F, -1F, 0F, 2F, 2F, 12F),
                PartPose.offsetAndRotation(-8F, -14F, 2F, 0.5F, -0.6F, 0F));
        PartDefinition p_xhorn_l = p_head.addOrReplaceChild("xhorn_l", CubeListBuilder.create()
                .texOffs(430, 260).mirror().addBox(-1F, -1F, 0F, 2F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(8F, -14F, 2F, 0.5F, 0.6F, 0F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(380, 224).addBox(-10F, -7F, -12F, 21F, 7F, 23F)
                .texOffs(102, 260).addBox(-8F, -8F, -9F, 16F, 1F, 18F),
                PartPose.offsetAndRotation(0F, -34F, -5F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon = p_turret.addOrReplaceChild("turret_cannon", CubeListBuilder.create()
                .texOffs(286, 171).addBox(-8F, -8F, -23F, 16F, 16F, 28F)
                .texOffs(170, 260).addBox(-6F, -9F, -18F, 12F, 1F, 18F)
                .texOffs(468, 224).addBox(8F, -5F, -18F, 1F, 9F, 18F),
                PartPose.offsetAndRotation(0F, -8F, -5F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon_barrel = p_turret_cannon.addOrReplaceChild("turret_cannon_barrel", CubeListBuilder.create()
                .texOffs(0, 224).addBox(-4F, -4F, -28F, 8F, 8F, 28F)
                .texOffs(62, 260).addBox(-6F, -6F, -32F, 13F, 13F, 7F),
                PartPose.offsetAndRotation(0F, 0F, -23F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon_flash = p_turret_cannon_barrel.addOrReplaceChild("turret_cannon_flash", CubeListBuilder.create()
                .texOffs(20, 260).addBox(-3F, -3F, -14F, 7F, 7F, 14F)
                .texOffs(56, 283).addBox(-8F, -1F, -4F, 16F, 2F, 3F)
                .texOffs(230, 260).addBox(-1F, -8F, -4F, 2F, 16F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -32F, 0F, 0F, 0F));
        PartDefinition p_coil_r = p_body.addOrReplaceChild("coil_r", CubeListBuilder.create()
                .texOffs(0, 260).addBox(-2F, -14F, -2F, 5F, 18F, 5F)
                .texOffs(458, 260).addBox(-5F, -6F, -5F, 9F, 2F, 9F)
                .texOffs(0, 283).addBox(-5F, -12F, -5F, 9F, 2F, 9F)
                .texOffs(458, 260).addBox(-5F, -17F, -5F, 9F, 2F, 9F)
                .texOffs(36, 283).addBox(-2F, -23F, -2F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(-12F, -28F, 39F, 0F, 0F, 0F));
        PartDefinition p_coil_l = p_body.addOrReplaceChild("coil_l", CubeListBuilder.create()
                .texOffs(0, 260).addBox(-2F, -14F, -2F, 5F, 18F, 5F)
                .texOffs(458, 260).addBox(-5F, -6F, -5F, 9F, 2F, 9F)
                .texOffs(0, 283).addBox(-5F, -12F, -5F, 9F, 2F, 9F)
                .texOffs(458, 260).addBox(-5F, -17F, -5F, 9F, 2F, 9F)
                .texOffs(36, 283).addBox(-2F, -23F, -2F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(12F, -28F, 39F, 0F, 0F, 0F));
        PartDefinition p_bspike0 = p_body.addOrReplaceChild("bspike0", CubeListBuilder.create()
                .texOffs(338, 260).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(0F, -34F, -18F, 0.5F, 0F, 0F));
        PartDefinition p_bspike1 = p_body.addOrReplaceChild("bspike1", CubeListBuilder.create()
                .texOffs(338, 260).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(0F, -34F, 0F, 0.5F, 0F, 0F));
        PartDefinition p_bspike2 = p_body.addOrReplaceChild("bspike2", CubeListBuilder.create()
                .texOffs(338, 260).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(0F, -34F, 18F, 0.5F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.3478F)
                .legLengths(9.2F, 10.35F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .jaw("body/head/jaw")
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null);
    }
}
