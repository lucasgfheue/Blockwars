package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Spore Mother (madreespora). */
@SuppressWarnings("unused")
public final class M_madreespora {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("madreespora"), "main");

    private M_madreespora() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 63).addBox(-19F, -19F, -25F, 38F, 19F, 34F),
                PartPose.offsetAndRotation(0F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_abdomen = p_body.addOrReplaceChild("abdomen", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-17F, -17F, 0F, 34F, 25F, 38F)
                .texOffs(68, 116).addBox(-13F, -18F, 4F, 25F, 1F, 29F)
                .texOffs(92, 170).addBox(-6F, -8F, 38F, 13F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -10F, 8F, -0.25F, 0F, 0F));
        PartDefinition p_hip_r0 = root.addOrReplaceChild("hip_r0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-19F, 8F, -21F, 0F, -0.5F, 0F));
        PartDefinition p_leg_r0 = p_hip_r0.addOrReplaceChild("leg_r0", CubeListBuilder.create()
                .texOffs(168, 63).addBox(-4F, 0F, -5F, 8F, 27F, 9F)
                .texOffs(72, 148).addBox(-5F, -1F, -6F, 10F, 6F, 12F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r0 = p_leg_r0.addOrReplaceChild("shin_r0", CubeListBuilder.create()
                .texOffs(144, 63).addBox(-3F, 0F, -3F, 6F, 40F, 6F)
                .texOffs(44, 148).addBox(-4F, 5F, -4F, 7F, 14F, 7F)
                .texOffs(120, 170).addBox(-2F, 37F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l0 = root.addOrReplaceChild("hip_l0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(19F, 8F, -21F, 0F, 0.5F, 0F));
        PartDefinition p_leg_l0 = p_hip_l0.addOrReplaceChild("leg_l0", CubeListBuilder.create()
                .texOffs(168, 63).mirror().addBox(-4F, 0F, -5F, 8F, 27F, 9F).mirror(false)
                .texOffs(72, 148).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l0 = p_leg_l0.addOrReplaceChild("shin_l0", CubeListBuilder.create()
                .texOffs(144, 63).mirror().addBox(-3F, 0F, -3F, 6F, 40F, 6F).mirror(false)
                .texOffs(44, 148).mirror().addBox(-4F, 5F, -4F, 7F, 14F, 7F).mirror(false)
                .texOffs(120, 170).mirror().addBox(-2F, 37F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r1 = root.addOrReplaceChild("hip_r1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-19F, 8F, -8F, 0F, 0F, 0F));
        PartDefinition p_leg_r1 = p_hip_r1.addOrReplaceChild("leg_r1", CubeListBuilder.create()
                .texOffs(168, 63).addBox(-4F, 0F, -5F, 8F, 27F, 9F)
                .texOffs(72, 148).addBox(-5F, -1F, -6F, 10F, 6F, 12F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r1 = p_leg_r1.addOrReplaceChild("shin_r1", CubeListBuilder.create()
                .texOffs(144, 63).addBox(-3F, 0F, -3F, 6F, 40F, 6F)
                .texOffs(44, 148).addBox(-4F, 5F, -4F, 7F, 14F, 7F)
                .texOffs(120, 170).addBox(-2F, 37F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l1 = root.addOrReplaceChild("hip_l1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(19F, 8F, -8F, 0F, 0F, 0F));
        PartDefinition p_leg_l1 = p_hip_l1.addOrReplaceChild("leg_l1", CubeListBuilder.create()
                .texOffs(168, 63).mirror().addBox(-4F, 0F, -5F, 8F, 27F, 9F).mirror(false)
                .texOffs(72, 148).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l1 = p_leg_l1.addOrReplaceChild("shin_l1", CubeListBuilder.create()
                .texOffs(144, 63).mirror().addBox(-3F, 0F, -3F, 6F, 40F, 6F).mirror(false)
                .texOffs(44, 148).mirror().addBox(-4F, 5F, -4F, 7F, 14F, 7F).mirror(false)
                .texOffs(120, 170).mirror().addBox(-2F, 37F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r2 = root.addOrReplaceChild("hip_r2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-19F, 8F, 4F, 0F, 0.5F, 0F));
        PartDefinition p_leg_r2 = p_hip_r2.addOrReplaceChild("leg_r2", CubeListBuilder.create()
                .texOffs(168, 63).addBox(-4F, 0F, -5F, 8F, 27F, 9F)
                .texOffs(72, 148).addBox(-5F, -1F, -6F, 10F, 6F, 12F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r2 = p_leg_r2.addOrReplaceChild("shin_r2", CubeListBuilder.create()
                .texOffs(144, 63).addBox(-3F, 0F, -3F, 6F, 40F, 6F)
                .texOffs(44, 148).addBox(-4F, 5F, -4F, 7F, 14F, 7F)
                .texOffs(120, 170).addBox(-2F, 37F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l2 = root.addOrReplaceChild("hip_l2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(19F, 8F, 4F, 0F, -0.5F, 0F));
        PartDefinition p_leg_l2 = p_hip_l2.addOrReplaceChild("leg_l2", CubeListBuilder.create()
                .texOffs(168, 63).mirror().addBox(-4F, 0F, -5F, 8F, 27F, 9F).mirror(false)
                .texOffs(72, 148).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l2 = p_leg_l2.addOrReplaceChild("shin_l2", CubeListBuilder.create()
                .texOffs(144, 63).mirror().addBox(-3F, 0F, -3F, 6F, 40F, 6F).mirror(false)
                .texOffs(44, 148).mirror().addBox(-4F, 5F, -4F, 7F, 14F, 7F).mirror(false)
                .texOffs(120, 170).mirror().addBox(-2F, 37F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 116).addBox(-8F, -14F, -13F, 17F, 15F, 17F)
                .texOffs(178, 148).addBox(-6F, -8F, -20F, 13F, 8F, 8F)
                .texOffs(164, 170).addBox(-6F, -10F, -13F, 3F, 2F, 1F)
                .texOffs(164, 170).addBox(3F, -10F, -13F, 3F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -10F, -25F, 0F, 0F, 0F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(132, 148).addBox(-5F, 0F, -13F, 10F, 3F, 13F)
                .texOffs(144, 170).addBox(-4F, -1F, -13F, 8F, 1F, 2F),
                PartPose.offsetAndRotation(0F, 1F, -8F, 0F, 0F, 0F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(176, 116).addBox(-9F, -6F, -9F, 19F, 6F, 19F),
                PartPose.offsetAndRotation(0F, -21F, -2F, 0F, 0F, 0F));
        PartDefinition p_turret_emitter = p_turret.addOrReplaceChild("turret_emitter", CubeListBuilder.create()
                .texOffs(0, 148).addBox(-5F, -5F, -10F, 9F, 9F, 13F)
                .texOffs(0, 170).addBox(-1F, 4F, -18F, 2F, 2F, 10F)
                .texOffs(0, 170).addBox(-6F, -4F, -18F, 2F, 2F, 10F)
                .texOffs(0, 170).addBox(3F, -4F, -18F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, -8F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_emitter_orb = p_turret_emitter.addOrReplaceChild("turret_emitter_orb", CubeListBuilder.create()
                .texOffs(24, 170).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(64, 170).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -16F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_spine0 = p_body.addOrReplaceChild("spine0", CubeListBuilder.create()
                .texOffs(116, 148).addBox(-2F, -13F, 0F, 4F, 13F, 4F)
                .texOffs(136, 170).addBox(-1F, -14F, 1F, 2F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -21F, 19F, 0.6F, 0F, 0F));
        PartDefinition p_spine1 = p_body.addOrReplaceChild("spine1", CubeListBuilder.create()
                .texOffs(220, 148).addBox(-2F, -11F, 0F, 4F, 10F, 4F)
                .texOffs(136, 170).addBox(-1F, -13F, 1F, 2F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -13F, 19F, 0.7F, 0F, 0F));
        PartDefinition p_spine2 = p_body.addOrReplaceChild("spine2", CubeListBuilder.create()
                .texOffs(48, 170).addBox(-2F, -9F, 0F, 4F, 8F, 4F)
                .texOffs(136, 170).addBox(-1F, -12F, 1F, 2F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -4F, 19F, 0.8F, 0F, 0F));
        PartDefinition p_spine3 = p_body.addOrReplaceChild("spine3", CubeListBuilder.create()
                .texOffs(76, 170).addBox(-2F, -8F, 0F, 4F, 6F, 4F)
                .texOffs(136, 170).addBox(-1F, -10F, 1F, 2F, 3F, 2F),
                PartPose.offsetAndRotation(0F, 4F, 19F, 0.9F, 0F, 0F));
        PartDefinition p_bspike0 = p_body.addOrReplaceChild("bspike0", CubeListBuilder.create()
                .texOffs(236, 148).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -21F, -13F, 0.5F, 0F, 0F));
        PartDefinition p_bspike1 = p_body.addOrReplaceChild("bspike1", CubeListBuilder.create()
                .texOffs(236, 148).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -21F, 0F, 0.5F, 0F, 0F));
        PartDefinition p_bspike2 = p_body.addOrReplaceChild("bspike2", CubeListBuilder.create()
                .texOffs(236, 148).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -21F, 13F, 0.5F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4762F)
                .legLengths(13.65F, 19.95F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .spin("body/turret/turret_emitter/turret_emitter_orb", 2, 0.25F, 0)
                .sway("body/abdomen", 0, 0.04F, 0F)
                .sway("body/spine0", 0, 0.05F, 0F)
                .sway("body/spine1", 0, 0.05F, 0.7F)
                .sway("body/spine2", 0, 0.05F, 1.4F)
                .sway("body/spine3", 0, 0.05F, 2.1F)
                .jaw("body/head/jaw")
                .primary(Rig.MountKind.TURRET, "body/turret", null, null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", null, null, null);
    }
}
