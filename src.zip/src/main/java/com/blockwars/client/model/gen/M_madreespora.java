package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Spore Mother (madreespora). */
@SuppressWarnings("unused")
public final class M_madreespora {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("madreespora"), "main");

    private M_madreespora() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "body,-1,0,8,0,0,0,0/0,63,-19,-19,-25,38,19,34;abdomen,0,0,-10,8,-0.25,0,0/0,0,-17,-17,0,34,25,38/68,116,-13,-18,4,25,1,29/"
                + "92,170,-6,-8,38,13,8,1;hip_r0,-1,-19,8,-21,0,-0.5,0;leg_r0,2,0,-8,0,0,0,2.15/168,63,-4,0,-5,8,27,9/72,148,-5,-1,-6,10,6,12;"
                + "shin_r0,3,0,27,0,0,0,-1.75/144,63,-3,0,-3,6,40,6/44,148,-4,5,-4,7,14,7/120,170,-2,37,-2,4,4,4;hip_l0,-1,19,8,-21,0,0.5,0;"
                + "leg_l0,5,0,-8,0,0,0,-2.15/!168,63,-4,0,-5,8,27,9/!72,148,-5,-1,-6,10,6,12;shin_l0,6,0,27,0,0,0,1.75/!144,63,-3,0,-3,6,40,6/"
                + "!44,148,-4,5,-4,7,14,7/!120,170,-2,37,-2,4,4,4;hip_r1,-1,-19,8,-8,0,0,0;leg_r1,8,0,-8,0,0,0,2.15/168,63,-4,0,-5,8,27,9/"
                + "72,148,-5,-1,-6,10,6,12;shin_r1,9,0,27,0,0,0,-1.75/144,63,-3,0,-3,6,40,6/44,148,-4,5,-4,7,14,7/120,170,-2,37,-2,4,4,4;"
                + "hip_l1,-1,19,8,-8,0,0,0;leg_l1,11,0,-8,0,0,0,-2.15/!168,63,-4,0,-5,8,27,9/!72,148,-5,-1,-6,10,6,12;shin_l1,12,0,27,0,0,0,1.75/"
                + "!144,63,-3,0,-3,6,40,6/!44,148,-4,5,-4,7,14,7/!120,170,-2,37,-2,4,4,4;hip_r2,-1,-19,8,4,0,0.5,0;leg_r2,14,0,-8,0,0,0,2.15/"
                + "168,63,-4,0,-5,8,27,9/72,148,-5,-1,-6,10,6,12;shin_r2,15,0,27,0,0,0,-1.75/144,63,-3,0,-3,6,40,6/44,148,-4,5,-4,7,14,7/"
                + "120,170,-2,37,-2,4,4,4;hip_l2,-1,19,8,4,0,-0.5,0;leg_l2,17,0,-8,0,0,0,-2.15/!168,63,-4,0,-5,8,27,9/!72,148,-5,-1,-6,10,6,12;"
                + "shin_l2,18,0,27,0,0,0,1.75/!144,63,-3,0,-3,6,40,6/!44,148,-4,5,-4,7,14,7/!120,170,-2,37,-2,4,4,4;head,0,0,-10,-25,0,0,0/"
                + "0,116,-8,-14,-13,17,15,17/178,148,-6,-8,-20,13,8,8/164,170,-6,-10,-13,3,2,1/164,170,3,-10,-13,3,2,1;jaw,20,0,1,-8,0,0,0/"
                + "132,148,-5,0,-13,10,3,13/144,170,-4,-1,-13,8,1,2;turret,0,0,-21,-2,0,0,0/176,116,-9,-6,-9,19,6,19;turret_emitter,22,0,-8,-4,0,0,0/"
                + "0,148,-5,-5,-10,9,9,13/0,170,-1,4,-18,2,2,10/0,170,-6,-4,-18,2,2,10/0,170,3,-4,-18,2,2,10;turret_emitter_orb,23,0,0,-16,0.7854,0.7854,0/"
                + "24,170,-3,-3,-3,6,6,6/64,170,-2,-4,-2,3,8,3;spine0,0,0,-21,19,0.6,0,0/116,148,-2,-13,0,4,13,4/136,170,-1,-14,1,2,3,2;"
                + "spine1,0,0,-13,19,0.7,0,0/220,148,-2,-11,0,4,10,4/136,170,-1,-13,1,2,3,2;spine2,0,0,-4,19,0.8,0,0/48,170,-2,-9,0,4,8,4/"
                + "136,170,-1,-12,1,2,3,2;spine3,0,0,4,19,0.9,0,0/76,170,-2,-8,0,4,6,4/136,170,-1,-10,1,2,3,2;bspike0,0,0,-21,-13,0.5,0,0/"
                + "236,148,-2,-10,-2,3,10,3;bspike1,0,0,-21,0,0.5,0,0/236,148,-2,-10,-2,3,10,3;bspike2,0,0,-21,13,0.5,0,0/"
                + "236,148,-2,-10,-2,3,10,3");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4762F)
                .legLengths(13.65F, 19.95F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .spin("body/turret/turret_emitter/turret_emitter_orb", 2, 0.25F, 0)
                .sway("body/abdomen", 0, 0.04F, 0F)
                .sway("body/spine0", 0, 0.05F, 0F)
                .sway("body/spine1", 0, 0.05F, 0.7F)
                .sway("body/spine2", 0, 0.05F, 1.4F)
                .sway("body/spine3", 0, 0.05F, 2.1F)
                .jaw("body/head/jaw")
                .primary(Rig.MountKind.TURRET, "body/turret", null, null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", null, null, null);
    }
}
