package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Cinder (ceniza). */
@SuppressWarnings("unused")
public final class M_ceniza {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("ceniza"), "main");

    private M_ceniza() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "body,-1,0,-11,0,0,0,0/0,0,-16,-25,-27,32,25,54/0,79,-13,-27,-23,26,3,46/40,191,-13,-14,-28,26,4,1/186,176,-10,-18,27,19,10,1;"
                + "leg_fr,-1,-19,-11,-20,0,0,0.12/144,79,-7,-2,-8,14,18,16/72,128,-8,-4,-9,16,7,18;shin_fr,1,0,14,0,0,0,-0.12/"
                + "204,79,-5,0,-5,11,16,11/152,176,-4,2,-7,9,10,2;foot_fr,2,0,16,0,0,0,0/0,128,-8,0,-12,16,5,20/110,191,-7,2,-13,14,3,1;"
                + "leg_fl,-1,19,-11,-20,0,0,-0.12/!144,79,-7,-2,-8,14,18,16/!72,128,-8,-4,-9,16,7,18;shin_fl,4,0,14,0,0,0,0.12/"
                + "!204,79,-5,0,-5,11,16,11/!152,176,-4,2,-7,9,10,2;foot_fl,5,0,16,0,0,0,0/!0,128,-8,0,-12,16,5,20/!110,191,-7,2,-13,14,3,1;"
                + "leg_br,-1,-19,-11,20,0,0,0.12/144,79,-7,-2,-8,14,18,16/72,128,-8,-4,-9,16,7,18;shin_br,7,0,14,0,0,0,-0.12/"
                + "204,79,-5,0,-5,11,16,11/152,176,-4,2,-7,9,10,2;foot_br,8,0,16,0,0,0,0/0,128,-8,0,-12,16,5,20/110,191,-7,2,-13,14,3,1;"
                + "leg_bl,-1,19,-11,20,0,0,-0.12/!144,79,-7,-2,-8,14,18,16/!72,128,-8,-4,-9,16,7,18;shin_bl,10,0,14,0,0,0,0.12/"
                + "!204,79,-5,0,-5,11,16,11/!152,176,-4,2,-7,9,10,2;foot_bl,11,0,16,0,0,0,0/!0,128,-8,0,-12,16,5,20/!110,191,-7,2,-13,14,3,1;"
                + "head,0,0,-15,-29,0,0,0/140,128,-5,-11,-8,11,11,13/170,153,-4,-6,-18,7,5,11/148,191,-4,-8,-9,2,2,1/148,191,3,-8,-9,2,2,1;"
                + "ear_r,13,-4,-11,2,0.5,0,-0.3/226,176,-1,-7,-2,3,7,4;ear_l,13,4,-11,2,0.5,0,0.3/!226,176,-1,-7,-2,3,7,4;"
                + "jaw,13,0,0,-5,0,0,0/84,176,-3,0,-11,6,2,11;turret,0,0,-27,-4,0,0,0/188,128,-8,-5,-9,16,5,18/0,176,-6,-6,-7,13,1,14;"
                + "turret_flamer,17,0,-7,-4,0,0,0/0,153,-4,-4,-14,7,7,16/206,153,-3,4,-5,5,5,11/118,176,-3,5,-6,6,2,11;turret_flamer_barrel,18,0,-1,-14,0,0,0/"
                + "54,176,-2,-2,-11,4,4,11/24,191,-3,-3,-13,5,5,3/140,191,-1,2,-13,2,1,2;stack_r,0,-10,-22,31,-0.15,0,0.1/"
                + "46,153,-3,-15,-3,5,16,5/0,191,-3,-17,-3,6,2,6/94,191,-2,-17,-2,4,1,4;stack_l,0,10,-22,31,-0.15,0,-0.1/"
                + "46,153,-3,-15,-3,5,16,5/0,191,-3,-17,-3,6,2,6/94,191,-2,-17,-2,4,1,4;tail0,0,0,-15,27,0.5,0,0/66,153,-3,-3,-1,5,5,13;"
                + "tail1,22,0,0,12,0.2,0,0/102,153,-2,-2,-1,4,4,13;tail2,23,0,0,12,0.2,0,0/136,153,-2,-2,-1,4,4,13;bspike0,0,0,-27,-14,0.5,0,0/"
                + "174,176,-1,-9,-1,3,9,3;bspike1,0,0,-27,0,0.5,0,0/174,176,-1,-9,-1,3,9,3;bspike2,0,0,-27,14,0.5,0,0/174,176,-1,-9,-1,3,9,3");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.4444F)
                .legLengths(7.2F, 8.1F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .sway("body/head/ear_r", 0, 0.08F, -0.3F)
                .sway("body/head/ear_l", 0, 0.08F, 0.3F)
                .sway("body/tail0", 1, 0.12F, 0F)
                .sway("body/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("body/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .jaw("body/head/jaw")
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_flamer/turret_flamer_barrel", null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_flamer/turret_flamer_barrel", null, null);
    }
}
