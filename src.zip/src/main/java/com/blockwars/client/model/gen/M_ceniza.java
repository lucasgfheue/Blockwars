package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Cinder (ceniza). */
@SuppressWarnings("unused")
public final class M_ceniza {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("ceniza"), "main");

    private M_ceniza() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-16F, -25F, -27F, 32F, 25F, 54F)
                .texOffs(0, 79).addBox(-13F, -27F, -23F, 26F, 3F, 46F)
                .texOffs(40, 191).addBox(-13F, -14F, -28F, 26F, 4F, 1F)
                .texOffs(186, 176).addBox(-10F, -18F, 27F, 19F, 10F, 1F),
                PartPose.offsetAndRotation(0F, -11F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create()
                .texOffs(144, 79).addBox(-7F, -2F, -8F, 14F, 18F, 16F)
                .texOffs(72, 128).addBox(-8F, -4F, -9F, 16F, 7F, 18F),
                PartPose.offsetAndRotation(-19F, -11F, -20F, 0F, 0F, 0.12F));
        PartDefinition p_shin_fr = p_leg_fr.addOrReplaceChild("shin_fr", CubeListBuilder.create()
                .texOffs(204, 79).addBox(-5F, 0F, -5F, 11F, 16F, 11F)
                .texOffs(152, 176).addBox(-4F, 2F, -7F, 9F, 10F, 2F),
                PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_fr = p_shin_fr.addOrReplaceChild("foot_fr", CubeListBuilder.create()
                .texOffs(0, 128).addBox(-8F, 0F, -12F, 16F, 5F, 20F)
                .texOffs(110, 191).addBox(-7F, 2F, -13F, 14F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 16F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create()
                .texOffs(144, 79).mirror().addBox(-7F, -2F, -8F, 14F, 18F, 16F).mirror(false)
                .texOffs(72, 128).mirror().addBox(-8F, -4F, -9F, 16F, 7F, 18F).mirror(false),
                PartPose.offsetAndRotation(19F, -11F, -20F, 0F, 0F, -0.12F));
        PartDefinition p_shin_fl = p_leg_fl.addOrReplaceChild("shin_fl", CubeListBuilder.create()
                .texOffs(204, 79).mirror().addBox(-5F, 0F, -5F, 11F, 16F, 11F).mirror(false)
                .texOffs(152, 176).mirror().addBox(-4F, 2F, -7F, 9F, 10F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_fl = p_shin_fl.addOrReplaceChild("foot_fl", CubeListBuilder.create()
                .texOffs(0, 128).mirror().addBox(-8F, 0F, -12F, 16F, 5F, 20F).mirror(false)
                .texOffs(110, 191).mirror().addBox(-7F, 2F, -13F, 14F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 16F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create()
                .texOffs(144, 79).addBox(-7F, -2F, -8F, 14F, 18F, 16F)
                .texOffs(72, 128).addBox(-8F, -4F, -9F, 16F, 7F, 18F),
                PartPose.offsetAndRotation(-19F, -11F, 20F, 0F, 0F, 0.12F));
        PartDefinition p_shin_br = p_leg_br.addOrReplaceChild("shin_br", CubeListBuilder.create()
                .texOffs(204, 79).addBox(-5F, 0F, -5F, 11F, 16F, 11F)
                .texOffs(152, 176).addBox(-4F, 2F, -7F, 9F, 10F, 2F),
                PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_br = p_shin_br.addOrReplaceChild("foot_br", CubeListBuilder.create()
                .texOffs(0, 128).addBox(-8F, 0F, -12F, 16F, 5F, 20F)
                .texOffs(110, 191).addBox(-7F, 2F, -13F, 14F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 16F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create()
                .texOffs(144, 79).mirror().addBox(-7F, -2F, -8F, 14F, 18F, 16F).mirror(false)
                .texOffs(72, 128).mirror().addBox(-8F, -4F, -9F, 16F, 7F, 18F).mirror(false),
                PartPose.offsetAndRotation(19F, -11F, 20F, 0F, 0F, -0.12F));
        PartDefinition p_shin_bl = p_leg_bl.addOrReplaceChild("shin_bl", CubeListBuilder.create()
                .texOffs(204, 79).mirror().addBox(-5F, 0F, -5F, 11F, 16F, 11F).mirror(false)
                .texOffs(152, 176).mirror().addBox(-4F, 2F, -7F, 9F, 10F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_bl = p_shin_bl.addOrReplaceChild("foot_bl", CubeListBuilder.create()
                .texOffs(0, 128).mirror().addBox(-8F, 0F, -12F, 16F, 5F, 20F).mirror(false)
                .texOffs(110, 191).mirror().addBox(-7F, 2F, -13F, 14F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 16F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(140, 128).addBox(-5F, -11F, -8F, 11F, 11F, 13F)
                .texOffs(170, 153).addBox(-4F, -6F, -18F, 7F, 5F, 11F)
                .texOffs(148, 191).addBox(-4F, -8F, -9F, 2F, 2F, 1F)
                .texOffs(148, 191).addBox(3F, -8F, -9F, 2F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -15F, -29F, 0F, 0F, 0F));
        PartDefinition p_ear_r = p_head.addOrReplaceChild("ear_r", CubeListBuilder.create()
                .texOffs(226, 176).addBox(-1F, -7F, -2F, 3F, 7F, 4F),
                PartPose.offsetAndRotation(-4F, -11F, 2F, 0.5F, 0F, -0.3F));
        PartDefinition p_ear_l = p_head.addOrReplaceChild("ear_l", CubeListBuilder.create()
                .texOffs(226, 176).mirror().addBox(-1F, -7F, -2F, 3F, 7F, 4F).mirror(false),
                PartPose.offsetAndRotation(4F, -11F, 2F, 0.5F, 0F, 0.3F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(84, 176).addBox(-3F, 0F, -11F, 6F, 2F, 11F),
                PartPose.offsetAndRotation(0F, 0F, -5F, 0F, 0F, 0F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(188, 128).addBox(-8F, -5F, -9F, 16F, 5F, 18F)
                .texOffs(0, 176).addBox(-6F, -6F, -7F, 13F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -27F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_flamer = p_turret.addOrReplaceChild("turret_flamer", CubeListBuilder.create()
                .texOffs(0, 153).addBox(-4F, -4F, -14F, 7F, 7F, 16F)
                .texOffs(206, 153).addBox(-3F, 4F, -5F, 5F, 5F, 11F)
                .texOffs(118, 176).addBox(-3F, 5F, -6F, 6F, 2F, 11F),
                PartPose.offsetAndRotation(0F, -7F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_flamer_barrel = p_turret_flamer.addOrReplaceChild("turret_flamer_barrel", CubeListBuilder.create()
                .texOffs(54, 176).addBox(-2F, -2F, -11F, 4F, 4F, 11F)
                .texOffs(24, 191).addBox(-3F, -3F, -13F, 5F, 5F, 3F)
                .texOffs(140, 191).addBox(-1F, 2F, -13F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -1F, -14F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_body.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(46, 153).addBox(-3F, -15F, -3F, 5F, 16F, 5F)
                .texOffs(0, 191).addBox(-3F, -17F, -3F, 6F, 2F, 6F)
                .texOffs(94, 191).addBox(-2F, -17F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-10F, -22F, 31F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_body.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(46, 153).addBox(-3F, -15F, -3F, 5F, 16F, 5F)
                .texOffs(0, 191).addBox(-3F, -17F, -3F, 6F, 2F, 6F)
                .texOffs(94, 191).addBox(-2F, -17F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(10F, -22F, 31F, -0.15F, 0F, -0.1F));
        PartDefinition p_tail0 = p_body.addOrReplaceChild("tail0", CubeListBuilder.create()
                .texOffs(66, 153).addBox(-3F, -3F, -1F, 5F, 5F, 13F),
                PartPose.offsetAndRotation(0F, -15F, 27F, 0.5F, 0F, 0F));
        PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create()
                .texOffs(102, 153).addBox(-2F, -2F, -1F, 4F, 4F, 13F),
                PartPose.offsetAndRotation(0F, 0F, 12F, 0.2F, 0F, 0F));
        PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create()
                .texOffs(136, 153).addBox(-2F, -2F, -1F, 4F, 4F, 13F),
                PartPose.offsetAndRotation(0F, 0F, 12F, 0.2F, 0F, 0F));
        PartDefinition p_bspike0 = p_body.addOrReplaceChild("bspike0", CubeListBuilder.create()
                .texOffs(174, 176).addBox(-1F, -9F, -1F, 3F, 9F, 3F),
                PartPose.offsetAndRotation(0F, -27F, -14F, 0.5F, 0F, 0F));
        PartDefinition p_bspike1 = p_body.addOrReplaceChild("bspike1", CubeListBuilder.create()
                .texOffs(174, 176).addBox(-1F, -9F, -1F, 3F, 9F, 3F),
                PartPose.offsetAndRotation(0F, -27F, 0F, 0.5F, 0F, 0F));
        PartDefinition p_bspike2 = p_body.addOrReplaceChild("bspike2", CubeListBuilder.create()
                .texOffs(174, 176).addBox(-1F, -9F, -1F, 3F, 9F, 3F),
                PartPose.offsetAndRotation(0F, -27F, 14F, 0.5F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.4444F)
                .legLengths(7.2F, 8.1F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .sway("body/head/ear_r", 0, 0.08F, -0.3F)
                .sway("body/head/ear_l", 0, 0.08F, 0.3F)
                .sway("body/tail0", 1, 0.12F, 0F)
                .sway("body/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("body/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .jaw("body/head/jaw")
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_flamer/turret_flamer_barrel", null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_flamer/turret_flamer_barrel", null, null);
    }
}
