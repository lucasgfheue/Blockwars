package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Colossus (coloso). */
@SuppressWarnings("unused")
public final class M_coloso {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("coloso"), "main");

    private M_coloso() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 160).addBox(-21F, -7F, -11F, 42F, 14F, 22F)
                .texOffs(0, 196).addBox(-22F, -6F, -13F, 45F, 7F, 25F)
                .texOffs(120, 251).addBox(-4F, -3F, -14F, 8F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -43F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt0 = p_hips.addOrReplaceChild("skirt0", CubeListBuilder.create()
                .texOffs(80, 228).addBox(-18F, 0F, -1F, 36F, 20F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -13F, -0.15F, 0F, 0F));
        PartDefinition p_skirt1 = p_hips.addOrReplaceChild("skirt1", CubeListBuilder.create()
                .texOffs(80, 228).addBox(-18F, 0F, -1F, 36F, 20F, 3F),
                PartPose.offsetAndRotation(0F, 0F, 13F, 0.15F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(188, 70).addBox(-10F, 0F, -10F, 20F, 27F, 20F)
                .texOffs(378, 196).addBox(-11F, 3F, -14F, 22F, 19F, 6F)
                .texOffs(128, 160).addBox(-11F, 3F, -10F, 3F, 16F, 20F),
                PartPose.offsetAndRotation(-18F, -43F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(0, 70).addBox(-11F, 0F, -11F, 22F, 28F, 22F)
                .texOffs(450, 228).addBox(-10F, -7F, -15F, 20F, 11F, 6F)
                .texOffs(408, 228).addBox(-8F, 8F, 11F, 17F, 14F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(274, 228).addBox(-7F, -1F, -7F, 14F, 6F, 14F)
                .texOffs(268, 70).addBox(-15F, 4F, -23F, 31F, 8F, 38F)
                .texOffs(220, 251).addBox(-14F, 7F, -24F, 28F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 28F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(188, 70).mirror().addBox(-10F, 0F, -10F, 20F, 27F, 20F).mirror(false)
                .texOffs(378, 196).mirror().addBox(-11F, 3F, -14F, 22F, 19F, 6F).mirror(false)
                .texOffs(128, 160).mirror().addBox(8F, 3F, -10F, 3F, 16F, 20F).mirror(false),
                PartPose.offsetAndRotation(18F, -43F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(0, 70).mirror().addBox(-11F, 0F, -11F, 22F, 28F, 22F).mirror(false)
                .texOffs(450, 228).mirror().addBox(-10F, -7F, -15F, 20F, 11F, 6F).mirror(false)
                .texOffs(408, 228).mirror().addBox(-8F, 8F, 11F, 17F, 14F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(274, 228).mirror().addBox(-7F, -1F, -7F, 14F, 6F, 14F).mirror(false)
                .texOffs(268, 70).mirror().addBox(-15F, 4F, -23F, 31F, 8F, 38F).mirror(false)
                .texOffs(220, 251).mirror().addBox(-14F, 7F, -24F, 28F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 28F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(288, 120).addBox(-18F, -14F, -12F, 35F, 14F, 24F)
                .texOffs(172, 0).addBox(-29F, -48F, -16F, 59F, 36F, 31F)
                .texOffs(0, 0).addBox(-24F, -45F, -20F, 47F, 31F, 39F)
                .texOffs(0, 120).addBox(-30F, -33F, -17F, 60F, 7F, 33F)
                .texOffs(302, 160).addBox(-21F, -50F, -14F, 41F, 6F, 27F),
                PartPose.offsetAndRotation(0F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 251).addBox(-6F, -3F, -6F, 11F, 3F, 11F)
                .texOffs(248, 196).addBox(-10F, -14F, -8F, 20F, 11F, 17F)
                .texOffs(84, 251).addBox(-8F, -13F, -9F, 17F, 8F, 1F)
                .texOffs(278, 251).addBox(-8F, -10F, -10F, 4F, 4F, 1F)
                .texOffs(278, 251).addBox(-2F, -10F, -10F, 4F, 4F, 1F)
                .texOffs(278, 251).addBox(4F, -10F, -10F, 4F, 4F, 1F)
                .texOffs(330, 228).addBox(-10F, -15F, -9F, 21F, 1F, 18F),
                PartPose.offsetAndRotation(0F, -50F, -3F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(298, 160).addBox(-1F, -34F, -1F, 1F, 34F, 1F)
                .texOffs(208, 251).addBox(-1F, -35F, -1F, 3F, 3F, 3F),
                PartPose.offsetAndRotation(7F, -17F, 6F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(322, 196).addBox(-7F, -7F, -7F, 14F, 14F, 14F)
                .texOffs(244, 120).addBox(-6F, 3F, -6F, 11F, 28F, 11F),
                PartPose.offsetAndRotation(-38F, -41F, 0F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r_pod = p_shoulder_r.addOrReplaceChild("shoulder_r_pod", CubeListBuilder.create()
                .texOffs(352, 0).addBox(-14F, -22F, -17F, 28F, 22F, 34F)
                .texOffs(174, 160).addBox(-14F, -24F, -17F, 28F, 1F, 34F)
                .texOffs(158, 228).addBox(-13F, -21F, -18F, 25F, 20F, 1F),
                PartPose.offsetAndRotation(-3F, -8F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(186, 120).addBox(-7F, 0F, -8F, 14F, 25F, 15F)
                .texOffs(210, 228).addBox(-8F, 24F, -8F, 15F, 3F, 17F),
                PartPose.offsetAndRotation(0F, 29F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_fist = p_forearm_r.addOrReplaceChild("forearm_r_fist", CubeListBuilder.create()
                .texOffs(88, 70).addBox(-13F, -1F, -13F, 25F, 22F, 25F)
                .texOffs(138, 251).addBox(-11F, 15F, -14F, 22F, 6F, 1F)
                .texOffs(140, 196).addBox(-13F, -2F, -13F, 27F, 4F, 27F)
                .texOffs(0, 228).addBox(-10F, 21F, -10F, 20F, 3F, 20F),
                PartPose.offsetAndRotation(0F, 29F, -3F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(322, 196).mirror().addBox(-7F, -7F, -7F, 14F, 14F, 14F).mirror(false)
                .texOffs(244, 120).mirror().addBox(-6F, 3F, -6F, 11F, 28F, 11F).mirror(false),
                PartPose.offsetAndRotation(38F, -41F, 0F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l_pod = p_shoulder_l.addOrReplaceChild("shoulder_l_pod", CubeListBuilder.create()
                .texOffs(352, 0).addBox(-14F, -22F, -17F, 28F, 22F, 34F)
                .texOffs(174, 160).addBox(-14F, -24F, -17F, 28F, 1F, 34F)
                .texOffs(158, 228).addBox(-13F, -21F, -18F, 25F, 20F, 1F),
                PartPose.offsetAndRotation(3F, -8F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(186, 120).mirror().addBox(-7F, 0F, -8F, 14F, 25F, 15F).mirror(false)
                .texOffs(210, 228).mirror().addBox(-8F, 24F, -8F, 15F, 3F, 17F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_fist = p_forearm_l.addOrReplaceChild("forearm_l_fist", CubeListBuilder.create()
                .texOffs(88, 70).addBox(-13F, -1F, -13F, 25F, 22F, 25F)
                .texOffs(138, 251).addBox(-11F, 15F, -14F, 22F, 6F, 1F)
                .texOffs(140, 196).addBox(-13F, -2F, -13F, 27F, 4F, 27F)
                .texOffs(0, 228).addBox(-10F, 21F, -10F, 20F, 3F, 20F),
                PartPose.offsetAndRotation(0F, 29F, -3F, 0F, 0F, 0F));
        PartDefinition p_torso_pod = p_torso.addOrReplaceChild("torso_pod", CubeListBuilder.create()
                .texOffs(352, 0).addBox(-14F, -22F, -17F, 28F, 22F, 34F)
                .texOffs(174, 160).addBox(-14F, -24F, -17F, 28F, 1F, 34F)
                .texOffs(158, 228).addBox(-13F, -21F, -18F, 25F, 20F, 1F),
                PartPose.offsetAndRotation(0F, -48F, 34F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(438, 160).addBox(-4F, -24F, -4F, 8F, 25F, 8F)
                .texOffs(44, 251).addBox(-5F, -26F, -5F, 10F, 3F, 10F)
                .texOffs(184, 251).addBox(-3F, -27F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(-18F, -45F, 25F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(438, 160).addBox(-4F, -24F, -4F, 8F, 25F, 8F)
                .texOffs(44, 251).addBox(-5F, -26F, -5F, 10F, 3F, 10F)
                .texOffs(184, 251).addBox(-3F, -27F, -3F, 6F, 1F, 6F),
                PartPose.offsetAndRotation(18F, -45F, 25F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2357F)
                .legLengths(13.3F, 14F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r/shoulder_r_pod", null, null, null);
    }
}
