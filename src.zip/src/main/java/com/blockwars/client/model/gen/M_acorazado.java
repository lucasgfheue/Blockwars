package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Dreadnought (acorazado). */
@SuppressWarnings("unused")
public final class M_acorazado {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("acorazado"), "main");

    private M_acorazado() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "body,-1,0,-30,0,0,0,0/0,0,-24,-38,-40,49,38,81/260,0,-19,-41,-34,39,4,69/240,235,-19,-22,-42,39,5,1/0,235,-15,-26,40,29,15,1;"
                + "leg_fr,-1,-28,-30,-30,0,0,0.12/102,119,-11,-3,-12,22,27,24/108,170,-12,-7,-14,24,11,27;shin_fr,1,0,22,0,0,0,-0.12/"
                + "370,119,-8,0,-8,16,24,16/408,208,-7,2,-11,14,15,3;foot_fr,2,0,24,0,0,0,0/0,170,-12,0,-18,24,8,30/352,235,-11,3,-19,22,4,1;"
                + "leg_fl,-1,28,-30,-30,0,0,-0.12/!102,119,-11,-3,-12,22,27,24/!108,170,-12,-7,-14,24,11,27;shin_fl,4,0,22,0,0,0,0.12/"
                + "!370,119,-8,0,-8,16,24,16/!408,208,-7,2,-11,14,15,3;foot_fl,5,0,24,0,0,0,0/!0,170,-12,0,-18,24,8,30/!352,235,-11,3,-19,22,4,1;"
                + "leg_br,-1,-28,-30,30,0,0,0.12/102,119,-11,-3,-12,22,27,24/108,170,-12,-7,-14,24,11,27;shin_br,7,0,22,0,0,0,-0.12/"
                + "370,119,-8,0,-8,16,24,16/408,208,-7,2,-11,14,15,3;foot_br,8,0,24,0,0,0,0/0,170,-12,0,-18,24,8,30/352,235,-11,3,-19,22,4,1;"
                + "leg_bl,-1,28,-30,30,0,0,-0.12/!102,119,-11,-3,-12,22,27,24/!108,170,-12,-7,-14,24,11,27;shin_bl,10,0,22,0,0,0,0.12/"
                + "!370,119,-8,0,-8,16,24,16/!408,208,-7,2,-11,14,15,3;foot_bl,11,0,24,0,0,0,0/!0,170,-12,0,-18,24,8,30/"
                + "!352,235,-11,3,-19,22,4,1;head,0,0,-23,-43,0,0,0/60,235,-5,-3,-5,11,3,11/0,208,-9,-14,-8,19,11,16/160,235,-8,-12,-9,16,8,1/"
                + "398,235,-7,-10,-10,4,4,1/398,235,-2,-10,-10,4,4,1/398,235,3,-10,-10,4,4,1/332,208,-10,-15,-9,20,1,18;"
                + "antenna,13,7,-16,5,-0.2,0,0.15/454,170,-1,-32,-1,1,32,1/340,235,-1,-34,-1,3,3,3;turret,0,0,-40,-5,0,0,0/"
                + "210,170,-12,-8,-14,24,8,27/118,208,-9,-9,-11,19,1,22;turret_cannon,15,0,-9,-5,0,0,0/0,119,-9,-9,-27,19,19,32/"
                + "200,208,-7,-11,-22,14,1,22/408,170,9,-5,-22,1,11,22;turret_cannon_barrel,16,0,0,-27,0,0,0/288,119,-5,-5,-32,9,9,32/"
                + "272,208,-7,-7,-38,15,15,8;turret_cannon_flash,17,0,0,-38,0,0,0/70,208,-4,-4,-16,8,8,16/194,235,-9,-1,-5,19,3,4/"
                + "318,208,-1,-9,-5,3,19,4;stack_r,0,-15,-32,46,-0.15,0,0.1/458,170,-4,-23,-4,8,24,8/104,235,-5,-25,-5,9,3,9/"
                + "320,235,-3,-26,-3,5,1,5;stack_l,0,15,-32,46,-0.15,0,-0.1/458,170,-4,-23,-4,8,24,8/104,235,-5,-25,-5,9,3,9/"
                + "320,235,-3,-26,-3,5,1,5;dish_mast,0,0,-38,49,0,0,0/380,170,-3,-27,-3,7,27,7;dish,21,0,-27,0,-0.6,0,0/"
                + "194,119,-22,-22,-2,43,43,4/312,170,-15,-15,-5,30,30,4/442,208,-1,-1,-15,3,3,14/140,235,-3,-3,-19,5,5,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.2963F)
                .legLengths(10.8F, 12.15F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .spin("body/dish_mast", 1, 0.02F, 0)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null);
    }
}
