package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Dreadnought (acorazado). */
@SuppressWarnings("unused")
public final class M_acorazado {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("acorazado"), "main");

    private M_acorazado() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-24F, -38F, -40F, 49F, 38F, 81F)
                .texOffs(260, 0).addBox(-19F, -41F, -34F, 39F, 4F, 69F)
                .texOffs(240, 235).addBox(-19F, -22F, -42F, 39F, 5F, 1F)
                .texOffs(0, 235).addBox(-15F, -26F, 40F, 29F, 15F, 1F),
                PartPose.offsetAndRotation(0F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create()
                .texOffs(102, 119).addBox(-11F, -3F, -12F, 22F, 27F, 24F)
                .texOffs(108, 170).addBox(-12F, -7F, -14F, 24F, 11F, 27F),
                PartPose.offsetAndRotation(-28F, -30F, -30F, 0F, 0F, 0.12F));
        PartDefinition p_shin_fr = p_leg_fr.addOrReplaceChild("shin_fr", CubeListBuilder.create()
                .texOffs(370, 119).addBox(-8F, 0F, -8F, 16F, 24F, 16F)
                .texOffs(408, 208).addBox(-7F, 2F, -11F, 14F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_fr = p_shin_fr.addOrReplaceChild("foot_fr", CubeListBuilder.create()
                .texOffs(0, 170).addBox(-12F, 0F, -18F, 24F, 8F, 30F)
                .texOffs(352, 235).addBox(-11F, 3F, -19F, 22F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create()
                .texOffs(102, 119).mirror().addBox(-11F, -3F, -12F, 22F, 27F, 24F).mirror(false)
                .texOffs(108, 170).mirror().addBox(-12F, -7F, -14F, 24F, 11F, 27F).mirror(false),
                PartPose.offsetAndRotation(28F, -30F, -30F, 0F, 0F, -0.12F));
        PartDefinition p_shin_fl = p_leg_fl.addOrReplaceChild("shin_fl", CubeListBuilder.create()
                .texOffs(370, 119).mirror().addBox(-8F, 0F, -8F, 16F, 24F, 16F).mirror(false)
                .texOffs(408, 208).mirror().addBox(-7F, 2F, -11F, 14F, 15F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_fl = p_shin_fl.addOrReplaceChild("foot_fl", CubeListBuilder.create()
                .texOffs(0, 170).mirror().addBox(-12F, 0F, -18F, 24F, 8F, 30F).mirror(false)
                .texOffs(352, 235).mirror().addBox(-11F, 3F, -19F, 22F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create()
                .texOffs(102, 119).addBox(-11F, -3F, -12F, 22F, 27F, 24F)
                .texOffs(108, 170).addBox(-12F, -7F, -14F, 24F, 11F, 27F),
                PartPose.offsetAndRotation(-28F, -30F, 30F, 0F, 0F, 0.12F));
        PartDefinition p_shin_br = p_leg_br.addOrReplaceChild("shin_br", CubeListBuilder.create()
                .texOffs(370, 119).addBox(-8F, 0F, -8F, 16F, 24F, 16F)
                .texOffs(408, 208).addBox(-7F, 2F, -11F, 14F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_br = p_shin_br.addOrReplaceChild("foot_br", CubeListBuilder.create()
                .texOffs(0, 170).addBox(-12F, 0F, -18F, 24F, 8F, 30F)
                .texOffs(352, 235).addBox(-11F, 3F, -19F, 22F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create()
                .texOffs(102, 119).mirror().addBox(-11F, -3F, -12F, 22F, 27F, 24F).mirror(false)
                .texOffs(108, 170).mirror().addBox(-12F, -7F, -14F, 24F, 11F, 27F).mirror(false),
                PartPose.offsetAndRotation(28F, -30F, 30F, 0F, 0F, -0.12F));
        PartDefinition p_shin_bl = p_leg_bl.addOrReplaceChild("shin_bl", CubeListBuilder.create()
                .texOffs(370, 119).mirror().addBox(-8F, 0F, -8F, 16F, 24F, 16F).mirror(false)
                .texOffs(408, 208).mirror().addBox(-7F, 2F, -11F, 14F, 15F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_bl = p_shin_bl.addOrReplaceChild("foot_bl", CubeListBuilder.create()
                .texOffs(0, 170).mirror().addBox(-12F, 0F, -18F, 24F, 8F, 30F).mirror(false)
                .texOffs(352, 235).mirror().addBox(-11F, 3F, -19F, 22F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(60, 235).addBox(-5F, -3F, -5F, 11F, 3F, 11F)
                .texOffs(0, 208).addBox(-9F, -14F, -8F, 19F, 11F, 16F)
                .texOffs(160, 235).addBox(-8F, -12F, -9F, 16F, 8F, 1F)
                .texOffs(398, 235).addBox(-7F, -10F, -10F, 4F, 4F, 1F)
                .texOffs(398, 235).addBox(-2F, -10F, -10F, 4F, 4F, 1F)
                .texOffs(398, 235).addBox(3F, -10F, -10F, 4F, 4F, 1F)
                .texOffs(332, 208).addBox(-10F, -15F, -9F, 20F, 1F, 18F),
                PartPose.offsetAndRotation(0F, -23F, -43F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(454, 170).addBox(-1F, -32F, -1F, 1F, 32F, 1F)
                .texOffs(340, 235).addBox(-1F, -34F, -1F, 3F, 3F, 3F),
                PartPose.offsetAndRotation(7F, -16F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(210, 170).addBox(-12F, -8F, -14F, 24F, 8F, 27F)
                .texOffs(118, 208).addBox(-9F, -9F, -11F, 19F, 1F, 22F),
                PartPose.offsetAndRotation(0F, -40F, -5F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon = p_turret.addOrReplaceChild("turret_cannon", CubeListBuilder.create()
                .texOffs(0, 119).addBox(-9F, -9F, -27F, 19F, 19F, 32F)
                .texOffs(200, 208).addBox(-7F, -11F, -22F, 14F, 1F, 22F)
                .texOffs(408, 170).addBox(9F, -5F, -22F, 1F, 11F, 22F),
                PartPose.offsetAndRotation(0F, -9F, -5F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon_barrel = p_turret_cannon.addOrReplaceChild("turret_cannon_barrel", CubeListBuilder.create()
                .texOffs(288, 119).addBox(-5F, -5F, -32F, 9F, 9F, 32F)
                .texOffs(272, 208).addBox(-7F, -7F, -38F, 15F, 15F, 8F),
                PartPose.offsetAndRotation(0F, 0F, -27F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon_flash = p_turret_cannon_barrel.addOrReplaceChild("turret_cannon_flash", CubeListBuilder.create()
                .texOffs(70, 208).addBox(-4F, -4F, -16F, 8F, 8F, 16F)
                .texOffs(194, 235).addBox(-9F, -1F, -5F, 19F, 3F, 4F)
                .texOffs(318, 208).addBox(-1F, -9F, -5F, 3F, 19F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -38F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_body.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(458, 170).addBox(-4F, -23F, -4F, 8F, 24F, 8F)
                .texOffs(104, 235).addBox(-5F, -25F, -5F, 9F, 3F, 9F)
                .texOffs(320, 235).addBox(-3F, -26F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(-15F, -32F, 46F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_body.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(458, 170).addBox(-4F, -23F, -4F, 8F, 24F, 8F)
                .texOffs(104, 235).addBox(-5F, -25F, -5F, 9F, 3F, 9F)
                .texOffs(320, 235).addBox(-3F, -26F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(15F, -32F, 46F, -0.15F, 0F, -0.1F));
        PartDefinition p_dish_mast = p_body.addOrReplaceChild("dish_mast", CubeListBuilder.create()
                .texOffs(380, 170).addBox(-3F, -27F, -3F, 7F, 27F, 7F),
                PartPose.offsetAndRotation(0F, -38F, 49F, 0F, 0F, 0F));
        PartDefinition p_dish = p_dish_mast.addOrReplaceChild("dish", CubeListBuilder.create()
                .texOffs(194, 119).addBox(-22F, -22F, -2F, 43F, 43F, 4F)
                .texOffs(312, 170).addBox(-15F, -15F, -5F, 30F, 30F, 4F)
                .texOffs(442, 208).addBox(-1F, -1F, -15F, 3F, 3F, 14F)
                .texOffs(140, 235).addBox(-3F, -3F, -19F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(0F, -27F, 0F, -0.6F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.2963F)
                .legLengths(10.8F, 12.15F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .spin("body/dish_mast", 1, 0.02F, 0)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null);
    }
}
