package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Siege Titan (titan). */
@SuppressWarnings("unused")
public final class M_titan {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("titan"), "main");

    private M_titan() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hull,-1,0,25,0,0,0,0/0,119,-46,-45,-39,92,19,78/196,311,-24,-49,-25,49,5,55/0,216,-24,-27,-37,49,22,73/"
                + "210,447,-43,-39,-40,86,8,1;tread_r,0,-35,-14,0,0,0,0/0,0,-11,-14,-46,22,27,92/228,0,-12,-20,-47,24,7,94;"
                + "wheel_r0,1,-11,3,-32,0,0,0/412,379,-1,-8,-8,1,16,16/196,447,-1,-3,-3,2,5,5;wheel_r1,1,-11,3,-11,0,0,0/"
                + "412,379,-1,-8,-8,1,16,16/196,447,-1,-3,-3,2,5,5;wheel_r2,1,-11,3,11,0,0,0/412,379,-1,-8,-8,1,16,16/196,447,-1,-3,-3,2,5,5;"
                + "wheel_r3,1,-11,3,32,0,0,0/412,379,-1,-8,-8,1,16,16/196,447,-1,-3,-3,2,5,5;tread_l,0,35,-14,0,0,0,0/!0,0,-11,-14,-46,22,27,92/"
                + "!228,0,-12,-20,-47,24,7,94;wheel_l0,6,11,3,-32,0,0,0/!412,379,-1,-8,-8,1,16,16/!196,447,-1,-3,-3,2,5,5;"
                + "wheel_l1,6,11,3,-11,0,0,0/!412,379,-1,-8,-8,1,16,16/!196,447,-1,-3,-3,2,5,5;wheel_l2,6,11,3,11,0,0,0/"
                + "!412,379,-1,-8,-8,1,16,16/!196,447,-1,-3,-3,2,5,5;wheel_l3,6,11,3,32,0,0,0/!412,379,-1,-8,-8,1,16,16/"
                + "!196,447,-1,-3,-3,2,5,5;turret,0,0,-46,5,0,0,0/0,311,-24,-19,-24,49,19,49/222,379,-19,-20,-14,38,1,32/"
                + "70,447,-16,-15,24,32,11,1;head,11,14,-19,8,0,0,0/0,447,-5,-3,-5,11,3,11/0,420,-9,-14,-8,19,11,16/384,447,-8,-12,-9,16,8,1/"
                + "496,447,-7,-10,-10,4,4,1/496,447,-2,-10,-10,4,4,1/496,447,3,-10,-10,4,4,1/436,420,-10,-15,-9,20,1,18;"
                + "antenna,12,7,-16,5,-0.2,0,0.15/408,379,-1,-32,-1,1,32,1/484,447,-1,-34,-1,3,3,3;turret_cannon,11,0,-7,-22,0,0,0/"
                + "404,311,-9,-9,-27,19,19,32/232,420,-7,-11,-22,14,1,22/362,379,9,-5,-22,1,11,22;turret_cannon_barrel,14,0,0,-27,0,0,0/"
                + "0,379,-5,-5,-32,9,9,32/304,420,-7,-7,-38,15,15,8;turret_cannon_flash,15,0,0,-38,0,0,0/184,420,-4,-4,-16,8,8,16/"
                + "418,447,-9,-1,-5,19,3,4/350,420,-1,-9,-5,3,19,4;turret_gun,11,16,-8,-22,0,0,0/146,379,-5,-6,-24,11,12,27/"
                + "124,420,-4,-9,-22,8,3,22/44,447,-3,5,-4,5,5,8;turret_gun_barrel,17,0,-1,-24,0,0,0/70,420,-3,-3,-22,5,5,22/"
                + "172,447,-4,-4,-24,8,8,4;turret_gun_flash,18,0,0,-24,0,0,0/184,420,-4,-4,-16,8,8,16/418,447,-9,-1,-5,19,3,4/"
                + "350,420,-1,-9,-5,3,19,4;stack_r,11,-15,-16,30,-0.15,0,0.1/446,379,-4,-23,-4,8,24,8/136,447,-5,-25,-5,9,3,9/"
                + "464,447,-3,-26,-3,5,1,5;stack_l,11,15,-16,30,-0.15,0,-0.1/446,379,-4,-23,-4,8,24,8/136,447,-5,-25,-5,9,3,9/"
                + "464,447,-3,-26,-3,5,1,5;drum,11,0,-5,32,0,0,1.5708/82,379,-8,-12,-8,16,24,16/364,420,-9,-1,-9,18,3,18;"
                + "skirt_r,0,-48,-24,0,0,0,0/244,216,-1,-8,-37,1,16,73;skirt_l,0,48,-24,0,0,0,0/!244,216,-1,-8,-37,1,16,73");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_cannon/turret_cannon_barrel", "hull/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
