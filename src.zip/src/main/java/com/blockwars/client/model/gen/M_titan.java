package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Siege Titan (titan). */
@SuppressWarnings("unused")
public final class M_titan {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("titan"), "main");

    private M_titan() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 119).addBox(-46F, -45F, -39F, 92F, 19F, 78F)
                .texOffs(196, 311).addBox(-24F, -49F, -25F, 49F, 5F, 55F)
                .texOffs(0, 216).addBox(-24F, -27F, -37F, 49F, 22F, 73F)
                .texOffs(210, 447).addBox(-43F, -39F, -40F, 86F, 8F, 1F),
                PartPose.offsetAndRotation(0F, 25F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-11F, -14F, -46F, 22F, 27F, 92F)
                .texOffs(228, 0).addBox(-12F, -20F, -47F, 24F, 7F, 94F),
                PartPose.offsetAndRotation(-35F, -14F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(412, 379).addBox(-1F, -8F, -8F, 1F, 16F, 16F)
                .texOffs(196, 447).addBox(-1F, -3F, -3F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-11F, 3F, -32F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(412, 379).addBox(-1F, -8F, -8F, 1F, 16F, 16F)
                .texOffs(196, 447).addBox(-1F, -3F, -3F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-11F, 3F, -11F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(412, 379).addBox(-1F, -8F, -8F, 1F, 16F, 16F)
                .texOffs(196, 447).addBox(-1F, -3F, -3F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-11F, 3F, 11F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(412, 379).addBox(-1F, -8F, -8F, 1F, 16F, 16F)
                .texOffs(196, 447).addBox(-1F, -3F, -3F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-11F, 3F, 32F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-11F, -14F, -46F, 22F, 27F, 92F).mirror(false)
                .texOffs(228, 0).mirror().addBox(-12F, -20F, -47F, 24F, 7F, 94F).mirror(false),
                PartPose.offsetAndRotation(35F, -14F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(412, 379).mirror().addBox(-1F, -8F, -8F, 1F, 16F, 16F).mirror(false)
                .texOffs(196, 447).mirror().addBox(-1F, -3F, -3F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(11F, 3F, -32F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(412, 379).mirror().addBox(-1F, -8F, -8F, 1F, 16F, 16F).mirror(false)
                .texOffs(196, 447).mirror().addBox(-1F, -3F, -3F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(11F, 3F, -11F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(412, 379).mirror().addBox(-1F, -8F, -8F, 1F, 16F, 16F).mirror(false)
                .texOffs(196, 447).mirror().addBox(-1F, -3F, -3F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(11F, 3F, 11F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(412, 379).mirror().addBox(-1F, -8F, -8F, 1F, 16F, 16F).mirror(false)
                .texOffs(196, 447).mirror().addBox(-1F, -3F, -3F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(11F, 3F, 32F, 0F, 0F, 0F));
        PartDefinition p_turret = p_hull.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(0, 311).addBox(-24F, -19F, -24F, 49F, 19F, 49F)
                .texOffs(222, 379).addBox(-19F, -20F, -14F, 38F, 1F, 32F)
                .texOffs(70, 447).addBox(-16F, -15F, 24F, 32F, 11F, 1F),
                PartPose.offsetAndRotation(0F, -46F, 5F, 0F, 0F, 0F));
        PartDefinition p_head = p_turret.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 447).addBox(-5F, -3F, -5F, 11F, 3F, 11F)
                .texOffs(0, 420).addBox(-9F, -14F, -8F, 19F, 11F, 16F)
                .texOffs(384, 447).addBox(-8F, -12F, -9F, 16F, 8F, 1F)
                .texOffs(496, 447).addBox(-7F, -10F, -10F, 4F, 4F, 1F)
                .texOffs(496, 447).addBox(-2F, -10F, -10F, 4F, 4F, 1F)
                .texOffs(496, 447).addBox(3F, -10F, -10F, 4F, 4F, 1F)
                .texOffs(436, 420).addBox(-10F, -15F, -9F, 20F, 1F, 18F),
                PartPose.offsetAndRotation(14F, -19F, 8F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(408, 379).addBox(-1F, -32F, -1F, 1F, 32F, 1F)
                .texOffs(484, 447).addBox(-1F, -34F, -1F, 3F, 3F, 3F),
                PartPose.offsetAndRotation(7F, -16F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret_cannon = p_turret.addOrReplaceChild("turret_cannon", CubeListBuilder.create()
                .texOffs(404, 311).addBox(-9F, -9F, -27F, 19F, 19F, 32F)
                .texOffs(232, 420).addBox(-7F, -11F, -22F, 14F, 1F, 22F)
                .texOffs(362, 379).addBox(9F, -5F, -22F, 1F, 11F, 22F),
                PartPose.offsetAndRotation(0F, -7F, -22F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon_barrel = p_turret_cannon.addOrReplaceChild("turret_cannon_barrel", CubeListBuilder.create()
                .texOffs(0, 379).addBox(-5F, -5F, -32F, 9F, 9F, 32F)
                .texOffs(304, 420).addBox(-7F, -7F, -38F, 15F, 15F, 8F),
                PartPose.offsetAndRotation(0F, 0F, -27F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon_flash = p_turret_cannon_barrel.addOrReplaceChild("turret_cannon_flash", CubeListBuilder.create()
                .texOffs(184, 420).addBox(-4F, -4F, -16F, 8F, 8F, 16F)
                .texOffs(418, 447).addBox(-9F, -1F, -5F, 19F, 3F, 4F)
                .texOffs(350, 420).addBox(-1F, -9F, -5F, 3F, 19F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -38F, 0F, 0F, 0F));
        PartDefinition p_turret_gun = p_turret.addOrReplaceChild("turret_gun", CubeListBuilder.create()
                .texOffs(146, 379).addBox(-5F, -6F, -24F, 11F, 12F, 27F)
                .texOffs(124, 420).addBox(-4F, -9F, -22F, 8F, 3F, 22F)
                .texOffs(44, 447).addBox(-3F, 5F, -4F, 5F, 5F, 8F),
                PartPose.offsetAndRotation(16F, -8F, -22F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_barrel = p_turret_gun.addOrReplaceChild("turret_gun_barrel", CubeListBuilder.create()
                .texOffs(70, 420).addBox(-3F, -3F, -22F, 5F, 5F, 22F)
                .texOffs(172, 447).addBox(-4F, -4F, -24F, 8F, 8F, 4F),
                PartPose.offsetAndRotation(0F, -1F, -24F, 0F, 0F, 0F));
        PartDefinition p_turret_gun_flash = p_turret_gun_barrel.addOrReplaceChild("turret_gun_flash", CubeListBuilder.create()
                .texOffs(184, 420).addBox(-4F, -4F, -16F, 8F, 8F, 16F)
                .texOffs(418, 447).addBox(-9F, -1F, -5F, 19F, 3F, 4F)
                .texOffs(350, 420).addBox(-1F, -9F, -5F, 3F, 19F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -24F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_turret.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(446, 379).addBox(-4F, -23F, -4F, 8F, 24F, 8F)
                .texOffs(136, 447).addBox(-5F, -25F, -5F, 9F, 3F, 9F)
                .texOffs(464, 447).addBox(-3F, -26F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(-15F, -16F, 30F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_turret.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(446, 379).addBox(-4F, -23F, -4F, 8F, 24F, 8F)
                .texOffs(136, 447).addBox(-5F, -25F, -5F, 9F, 3F, 9F)
                .texOffs(464, 447).addBox(-3F, -26F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(15F, -16F, 30F, -0.15F, 0F, -0.1F));
        PartDefinition p_drum = p_turret.addOrReplaceChild("drum", CubeListBuilder.create()
                .texOffs(82, 379).addBox(-8F, -12F, -8F, 16F, 24F, 16F)
                .texOffs(364, 420).addBox(-9F, -1F, -9F, 18F, 3F, 18F),
                PartPose.offsetAndRotation(0F, -5F, 32F, 0F, 0F, 1.5708F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(244, 216).addBox(-1F, -8F, -37F, 1F, 16F, 73F),
                PartPose.offsetAndRotation(-48F, -24F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(244, 216).mirror().addBox(-1F, -8F, -37F, 1F, 16F, 73F).mirror(false),
                PartPose.offsetAndRotation(48F, -24F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_cannon/turret_cannon_barrel", "hull/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_gun/turret_gun_barrel", "hull/turret/turret_gun/turret_gun_barrel/turret_gun_flash", null);
    }
}
