package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Patchwork (frankenstein). */
@SuppressWarnings("unused")
public final class M_frankenstein {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("frankenstein"), "main");

    private M_frankenstein() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-31,0,0,0,0/320,49,-17,-6,-9,34,12,18/60,87,-18,-5,-10,37,6,21/48,151,-3,-2,-12,7,7,1;thigh_r,-1,-15,-31,0,0,0,0/"
                + "0,49,-8,0,-8,16,22,16/0,115,-9,2,-12,18,15,5/424,49,-9,2,-8,2,13,16;shin_r,1,0,22,0,0,0,0/88,0,-9,0,-9,18,23,18/"
                + "422,135,-8,-6,-13,16,9,5/294,135,-7,7,9,14,12,3;foot_r,2,0,23,0,0,0,0/152,135,-6,-1,-6,11,5,11/394,0,-13,3,-19,25,7,32/"
                + "144,151,-12,6,-20,23,3,1;thigh_l,-1,15,-31,0,0,0,0/!0,49,-8,0,-8,16,22,16/!0,115,-9,2,-12,18,15,5/!424,49,7,2,-8,2,13,16;"
                + "shin_l,4,0,22,0,0,0,0/!88,0,-9,0,-9,18,23,18/!422,135,-8,-6,-13,16,9,5/!294,135,-7,7,9,14,12,3;foot_l,5,0,23,0,0,0,0/"
                + "!152,135,-6,-1,-6,11,5,11/!394,0,-13,3,-19,25,7,32/!144,151,-12,6,-20,23,3,1;torso,0,0,-6,0,0,0,0/292,49,-3,-25,-3,7,25,7/"
                + "238,115,-13,-14,-9,25,3,16/146,115,-15,-21,-9,30,3,16/46,115,-17,-28,-9,34,3,16/160,0,-23,-41,-12,46,17,23/"
                + "226,87,-10,-24,-5,21,14,10;tspike_r0,7,-21,-39,5,0.5,0,-0.5/358,135,-2,-12,-2,3,12,3;tspike_r1,7,-21,-39,12,0.5,0,-0.5/"
                + "358,135,-2,-12,-2,3,12,3;tspike_l0,7,21,-39,5,0.5,0,0.5/358,135,-2,-12,-2,3,12,3;tspike_l1,7,21,-39,12,0.5,0,0.5/"
                + "358,135,-2,-12,-2,3,12,3;head,7,0,-41,-2,0,0,0/464,135,-5,-5,-5,9,5,9/0,87,-7,-16,-7,14,12,16/28,151,-5,-15,-8,9,9,1/"
                + "94,151,-2,-13,-9,5,5,1/248,135,-5,-17,-6,9,1,14;antenna,12,6,-14,5,-0.2,0,0.15/460,49,-1,-28,-1,1,28,1/"
                + "192,151,-1,-29,-1,2,2,2;shoulder_r,7,-30,-33,0,0,0,0/288,87,-6,-6,-6,12,12,12/114,49,-12,-12,-10,18,12,21/"
                + "320,115,-10,-13,-9,16,1,18/256,49,-5,2,-5,9,23,9;sspike_r0,14,-5,-12,-5,0,0,-0.3/358,135,-2,-12,-2,3,12,3;"
                + "sspike_r4,14,-5,-12,5,0,0,-0.3/358,135,-2,-12,-2,3,12,3;forearm_r,14,0,24,0,-0.25,0,0/64,49,-6,0,-6,12,21,13/"
                + "0,135,-6,20,-7,13,2,14;forearm_r_crane,17,0,24,-2,-0.9,0,0/20,0,-3,0,-3,7,41,7/0,0,-2,-1,-2,5,44,5;forearm_r_crane_hook,18,0,41,0,0.9,0,0/"
                + "370,135,-1,0,-1,1,14,1/74,151,-3,13,-2,7,3,3/64,151,1,15,-2,2,5,3;shoulder_l,7,30,-33,0,0,0,0/!288,87,-6,-6,-6,12,12,12/"
                + "!114,49,-7,-12,-10,18,12,21/!320,115,-6,-13,-9,16,1,18/!256,49,-5,2,-5,9,23,9;sspike_l0,20,5,-12,-5,0,0,0.3/"
                + "!358,135,-2,-12,-2,3,12,3;sspike_l4,20,5,-12,5,0,0,0.3/!358,135,-2,-12,-2,3,12,3;forearm_l,20,0,24,0,-0.25,0,0/"
                + "!64,49,-6,0,-6,12,21,13/!0,135,-6,20,-7,13,2,14;forearm_l_gatling,23,0,26,-2,0,0,0/192,49,-7,-7,-16,14,14,18/"
                + "106,135,-5,-9,-14,9,2,14/450,115,7,-5,-9,2,9,9;forearm_l_gatling_barrel,24,0,0,-16,0,0,0/176,87,3,-1,-23,2,2,23/"
                + "176,87,1,2,-23,2,2,23/176,87,-3,2,-23,2,2,23/176,87,-5,-1,-23,2,2,23/176,87,-3,-5,-23,2,2,23/176,87,1,-5,-23,2,2,23/"
                + "328,135,-6,-6,-4,12,12,3/0,151,-6,-6,-20,12,12,2;forearm_l_gatling_flash,25,0,0,-23,0,0,0/420,87,-3,-3,-14,7,7,14/"
                + "106,151,-8,-1,-4,16,2,3/388,115,-1,-8,-4,2,16,3;exhaust,7,12,-41,18,0,0,0/48,0,-5,-34,-5,10,37,10/374,135,-6,-8,-6,12,2,12/"
                + "374,135,-6,-26,-6,12,2,12/54,135,-6,-37,-6,13,3,13;flame_exh,27,0,-37,0,3.1416,0,0/462,87,-3,0,-3,7,14,7;"
                + "tank,7,0,-23,18,0,0,1.5708/298,0,-6,-14,-6,12,28,12/196,135,-6,-14,-6,13,2,13/196,135,-6,12,-6,13,2,13/"
                + "398,115,-6,-2,-6,13,5,13;spool,7,0,-25,21,0,0,1.5708/346,0,-6,-14,-6,12,28,12/336,87,-10,-16,-10,21,2,21/"
                + "336,87,-10,14,-10,21,2,21");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.287F)
                .legLengths(10.925F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/spool", 1, 0F, 1)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel", 2, 1.2F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/torso/shoulder_r/forearm_r/forearm_r_crane/forearm_r_crane_hook", 0, 0.1F, 0F)
                .flame("hips/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel/forearm_l_gatling_flash", null);
    }
}
