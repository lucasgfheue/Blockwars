package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Patchwork (frankenstein). */
@SuppressWarnings("unused")
public final class M_frankenstein {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("frankenstein"), "main");

    private M_frankenstein() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(320, 49).addBox(-17F, -6F, -9F, 34F, 12F, 18F)
                .texOffs(60, 87).addBox(-18F, -5F, -10F, 37F, 6F, 21F)
                .texOffs(48, 151).addBox(-3F, -2F, -12F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(0, 49).addBox(-8F, 0F, -8F, 16F, 22F, 16F)
                .texOffs(0, 115).addBox(-9F, 2F, -12F, 18F, 15F, 5F)
                .texOffs(424, 49).addBox(-9F, 2F, -8F, 2F, 13F, 16F),
                PartPose.offsetAndRotation(-15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(88, 0).addBox(-9F, 0F, -9F, 18F, 23F, 18F)
                .texOffs(422, 135).addBox(-8F, -6F, -13F, 16F, 9F, 5F)
                .texOffs(294, 135).addBox(-7F, 7F, 9F, 14F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(152, 135).addBox(-6F, -1F, -6F, 11F, 5F, 11F)
                .texOffs(394, 0).addBox(-13F, 3F, -19F, 25F, 7F, 32F)
                .texOffs(144, 151).addBox(-12F, 6F, -20F, 23F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(0, 49).mirror().addBox(-8F, 0F, -8F, 16F, 22F, 16F).mirror(false)
                .texOffs(0, 115).mirror().addBox(-9F, 2F, -12F, 18F, 15F, 5F).mirror(false)
                .texOffs(424, 49).mirror().addBox(7F, 2F, -8F, 2F, 13F, 16F).mirror(false),
                PartPose.offsetAndRotation(15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(88, 0).mirror().addBox(-9F, 0F, -9F, 18F, 23F, 18F).mirror(false)
                .texOffs(422, 135).mirror().addBox(-8F, -6F, -13F, 16F, 9F, 5F).mirror(false)
                .texOffs(294, 135).mirror().addBox(-7F, 7F, 9F, 14F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(152, 135).mirror().addBox(-6F, -1F, -6F, 11F, 5F, 11F).mirror(false)
                .texOffs(394, 0).mirror().addBox(-13F, 3F, -19F, 25F, 7F, 32F).mirror(false)
                .texOffs(144, 151).mirror().addBox(-12F, 6F, -20F, 23F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(292, 49).addBox(-3F, -25F, -3F, 7F, 25F, 7F)
                .texOffs(238, 115).addBox(-13F, -14F, -9F, 25F, 3F, 16F)
                .texOffs(146, 115).addBox(-15F, -21F, -9F, 30F, 3F, 16F)
                .texOffs(46, 115).addBox(-17F, -28F, -9F, 34F, 3F, 16F)
                .texOffs(160, 0).addBox(-23F, -41F, -12F, 46F, 17F, 23F)
                .texOffs(226, 87).addBox(-10F, -24F, -5F, 21F, 14F, 10F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(358, 135).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-21F, -39F, 5F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(358, 135).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-21F, -39F, 12F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(358, 135).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(21F, -39F, 5F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(358, 135).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(21F, -39F, 12F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(464, 135).addBox(-5F, -5F, -5F, 9F, 5F, 9F)
                .texOffs(0, 87).addBox(-7F, -16F, -7F, 14F, 12F, 16F)
                .texOffs(28, 151).addBox(-5F, -15F, -8F, 9F, 9F, 1F)
                .texOffs(94, 151).addBox(-2F, -13F, -9F, 5F, 5F, 1F)
                .texOffs(248, 135).addBox(-5F, -17F, -6F, 9F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -41F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(460, 49).addBox(-1F, -28F, -1F, 1F, 28F, 1F)
                .texOffs(192, 151).addBox(-1F, -29F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -14F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(288, 87).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(114, 49).addBox(-12F, -12F, -10F, 18F, 12F, 21F)
                .texOffs(320, 115).addBox(-10F, -13F, -9F, 16F, 1F, 18F)
                .texOffs(256, 49).addBox(-5F, 2F, -5F, 9F, 23F, 9F),
                PartPose.offsetAndRotation(-30F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_r0 = p_shoulder_r.addOrReplaceChild("sspike_r0", CubeListBuilder.create()
                .texOffs(358, 135).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-5F, -12F, -5F, 0F, 0F, -0.3F));
        PartDefinition p_sspike_r4 = p_shoulder_r.addOrReplaceChild("sspike_r4", CubeListBuilder.create()
                .texOffs(358, 135).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-5F, -12F, 5F, 0F, 0F, -0.3F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(64, 49).addBox(-6F, 0F, -6F, 12F, 21F, 13F)
                .texOffs(0, 135).addBox(-6F, 20F, -7F, 13F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_crane = p_forearm_r.addOrReplaceChild("forearm_r_crane", CubeListBuilder.create()
                .texOffs(20, 0).addBox(-3F, 0F, -3F, 7F, 41F, 7F)
                .texOffs(0, 0).addBox(-2F, -1F, -2F, 5F, 44F, 5F),
                PartPose.offsetAndRotation(0F, 24F, -2F, -0.9F, 0F, 0F));
        PartDefinition p_forearm_r_crane_hook = p_forearm_r_crane.addOrReplaceChild("forearm_r_crane_hook", CubeListBuilder.create()
                .texOffs(370, 135).addBox(-1F, 0F, -1F, 1F, 14F, 1F)
                .texOffs(74, 151).addBox(-3F, 13F, -2F, 7F, 3F, 3F)
                .texOffs(64, 151).addBox(1F, 15F, -2F, 2F, 5F, 3F),
                PartPose.offsetAndRotation(0F, 41F, 0F, 0.9F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(288, 87).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(114, 49).mirror().addBox(-7F, -12F, -10F, 18F, 12F, 21F).mirror(false)
                .texOffs(320, 115).mirror().addBox(-6F, -13F, -9F, 16F, 1F, 18F).mirror(false)
                .texOffs(256, 49).mirror().addBox(-5F, 2F, -5F, 9F, 23F, 9F).mirror(false),
                PartPose.offsetAndRotation(30F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_l0 = p_shoulder_l.addOrReplaceChild("sspike_l0", CubeListBuilder.create()
                .texOffs(358, 135).mirror().addBox(-2F, -12F, -2F, 3F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(5F, -12F, -5F, 0F, 0F, 0.3F));
        PartDefinition p_sspike_l4 = p_shoulder_l.addOrReplaceChild("sspike_l4", CubeListBuilder.create()
                .texOffs(358, 135).mirror().addBox(-2F, -12F, -2F, 3F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(5F, -12F, 5F, 0F, 0F, 0.3F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(64, 49).mirror().addBox(-6F, 0F, -6F, 12F, 21F, 13F).mirror(false)
                .texOffs(0, 135).mirror().addBox(-6F, 20F, -7F, 13F, 2F, 14F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_gatling = p_forearm_l.addOrReplaceChild("forearm_l_gatling", CubeListBuilder.create()
                .texOffs(192, 49).addBox(-7F, -7F, -16F, 14F, 14F, 18F)
                .texOffs(106, 135).addBox(-5F, -9F, -14F, 9F, 2F, 14F)
                .texOffs(450, 115).addBox(7F, -5F, -9F, 2F, 9F, 9F),
                PartPose.offsetAndRotation(0F, 26F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gatling_barrel = p_forearm_l_gatling.addOrReplaceChild("forearm_l_gatling_barrel", CubeListBuilder.create()
                .texOffs(176, 87).addBox(3F, -1F, -23F, 2F, 2F, 23F)
                .texOffs(176, 87).addBox(1F, 2F, -23F, 2F, 2F, 23F)
                .texOffs(176, 87).addBox(-3F, 2F, -23F, 2F, 2F, 23F)
                .texOffs(176, 87).addBox(-5F, -1F, -23F, 2F, 2F, 23F)
                .texOffs(176, 87).addBox(-3F, -5F, -23F, 2F, 2F, 23F)
                .texOffs(176, 87).addBox(1F, -5F, -23F, 2F, 2F, 23F)
                .texOffs(328, 135).addBox(-6F, -6F, -4F, 12F, 12F, 3F)
                .texOffs(0, 151).addBox(-6F, -6F, -20F, 12F, 12F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -16F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gatling_flash = p_forearm_l_gatling_barrel.addOrReplaceChild("forearm_l_gatling_flash", CubeListBuilder.create()
                .texOffs(420, 87).addBox(-3F, -3F, -14F, 7F, 7F, 14F)
                .texOffs(106, 151).addBox(-8F, -1F, -4F, 16F, 2F, 3F)
                .texOffs(388, 115).addBox(-1F, -8F, -4F, 2F, 16F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -23F, 0F, 0F, 0F));
        PartDefinition p_exhaust = p_torso.addOrReplaceChild("exhaust", CubeListBuilder.create()
                .texOffs(48, 0).addBox(-5F, -34F, -5F, 10F, 37F, 10F)
                .texOffs(374, 135).addBox(-6F, -8F, -6F, 12F, 2F, 12F)
                .texOffs(374, 135).addBox(-6F, -26F, -6F, 12F, 2F, 12F)
                .texOffs(54, 135).addBox(-6F, -37F, -6F, 13F, 3F, 13F),
                PartPose.offsetAndRotation(12F, -41F, 18F, 0F, 0F, 0F));
        PartDefinition p_flame_exh = p_exhaust.addOrReplaceChild("flame_exh", CubeListBuilder.create()
                .texOffs(462, 87).addBox(-3F, 0F, -3F, 7F, 14F, 7F),
                PartPose.offsetAndRotation(0F, -37F, 0F, 3.1416F, 0F, 0F));
        PartDefinition p_tank = p_torso.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(298, 0).addBox(-6F, -14F, -6F, 12F, 28F, 12F)
                .texOffs(196, 135).addBox(-6F, -14F, -6F, 13F, 2F, 13F)
                .texOffs(196, 135).addBox(-6F, 12F, -6F, 13F, 2F, 13F)
                .texOffs(398, 115).addBox(-6F, -2F, -6F, 13F, 5F, 13F),
                PartPose.offsetAndRotation(0F, -23F, 18F, 0F, 0F, 1.5708F));
        PartDefinition p_spool = p_torso.addOrReplaceChild("spool", CubeListBuilder.create()
                .texOffs(346, 0).addBox(-6F, -14F, -6F, 12F, 28F, 12F)
                .texOffs(336, 87).addBox(-10F, -16F, -10F, 21F, 2F, 21F)
                .texOffs(336, 87).addBox(-10F, 14F, -10F, 21F, 2F, 21F),
                PartPose.offsetAndRotation(0F, -25F, 21F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.287F)
                .legLengths(10.925F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/spool", 1, 0F, 1)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel", 2, 1.2F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/torso/shoulder_r/forearm_r/forearm_r_crane/forearm_r_crane_hook", 0, 0.1F, 0F)
                .flame("hips/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gatling/forearm_l_gatling_barrel/forearm_l_gatling_flash", null);
    }
}
