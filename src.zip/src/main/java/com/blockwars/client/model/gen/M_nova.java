package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Nova (nova). */
@SuppressWarnings("unused")
public final class M_nova {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("nova"), "main");

    private M_nova() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(156, 114).addBox(-12F, -5F, -8F, 24F, 10F, 16F)
                .texOffs(150, 141).addBox(-13F, -4F, -9F, 26F, 5F, 18F)
                .texOffs(16, 238).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(48, 50).addBox(-5F, 0F, -5F, 10F, 22F, 10F)
                .texOffs(124, 190).addBox(-6F, 2F, -8F, 12F, 15F, 4F)
                .texOffs(56, 167).addBox(-6F, 2F, -5F, 2F, 13F, 10F),
                PartPose.offsetAndRotation(-10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(0, 50).addBox(-6F, 0F, -6F, 12F, 23F, 12F)
                .texOffs(40, 226).addBox(-5F, -5F, -9F, 10F, 8F, 4F)
                .texOffs(128, 238).addBox(-2F, -2F, -10F, 3F, 3F, 1F)
                .texOffs(82, 209).addBox(-4F, 7F, 6F, 8F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(116, 226).addBox(-4F, -1F, -4F, 7F, 4F, 7F)
                .texOffs(80, 114).addBox(-8F, 3F, -13F, 17F, 6F, 21F)
                .texOffs(64, 238).addBox(-8F, 5F, -14F, 15F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(48, 50).mirror().addBox(-5F, 0F, -5F, 10F, 22F, 10F).mirror(false)
                .texOffs(124, 190).mirror().addBox(-6F, 2F, -8F, 12F, 15F, 4F).mirror(false)
                .texOffs(56, 167).mirror().addBox(4F, 2F, -5F, 2F, 13F, 10F).mirror(false),
                PartPose.offsetAndRotation(10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(0, 50).mirror().addBox(-6F, 0F, -6F, 12F, 23F, 12F).mirror(false)
                .texOffs(40, 226).mirror().addBox(-5F, -5F, -9F, 10F, 8F, 4F).mirror(false)
                .texOffs(128, 238).mirror().addBox(-2F, -2F, -10F, 3F, 3F, 1F).mirror(false)
                .texOffs(82, 209).mirror().addBox(-4F, 7F, 6F, 8F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(116, 226).mirror().addBox(-4F, -1F, -4F, 7F, 4F, 7F).mirror(false)
                .texOffs(80, 114).mirror().addBox(-8F, 3F, -13F, 17F, 6F, 21F).mirror(false)
                .texOffs(64, 238).mirror().addBox(-8F, 5F, -14F, 15F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 114).addBox(-11F, -10F, -8F, 23F, 10F, 17F)
                .texOffs(116, 0).addBox(-19F, -34F, -11F, 38F, 26F, 22F)
                .texOffs(0, 0).addBox(-15F, -32F, -14F, 30F, 22F, 28F)
                .texOffs(0, 85).addBox(-20F, -24F, -12F, 39F, 5F, 24F)
                .texOffs(56, 141).addBox(-13F, -36F, -10F, 27F, 4F, 20F)
                .texOffs(184, 226).addBox(-4F, -28F, -16F, 8F, 8F, 2F)
                .texOffs(190, 209).addBox(-6F, -30F, -15F, 12F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(150, 209).addBox(-5F, -4F, -5F, 10F, 4F, 10F)
                .texOffs(0, 190).addBox(-8F, -6F, -8F, 16F, 3F, 16F)
                .texOffs(0, 167).addBox(-7F, -16F, -7F, 14F, 9F, 14F)
                .texOffs(0, 226).addBox(-5F, -18F, -5F, 10F, 2F, 10F)
                .texOffs(0, 238).addBox(-2F, -12F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, -36F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(154, 167).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(0, 141).addBox(-8F, -9F, -7F, 14F, 12F, 14F)
                .texOffs(64, 190).addBox(-8F, -5F, -8F, 15F, 4F, 15F)
                .texOffs(224, 85).addBox(-4F, 2F, -4F, 8F, 20F, 8F),
                PartPose.offsetAndRotation(-25F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(182, 85).addBox(-5F, 0F, -6F, 10F, 18F, 11F)
                .texOffs(104, 209).addBox(-6F, 17F, -6F, 11F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_emitter = p_forearm_r.addOrReplaceChild("forearm_r_emitter", CubeListBuilder.create()
                .texOffs(112, 167).addBox(-4F, -4F, -10F, 9F, 9F, 12F)
                .texOffs(68, 226).addBox(-1F, 4F, -17F, 2F, 2F, 10F)
                .texOffs(68, 226).addBox(-5F, -3F, -17F, 2F, 2F, 10F)
                .texOffs(68, 226).addBox(3F, -4F, -17F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_emitter_orb = p_forearm_r_emitter.addOrReplaceChild("forearm_r_emitter_orb", CubeListBuilder.create()
                .texOffs(92, 226).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(144, 226).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(154, 167).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(0, 141).mirror().addBox(-6F, -9F, -7F, 14F, 12F, 14F).mirror(false)
                .texOffs(64, 190).mirror().addBox(-6F, -5F, -8F, 15F, 4F, 15F).mirror(false)
                .texOffs(224, 85).mirror().addBox(-4F, 2F, -4F, 8F, 20F, 8F).mirror(false),
                PartPose.offsetAndRotation(25F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(182, 85).mirror().addBox(-5F, 0F, -6F, 10F, 18F, 11F).mirror(false)
                .texOffs(104, 209).mirror().addBox(-6F, 17F, -6F, 11F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_gun = p_forearm_l.addOrReplaceChild("forearm_l_gun", CubeListBuilder.create()
                .texOffs(126, 85).addBox(-4F, -4F, -18F, 8F, 9F, 20F)
                .texOffs(156, 190).addBox(-3F, -6F, -16F, 6F, 2F, 16F)
                .texOffs(204, 226).addBox(-2F, 4F, -3F, 4F, 4F, 6F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_barrel = p_forearm_l_gun.addOrReplaceChild("forearm_l_gun_barrel", CubeListBuilder.create()
                .texOffs(194, 167).addBox(-2F, -2F, -16F, 4F, 4F, 16F)
                .texOffs(224, 226).addBox(-3F, -3F, -18F, 6F, 6F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -18F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_flash = p_forearm_l_gun_barrel.addOrReplaceChild("forearm_l_gun_flash", CubeListBuilder.create()
                .texOffs(200, 190).addBox(-3F, -3F, -12F, 6F, 6F, 12F)
                .texOffs(30, 238).addBox(-7F, -1F, -4F, 14F, 2F, 3F)
                .texOffs(0, 209).addBox(-1F, -7F, -4F, 2F, 14F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -18F, 0F, 0F, 0F));
        PartDefinition p_reactor = p_torso.addOrReplaceChild("reactor", CubeListBuilder.create()
                .texOffs(88, 50).addBox(-9F, -10F, -5F, 18F, 20F, 10F)
                .texOffs(216, 209).addBox(-4F, -6F, 5F, 8F, 12F, 1F)
                .texOffs(18, 209).addBox(-10F, -8F, -5F, 20F, 3F, 12F)
                .texOffs(18, 209).addBox(-10F, 6F, -5F, 20F, 3F, 12F),
                PartPose.offsetAndRotation(0F, -20F, 20F, 0F, 0F, 0F));
        PartDefinition p_reactor_ring = p_reactor.addOrReplaceChild("reactor_ring", CubeListBuilder.create()
                .texOffs(96, 238).addBox(-7F, -1F, -1F, 14F, 2F, 2F)
                .texOffs(10, 209).addBox(-1F, -7F, -1F, 2F, 14F, 2F),
                PartPose.offsetAndRotation(0F, 0F, 6F, 0F, 0F, 0F));
        PartDefinition p_thr_r = p_torso.addOrReplaceChild("thr_r", CubeListBuilder.create()
                .texOffs(80, 167).addBox(-4F, -7F, -4F, 8F, 14F, 8F)
                .texOffs(156, 226).addBox(-4F, 7F, -4F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(-11F, -24F, 18F, 0.35F, 0F, 0F));
        PartDefinition p_flame_r = p_thr_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(236, 190).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition p_thr_l = p_torso.addOrReplaceChild("thr_l", CubeListBuilder.create()
                .texOffs(80, 167).addBox(-4F, -7F, -4F, 8F, 14F, 8F)
                .texOffs(156, 226).addBox(-4F, 7F, -4F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(11F, -24F, 18F, 0.35F, 0F, 0F));
        PartDefinition p_flame_l = p_thr_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(236, 190).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/reactor/reactor_ring", 2, 0.15F, 0)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
