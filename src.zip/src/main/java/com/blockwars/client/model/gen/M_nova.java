package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Nova (nova). */
@SuppressWarnings("unused")
public final class M_nova {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("nova"), "main");

    private M_nova() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-30,0,0,0,0/156,114,-12,-5,-8,24,10,16/150,141,-13,-4,-9,26,5,18/16,238,-3,-2,-10,6,6,1;thigh_r,-1,-10,-30,0,0,0,0/"
                + "48,50,-5,0,-5,10,22,10/124,190,-6,2,-8,12,15,4/56,167,-6,2,-5,2,13,10;shin_r,1,0,22,0,0,0,0/0,50,-6,0,-6,12,23,12/"
                + "40,226,-5,-5,-9,10,8,4/128,238,-2,-2,-10,3,3,1/82,209,-4,7,6,8,12,3;foot_r,2,0,23,0,0,0,0/116,226,-4,-1,-4,7,4,7/"
                + "80,114,-8,3,-13,17,6,21/64,238,-8,5,-14,15,3,1;thigh_l,-1,10,-30,0,0,0,0/!48,50,-5,0,-5,10,22,10/!124,190,-6,2,-8,12,15,4/"
                + "!56,167,4,2,-5,2,13,10;shin_l,4,0,22,0,0,0,0/!0,50,-6,0,-6,12,23,12/!40,226,-5,-5,-9,10,8,4/!128,238,-2,-2,-10,3,3,1/"
                + "!82,209,-4,7,6,8,12,3;foot_l,5,0,23,0,0,0,0/!116,226,-4,-1,-4,7,4,7/!80,114,-8,3,-13,17,6,21/!64,238,-8,5,-14,15,3,1;"
                + "torso,0,0,-5,0,0,0,0/0,114,-11,-10,-8,23,10,17/116,0,-19,-34,-11,38,26,22/0,0,-15,-32,-14,30,22,28/0,85,-20,-24,-12,39,5,24/"
                + "56,141,-13,-36,-10,27,4,20/184,226,-4,-28,-16,8,8,2/190,209,-6,-30,-15,12,12,1;head,7,0,-36,-2,0,0,0/"
                + "150,209,-5,-4,-5,10,4,10/0,190,-8,-6,-8,16,3,16/0,167,-7,-16,-7,14,9,14/0,226,-5,-18,-5,10,2,10/0,238,-2,-12,-2,4,4,4;"
                + "shoulder_r,7,-25,-29,0,0,0,0/154,167,-5,-5,-5,10,10,10/0,141,-8,-9,-7,14,12,14/64,190,-8,-5,-8,15,4,15/"
                + "224,85,-4,2,-4,8,20,8;forearm_r,9,0,21,0,-0.25,0,0/182,85,-5,0,-6,10,18,11/104,209,-6,17,-6,11,2,12;forearm_r_emitter,10,0,23,-2,0,0,0/"
                + "112,167,-4,-4,-10,9,9,12/68,226,-1,4,-17,2,2,10/68,226,-5,-3,-17,2,2,10/68,226,3,-4,-17,2,2,10;forearm_r_emitter_orb,11,0,0,-15,0.7854,0.7854,0/"
                + "92,226,-3,-3,-3,6,6,6/144,226,-2,-4,-2,3,8,3;shoulder_l,7,25,-29,0,0,0,0/!154,167,-5,-5,-5,10,10,10/!0,141,-6,-9,-7,14,12,14/"
                + "!64,190,-6,-5,-8,15,4,15/!224,85,-4,2,-4,8,20,8;forearm_l,13,0,21,0,-0.25,0,0/!182,85,-5,0,-6,10,18,11/"
                + "!104,209,-6,17,-6,11,2,12;forearm_l_gun,14,0,23,-2,0,0,0/126,85,-4,-4,-18,8,9,20/156,190,-3,-6,-16,6,2,16/"
                + "204,226,-2,4,-3,4,4,6;forearm_l_gun_barrel,15,0,-1,-18,0,0,0/194,167,-2,-2,-16,4,4,16/224,226,-3,-3,-18,6,6,3;"
                + "forearm_l_gun_flash,16,0,0,-18,0,0,0/200,190,-3,-3,-12,6,6,12/30,238,-7,-1,-4,14,2,3/0,209,-1,-7,-4,2,14,3;"
                + "reactor,7,0,-20,20,0,0,0/88,50,-9,-10,-5,18,20,10/216,209,-4,-6,5,8,12,1/18,209,-10,-8,-5,20,3,12/18,209,-10,6,-5,20,3,12;"
                + "reactor_ring,18,0,0,6,0,0,0/96,238,-7,-1,-1,14,2,2/10,209,-1,-7,-1,2,14,2;thr_r,7,-11,-24,18,0.35,0,0/"
                + "80,167,-4,-7,-4,8,14,8/156,226,-4,7,-4,7,3,7;flame_r,20,0,10,0,0,0,0/236,190,-2,0,-2,5,12,5;thr_l,7,11,-24,18,0.35,0,0/"
                + "80,167,-4,-7,-4,8,14,8/156,226,-4,7,-4,7,3,7;flame_l,22,0,10,0,0,0,0/236,190,-2,0,-2,5,12,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/reactor/reactor_ring", 2, 0.15F, 0)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
