package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Seraph (serafin). */
@SuppressWarnings("unused")
public final class M_serafin {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("serafin"), "main");

    private M_serafin() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-32,0,0,0,0/172,88,-13,-5,-8,25,10,17/4,117,-14,-5,-9,27,5,19/20,199,-3,-2,-10,6,6,1;thigh_r,-1,-10,-32,0,0,0,0/"
                + "0,55,-5,0,-5,10,23,10/0,165,-6,2,-8,13,16,4/96,117,-6,2,-5,2,14,10;shin_r,1,0,23,0,0,0,0/188,0,-6,0,-6,13,24,13/"
                + "112,185,-5,-5,-9,10,8,4/118,199,-2,-3,-10,3,3,1/228,165,-4,7,6,8,12,3;foot_r,2,0,24,0,0,0,0/188,185,-4,-1,-4,7,4,7/"
                + "32,88,-9,3,-13,18,6,22/34,199,-8,5,-14,16,3,1;thigh_l,-1,10,-32,0,0,0,0/!0,55,-5,0,-5,10,23,10/!0,165,-6,2,-8,13,16,4/"
                + "!96,117,4,2,-5,2,14,10;shin_l,4,0,23,0,0,0,0/!188,0,-6,0,-6,13,24,13/!112,185,-5,-5,-9,10,8,4/!118,199,-2,-3,-10,3,3,1/"
                + "!228,165,-4,7,6,8,12,3;foot_l,5,0,24,0,0,0,0/!188,185,-4,-1,-4,7,4,7/!32,88,-9,3,-13,18,6,22/!34,199,-8,5,-14,16,3,1;"
                + "torso,0,0,-5,0,0,0,0/120,117,-9,-10,-6,19,10,13/40,55,-14,-22,-9,27,14,18/58,0,-21,-34,-13,42,16,23/44,143,-13,-36,-8,25,4,16/"
                + "0,185,-10,-31,-15,21,11,3/0,199,-4,-27,-13,8,8,2/48,185,-6,-29,-12,13,13,1;head,7,0,-36,-2,0,0,0/80,185,-4,-4,-4,8,4,8/"
                + "174,55,-7,-17,-8,15,13,17/90,165,-6,-18,-6,13,1,15/68,199,-6,-12,-9,13,3,1/96,199,-5,-8,-9,10,3,1;crest,8,0,-17,-2,-0.8,0,0/"
                + "216,117,-1,-17,-3,2,17,6/76,185,-1,-15,-4,1,13,1;shoulder_r,7,-27,-28,0,0,0,0/190,143,-5,-5,-5,10,10,10/"
                + "112,88,-8,-9,-7,15,13,15/126,143,-9,-5,-8,16,4,16/0,88,-4,2,-4,8,21,8;forearm_r,10,0,22,0,-0.25,0,0/130,55,-5,0,-6,10,19,12/"
                + "178,165,-6,18,-6,12,2,13;forearm_r_emitter,11,0,24,-2,0,0,0/0,143,-5,-5,-10,9,9,13/140,185,-1,4,-18,2,2,10/"
                + "140,185,-6,-4,-18,2,2,10/140,185,3,-4,-18,2,2,10;forearm_r_emitter_orb,12,0,0,-16,0.7854,0.7854,0/164,185,-3,-3,-3,6,6,6/"
                + "216,185,-2,-4,-2,3,8,3;shoulder_l,7,27,-28,0,0,0,0/!190,143,-5,-5,-5,10,10,10/!112,88,-6,-9,-7,15,13,15/"
                + "!126,143,-7,-5,-8,16,4,16/!0,88,-4,2,-4,8,21,8;forearm_l,14,0,22,0,-0.25,0,0/!130,55,-5,0,-6,10,19,12/"
                + "!178,165,-6,18,-6,12,2,13;forearm_l_emitter,15,0,24,-2,0,0,0/0,143,-5,-5,-10,9,9,13/140,185,-1,4,-18,2,2,10/"
                + "140,185,-6,-4,-18,2,2,10/140,185,3,-4,-18,2,2,10;forearm_l_emitter_orb,16,0,0,-16,0.7854,0.7854,0/164,185,-3,-3,-3,6,6,6/"
                + "216,185,-2,-4,-2,3,8,3;wing0_r,7,-6,-36,14,0.4,-0.35,-0.65/0,0,-2,-42,-2,3,42,13/34,165,-2,-42,-3,4,4,14/"
                + "240,0,-1,-39,10,1,36,1;wing0_l,7,6,-36,14,0.4,0.35,0.65/!0,0,-2,-42,-2,3,42,13/!34,165,-2,-42,-3,4,4,14/"
                + "!240,0,-1,-39,10,1,36,1;wing1_r,7,-6,-27,14,0.55,-0.35,-1.15/32,0,-2,-32,-1,3,32,10/146,165,-2,-32,-2,4,4,12/"
                + "0,117,-1,-28,8,1,25,1;wing1_l,7,6,-27,14,0.55,0.35,1.15/!32,0,-2,-32,-1,3,32,10/!146,165,-2,-32,-2,4,4,12/"
                + "!0,117,-1,-28,8,1,25,1;thr_r,7,-12,-23,16,0.35,0,0/184,117,-4,-7,-4,8,15,8/228,185,-4,7,-4,7,3,7;flame_r,22,0,10,0,0,0,0/"
                + "70,165,-3,0,-3,5,13,5;thr_l,7,12,-23,16,0.35,0,0/184,117,-4,-7,-4,8,15,8/228,185,-4,7,-4,7,3,7;flame_l,24,0,10,0,0,0,0/"
                + "70,165,-3,0,-3,5,13,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3143F)
                .legLengths(11.55F, 12.075F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_emitter/forearm_l_emitter_orb", 2, 0.25F, 0)
                .wing("hips/torso/wing0_r", -1)
                .wing("hips/torso/wing0_l", 1)
                .wing("hips/torso/wing1_r", -1)
                .wing("hips/torso/wing1_l", 1)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .primaryTwin(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
