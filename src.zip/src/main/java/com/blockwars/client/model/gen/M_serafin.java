package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Seraph (serafin). */
@SuppressWarnings("unused")
public final class M_serafin {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("serafin"), "main");

    private M_serafin() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(172, 88).addBox(-13F, -5F, -8F, 25F, 10F, 17F)
                .texOffs(4, 117).addBox(-14F, -5F, -9F, 27F, 5F, 19F)
                .texOffs(20, 199).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(0, 55).addBox(-5F, 0F, -5F, 10F, 23F, 10F)
                .texOffs(0, 165).addBox(-6F, 2F, -8F, 13F, 16F, 4F)
                .texOffs(96, 117).addBox(-6F, 2F, -5F, 2F, 14F, 10F),
                PartPose.offsetAndRotation(-10F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(188, 0).addBox(-6F, 0F, -6F, 13F, 24F, 13F)
                .texOffs(112, 185).addBox(-5F, -5F, -9F, 10F, 8F, 4F)
                .texOffs(118, 199).addBox(-2F, -3F, -10F, 3F, 3F, 1F)
                .texOffs(228, 165).addBox(-4F, 7F, 6F, 8F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(188, 185).addBox(-4F, -1F, -4F, 7F, 4F, 7F)
                .texOffs(32, 88).addBox(-9F, 3F, -13F, 18F, 6F, 22F)
                .texOffs(34, 199).addBox(-8F, 5F, -14F, 16F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(0, 55).mirror().addBox(-5F, 0F, -5F, 10F, 23F, 10F).mirror(false)
                .texOffs(0, 165).mirror().addBox(-6F, 2F, -8F, 13F, 16F, 4F).mirror(false)
                .texOffs(96, 117).mirror().addBox(4F, 2F, -5F, 2F, 14F, 10F).mirror(false),
                PartPose.offsetAndRotation(10F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(188, 0).mirror().addBox(-6F, 0F, -6F, 13F, 24F, 13F).mirror(false)
                .texOffs(112, 185).mirror().addBox(-5F, -5F, -9F, 10F, 8F, 4F).mirror(false)
                .texOffs(118, 199).mirror().addBox(-2F, -3F, -10F, 3F, 3F, 1F).mirror(false)
                .texOffs(228, 165).mirror().addBox(-4F, 7F, 6F, 8F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(188, 185).mirror().addBox(-4F, -1F, -4F, 7F, 4F, 7F).mirror(false)
                .texOffs(32, 88).mirror().addBox(-9F, 3F, -13F, 18F, 6F, 22F).mirror(false)
                .texOffs(34, 199).mirror().addBox(-8F, 5F, -14F, 16F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(120, 117).addBox(-9F, -10F, -6F, 19F, 10F, 13F)
                .texOffs(40, 55).addBox(-14F, -22F, -9F, 27F, 14F, 18F)
                .texOffs(58, 0).addBox(-21F, -34F, -13F, 42F, 16F, 23F)
                .texOffs(44, 143).addBox(-13F, -36F, -8F, 25F, 4F, 16F)
                .texOffs(0, 185).addBox(-10F, -31F, -15F, 21F, 11F, 3F)
                .texOffs(0, 199).addBox(-4F, -27F, -13F, 8F, 8F, 2F)
                .texOffs(48, 185).addBox(-6F, -29F, -12F, 13F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(80, 185).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(174, 55).addBox(-7F, -17F, -8F, 15F, 13F, 17F)
                .texOffs(90, 165).addBox(-6F, -18F, -6F, 13F, 1F, 15F)
                .texOffs(68, 199).addBox(-6F, -12F, -9F, 13F, 3F, 1F)
                .texOffs(96, 199).addBox(-5F, -8F, -9F, 10F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -36F, -2F, 0F, 0F, 0F));
        PartDefinition p_crest = p_head.addOrReplaceChild("crest", CubeListBuilder.create()
                .texOffs(216, 117).addBox(-1F, -17F, -3F, 2F, 17F, 6F)
                .texOffs(76, 185).addBox(-1F, -15F, -4F, 1F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -17F, -2F, -0.8F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(190, 143).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(112, 88).addBox(-8F, -9F, -7F, 15F, 13F, 15F)
                .texOffs(126, 143).addBox(-9F, -5F, -8F, 16F, 4F, 16F)
                .texOffs(0, 88).addBox(-4F, 2F, -4F, 8F, 21F, 8F),
                PartPose.offsetAndRotation(-27F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(130, 55).addBox(-5F, 0F, -6F, 10F, 19F, 12F)
                .texOffs(178, 165).addBox(-6F, 18F, -6F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 22F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_emitter = p_forearm_r.addOrReplaceChild("forearm_r_emitter", CubeListBuilder.create()
                .texOffs(0, 143).addBox(-5F, -5F, -10F, 9F, 9F, 13F)
                .texOffs(140, 185).addBox(-1F, 4F, -18F, 2F, 2F, 10F)
                .texOffs(140, 185).addBox(-6F, -4F, -18F, 2F, 2F, 10F)
                .texOffs(140, 185).addBox(3F, -4F, -18F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_emitter_orb = p_forearm_r_emitter.addOrReplaceChild("forearm_r_emitter_orb", CubeListBuilder.create()
                .texOffs(164, 185).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(216, 185).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -16F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(190, 143).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(112, 88).mirror().addBox(-6F, -9F, -7F, 15F, 13F, 15F).mirror(false)
                .texOffs(126, 143).mirror().addBox(-7F, -5F, -8F, 16F, 4F, 16F).mirror(false)
                .texOffs(0, 88).mirror().addBox(-4F, 2F, -4F, 8F, 21F, 8F).mirror(false),
                PartPose.offsetAndRotation(27F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(130, 55).mirror().addBox(-5F, 0F, -6F, 10F, 19F, 12F).mirror(false)
                .texOffs(178, 165).mirror().addBox(-6F, 18F, -6F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_emitter = p_forearm_l.addOrReplaceChild("forearm_l_emitter", CubeListBuilder.create()
                .texOffs(0, 143).addBox(-5F, -5F, -10F, 9F, 9F, 13F)
                .texOffs(140, 185).addBox(-1F, 4F, -18F, 2F, 2F, 10F)
                .texOffs(140, 185).addBox(-6F, -4F, -18F, 2F, 2F, 10F)
                .texOffs(140, 185).addBox(3F, -4F, -18F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_emitter_orb = p_forearm_l_emitter.addOrReplaceChild("forearm_l_emitter_orb", CubeListBuilder.create()
                .texOffs(164, 185).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(216, 185).addBox(-2F, -4F, -2F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -16F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_wing0_r = p_torso.addOrReplaceChild("wing0_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2F, -42F, -2F, 3F, 42F, 13F)
                .texOffs(34, 165).addBox(-2F, -42F, -3F, 4F, 4F, 14F)
                .texOffs(240, 0).addBox(-1F, -39F, 10F, 1F, 36F, 1F),
                PartPose.offsetAndRotation(-6F, -36F, 14F, 0.4F, -0.35F, -0.65F));
        PartDefinition p_wing0_l = p_torso.addOrReplaceChild("wing0_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-2F, -42F, -2F, 3F, 42F, 13F).mirror(false)
                .texOffs(34, 165).mirror().addBox(-2F, -42F, -3F, 4F, 4F, 14F).mirror(false)
                .texOffs(240, 0).mirror().addBox(-1F, -39F, 10F, 1F, 36F, 1F).mirror(false),
                PartPose.offsetAndRotation(6F, -36F, 14F, 0.4F, 0.35F, 0.65F));
        PartDefinition p_wing1_r = p_torso.addOrReplaceChild("wing1_r", CubeListBuilder.create()
                .texOffs(32, 0).addBox(-2F, -32F, -1F, 3F, 32F, 10F)
                .texOffs(146, 165).addBox(-2F, -32F, -2F, 4F, 4F, 12F)
                .texOffs(0, 117).addBox(-1F, -28F, 8F, 1F, 25F, 1F),
                PartPose.offsetAndRotation(-6F, -27F, 14F, 0.55F, -0.35F, -1.15F));
        PartDefinition p_wing1_l = p_torso.addOrReplaceChild("wing1_l", CubeListBuilder.create()
                .texOffs(32, 0).mirror().addBox(-2F, -32F, -1F, 3F, 32F, 10F).mirror(false)
                .texOffs(146, 165).mirror().addBox(-2F, -32F, -2F, 4F, 4F, 12F).mirror(false)
                .texOffs(0, 117).mirror().addBox(-1F, -28F, 8F, 1F, 25F, 1F).mirror(false),
                PartPose.offsetAndRotation(6F, -27F, 14F, 0.55F, 0.35F, 1.15F));
        PartDefinition p_thr_r = p_torso.addOrReplaceChild("thr_r", CubeListBuilder.create()
                .texOffs(184, 117).addBox(-4F, -7F, -4F, 8F, 15F, 8F)
                .texOffs(228, 185).addBox(-4F, 7F, -4F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(-12F, -23F, 16F, 0.35F, 0F, 0F));
        PartDefinition p_flame_r = p_thr_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(70, 165).addBox(-3F, 0F, -3F, 5F, 13F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition p_thr_l = p_torso.addOrReplaceChild("thr_l", CubeListBuilder.create()
                .texOffs(184, 117).addBox(-4F, -7F, -4F, 8F, 15F, 8F)
                .texOffs(228, 185).addBox(-4F, 7F, -4F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(12F, -23F, 16F, 0.35F, 0F, 0F));
        PartDefinition p_flame_l = p_thr_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(70, 165).addBox(-3F, 0F, -3F, 5F, 13F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3143F)
                .legLengths(11.55F, 12.075F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_emitter/forearm_l_emitter_orb", 2, 0.25F, 0)
                .wing("hips/torso/wing0_r", -1)
                .wing("hips/torso/wing0_l", 1)
                .wing("hips/torso/wing1_r", -1)
                .wing("hips/torso/wing1_l", 1)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .primaryTwin(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
