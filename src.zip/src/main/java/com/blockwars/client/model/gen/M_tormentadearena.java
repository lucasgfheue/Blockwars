package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Sandstorm (tormentadearena). */
@SuppressWarnings("unused")
public final class M_tormentadearena {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("tormentadearena"), "main");

    private M_tormentadearena() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hull,-1,0,25,0,0,0,0/0,101,-39,-38,-33,78,16,66/292,183,-21,-41,-21,41,5,47/288,101,-21,-23,-31,41,18,63/"
                + "250,340,-37,-33,-34,74,7,1;tread_r,0,-30,-12,0,0,0,0/0,0,-9,-12,-39,18,23,78/192,0,-10,-17,-40,21,6,80;"
                + "wheel_r0,1,-10,2,-28,0,0,0/170,311,-1,-7,-7,1,14,14/236,340,-1,-2,-2,2,5,5;wheel_r1,1,-10,2,-9,0,0,0/"
                + "170,311,-1,-7,-7,1,14,14/236,340,-1,-2,-2,2,5,5;wheel_r2,1,-10,2,9,0,0,0/170,311,-1,-7,-7,1,14,14/236,340,-1,-2,-2,2,5,5;"
                + "wheel_r3,1,-10,2,28,0,0,0/170,311,-1,-7,-7,1,14,14/236,340,-1,-2,-2,2,5,5;tread_l,0,30,-12,0,0,0,0/!0,0,-9,-12,-39,18,23,78/"
                + "!192,0,-10,-17,-40,21,6,80;wheel_l0,6,10,2,-28,0,0,0/!170,311,-1,-7,-7,1,14,14/!236,340,-1,-2,-2,2,5,5;"
                + "wheel_l1,6,10,2,-9,0,0,0/!170,311,-1,-7,-7,1,14,14/!236,340,-1,-2,-2,2,5,5;wheel_l2,6,10,2,9,0,0,0/!170,311,-1,-7,-7,1,14,14/"
                + "!236,340,-1,-2,-2,2,5,5;wheel_l3,6,10,2,28,0,0,0/!170,311,-1,-7,-7,1,14,14/!236,340,-1,-2,-2,2,5,5;turret,0,0,-39,5,0,0,0/"
                + "128,183,-21,-16,-21,41,16,41/392,260,-16,-17,-12,32,1,28/178,340,-14,-13,21,28,9,1;head,11,12,-16,7,0,0,0/"
                + "142,340,-5,-2,-5,9,2,9/200,311,-8,-12,-7,16,9,14/400,340,-7,-10,-8,14,7,1/468,340,-6,-9,-9,3,3,1/468,340,-2,-9,-9,3,3,1/"
                + "468,340,3,-9,-9,3,3,1/78,340,-9,-13,-7,17,1,15;antenna,12,6,-14,5,-0.2,0,0.15/102,311,-1,-28,-1,1,28,1/"
                + "476,340,-1,-29,-1,2,2,2;turret_mortar,11,0,-9,-18,-0.55,0,0/106,311,-8,-6,-8,16,12,16;turret_mortar_barrel,14,0,-5,-5,0,0,0/"
                + "0,260,-7,-7,-37,14,14,37/44,340,-7,-7,-33,15,15,2/260,311,-8,-8,-40,16,16,5;turret_mortar_flash,15,0,0,-39,0,0,0/"
                + "302,311,-3,-3,-14,7,7,14/430,340,-8,-1,-4,16,2,3/344,311,-1,-8,-4,2,16,3;turret_pod,11,14,-9,-18,0,0,0/"
                + "102,260,-12,-18,-14,23,18,28/0,311,-12,-20,-14,23,1,28/0,340,-10,-17,-15,21,16,1;drum,11,0,-5,28,0,0,1.5708/"
                + "204,260,-7,-10,-7,14,21,14/424,311,-7,-1,-7,15,2,15;cargo0,11,-9,-7,30,0,0,0/260,260,-9,-7,-8,17,15,16/"
                + "0,357,-8,-1,-9,15,2,1/354,311,-9,-8,-9,18,1,17;cargo1,11,9,-7,30,0,0,0/260,260,-9,-7,-8,17,15,16/0,357,-8,-1,-9,15,2,1/"
                + "354,311,-9,-8,-9,18,1,17;cargo2,11,0,-23,30,0,0,0/326,260,-9,-7,-8,17,15,16/0,357,-8,-1,-9,15,2,1/354,311,-9,-8,-9,18,1,17;"
                + "skirt_r,0,-41,-21,0,0,0,0/0,183,-1,-7,-31,1,14,63;skirt_l,0,41,-21,0,0,0,0/!0,183,-1,-7,-31,1,14,63");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_mortar/turret_mortar_barrel", "hull/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", null, null, null);
    }
}
