package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Sandstorm (tormentadearena). */
@SuppressWarnings("unused")
public final class M_tormentadearena {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("tormentadearena"), "main");

    private M_tormentadearena() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 101).addBox(-39F, -38F, -33F, 78F, 16F, 66F)
                .texOffs(292, 183).addBox(-21F, -41F, -21F, 41F, 5F, 47F)
                .texOffs(288, 101).addBox(-21F, -23F, -31F, 41F, 18F, 63F)
                .texOffs(250, 340).addBox(-37F, -33F, -34F, 74F, 7F, 1F),
                PartPose.offsetAndRotation(0F, 25F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-9F, -12F, -39F, 18F, 23F, 78F)
                .texOffs(192, 0).addBox(-10F, -17F, -40F, 21F, 6F, 80F),
                PartPose.offsetAndRotation(-30F, -12F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(170, 311).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(236, 340).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, -28F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(170, 311).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(236, 340).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(170, 311).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(236, 340).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(170, 311).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(236, 340).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, 28F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-9F, -12F, -39F, 18F, 23F, 78F).mirror(false)
                .texOffs(192, 0).mirror().addBox(-10F, -17F, -40F, 21F, 6F, 80F).mirror(false),
                PartPose.offsetAndRotation(30F, -12F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(170, 311).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(236, 340).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, -28F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(170, 311).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(236, 340).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(170, 311).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(236, 340).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(170, 311).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(236, 340).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, 28F, 0F, 0F, 0F));
        PartDefinition p_turret = p_hull.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(128, 183).addBox(-21F, -16F, -21F, 41F, 16F, 41F)
                .texOffs(392, 260).addBox(-16F, -17F, -12F, 32F, 1F, 28F)
                .texOffs(178, 340).addBox(-14F, -13F, 21F, 28F, 9F, 1F),
                PartPose.offsetAndRotation(0F, -39F, 5F, 0F, 0F, 0F));
        PartDefinition p_head = p_turret.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(142, 340).addBox(-5F, -2F, -5F, 9F, 2F, 9F)
                .texOffs(200, 311).addBox(-8F, -12F, -7F, 16F, 9F, 14F)
                .texOffs(400, 340).addBox(-7F, -10F, -8F, 14F, 7F, 1F)
                .texOffs(468, 340).addBox(-6F, -9F, -9F, 3F, 3F, 1F)
                .texOffs(468, 340).addBox(-2F, -9F, -9F, 3F, 3F, 1F)
                .texOffs(468, 340).addBox(3F, -9F, -9F, 3F, 3F, 1F)
                .texOffs(78, 340).addBox(-9F, -13F, -7F, 17F, 1F, 15F),
                PartPose.offsetAndRotation(12F, -16F, 7F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(102, 311).addBox(-1F, -28F, -1F, 1F, 28F, 1F)
                .texOffs(476, 340).addBox(-1F, -29F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -14F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret_mortar = p_turret.addOrReplaceChild("turret_mortar", CubeListBuilder.create()
                .texOffs(106, 311).addBox(-8F, -6F, -8F, 16F, 12F, 16F),
                PartPose.offsetAndRotation(0F, -9F, -18F, -0.55F, 0F, 0F));
        PartDefinition p_turret_mortar_barrel = p_turret_mortar.addOrReplaceChild("turret_mortar_barrel", CubeListBuilder.create()
                .texOffs(0, 260).addBox(-7F, -7F, -37F, 14F, 14F, 37F)
                .texOffs(44, 340).addBox(-7F, -7F, -33F, 15F, 15F, 2F)
                .texOffs(260, 311).addBox(-8F, -8F, -40F, 16F, 16F, 5F),
                PartPose.offsetAndRotation(0F, -5F, -5F, 0F, 0F, 0F));
        PartDefinition p_turret_mortar_flash = p_turret_mortar_barrel.addOrReplaceChild("turret_mortar_flash", CubeListBuilder.create()
                .texOffs(302, 311).addBox(-3F, -3F, -14F, 7F, 7F, 14F)
                .texOffs(430, 340).addBox(-8F, -1F, -4F, 16F, 2F, 3F)
                .texOffs(344, 311).addBox(-1F, -8F, -4F, 2F, 16F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -39F, 0F, 0F, 0F));
        PartDefinition p_turret_pod = p_turret.addOrReplaceChild("turret_pod", CubeListBuilder.create()
                .texOffs(102, 260).addBox(-12F, -18F, -14F, 23F, 18F, 28F)
                .texOffs(0, 311).addBox(-12F, -20F, -14F, 23F, 1F, 28F)
                .texOffs(0, 340).addBox(-10F, -17F, -15F, 21F, 16F, 1F),
                PartPose.offsetAndRotation(14F, -9F, -18F, 0F, 0F, 0F));
        PartDefinition p_drum = p_turret.addOrReplaceChild("drum", CubeListBuilder.create()
                .texOffs(204, 260).addBox(-7F, -10F, -7F, 14F, 21F, 14F)
                .texOffs(424, 311).addBox(-7F, -1F, -7F, 15F, 2F, 15F),
                PartPose.offsetAndRotation(0F, -5F, 28F, 0F, 0F, 1.5708F));
        PartDefinition p_cargo0 = p_turret.addOrReplaceChild("cargo0", CubeListBuilder.create()
                .texOffs(260, 260).addBox(-9F, -7F, -8F, 17F, 15F, 16F)
                .texOffs(0, 357).addBox(-8F, -1F, -9F, 15F, 2F, 1F)
                .texOffs(354, 311).addBox(-9F, -8F, -9F, 18F, 1F, 17F),
                PartPose.offsetAndRotation(-9F, -7F, 30F, 0F, 0F, 0F));
        PartDefinition p_cargo1 = p_turret.addOrReplaceChild("cargo1", CubeListBuilder.create()
                .texOffs(260, 260).addBox(-9F, -7F, -8F, 17F, 15F, 16F)
                .texOffs(0, 357).addBox(-8F, -1F, -9F, 15F, 2F, 1F)
                .texOffs(354, 311).addBox(-9F, -8F, -9F, 18F, 1F, 17F),
                PartPose.offsetAndRotation(9F, -7F, 30F, 0F, 0F, 0F));
        PartDefinition p_cargo2 = p_turret.addOrReplaceChild("cargo2", CubeListBuilder.create()
                .texOffs(326, 260).addBox(-9F, -7F, -8F, 17F, 15F, 16F)
                .texOffs(0, 357).addBox(-8F, -1F, -9F, 15F, 2F, 1F)
                .texOffs(354, 311).addBox(-9F, -8F, -9F, 18F, 1F, 17F),
                PartPose.offsetAndRotation(0F, -23F, 30F, 0F, 0F, 0F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(0, 183).addBox(-1F, -7F, -31F, 1F, 14F, 63F),
                PartPose.offsetAndRotation(-41F, -21F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(0, 183).mirror().addBox(-1F, -7F, -31F, 1F, 14F, 63F).mirror(false),
                PartPose.offsetAndRotation(41F, -21F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/turret", "hull/turret/head").walkRate(0F)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .sway("hull/turret/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "hull/turret", "hull/turret/turret_mortar/turret_mortar_barrel", "hull/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null)
                .secondary(Rig.MountKind.TURRET, "hull/turret", null, null, null);
    }
}
