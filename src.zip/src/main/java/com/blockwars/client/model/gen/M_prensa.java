package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Press (prensa). */
@SuppressWarnings("unused")
public final class M_prensa {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("prensa"), "main");

    private M_prensa() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 115).addBox(-20F, -7F, -11F, 40F, 14F, 22F)
                .texOffs(0, 151).addBox(-22F, -6F, -12F, 43F, 7F, 24F)
                .texOffs(294, 204).addBox(-4F, -3F, -14F, 8F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -41F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt0 = p_hips.addOrReplaceChild("skirt0", CubeListBuilder.create()
                .texOffs(86, 182).addBox(-18F, 0F, -1F, 35F, 19F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -13F, -0.15F, 0F, 0F));
        PartDefinition p_skirt1 = p_hips.addOrReplaceChild("skirt1", CubeListBuilder.create()
                .texOffs(86, 182).addBox(-18F, 0F, -1F, 35F, 19F, 3F),
                PartPose.offsetAndRotation(0F, 0F, 13F, 0.15F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(134, 70).addBox(-9F, 0F, -9F, 19F, 26F, 19F)
                .texOffs(376, 151).addBox(-11F, 3F, -14F, 22F, 18F, 5F)
                .texOffs(124, 115).addBox(-11F, 3F, -9F, 3F, 15F, 19F),
                PartPose.offsetAndRotation(-18F, -41F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(182, 0).addBox(-11F, 0F, -11F, 22F, 27F, 22F)
                .texOffs(166, 204).addBox(-9F, -7F, -15F, 19F, 11F, 5F)
                .texOffs(52, 204).addBox(-8F, 8F, 11F, 16F, 14F, 4F),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(0, 204).addBox(-7F, -1F, -7F, 13F, 5F, 13F)
                .texOffs(0, 70).addBox(-15F, 4F, -22F, 30F, 8F, 37F)
                .texOffs(390, 204).addBox(-14F, 7F, -24F, 27F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(134, 70).mirror().addBox(-9F, 0F, -9F, 19F, 26F, 19F).mirror(false)
                .texOffs(376, 151).mirror().addBox(-11F, 3F, -14F, 22F, 18F, 5F).mirror(false)
                .texOffs(124, 115).mirror().addBox(8F, 3F, -9F, 3F, 15F, 19F).mirror(false),
                PartPose.offsetAndRotation(18F, -41F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(182, 0).mirror().addBox(-11F, 0F, -11F, 22F, 27F, 22F).mirror(false)
                .texOffs(166, 204).mirror().addBox(-9F, -7F, -15F, 19F, 11F, 5F).mirror(false)
                .texOffs(52, 204).mirror().addBox(-8F, 8F, 11F, 16F, 14F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(0, 204).mirror().addBox(-7F, -1F, -7F, 13F, 5F, 13F).mirror(false)
                .texOffs(0, 70).mirror().addBox(-15F, 4F, -22F, 30F, 8F, 37F).mirror(false)
                .texOffs(390, 204).mirror().addBox(-14F, 7F, -24F, 27F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(168, 115).addBox(-16F, -14F, -10F, 33F, 14F, 19F)
                .texOffs(0, 0).addBox(-30F, -49F, -16F, 59F, 38F, 32F)
                .texOffs(0, 182).addBox(-21F, -40F, -18F, 42F, 21F, 1F)
                .texOffs(308, 115).addBox(-22F, -47F, -13F, 45F, 5F, 26F)
                .texOffs(92, 204).addBox(-18F, -32F, 16F, 36F, 15F, 1F),
                PartPose.offsetAndRotation(0F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(214, 204).addBox(-5F, -5F, -5F, 11F, 5F, 11F)
                .texOffs(360, 70).addBox(-9F, -22F, -11F, 19F, 16F, 22F)
                .texOffs(238, 182).addBox(-8F, -23F, -8F, 16F, 1F, 19F)
                .texOffs(446, 204).addBox(-8F, -16F, -12F, 16F, 4F, 1F)
                .texOffs(480, 204).addBox(-7F, -10F, -12F, 14F, 4F, 1F),
                PartPose.offsetAndRotation(0F, -49F, -3F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(272, 115).addBox(-1F, -32F, -1F, 1F, 32F, 1F)
                .texOffs(378, 204).addBox(-1F, -34F, -1F, 3F, 3F, 3F),
                PartPose.offsetAndRotation(7F, -16F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(238, 151).addBox(-7F, -7F, -7F, 14F, 14F, 14F)
                .texOffs(268, 70).addBox(-14F, -14F, -12F, 22F, 14F, 24F)
                .texOffs(294, 151).addBox(-12F, -15F, -11F, 19F, 1F, 22F)
                .texOffs(442, 70).addBox(-5F, 3F, -5F, 11F, 27F, 11F),
                PartPose.offsetAndRotation(-38F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(210, 70).addBox(-7F, 0F, -7F, 14F, 24F, 15F)
                .texOffs(368, 182).addBox(-7F, 23F, -8F, 15F, 3F, 16F),
                PartPose.offsetAndRotation(0F, 28F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_fist = p_forearm_r.addOrReplaceChild("forearm_r_fist", CubeListBuilder.create()
                .texOffs(270, 0).addBox(-12F, -1F, -12F, 24F, 22F, 24F)
                .texOffs(312, 204).addBox(-11F, 15F, -14F, 22F, 5F, 1F)
                .texOffs(134, 151).addBox(-13F, -2F, -13F, 26F, 4F, 26F)
                .texOffs(162, 182).addBox(-9F, 20F, -9F, 19F, 3F, 19F),
                PartPose.offsetAndRotation(0F, 28F, -3F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(238, 151).mirror().addBox(-7F, -7F, -7F, 14F, 14F, 14F).mirror(false)
                .texOffs(268, 70).mirror().addBox(-8F, -14F, -12F, 22F, 14F, 24F).mirror(false)
                .texOffs(294, 151).mirror().addBox(-7F, -15F, -11F, 19F, 1F, 22F).mirror(false)
                .texOffs(442, 70).mirror().addBox(-5F, 3F, -5F, 11F, 27F, 11F).mirror(false),
                PartPose.offsetAndRotation(38F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(210, 70).mirror().addBox(-7F, 0F, -7F, 14F, 24F, 15F).mirror(false)
                .texOffs(368, 182).mirror().addBox(-7F, 23F, -8F, 15F, 3F, 16F).mirror(false),
                PartPose.offsetAndRotation(0F, 28F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_fist = p_forearm_l.addOrReplaceChild("forearm_l_fist", CubeListBuilder.create()
                .texOffs(270, 0).addBox(-12F, -1F, -12F, 24F, 22F, 24F)
                .texOffs(312, 204).addBox(-11F, 15F, -14F, 22F, 5F, 1F)
                .texOffs(134, 151).addBox(-13F, -2F, -13F, 26F, 4F, 26F)
                .texOffs(162, 182).addBox(-9F, 20F, -9F, 19F, 3F, 19F),
                PartPose.offsetAndRotation(0F, 28F, -3F, 0F, 0F, 0F));
        PartDefinition p_tank = p_torso.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(366, 0).addBox(-7F, -16F, -7F, 14F, 32F, 14F)
                .texOffs(430, 182).addBox(-7F, -16F, -7F, 15F, 3F, 15F)
                .texOffs(430, 182).addBox(-7F, 14F, -7F, 15F, 3F, 15F)
                .texOffs(308, 182).addBox(-7F, -3F, -7F, 15F, 5F, 15F),
                PartPose.offsetAndRotation(0F, -27F, 24F, 0F, 0F, 1.5708F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(276, 115).addBox(-4F, -23F, -4F, 8F, 24F, 8F)
                .texOffs(258, 204).addBox(-5F, -25F, -5F, 9F, 3F, 9F)
                .texOffs(358, 204).addBox(-3F, -26F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(-18F, -43F, 22F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(276, 115).addBox(-4F, -23F, -4F, 8F, 24F, 8F)
                .texOffs(258, 204).addBox(-5F, -25F, -5F, 9F, 3F, 9F)
                .texOffs(358, 204).addBox(-3F, -26F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(18F, -43F, 22F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2444F)
                .legLengths(12.825F, 13.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
