package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Valkyrie (valquiria). */
@SuppressWarnings("unused")
public final class M_valquiria {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("valquiria"), "main");

    private M_valquiria() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(386, 80).addBox(-12F, -5F, -8F, 24F, 10F, 16F)
                .texOffs(56, 112).addBox(-13F, -4F, -9F, 26F, 5F, 18F)
                .texOffs(454, 138).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(88, 80).addBox(-5F, 0F, -5F, 10F, 22F, 10F)
                .texOffs(454, 112).addBox(-6F, 2F, -8F, 12F, 15F, 4F)
                .texOffs(144, 112).addBox(-6F, 2F, -5F, 2F, 13F, 10F),
                PartPose.offsetAndRotation(-10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(456, 0).addBox(-6F, 0F, -6F, 12F, 23F, 12F)
                .texOffs(294, 138).addBox(-5F, -5F, -9F, 10F, 8F, 4F)
                .texOffs(86, 138).addBox(-4F, 7F, 6F, 8F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(352, 138).addBox(-4F, -1F, -4F, 7F, 4F, 7F)
                .texOffs(310, 80).addBox(-8F, 3F, -13F, 17F, 6F, 21F)
                .texOffs(468, 138).addBox(-8F, 5F, -14F, 15F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(88, 80).mirror().addBox(-5F, 0F, -5F, 10F, 22F, 10F).mirror(false)
                .texOffs(454, 112).mirror().addBox(-6F, 2F, -8F, 12F, 15F, 4F).mirror(false)
                .texOffs(144, 112).mirror().addBox(4F, 2F, -5F, 2F, 13F, 10F).mirror(false),
                PartPose.offsetAndRotation(10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(456, 0).mirror().addBox(-6F, 0F, -6F, 12F, 23F, 12F).mirror(false)
                .texOffs(294, 138).mirror().addBox(-5F, -5F, -9F, 10F, 8F, 4F).mirror(false)
                .texOffs(86, 138).mirror().addBox(-4F, 7F, 6F, 8F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(352, 138).mirror().addBox(-4F, -1F, -4F, 7F, 4F, 7F).mirror(false)
                .texOffs(310, 80).mirror().addBox(-8F, 3F, -13F, 17F, 6F, 21F).mirror(false)
                .texOffs(468, 138).mirror().addBox(-8F, 5F, -14F, 15F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(168, 112).addBox(-9F, -10F, -6F, 18F, 10F, 12F)
                .texOffs(0, 80).addBox(-13F, -21F, -9F, 26F, 14F, 18F)
                .texOffs(314, 0).addBox(-20F, -32F, -12F, 40F, 15F, 22F)
                .texOffs(316, 112).addBox(-12F, -34F, -8F, 24F, 4F, 15F)
                .texOffs(154, 138).addBox(-10F, -30F, -14F, 20F, 10F, 3F)
                .texOffs(408, 138).addBox(-4F, -26F, -13F, 8F, 8F, 2F)
                .texOffs(232, 138).addBox(-6F, -28F, -12F, 12F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(262, 138).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(128, 80).addBox(-7F, -18F, -8F, 14F, 14F, 16F)
                .texOffs(54, 138).addBox(-8F, -18F, -9F, 15F, 14F, 1F)
                .texOffs(0, 155).addBox(-5F, -12F, -9F, 10F, 2F, 1F)
                .texOffs(22, 155).addBox(-4F, -12F, -9F, 8F, 1F, 1F)
                .texOffs(200, 138).addBox(-2F, -19F, -4F, 4F, 1F, 12F),
                PartPose.offsetAndRotation(0F, -34F, -2F, 0F, 0F, 0F));
        PartDefinition p_crest = p_head.addOrReplaceChild("crest", CubeListBuilder.create()
                .texOffs(260, 112).addBox(-1F, -16F, -3F, 2F, 16F, 6F)
                .texOffs(258, 138).addBox(0F, -14F, -4F, 1F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -16F, -2F, -0.8F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(276, 112).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(0, 112).addBox(-8F, -9F, -7F, 14F, 12F, 14F)
                .texOffs(394, 112).addBox(-8F, -5F, -8F, 15F, 4F, 15F)
                .texOffs(278, 80).addBox(-4F, 2F, -4F, 8F, 20F, 8F),
                PartPose.offsetAndRotation(-26F, -27F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(236, 80).addBox(-5F, 0F, -6F, 10F, 18F, 11F)
                .texOffs(108, 138).addBox(-6F, 17F, -6F, 11F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_spear = p_forearm_r.addOrReplaceChild("forearm_r_spear", CubeListBuilder.create()
                .texOffs(142, 0).addBox(-2F, -2F, -46F, 3F, 3F, 68F)
                .texOffs(322, 138).addBox(-3F, -3F, -5F, 6F, 6F, 6F)
                .texOffs(428, 138).addBox(-3F, -3F, -43F, 6F, 6F, 2F)
                .texOffs(188, 80).addBox(-1F, -4F, -65F, 2F, 8F, 22F)
                .texOffs(346, 138).addBox(0F, -5F, -45F, 1F, 10F, 2F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(276, 112).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(0, 112).mirror().addBox(-6F, -9F, -7F, 14F, 12F, 14F).mirror(false)
                .texOffs(394, 112).mirror().addBox(-6F, -5F, -8F, 15F, 4F, 15F).mirror(false)
                .texOffs(278, 80).mirror().addBox(-4F, 2F, -4F, 8F, 20F, 8F).mirror(false),
                PartPose.offsetAndRotation(26F, -27F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(236, 80).mirror().addBox(-5F, 0F, -6F, 10F, 18F, 11F).mirror(false)
                .texOffs(108, 138).mirror().addBox(-6F, 17F, -6F, 11F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_shield = p_forearm_l.addOrReplaceChild("forearm_l_shield", CubeListBuilder.create()
                .texOffs(70, 0).addBox(-2F, -22F, -16F, 4F, 44F, 32F)
                .texOffs(0, 0).addBox(2F, -23F, -17F, 1F, 46F, 34F)
                .texOffs(438, 0).addBox(2F, -14F, -4F, 1F, 28F, 8F)
                .texOffs(444, 138).addBox(3F, -14F, -2F, 1F, 4F, 4F),
                PartPose.offsetAndRotation(7F, 9F, -4F, 0F, 0F, 0F));
        PartDefinition p_wing0_r = p_torso.addOrReplaceChild("wing0_r", CubeListBuilder.create()
                .texOffs(284, 0).addBox(-2F, -40F, -2F, 3F, 40F, 12F)
                .texOffs(0, 138).addBox(-2F, -40F, -2F, 4F, 4F, 13F)
                .texOffs(504, 0).addBox(0F, -37F, 10F, 1F, 34F, 1F),
                PartPose.offsetAndRotation(-6F, -34F, 13F, 0.4F, -0.35F, -0.65F));
        PartDefinition p_wing0_l = p_torso.addOrReplaceChild("wing0_l", CubeListBuilder.create()
                .texOffs(284, 0).mirror().addBox(-2F, -40F, -2F, 3F, 40F, 12F).mirror(false)
                .texOffs(0, 138).mirror().addBox(-2F, -40F, -2F, 4F, 4F, 13F).mirror(false)
                .texOffs(504, 0).mirror().addBox(0F, -37F, 10F, 1F, 34F, 1F).mirror(false),
                PartPose.offsetAndRotation(6F, -34F, 13F, 0.4F, 0.35F, 0.65F));
        PartDefinition p_thr_r = p_torso.addOrReplaceChild("thr_r", CubeListBuilder.create()
                .texOffs(228, 112).addBox(-4F, -7F, -4F, 8F, 14F, 8F)
                .texOffs(380, 138).addBox(-4F, 7F, -4F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(-11F, -22F, 15F, 0.35F, 0F, 0F));
        PartDefinition p_flame_r = p_thr_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(34, 138).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition p_thr_l = p_torso.addOrReplaceChild("thr_l", CubeListBuilder.create()
                .texOffs(228, 112).addBox(-4F, -7F, -4F, 8F, 14F, 8F)
                .texOffs(380, 138).addBox(-4F, 7F, -4F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(11F, -22F, 15F, 0.35F, 0F, 0F));
        PartDefinition p_flame_l = p_thr_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(34, 138).addBox(-2F, 0F, -2F, 5F, 12F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .wing("hips/torso/wing0_r", -1)
                .wing("hips/torso/wing0_l", 1)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
