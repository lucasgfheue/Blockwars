package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Valkyrie (valquiria). */
@SuppressWarnings("unused")
public final class M_valquiria {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("valquiria"), "main");

    private M_valquiria() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-30,0,0,0,0/386,80,-12,-5,-8,24,10,16/56,112,-13,-4,-9,26,5,18/454,138,-3,-2,-10,6,6,1;thigh_r,-1,-10,-30,0,0,0,0/"
                + "88,80,-5,0,-5,10,22,10/454,112,-6,2,-8,12,15,4/144,112,-6,2,-5,2,13,10;shin_r,1,0,22,0,0,0,0/456,0,-6,0,-6,12,23,12/"
                + "294,138,-5,-5,-9,10,8,4/86,138,-4,7,6,8,12,3;foot_r,2,0,23,0,0,0,0/352,138,-4,-1,-4,7,4,7/310,80,-8,3,-13,17,6,21/"
                + "468,138,-8,5,-14,15,3,1;thigh_l,-1,10,-30,0,0,0,0/!88,80,-5,0,-5,10,22,10/!454,112,-6,2,-8,12,15,4/!144,112,4,2,-5,2,13,10;"
                + "shin_l,4,0,22,0,0,0,0/!456,0,-6,0,-6,12,23,12/!294,138,-5,-5,-9,10,8,4/!86,138,-4,7,6,8,12,3;foot_l,5,0,23,0,0,0,0/"
                + "!352,138,-4,-1,-4,7,4,7/!310,80,-8,3,-13,17,6,21/!468,138,-8,5,-14,15,3,1;torso,0,0,-5,0,0,0,0/168,112,-9,-10,-6,18,10,12/"
                + "0,80,-13,-21,-9,26,14,18/314,0,-20,-32,-12,40,15,22/316,112,-12,-34,-8,24,4,15/154,138,-10,-30,-14,20,10,3/"
                + "408,138,-4,-26,-13,8,8,2/232,138,-6,-28,-12,12,12,1;head,7,0,-34,-2,0,0,0/262,138,-4,-4,-4,8,4,8/128,80,-7,-18,-8,14,14,16/"
                + "54,138,-8,-18,-9,15,14,1/0,155,-5,-12,-9,10,2,1/22,155,-4,-12,-9,8,1,1/200,138,-2,-19,-4,4,1,12;crest,8,0,-16,-2,-0.8,0,0/"
                + "260,112,-1,-16,-3,2,16,6/258,138,0,-14,-4,1,12,1;shoulder_r,7,-26,-27,0,0,0,0/276,112,-5,-5,-5,10,10,10/"
                + "0,112,-8,-9,-7,14,12,14/394,112,-8,-5,-8,15,4,15/278,80,-4,2,-4,8,20,8;forearm_r,10,0,21,0,-0.25,0,0/"
                + "236,80,-5,0,-6,10,18,11/108,138,-6,17,-6,11,2,12;forearm_r_spear,11,0,23,-2,0,0,0/142,0,-2,-2,-46,3,3,68/"
                + "322,138,-3,-3,-5,6,6,6/428,138,-3,-3,-43,6,6,2/188,80,-1,-4,-65,2,8,22/346,138,0,-5,-45,1,10,2;shoulder_l,7,26,-27,0,0,0,0/"
                + "!276,112,-5,-5,-5,10,10,10/!0,112,-6,-9,-7,14,12,14/!394,112,-6,-5,-8,15,4,15/!278,80,-4,2,-4,8,20,8;"
                + "forearm_l,13,0,21,0,-0.25,0,0/!236,80,-5,0,-6,10,18,11/!108,138,-6,17,-6,11,2,12;forearm_l_shield,14,7,9,-4,0,0,0/"
                + "70,0,-2,-22,-16,4,44,32/0,0,2,-23,-17,1,46,34/438,0,2,-14,-4,1,28,8/444,138,3,-14,-2,1,4,4;wing0_r,7,-6,-34,13,0.4,-0.35,-0.65/"
                + "284,0,-2,-40,-2,3,40,12/0,138,-2,-40,-2,4,4,13/504,0,0,-37,10,1,34,1;wing0_l,7,6,-34,13,0.4,0.35,0.65/"
                + "!284,0,-2,-40,-2,3,40,12/!0,138,-2,-40,-2,4,4,13/!504,0,0,-37,10,1,34,1;thr_r,7,-11,-22,15,0.35,0,0/228,112,-4,-7,-4,8,14,8/"
                + "380,138,-4,7,-4,7,3,7;flame_r,18,0,10,0,0,0,0/34,138,-2,0,-2,5,12,5;thr_l,7,11,-22,15,0.35,0,0/228,112,-4,-7,-4,8,14,8/"
                + "380,138,-4,7,-4,7,3,7;flame_l,20,0,10,0,0,0,0/34,138,-2,0,-2,5,12,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .wing("hips/torso/wing0_r", -1)
                .wing("hips/torso/wing0_l", 1)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
