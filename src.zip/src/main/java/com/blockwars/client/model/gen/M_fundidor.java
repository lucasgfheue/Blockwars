package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Smelter (fundidor). */
@SuppressWarnings("unused")
public final class M_fundidor {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("fundidor"), "main");

    private M_fundidor() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 142).addBox(-12F, -5F, -8F, 24F, 10F, 16F)
                .texOffs(118, 168).addBox(-13F, -4F, -9F, 26F, 5F, 18F)
                .texOffs(154, 229).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(116, 50).addBox(-5F, 0F, -5F, 10F, 22F, 10F)
                .texOffs(144, 192).addBox(-6F, 2F, -8F, 12F, 15F, 4F)
                .texOffs(206, 168).addBox(-6F, 2F, -5F, 2F, 13F, 10F),
                PartPose.offsetAndRotation(-10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(0, 50).addBox(-6F, 0F, -6F, 12F, 23F, 12F)
                .texOffs(0, 229).addBox(-5F, -5F, -9F, 10F, 8F, 4F)
                .texOffs(52, 214).addBox(-4F, 7F, 6F, 8F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(52, 229).addBox(-4F, -1F, -4F, 7F, 4F, 7F)
                .texOffs(168, 114).addBox(-8F, 3F, -13F, 17F, 6F, 21F)
                .texOffs(218, 229).addBox(-8F, 5F, -14F, 15F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(116, 50).mirror().addBox(-5F, 0F, -5F, 10F, 22F, 10F).mirror(false)
                .texOffs(144, 192).mirror().addBox(-6F, 2F, -8F, 12F, 15F, 4F).mirror(false)
                .texOffs(206, 168).mirror().addBox(4F, 2F, -5F, 2F, 13F, 10F).mirror(false),
                PartPose.offsetAndRotation(10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(0, 50).mirror().addBox(-6F, 0F, -6F, 12F, 23F, 12F).mirror(false)
                .texOffs(0, 229).mirror().addBox(-5F, -5F, -9F, 10F, 8F, 4F).mirror(false)
                .texOffs(52, 214).mirror().addBox(-4F, 7F, 6F, 8F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(52, 229).mirror().addBox(-4F, -1F, -4F, 7F, 4F, 7F).mirror(false)
                .texOffs(168, 114).mirror().addBox(-8F, 3F, -13F, 17F, 6F, 21F).mirror(false)
                .texOffs(218, 229).mirror().addBox(-8F, 5F, -14F, 15F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(88, 114).addBox(-11F, -10F, -8F, 23F, 10F, 17F)
                .texOffs(116, 0).addBox(-19F, -34F, -11F, 38F, 26F, 22F)
                .texOffs(0, 0).addBox(-15F, -32F, -14F, 30F, 22F, 28F)
                .texOffs(0, 85).addBox(-20F, -24F, -12F, 39F, 5F, 24F)
                .texOffs(0, 168).addBox(-13F, -36F, -10F, 27F, 4F, 20F)
                .texOffs(106, 229).addBox(-4F, -28F, -16F, 8F, 8F, 2F)
                .texOffs(160, 214).addBox(-6F, -30F, -15F, 12F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(212, 214).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(168, 85).addBox(-7F, -16F, -8F, 14F, 12F, 16F)
                .texOffs(0, 214).addBox(-6F, -17F, -6F, 12F, 1F, 14F)
                .texOffs(0, 241).addBox(-6F, -12F, -9F, 12F, 3F, 1F)
                .texOffs(26, 241).addBox(-5F, -8F, -9F, 10F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -36F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(44, 192).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(80, 142).addBox(-8F, -9F, -7F, 14F, 12F, 14F)
                .texOffs(84, 192).addBox(-8F, -5F, -8F, 15F, 4F, 15F)
                .texOffs(56, 114).addBox(-4F, 2F, -4F, 8F, 20F, 8F),
                PartPose.offsetAndRotation(-25F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(126, 85).addBox(-5F, 0F, -6F, 10F, 18F, 11F)
                .texOffs(74, 214).addBox(-6F, 17F, -6F, 11F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_gatling = p_forearm_r.addOrReplaceChild("forearm_r_gatling", CubeListBuilder.create()
                .texOffs(0, 114).addBox(-6F, -6F, -14F, 12F, 12F, 16F)
                .texOffs(120, 214).addBox(-4F, -8F, -12F, 8F, 2F, 12F)
                .texOffs(222, 192).addBox(6F, -4F, -8F, 2F, 8F, 8F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gatling_barrel = p_forearm_r_gatling.addOrReplaceChild("forearm_r_gatling_barrel", CubeListBuilder.create()
                .texOffs(0, 192).addBox(3F, -1F, -20F, 2F, 2F, 20F)
                .texOffs(0, 192).addBox(1F, 2F, -20F, 2F, 2F, 20F)
                .texOffs(0, 192).addBox(-3F, 2F, -20F, 2F, 2F, 20F)
                .texOffs(0, 192).addBox(-5F, -1F, -20F, 2F, 2F, 20F)
                .texOffs(0, 192).addBox(-3F, -4F, -20F, 2F, 2F, 20F)
                .texOffs(0, 192).addBox(1F, -4F, -20F, 2F, 2F, 20F)
                .texOffs(186, 214).addBox(-5F, -5F, -4F, 10F, 10F, 3F)
                .texOffs(28, 229).addBox(-5F, -5F, -17F, 10F, 10F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -14F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gatling_flash = p_forearm_r_gatling_barrel.addOrReplaceChild("forearm_r_gatling_flash", CubeListBuilder.create()
                .texOffs(176, 192).addBox(-3F, -3F, -12F, 6F, 6F, 12F)
                .texOffs(168, 229).addBox(-7F, -1F, -4F, 14F, 2F, 3F)
                .texOffs(212, 192).addBox(-1F, -7F, -4F, 2F, 14F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(44, 192).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(80, 142).mirror().addBox(-6F, -9F, -7F, 14F, 12F, 14F).mirror(false)
                .texOffs(84, 192).mirror().addBox(-6F, -5F, -8F, 15F, 4F, 15F).mirror(false)
                .texOffs(56, 114).mirror().addBox(-4F, 2F, -4F, 8F, 20F, 8F).mirror(false),
                PartPose.offsetAndRotation(25F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(126, 85).mirror().addBox(-5F, 0F, -6F, 10F, 18F, 11F).mirror(false)
                .texOffs(74, 214).mirror().addBox(-6F, 17F, -6F, 11F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_hammer = p_forearm_l.addOrReplaceChild("forearm_l_hammer", CubeListBuilder.create()
                .texOffs(236, 0).addBox(-2F, -4F, -2F, 4F, 32F, 4F)
                .texOffs(48, 50).addBox(-7F, 24F, -10F, 14F, 12F, 20F)
                .texOffs(136, 142).addBox(-8F, 28F, -10F, 15F, 4F, 21F)
                .texOffs(80, 229).addBox(-6F, 25F, -11F, 12F, 10F, 1F),
                PartPose.offsetAndRotation(0F, 21F, -2F, -1.2F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(94, 168).addBox(-3F, -17F, -3F, 6F, 18F, 6F)
                .texOffs(126, 229).addBox(-4F, -18F, -4F, 7F, 2F, 7F)
                .texOffs(202, 229).addBox(-2F, -19F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-11F, -32F, 18F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(94, 168).addBox(-3F, -17F, -3F, 6F, 18F, 6F)
                .texOffs(126, 229).addBox(-4F, -18F, -4F, 7F, 2F, 7F)
                .texOffs(202, 229).addBox(-2F, -19F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(11F, -32F, 18F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", 2, 1.2F, 3)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
