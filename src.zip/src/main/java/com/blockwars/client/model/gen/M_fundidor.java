package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Smelter (fundidor). */
@SuppressWarnings("unused")
public final class M_fundidor {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("fundidor"), "main");

    private M_fundidor() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-30,0,0,0,0/0,142,-12,-5,-8,24,10,16/118,168,-13,-4,-9,26,5,18/154,229,-3,-2,-10,6,6,1;thigh_r,-1,-10,-30,0,0,0,0/"
                + "116,50,-5,0,-5,10,22,10/144,192,-6,2,-8,12,15,4/206,168,-6,2,-5,2,13,10;shin_r,1,0,22,0,0,0,0/0,50,-6,0,-6,12,23,12/"
                + "0,229,-5,-5,-9,10,8,4/52,214,-4,7,6,8,12,3;foot_r,2,0,23,0,0,0,0/52,229,-4,-1,-4,7,4,7/168,114,-8,3,-13,17,6,21/"
                + "218,229,-8,5,-14,15,3,1;thigh_l,-1,10,-30,0,0,0,0/!116,50,-5,0,-5,10,22,10/!144,192,-6,2,-8,12,15,4/!206,168,4,2,-5,2,13,10;"
                + "shin_l,4,0,22,0,0,0,0/!0,50,-6,0,-6,12,23,12/!0,229,-5,-5,-9,10,8,4/!52,214,-4,7,6,8,12,3;foot_l,5,0,23,0,0,0,0/"
                + "!52,229,-4,-1,-4,7,4,7/!168,114,-8,3,-13,17,6,21/!218,229,-8,5,-14,15,3,1;torso,0,0,-5,0,0,0,0/88,114,-11,-10,-8,23,10,17/"
                + "116,0,-19,-34,-11,38,26,22/0,0,-15,-32,-14,30,22,28/0,85,-20,-24,-12,39,5,24/0,168,-13,-36,-10,27,4,20/"
                + "106,229,-4,-28,-16,8,8,2/160,214,-6,-30,-15,12,12,1;head,7,0,-36,-2,0,0,0/212,214,-4,-4,-4,8,4,8/168,85,-7,-16,-8,14,12,16/"
                + "0,214,-6,-17,-6,12,1,14/0,241,-6,-12,-9,12,3,1/26,241,-5,-8,-9,10,3,1;shoulder_r,7,-25,-29,0,0,0,0/44,192,-5,-5,-5,10,10,10/"
                + "80,142,-8,-9,-7,14,12,14/84,192,-8,-5,-8,15,4,15/56,114,-4,2,-4,8,20,8;forearm_r,9,0,21,0,-0.25,0,0/126,85,-5,0,-6,10,18,11/"
                + "74,214,-6,17,-6,11,2,12;forearm_r_gatling,10,0,23,-2,0,0,0/0,114,-6,-6,-14,12,12,16/120,214,-4,-8,-12,8,2,12/"
                + "222,192,6,-4,-8,2,8,8;forearm_r_gatling_barrel,11,0,0,-14,0,0,0/0,192,3,-1,-20,2,2,20/0,192,1,2,-20,2,2,20/"
                + "0,192,-3,2,-20,2,2,20/0,192,-5,-1,-20,2,2,20/0,192,-3,-4,-20,2,2,20/0,192,1,-4,-20,2,2,20/186,214,-5,-5,-4,10,10,3/"
                + "28,229,-5,-5,-17,10,10,2;forearm_r_gatling_flash,12,0,0,-20,0,0,0/176,192,-3,-3,-12,6,6,12/168,229,-7,-1,-4,14,2,3/"
                + "212,192,-1,-7,-4,2,14,3;shoulder_l,7,25,-29,0,0,0,0/!44,192,-5,-5,-5,10,10,10/!80,142,-6,-9,-7,14,12,14/"
                + "!84,192,-6,-5,-8,15,4,15/!56,114,-4,2,-4,8,20,8;forearm_l,14,0,21,0,-0.25,0,0/!126,85,-5,0,-6,10,18,11/"
                + "!74,214,-6,17,-6,11,2,12;forearm_l_hammer,15,0,21,-2,-1.2,0,0/236,0,-2,-4,-2,4,32,4/48,50,-7,24,-10,14,12,20/"
                + "136,142,-8,28,-10,15,4,21/80,229,-6,25,-11,12,10,1;stack_r,7,-11,-32,18,-0.15,0,0.1/94,168,-3,-17,-3,6,18,6/"
                + "126,229,-4,-18,-4,7,2,7/202,229,-2,-19,-2,4,1,4;stack_l,7,11,-32,18,-0.15,0,-0.1/94,168,-3,-17,-3,6,18,6/"
                + "126,229,-4,-18,-4,7,2,7/202,229,-2,-19,-2,4,1,4");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", 2, 1.2F, 3)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
