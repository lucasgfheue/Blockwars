package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Penitent (penitente). */
@SuppressWarnings("unused")
public final class M_penitente {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("penitente"), "main");

    private M_penitente() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 131).addBox(-17F, -6F, -9F, 34F, 12F, 18F)
                .texOffs(350, 131).addBox(-18F, -5F, -10F, 37F, 6F, 21F)
                .texOffs(214, 185).addBox(-3F, -2F, -12F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt0 = p_hips.addOrReplaceChild("skirt0", CubeListBuilder.create()
                .texOffs(234, 161).addBox(-15F, 0F, -1F, 30F, 16F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -11F, -0.15F, 0F, 0F));
        PartDefinition p_skirt1 = p_hips.addOrReplaceChild("skirt1", CubeListBuilder.create()
                .texOffs(234, 161).addBox(-15F, 0F, -1F, 30F, 16F, 2F),
                PartPose.offsetAndRotation(0F, 0F, 11F, 0.15F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(114, 92).addBox(-8F, 0F, -8F, 16F, 22F, 16F)
                .texOffs(48, 161).addBox(-9F, 2F, -12F, 18F, 15F, 5F)
                .texOffs(194, 131).addBox(-9F, 2F, -8F, 2F, 13F, 16F),
                PartPose.offsetAndRotation(-15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(364, 0).addBox(-9F, 0F, -9F, 18F, 23F, 18F)
                .texOffs(22, 185).addBox(-8F, -6F, -13F, 16F, 9F, 5F)
                .texOffs(470, 161).addBox(-7F, 7F, 9F, 14F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(388, 161).addBox(-6F, -1F, -6F, 11F, 5F, 11F)
                .texOffs(0, 92).addBox(-13F, 3F, -19F, 25F, 7F, 32F)
                .texOffs(290, 185).addBox(-12F, 6F, -20F, 23F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(114, 92).mirror().addBox(-8F, 0F, -8F, 16F, 22F, 16F).mirror(false)
                .texOffs(48, 161).mirror().addBox(-9F, 2F, -12F, 18F, 15F, 5F).mirror(false)
                .texOffs(194, 131).mirror().addBox(7F, 2F, -8F, 2F, 13F, 16F).mirror(false),
                PartPose.offsetAndRotation(15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(364, 0).mirror().addBox(-9F, 0F, -9F, 18F, 23F, 18F).mirror(false)
                .texOffs(22, 185).mirror().addBox(-8F, -6F, -13F, 16F, 9F, 5F).mirror(false)
                .texOffs(470, 161).mirror().addBox(-7F, 7F, 9F, 14F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(388, 161).mirror().addBox(-6F, -1F, -6F, 11F, 5F, 11F).mirror(false)
                .texOffs(0, 92).mirror().addBox(-13F, 3F, -19F, 25F, 7F, 32F).mirror(false)
                .texOffs(290, 185).mirror().addBox(-12F, 6F, -20F, 23F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(104, 131).addBox(-14F, -12F, -8F, 28F, 12F, 17F)
                .texOffs(184, 0).addBox(-25F, -41F, -14F, 51F, 32F, 28F)
                .texOffs(94, 161).addBox(-18F, -34F, -15F, 35F, 18F, 1F)
                .texOffs(230, 131).addBox(-19F, -40F, -11F, 38F, 5F, 22F)
                .texOffs(128, 185).addBox(-15F, -27F, 14F, 30F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(64, 185).addBox(-5F, -5F, -5F, 9F, 5F, 9F)
                .texOffs(178, 92).addBox(-8F, -21F, -9F, 16F, 16F, 18F)
                .texOffs(298, 161).addBox(-9F, -21F, -10F, 17F, 16F, 1F)
                .texOffs(338, 185).addBox(-6F, -14F, -10F, 12F, 2F, 1F)
                .texOffs(364, 185).addBox(-5F, -13F, -11F, 9F, 1F, 1F)
                .texOffs(432, 161).addBox(-2F, -22F, -5F, 5F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -41F, -2F, 0F, 0F, 0F));
        PartDefinition p_crest = p_head.addOrReplaceChild("crest", CubeListBuilder.create()
                .texOffs(466, 131).addBox(-1F, -18F, -3F, 2F, 18F, 7F)
                .texOffs(18, 185).addBox(-1F, -16F, -4F, 1F, 14F, 1F),
                PartPose.offsetAndRotation(0F, -18F, -2F, -0.8F, 0F, 0F));
        PartDefinition p_xhorn_r = p_head.addOrReplaceChild("xhorn_r", CubeListBuilder.create()
                .texOffs(100, 185).addBox(-1F, -1F, 0F, 2F, 2F, 12F),
                PartPose.offsetAndRotation(-8F, -14F, 2F, 0.5F, -0.6F, 0F));
        PartDefinition p_xhorn_l = p_head.addOrReplaceChild("xhorn_l", CubeListBuilder.create()
                .texOffs(100, 185).mirror().addBox(-1F, -1F, 0F, 2F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(8F, -14F, 2F, 0.5F, 0.6F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(0, 161).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(296, 92).addBox(-12F, -12F, -10F, 18F, 12F, 21F)
                .texOffs(166, 161).addBox(-10F, -13F, -9F, 16F, 1F, 18F)
                .texOffs(374, 92).addBox(-5F, 2F, -5F, 9F, 23F, 9F),
                PartPose.offsetAndRotation(-32F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_r0 = p_shoulder_r.addOrReplaceChild("sspike_r0", CubeListBuilder.create()
                .texOffs(0, 185).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-5F, -12F, -5F, 0F, 0F, -0.3F));
        PartDefinition p_sspike_r4 = p_shoulder_r.addOrReplaceChild("sspike_r4", CubeListBuilder.create()
                .texOffs(0, 185).addBox(-2F, -12F, -2F, 3F, 12F, 3F),
                PartPose.offsetAndRotation(-5F, -12F, 5F, 0F, 0F, -0.3F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(246, 92).addBox(-6F, 0F, -6F, 12F, 21F, 13F)
                .texOffs(334, 161).addBox(-6F, 20F, -7F, 13F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_blade = p_forearm_r.addOrReplaceChild("forearm_r_blade", CubeListBuilder.create()
                .texOffs(190, 185).addBox(-2F, -7F, -2F, 3F, 9F, 3F)
                .texOffs(230, 185).addBox(-6F, 2F, -2F, 12F, 2F, 5F)
                .texOffs(164, 0).addBox(-1F, 3F, -4F, 2F, 55F, 8F),
                PartPose.offsetAndRotation(0F, 24F, -2F, -1.15F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(0, 161).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(296, 92).mirror().addBox(-7F, -12F, -10F, 18F, 12F, 21F).mirror(false)
                .texOffs(166, 161).mirror().addBox(-6F, -13F, -9F, 16F, 1F, 18F).mirror(false)
                .texOffs(374, 92).mirror().addBox(-5F, 2F, -5F, 9F, 23F, 9F).mirror(false),
                PartPose.offsetAndRotation(32F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_sspike_l0 = p_shoulder_l.addOrReplaceChild("sspike_l0", CubeListBuilder.create()
                .texOffs(0, 185).mirror().addBox(-2F, -12F, -2F, 3F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(5F, -12F, -5F, 0F, 0F, 0.3F));
        PartDefinition p_sspike_l4 = p_shoulder_l.addOrReplaceChild("sspike_l4", CubeListBuilder.create()
                .texOffs(0, 185).mirror().addBox(-2F, -12F, -2F, 3F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(5F, -12F, 5F, 0F, 0F, 0.3F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(246, 92).mirror().addBox(-6F, 0F, -6F, 12F, 21F, 13F).mirror(false)
                .texOffs(334, 161).mirror().addBox(-6F, 20F, -7F, 13F, 2F, 14F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_shield = p_forearm_l.addOrReplaceChild("forearm_l_shield", CubeListBuilder.create()
                .texOffs(80, 0).addBox(-2F, -25F, -18F, 5F, 51F, 37F)
                .texOffs(0, 0).addBox(2F, -26F, -20F, 1F, 53F, 39F)
                .texOffs(436, 0).addBox(3F, -16F, -5F, 1F, 32F, 9F)
                .texOffs(202, 185).addBox(3F, -16F, -2F, 1F, 5F, 5F),
                PartPose.offsetAndRotation(8F, 10F, -5F, 0F, 0F, 0F));
        PartDefinition p_cape0 = p_torso.addOrReplaceChild("cape0", CubeListBuilder.create()
                .texOffs(342, 0).addBox(-5F, 0F, 0F, 9F, 41F, 2F)
                .texOffs(264, 185).addBox(-5F, 39F, -1F, 10F, 2F, 3F)
                .texOffs(12, 185).addBox(-1F, 7F, 2F, 2F, 14F, 1F),
                PartPose.offsetAndRotation(-9F, -37F, 16F, 0.12F, 0F, -0.08F));
        PartDefinition p_cape1 = p_torso.addOrReplaceChild("cape1", CubeListBuilder.create()
                .texOffs(342, 0).addBox(-5F, 0F, 0F, 9F, 41F, 2F)
                .texOffs(264, 185).addBox(-5F, 39F, -1F, 10F, 2F, 3F)
                .texOffs(12, 185).addBox(-1F, 7F, 2F, 2F, 14F, 1F),
                PartPose.offsetAndRotation(0F, -37F, 16F, 0.12F, 0F, 0F));
        PartDefinition p_cape2 = p_torso.addOrReplaceChild("cape2", CubeListBuilder.create()
                .texOffs(342, 0).addBox(-5F, 0F, 0F, 9F, 41F, 2F)
                .texOffs(264, 185).addBox(-5F, 39F, -1F, 10F, 2F, 3F)
                .texOffs(12, 185).addBox(-1F, 7F, 2F, 2F, 14F, 1F),
                PartPose.offsetAndRotation(9F, -37F, 16F, 0.12F, 0F, 0.08F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.287F)
                .legLengths(10.925F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/cape0", 0, 0.06F, 0F)
                .sway("hips/torso/cape1", 0, 0.06F, 1.1F)
                .sway("hips/torso/cape2", 0, 0.06F, 2.2F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null);
    }
}
