package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Hive (colmena). */
@SuppressWarnings("unused")
public final class M_colmena {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("colmena"), "main");

    private M_colmena() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 66).addBox(-20F, -20F, -26F, 40F, 20F, 35F),
                PartPose.offsetAndRotation(0F, 9F, 0F, 0F, 0F, 0F));
        PartDefinition p_abdomen = p_body.addOrReplaceChild("abdomen", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-18F, -18F, 0F, 35F, 26F, 40F)
                .texOffs(134, 121).addBox(-13F, -19F, 4F, 26F, 1F, 31F)
                .texOffs(0, 214).addBox(-7F, -9F, 40F, 13F, 9F, 1F),
                PartPose.offsetAndRotation(0F, -11F, 9F, -0.25F, 0F, 0F));
        PartDefinition p_hip_r0 = root.addOrReplaceChild("hip_r0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-20F, 9F, -22F, 0F, -0.5F, 0F));
        PartDefinition p_leg_r0 = p_hip_r0.addOrReplaceChild("leg_r0", CubeListBuilder.create()
                .texOffs(96, 121).addBox(-4F, 0F, -5F, 9F, 29F, 10F)
                .texOffs(56, 192).addBox(-6F, -1F, -6F, 11F, 7F, 12F),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r0 = p_leg_r0.addOrReplaceChild("shin_r0", CubeListBuilder.create()
                .texOffs(150, 66).addBox(-3F, 0F, -3F, 7F, 42F, 7F)
                .texOffs(180, 165).addBox(-4F, 5F, -4F, 8F, 15F, 8F)
                .texOffs(56, 214).addBox(-2F, 38F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l0 = root.addOrReplaceChild("hip_l0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(20F, 9F, -22F, 0F, 0.5F, 0F));
        PartDefinition p_leg_l0 = p_hip_l0.addOrReplaceChild("leg_l0", CubeListBuilder.create()
                .texOffs(96, 121).mirror().addBox(-4F, 0F, -5F, 9F, 29F, 10F).mirror(false)
                .texOffs(56, 192).mirror().addBox(-6F, -1F, -6F, 11F, 7F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l0 = p_leg_l0.addOrReplaceChild("shin_l0", CubeListBuilder.create()
                .texOffs(150, 66).mirror().addBox(-3F, 0F, -3F, 7F, 42F, 7F).mirror(false)
                .texOffs(180, 165).mirror().addBox(-4F, 5F, -4F, 8F, 15F, 8F).mirror(false)
                .texOffs(56, 214).mirror().addBox(-2F, 38F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r1 = root.addOrReplaceChild("hip_r1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-20F, 9F, -9F, 0F, 0F, 0F));
        PartDefinition p_leg_r1 = p_hip_r1.addOrReplaceChild("leg_r1", CubeListBuilder.create()
                .texOffs(96, 121).addBox(-4F, 0F, -5F, 9F, 29F, 10F)
                .texOffs(56, 192).addBox(-6F, -1F, -6F, 11F, 7F, 12F),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r1 = p_leg_r1.addOrReplaceChild("shin_r1", CubeListBuilder.create()
                .texOffs(150, 66).addBox(-3F, 0F, -3F, 7F, 42F, 7F)
                .texOffs(180, 165).addBox(-4F, 5F, -4F, 8F, 15F, 8F)
                .texOffs(56, 214).addBox(-2F, 38F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l1 = root.addOrReplaceChild("hip_l1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(20F, 9F, -9F, 0F, 0F, 0F));
        PartDefinition p_leg_l1 = p_hip_l1.addOrReplaceChild("leg_l1", CubeListBuilder.create()
                .texOffs(96, 121).mirror().addBox(-4F, 0F, -5F, 9F, 29F, 10F).mirror(false)
                .texOffs(56, 192).mirror().addBox(-6F, -1F, -6F, 11F, 7F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l1 = p_leg_l1.addOrReplaceChild("shin_l1", CubeListBuilder.create()
                .texOffs(150, 66).mirror().addBox(-3F, 0F, -3F, 7F, 42F, 7F).mirror(false)
                .texOffs(180, 165).mirror().addBox(-4F, 5F, -4F, 8F, 15F, 8F).mirror(false)
                .texOffs(56, 214).mirror().addBox(-2F, 38F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r2 = root.addOrReplaceChild("hip_r2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-20F, 9F, 4F, 0F, 0.5F, 0F));
        PartDefinition p_leg_r2 = p_hip_r2.addOrReplaceChild("leg_r2", CubeListBuilder.create()
                .texOffs(96, 121).addBox(-4F, 0F, -5F, 9F, 29F, 10F)
                .texOffs(56, 192).addBox(-6F, -1F, -6F, 11F, 7F, 12F),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r2 = p_leg_r2.addOrReplaceChild("shin_r2", CubeListBuilder.create()
                .texOffs(150, 66).addBox(-3F, 0F, -3F, 7F, 42F, 7F)
                .texOffs(180, 165).addBox(-4F, 5F, -4F, 8F, 15F, 8F)
                .texOffs(56, 214).addBox(-2F, 38F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l2 = root.addOrReplaceChild("hip_l2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(20F, 9F, 4F, 0F, -0.5F, 0F));
        PartDefinition p_leg_l2 = p_hip_l2.addOrReplaceChild("leg_l2", CubeListBuilder.create()
                .texOffs(96, 121).mirror().addBox(-4F, 0F, -5F, 9F, 29F, 10F).mirror(false)
                .texOffs(56, 192).mirror().addBox(-6F, -1F, -6F, 11F, 7F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l2 = p_leg_l2.addOrReplaceChild("shin_l2", CubeListBuilder.create()
                .texOffs(150, 66).mirror().addBox(-3F, 0F, -3F, 7F, 42F, 7F).mirror(false)
                .texOffs(180, 165).mirror().addBox(-4F, 5F, -4F, 8F, 15F, 8F).mirror(false)
                .texOffs(56, 214).mirror().addBox(-2F, 38F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(204, 192).addBox(-4F, -2F, -4F, 9F, 2F, 9F)
                .texOffs(0, 192).addBox(-8F, -11F, -7F, 15F, 9F, 13F)
                .texOffs(28, 214).addBox(-7F, -10F, -7F, 13F, 7F, 1F)
                .texOffs(72, 214).addBox(-6F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(72, 214).addBox(-2F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(72, 214).addBox(3F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(144, 192).addBox(-8F, -12F, -7F, 16F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -11F, -26F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(176, 165).addBox(-1F, -26F, -1F, 1F, 26F, 1F)
                .texOffs(80, 214).addBox(-1F, -28F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(96, 165).addBox(-10F, -7F, -10F, 20F, 7F, 20F),
                PartPose.offsetAndRotation(0F, -22F, -2F, 0F, 0F, 0F));
        PartDefinition p_turret_pod = p_turret.addOrReplaceChild("turret_pod", CubeListBuilder.create()
                .texOffs(0, 121).addBox(-11F, -18F, -13F, 22F, 18F, 26F)
                .texOffs(0, 165).addBox(-11F, -19F, -13F, 22F, 1F, 26F)
                .texOffs(102, 192).addBox(-10F, -16F, -14F, 20F, 15F, 1F),
                PartPose.offsetAndRotation(0F, -11F, -4F, 0F, 0F, 0F));
        PartDefinition p_body_pod = p_body.addOrReplaceChild("body_pod", CubeListBuilder.create()
                .texOffs(0, 121).addBox(-11F, -18F, -13F, 22F, 18F, 26F)
                .texOffs(0, 165).addBox(-11F, -19F, -13F, 22F, 1F, 26F)
                .texOffs(102, 192).addBox(-10F, -16F, -14F, 20F, 15F, 1F),
                PartPose.offsetAndRotation(0F, -20F, 29F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4545F)
                .legLengths(14.3F, 20.9F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/abdomen", 0, 0.04F, 0F)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.POD, "body/body_pod", null, null, null)
                .secondary(Rig.MountKind.POD, "body/body_pod", null, null, null);
    }
}
