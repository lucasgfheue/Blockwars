package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Hive (colmena). */
@SuppressWarnings("unused")
public final class M_colmena {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("colmena"), "main");

    private M_colmena() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "body,-1,0,9,0,0,0,0/0,66,-20,-20,-26,40,20,35;abdomen,0,0,-11,9,-0.25,0,0/0,0,-18,-18,0,35,26,40/134,121,-13,-19,4,26,1,31/"
                + "0,214,-7,-9,40,13,9,1;hip_r0,-1,-20,9,-22,0,-0.5,0;leg_r0,2,0,-9,0,0,0,2.15/96,121,-4,0,-5,9,29,10/56,192,-6,-1,-6,11,7,12;"
                + "shin_r0,3,0,29,0,0,0,-1.75/150,66,-3,0,-3,7,42,7/180,165,-4,5,-4,8,15,8/56,214,-2,38,-2,4,4,4;hip_l0,-1,20,9,-22,0,0.5,0;"
                + "leg_l0,5,0,-9,0,0,0,-2.15/!96,121,-4,0,-5,9,29,10/!56,192,-6,-1,-6,11,7,12;shin_l0,6,0,29,0,0,0,1.75/"
                + "!150,66,-3,0,-3,7,42,7/!180,165,-4,5,-4,8,15,8/!56,214,-2,38,-2,4,4,4;hip_r1,-1,-20,9,-9,0,0,0;leg_r1,8,0,-9,0,0,0,2.15/"
                + "96,121,-4,0,-5,9,29,10/56,192,-6,-1,-6,11,7,12;shin_r1,9,0,29,0,0,0,-1.75/150,66,-3,0,-3,7,42,7/180,165,-4,5,-4,8,15,8/"
                + "56,214,-2,38,-2,4,4,4;hip_l1,-1,20,9,-9,0,0,0;leg_l1,11,0,-9,0,0,0,-2.15/!96,121,-4,0,-5,9,29,10/!56,192,-6,-1,-6,11,7,12;"
                + "shin_l1,12,0,29,0,0,0,1.75/!150,66,-3,0,-3,7,42,7/!180,165,-4,5,-4,8,15,8/!56,214,-2,38,-2,4,4,4;hip_r2,-1,-20,9,4,0,0.5,0;"
                + "leg_r2,14,0,-9,0,0,0,2.15/96,121,-4,0,-5,9,29,10/56,192,-6,-1,-6,11,7,12;shin_r2,15,0,29,0,0,0,-1.75/"
                + "150,66,-3,0,-3,7,42,7/180,165,-4,5,-4,8,15,8/56,214,-2,38,-2,4,4,4;hip_l2,-1,20,9,4,0,-0.5,0;leg_l2,17,0,-9,0,0,0,-2.15/"
                + "!96,121,-4,0,-5,9,29,10/!56,192,-6,-1,-6,11,7,12;shin_l2,18,0,29,0,0,0,1.75/!150,66,-3,0,-3,7,42,7/!180,165,-4,5,-4,8,15,8/"
                + "!56,214,-2,38,-2,4,4,4;head,0,0,-11,-26,0,0,0/204,192,-4,-2,-4,9,2,9/0,192,-8,-11,-7,15,9,13/28,214,-7,-10,-7,13,7,1/"
                + "72,214,-6,-8,-8,3,3,1/72,214,-2,-8,-8,3,3,1/72,214,3,-8,-8,3,3,1/144,192,-8,-12,-7,16,1,14;antenna,20,6,-13,4,-0.2,0,0.15/"
                + "176,165,-1,-26,-1,1,26,1/80,214,-1,-28,-1,2,2,2;turret,0,0,-22,-2,0,0,0/96,165,-10,-7,-10,20,7,20;turret_pod,22,0,-11,-4,0,0,0/"
                + "0,121,-11,-18,-13,22,18,26/0,165,-11,-19,-13,22,1,26/102,192,-10,-16,-14,20,15,1;body_pod,0,0,-20,29,0,0,0/"
                + "0,121,-11,-18,-13,22,18,26/0,165,-11,-19,-13,22,1,26/102,192,-10,-16,-14,20,15,1");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4545F)
                .legLengths(14.3F, 20.9F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/abdomen", 0, 0.04F, 0F)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.POD, "body/body_pod", null, null, null)
                .secondary(Rig.MountKind.POD, "body/body_pod", null, null, null);
    }
}
