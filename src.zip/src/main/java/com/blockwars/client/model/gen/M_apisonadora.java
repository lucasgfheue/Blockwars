package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Roadroller (apisonadora). */
@SuppressWarnings("unused")
public final class M_apisonadora {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("apisonadora"), "main");

    private M_apisonadora() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 106).addBox(-41F, -40F, -35F, 82F, 17F, 69F)
                .texOffs(0, 276).addBox(-22F, -43F, -22F, 43F, 5F, 49F)
                .texOffs(0, 192).addBox(-22F, -24F, -33F, 43F, 19F, 65F)
                .texOffs(182, 421).addBox(-38F, -35F, -36F, 77F, 7F, 1F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-10F, -12F, -41F, 19F, 24F, 82F)
                .texOffs(202, 0).addBox(-11F, -18F, -42F, 22F, 6F, 84F),
                PartPose.offsetAndRotation(-31F, -12F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(166, 368).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(168, 421).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, -29F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(166, 368).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(168, 421).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, -10F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(166, 368).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(168, 421).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, 10F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(166, 368).addBox(-1F, -7F, -7F, 1F, 14F, 14F)
                .texOffs(168, 421).addBox(-1F, -2F, -2F, 2F, 5F, 5F),
                PartPose.offsetAndRotation(-10F, 2F, 29F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-10F, -12F, -41F, 19F, 24F, 82F).mirror(false)
                .texOffs(202, 0).mirror().addBox(-11F, -18F, -42F, 22F, 6F, 84F).mirror(false),
                PartPose.offsetAndRotation(31F, -12F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(166, 368).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(168, 421).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, -29F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(166, 368).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(168, 421).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, -10F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(166, 368).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(168, 421).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, 10F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(166, 368).mirror().addBox(-1F, -7F, -7F, 1F, 14F, 14F).mirror(false)
                .texOffs(168, 421).mirror().addBox(-1F, -2F, -2F, 2F, 5F, 5F).mirror(false),
                PartPose.offsetAndRotation(10F, 2F, 29F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hull.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(86, 368).addBox(-12F, -12F, -8F, 24F, 12F, 16F)
                .texOffs(348, 192).addBox(-17F, -38F, -13F, 35F, 29F, 26F)
                .texOffs(228, 276).addBox(-22F, -35F, -11F, 43F, 22F, 21F)
                .texOffs(196, 368).addBox(-22F, -15F, -11F, 44F, 3F, 22F)
                .texOffs(196, 368).addBox(-22F, -28F, -11F, 44F, 3F, 22F)
                .texOffs(338, 421).addBox(-13F, -23F, -15F, 7F, 7F, 1F)
                .texOffs(180, 434).addBox(4F, -20F, -15F, 10F, 5F, 1F)
                .texOffs(0, 398).addBox(-13F, -37F, -9F, 26F, 5F, 18F)
                .texOffs(0, 421).addBox(-13F, -25F, 13F, 26F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -41F, 5F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(188, 398).addBox(-7F, -5F, -7F, 14F, 5F, 14F)
                .texOffs(376, 276).addBox(-12F, -22F, -10F, 24F, 17F, 22F)
                .texOffs(128, 421).addBox(-10F, -19F, -10F, 19F, 10F, 1F)
                .texOffs(472, 368).addBox(-13F, -19F, -6F, 1F, 10F, 14F)
                .texOffs(472, 368).addBox(12F, -19F, -6F, 1F, 10F, 14F)
                .texOffs(328, 368).addBox(-13F, -23F, -10F, 25F, 1F, 23F)
                .texOffs(214, 434).addBox(-12F, -7F, -10F, 24F, 2F, 1F)
                .texOffs(264, 434).addBox(-10F, -24F, -8F, 2F, 1F, 2F)
                .texOffs(264, 434).addBox(7F, -24F, -8F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -38F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(424, 368).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(82, 330).addBox(-12F, -12F, -11F, 19F, 12F, 22F)
                .texOffs(116, 398).addBox(-11F, -13F, -10F, 17F, 1F, 19F)
                .texOffs(214, 330).addBox(-5F, 2F, -5F, 10F, 22F, 10F),
                PartPose.offsetAndRotation(-29F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(164, 330).addBox(-6F, 0F, -7F, 12F, 19F, 13F)
                .texOffs(336, 398).addBox(-7F, 18F, -7F, 13F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_hammer = p_forearm_r.addOrReplaceChild("forearm_r_hammer", CubeListBuilder.create()
                .texOffs(356, 276).addBox(-2F, -5F, -2F, 5F, 38F, 5F)
                .texOffs(0, 330).addBox(-8F, 29F, -12F, 17F, 14F, 24F)
                .texOffs(0, 368).addBox(-9F, 34F, -13F, 18F, 5F, 25F)
                .texOffs(54, 421).addBox(-7F, 30F, -13F, 14F, 12F, 1F),
                PartPose.offsetAndRotation(0F, 23F, -2F, -1.2F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(424, 368).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(82, 330).mirror().addBox(-7F, -12F, -11F, 19F, 12F, 22F).mirror(false)
                .texOffs(116, 398).mirror().addBox(-6F, -13F, -10F, 17F, 1F, 19F).mirror(false)
                .texOffs(214, 330).mirror().addBox(-5F, 2F, -5F, 10F, 22F, 10F).mirror(false),
                PartPose.offsetAndRotation(29F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(164, 330).mirror().addBox(-6F, 0F, -7F, 12F, 19F, 13F).mirror(false)
                .texOffs(336, 398).mirror().addBox(-7F, 18F, -7F, 13F, 2F, 14F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_none = p_forearm_l.addOrReplaceChild("forearm_l_none", CubeListBuilder.create()
                .texOffs(296, 398).addBox(-5F, 0F, -5F, 10F, 7F, 10F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_exhaust = p_torso.addOrReplaceChild("exhaust", CubeListBuilder.create()
                .texOffs(184, 276).addBox(-5F, -36F, -5F, 11F, 38F, 11F)
                .texOffs(390, 398).addBox(-6F, -8F, -6F, 12F, 2F, 12F)
                .texOffs(390, 398).addBox(-6F, -28F, -6F, 12F, 2F, 12F)
                .texOffs(244, 398).addBox(-7F, -39F, -7F, 13F, 4F, 13F),
                PartPose.offsetAndRotation(11F, -38F, 20F, 0F, 0F, 0F));
        PartDefinition p_flame_exh = p_exhaust.addOrReplaceChild("flame_exh", CubeListBuilder.create()
                .texOffs(88, 398).addBox(-4F, 0F, -4F, 7F, 14F, 7F),
                PartPose.offsetAndRotation(0F, -38F, 0F, 3.1416F, 0F, 0F));
        PartDefinition p_beacon = p_torso.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(108, 421).addBox(-2F, -1F, -2F, 5F, 7F, 5F)
                .texOffs(438, 398).addBox(-4F, -7F, -4F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(-13F, -43F, 13F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(202, 434).addBox(-2F, -2F, -4F, 5F, 5F, 1F)
                .texOffs(202, 434).addBox(-2F, -2F, 3F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        PartDefinition p_plow = p_hull.addOrReplaceChild("plow", CubeListBuilder.create()
                .texOffs(254, 330).addBox(-46F, -13F, -2F, 91F, 26F, 5F)
                .texOffs(0, 434).addBox(-44F, -13F, -4F, 89F, 5F, 1F)
                .texOffs(84, 421).addBox(-36F, 11F, -6F, 5F, 5F, 7F)
                .texOffs(84, 421).addBox(-19F, 11F, -6F, 5F, 5F, 7F)
                .texOffs(84, 421).addBox(-2F, 11F, -6F, 5F, 5F, 7F)
                .texOffs(84, 421).addBox(14F, 11F, -6F, 5F, 5F, 7F)
                .texOffs(84, 421).addBox(31F, 11F, -6F, 5F, 5F, 7F),
                PartPose.offsetAndRotation(0F, -14F, -46F, 0.15F, 0F, 0F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(216, 192).addBox(-1F, -7F, -33F, 1F, 14F, 65F),
                PartPose.offsetAndRotation(-43F, -22F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(216, 192).mirror().addBox(-1F, -7F, -33F, 1F, 14F, 65F).mirror(false),
                PartPose.offsetAndRotation(43F, -22F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/torso", "hull/torso/head").walkRate(0F)
                .arm("hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r", -1, false)
                .arm("hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l", 1, false)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .flame("hull/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hull/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hull/torso/shoulder_r", null, null, null);
    }
}
