package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Blockhouse (fortin). */
@SuppressWarnings("unused")
public final class M_fortin {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("fortin"), "main");

    private M_fortin() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-34,0,0,0,0/144,136,-18,-6,-10,36,12,19/126,169,-19,-5,-11,38,6,22/328,217,-4,-2,-12,7,7,1;"
                + "skirt0,0,0,0,-11,-0.15,0,0/254,197,-16,0,-1,31,17,2;skirt1,0,0,0,11,0.15,0,0/254,197,-16,0,-1,31,17,2;"
                + "thigh_r,-1,-16,-34,0,0,0,0/118,96,-8,0,-8,17,23,17/346,169,-10,2,-12,19,16,5/254,136,-10,2,-8,2,14,17;"
                + "shin_r,3,0,23,0,0,0,0/356,0,-10,0,-10,19,24,19/68,217,-8,-6,-13,17,10,5/0,217,-7,7,10,14,12,4;foot_r,4,0,24,0,0,0,0/"
                + "358,197,-6,-1,-6,12,5,12/0,96,-13,4,-20,26,7,33/406,217,-12,6,-21,24,4,1;thigh_l,-1,16,-34,0,0,0,0/!118,96,-8,0,-8,17,23,17/"
                + "!346,169,-10,2,-12,19,16,5/!254,136,7,2,-8,2,14,17;shin_l,6,0,23,0,0,0,0/!356,0,-10,0,-10,19,24,19/!68,217,-8,-6,-13,17,10,5/"
                + "!0,217,-7,7,10,14,12,4;foot_l,7,0,24,0,0,0,0/!358,197,-6,-1,-6,12,5,12/!0,96,-13,4,-20,26,7,33/!406,217,-12,6,-21,24,4,1;"
                + "torso,0,0,-6,0,0,0,0/296,136,-15,-12,-9,29,12,17/170,0,-26,-43,-14,53,34,29/178,197,-18,-36,-16,37,18,1/"
                + "0,169,-20,-42,-12,40,5,23/190,217,-16,-28,14,32,13,1;head,9,0,-43,-2,0,0,0/112,217,-5,-5,-5,10,5,10/186,96,-8,-22,-10,17,17,19/"
                + "320,197,-9,-22,-10,18,17,1/0,233,-6,-14,-11,12,2,1/26,233,-5,-14,-11,10,1,1/152,217,-2,-23,-5,5,1,14;"
                + "antenna,10,6,-14,5,-0.2,0,0.15/292,136,-1,-29,-1,1,29,1/456,217,-1,-30,-1,2,2,2;shoulder_r,9,-34,-35,0,0,0,0/"
                + "298,169,-6,-6,-6,12,12,12/308,96,-12,-12,-11,19,12,22/0,197,-11,-13,-10,17,1,19/390,96,-5,2,-5,10,24,10;"
                + "forearm_r,12,0,25,0,-0.25,0,0/258,96,-6,0,-7,12,22,13/406,197,-7,20,-7,13,2,14;forearm_r_gatling,13,0,28,-2,0,0,0/"
                + "78,136,-7,-7,-17,14,14,19/460,197,-5,-10,-14,10,2,14/72,197,7,-5,-10,2,10,10;forearm_r_gatling_barrel,14,0,0,-17,0,0,0/"
                + "246,169,3,-1,-24,2,2,24/246,169,1,3,-24,2,2,24/246,169,-3,3,-24,2,2,24/246,169,-6,-1,-24,2,2,24/246,169,-3,-5,-24,2,2,24/"
                + "246,169,1,-5,-24,2,2,24/36,217,-6,-6,-4,12,12,4/256,217,-6,-6,-20,12,12,2;forearm_r_gatling_flash,15,0,0,-24,0,0,0/"
                + "394,169,-4,-4,-14,7,7,14/344,217,-8,-1,-4,17,2,4/436,169,-1,-8,-4,2,17,4;shoulder_l,9,34,-35,0,0,0,0/"
                + "!298,169,-6,-6,-6,12,12,12/!308,96,-7,-12,-11,19,12,22/!0,197,-6,-13,-10,17,1,19/!390,96,-5,2,-5,10,24,10;"
                + "forearm_l,17,0,25,0,-0.25,0,0/!258,96,-6,0,-7,12,22,13/!406,197,-7,20,-7,13,2,14;forearm_l_shield,18,8,11,-5,0,0,0/"
                + "84,0,-2,-26,-19,5,53,38/0,0,2,-28,-20,1,55,41/334,0,3,-17,-5,1,34,10/316,217,3,-17,-2,1,5,5;cargo0,9,-12,-31,24,0,0,0/"
                + "430,96,-11,-8,-8,22,16,17/464,217,-10,-1,-9,20,2,1/96,197,-12,-9,-9,23,1,18;cargo1,9,12,-31,24,0,0,0/"
                + "430,96,-11,-8,-8,22,16,17/464,217,-10,-1,-9,20,2,1/96,197,-12,-9,-9,23,1,18;cargo2,9,0,-48,24,0,0,0/0,136,-11,-8,-8,22,16,17/"
                + "464,217,-10,-1,-9,20,2,1/96,197,-12,-9,-9,23,1,18;stack_r,9,-16,-38,19,-0.15,0,0.1/388,136,-4,-20,-4,7,22,7/"
                + "284,217,-4,-22,-4,8,2,8/386,217,-2,-23,-2,5,1,5;stack_l,9,16,-38,19,-0.15,0,-0.1/388,136,-4,-20,-4,7,22,7/"
                + "284,217,-4,-22,-4,8,2,8/386,217,-2,-23,-2,5,1,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.275F)
                .legLengths(11.4F, 12F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", 2, 1.2F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null);
    }
}
