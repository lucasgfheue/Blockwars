package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Blockhouse (fortin). */
@SuppressWarnings("unused")
public final class M_fortin {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("fortin"), "main");

    private M_fortin() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(144, 136).addBox(-18F, -6F, -10F, 36F, 12F, 19F)
                .texOffs(126, 169).addBox(-19F, -5F, -11F, 38F, 6F, 22F)
                .texOffs(328, 217).addBox(-4F, -2F, -12F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -34F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt0 = p_hips.addOrReplaceChild("skirt0", CubeListBuilder.create()
                .texOffs(254, 197).addBox(-16F, 0F, -1F, 31F, 17F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -11F, -0.15F, 0F, 0F));
        PartDefinition p_skirt1 = p_hips.addOrReplaceChild("skirt1", CubeListBuilder.create()
                .texOffs(254, 197).addBox(-16F, 0F, -1F, 31F, 17F, 2F),
                PartPose.offsetAndRotation(0F, 0F, 11F, 0.15F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(118, 96).addBox(-8F, 0F, -8F, 17F, 23F, 17F)
                .texOffs(346, 169).addBox(-10F, 2F, -12F, 19F, 16F, 5F)
                .texOffs(254, 136).addBox(-10F, 2F, -8F, 2F, 14F, 17F),
                PartPose.offsetAndRotation(-16F, -34F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(356, 0).addBox(-10F, 0F, -10F, 19F, 24F, 19F)
                .texOffs(68, 217).addBox(-8F, -6F, -13F, 17F, 10F, 5F)
                .texOffs(0, 217).addBox(-7F, 7F, 10F, 14F, 12F, 4F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(358, 197).addBox(-6F, -1F, -6F, 12F, 5F, 12F)
                .texOffs(0, 96).addBox(-13F, 4F, -20F, 26F, 7F, 33F)
                .texOffs(406, 217).addBox(-12F, 6F, -21F, 24F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(118, 96).mirror().addBox(-8F, 0F, -8F, 17F, 23F, 17F).mirror(false)
                .texOffs(346, 169).mirror().addBox(-10F, 2F, -12F, 19F, 16F, 5F).mirror(false)
                .texOffs(254, 136).mirror().addBox(7F, 2F, -8F, 2F, 14F, 17F).mirror(false),
                PartPose.offsetAndRotation(16F, -34F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(356, 0).mirror().addBox(-10F, 0F, -10F, 19F, 24F, 19F).mirror(false)
                .texOffs(68, 217).mirror().addBox(-8F, -6F, -13F, 17F, 10F, 5F).mirror(false)
                .texOffs(0, 217).mirror().addBox(-7F, 7F, 10F, 14F, 12F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(358, 197).mirror().addBox(-6F, -1F, -6F, 12F, 5F, 12F).mirror(false)
                .texOffs(0, 96).mirror().addBox(-13F, 4F, -20F, 26F, 7F, 33F).mirror(false)
                .texOffs(406, 217).mirror().addBox(-12F, 6F, -21F, 24F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(296, 136).addBox(-15F, -12F, -9F, 29F, 12F, 17F)
                .texOffs(170, 0).addBox(-26F, -43F, -14F, 53F, 34F, 29F)
                .texOffs(178, 197).addBox(-18F, -36F, -16F, 37F, 18F, 1F)
                .texOffs(0, 169).addBox(-20F, -42F, -12F, 40F, 5F, 23F)
                .texOffs(190, 217).addBox(-16F, -28F, 14F, 32F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(112, 217).addBox(-5F, -5F, -5F, 10F, 5F, 10F)
                .texOffs(186, 96).addBox(-8F, -22F, -10F, 17F, 17F, 19F)
                .texOffs(320, 197).addBox(-9F, -22F, -10F, 18F, 17F, 1F)
                .texOffs(0, 233).addBox(-6F, -14F, -11F, 12F, 2F, 1F)
                .texOffs(26, 233).addBox(-5F, -14F, -11F, 10F, 1F, 1F)
                .texOffs(152, 217).addBox(-2F, -23F, -5F, 5F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -43F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(292, 136).addBox(-1F, -29F, -1F, 1F, 29F, 1F)
                .texOffs(456, 217).addBox(-1F, -30F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -14F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(298, 169).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(308, 96).addBox(-12F, -12F, -11F, 19F, 12F, 22F)
                .texOffs(0, 197).addBox(-11F, -13F, -10F, 17F, 1F, 19F)
                .texOffs(390, 96).addBox(-5F, 2F, -5F, 10F, 24F, 10F),
                PartPose.offsetAndRotation(-34F, -35F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(258, 96).addBox(-6F, 0F, -7F, 12F, 22F, 13F)
                .texOffs(406, 197).addBox(-7F, 20F, -7F, 13F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 25F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_gatling = p_forearm_r.addOrReplaceChild("forearm_r_gatling", CubeListBuilder.create()
                .texOffs(78, 136).addBox(-7F, -7F, -17F, 14F, 14F, 19F)
                .texOffs(460, 197).addBox(-5F, -10F, -14F, 10F, 2F, 14F)
                .texOffs(72, 197).addBox(7F, -5F, -10F, 2F, 10F, 10F),
                PartPose.offsetAndRotation(0F, 28F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gatling_barrel = p_forearm_r_gatling.addOrReplaceChild("forearm_r_gatling_barrel", CubeListBuilder.create()
                .texOffs(246, 169).addBox(3F, -1F, -24F, 2F, 2F, 24F)
                .texOffs(246, 169).addBox(1F, 3F, -24F, 2F, 2F, 24F)
                .texOffs(246, 169).addBox(-3F, 3F, -24F, 2F, 2F, 24F)
                .texOffs(246, 169).addBox(-6F, -1F, -24F, 2F, 2F, 24F)
                .texOffs(246, 169).addBox(-3F, -5F, -24F, 2F, 2F, 24F)
                .texOffs(246, 169).addBox(1F, -5F, -24F, 2F, 2F, 24F)
                .texOffs(36, 217).addBox(-6F, -6F, -4F, 12F, 12F, 4F)
                .texOffs(256, 217).addBox(-6F, -6F, -20F, 12F, 12F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -17F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gatling_flash = p_forearm_r_gatling_barrel.addOrReplaceChild("forearm_r_gatling_flash", CubeListBuilder.create()
                .texOffs(394, 169).addBox(-4F, -4F, -14F, 7F, 7F, 14F)
                .texOffs(344, 217).addBox(-8F, -1F, -4F, 17F, 2F, 4F)
                .texOffs(436, 169).addBox(-1F, -8F, -4F, 2F, 17F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -24F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(298, 169).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(308, 96).mirror().addBox(-7F, -12F, -11F, 19F, 12F, 22F).mirror(false)
                .texOffs(0, 197).mirror().addBox(-6F, -13F, -10F, 17F, 1F, 19F).mirror(false)
                .texOffs(390, 96).mirror().addBox(-5F, 2F, -5F, 10F, 24F, 10F).mirror(false),
                PartPose.offsetAndRotation(34F, -35F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(258, 96).mirror().addBox(-6F, 0F, -7F, 12F, 22F, 13F).mirror(false)
                .texOffs(406, 197).mirror().addBox(-7F, 20F, -7F, 13F, 2F, 14F).mirror(false),
                PartPose.offsetAndRotation(0F, 25F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_shield = p_forearm_l.addOrReplaceChild("forearm_l_shield", CubeListBuilder.create()
                .texOffs(84, 0).addBox(-2F, -26F, -19F, 5F, 53F, 38F)
                .texOffs(0, 0).addBox(2F, -28F, -20F, 1F, 55F, 41F)
                .texOffs(334, 0).addBox(3F, -17F, -5F, 1F, 34F, 10F)
                .texOffs(316, 217).addBox(3F, -17F, -2F, 1F, 5F, 5F),
                PartPose.offsetAndRotation(8F, 11F, -5F, 0F, 0F, 0F));
        PartDefinition p_cargo0 = p_torso.addOrReplaceChild("cargo0", CubeListBuilder.create()
                .texOffs(430, 96).addBox(-11F, -8F, -8F, 22F, 16F, 17F)
                .texOffs(464, 217).addBox(-10F, -1F, -9F, 20F, 2F, 1F)
                .texOffs(96, 197).addBox(-12F, -9F, -9F, 23F, 1F, 18F),
                PartPose.offsetAndRotation(-12F, -31F, 24F, 0F, 0F, 0F));
        PartDefinition p_cargo1 = p_torso.addOrReplaceChild("cargo1", CubeListBuilder.create()
                .texOffs(430, 96).addBox(-11F, -8F, -8F, 22F, 16F, 17F)
                .texOffs(464, 217).addBox(-10F, -1F, -9F, 20F, 2F, 1F)
                .texOffs(96, 197).addBox(-12F, -9F, -9F, 23F, 1F, 18F),
                PartPose.offsetAndRotation(12F, -31F, 24F, 0F, 0F, 0F));
        PartDefinition p_cargo2 = p_torso.addOrReplaceChild("cargo2", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-11F, -8F, -8F, 22F, 16F, 17F)
                .texOffs(464, 217).addBox(-10F, -1F, -9F, 20F, 2F, 1F)
                .texOffs(96, 197).addBox(-12F, -9F, -9F, 23F, 1F, 18F),
                PartPose.offsetAndRotation(0F, -48F, 24F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(388, 136).addBox(-4F, -20F, -4F, 7F, 22F, 7F)
                .texOffs(284, 217).addBox(-4F, -22F, -4F, 8F, 2F, 8F)
                .texOffs(386, 217).addBox(-2F, -23F, -2F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(-16F, -38F, 19F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(388, 136).addBox(-4F, -20F, -4F, 7F, 22F, 7F)
                .texOffs(284, 217).addBox(-4F, -22F, -4F, 8F, 2F, 8F)
                .texOffs(386, 217).addBox(-2F, -23F, -2F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(16F, -38F, 19F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.275F)
                .legLengths(11.4F, 12F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", 2, 1.2F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null);
    }
}
