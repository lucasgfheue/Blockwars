package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Tidebreaker (rompeolas). */
@SuppressWarnings("unused")
public final class M_rompeolas {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("rompeolas"), "main");

    private M_rompeolas() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "body,-1,0,8,0,0,0,0/0,0,-27,-17,-21,55,17,42/80,59,-23,-19,-17,46,3,34/0,174,-21,-12,-22,42,6,1;hip_r0,-1,-27,8,-13,0,-0.5,0;"
                + "leg_r0,1,0,-8,0,0,0,2.15/0,99,-4,0,-5,8,27,9/176,135,-5,-1,-6,10,6,12;shin_r0,2,0,27,0,0,0,-1.75/194,0,-3,0,-3,6,40,6/"
                + "56,135,-4,5,-4,7,14,7/198,156,-2,37,-2,4,4,4;hip_l0,-1,27,8,-13,0,0.5,0;leg_l0,4,0,-8,0,0,0,-2.15/!0,99,-4,0,-5,8,27,9/"
                + "!176,135,-5,-1,-6,10,6,12;shin_l0,5,0,27,0,0,0,1.75/!194,0,-3,0,-3,6,40,6/!56,135,-4,5,-4,7,14,7/!198,156,-2,37,-2,4,4,4;"
                + "hip_r1,-1,-27,8,0,0,0,0;leg_r1,7,0,-8,0,0,0,2.15/0,99,-4,0,-5,8,27,9/176,135,-5,-1,-6,10,6,12;shin_r1,8,0,27,0,0,0,-1.75/"
                + "194,0,-3,0,-3,6,40,6/56,135,-4,5,-4,7,14,7/198,156,-2,37,-2,4,4,4;hip_l1,-1,27,8,0,0,0,0;leg_l1,10,0,-8,0,0,0,-2.15/"
                + "!0,99,-4,0,-5,8,27,9/!176,135,-5,-1,-6,10,6,12;shin_l1,11,0,27,0,0,0,1.75/!194,0,-3,0,-3,6,40,6/!56,135,-4,5,-4,7,14,7/"
                + "!198,156,-2,37,-2,4,4,4;hip_r2,-1,-27,8,13,0,0.5,0;leg_r2,13,0,-8,0,0,0,2.15/0,99,-4,0,-5,8,27,9/176,135,-5,-1,-6,10,6,12;"
                + "shin_r2,14,0,27,0,0,0,-1.75/194,0,-3,0,-3,6,40,6/56,135,-4,5,-4,7,14,7/198,156,-2,37,-2,4,4,4;hip_l2,-1,27,8,13,0,-0.5,0;"
                + "leg_l2,16,0,-8,0,0,0,-2.15/!0,99,-4,0,-5,8,27,9/!176,135,-5,-1,-6,10,6,12;shin_l2,17,0,27,0,0,0,1.75/"
                + "!194,0,-3,0,-3,6,40,6/!56,135,-4,5,-4,7,14,7/!198,156,-2,37,-2,4,4,4;head,0,0,-10,-21,0,0,0/166,156,-4,-2,-4,8,2,8/"
                + "0,135,-7,-10,-6,15,8,13/86,174,-6,-9,-7,13,6,1/150,174,-6,-8,-8,3,3,1/150,174,-2,-8,-8,3,3,1/150,174,3,-8,-8,3,3,1/"
                + "58,156,-8,-12,-7,16,1,14;antenna,19,5,-13,4,-0.2,0,0.15/138,99,-1,-25,-1,1,25,1/158,174,-1,-26,-1,2,2,2;"
                + "turret,0,0,-21,-2,0,0,0/142,99,-9,-6,-9,19,6,19;turret_cannon,21,0,-7,-4,0,0,0/0,59,-7,-7,-21,15,15,25/"
                + "122,135,-5,-8,-17,10,1,17/218,99,7,-4,-17,1,8,17;turret_cannon_barrel,22,0,0,-21,0,0,0/74,99,-4,-4,-25,7,7,25/"
                + "220,135,-6,-6,-29,12,12,6;turret_cannon_flash,23,0,0,-29,0,0,0/84,135,-3,-3,-13,6,6,13/114,174,-7,-1,-4,15,2,3/"
                + "0,156,-1,-7,-4,2,15,3;tank,0,0,-4,23,0,0,1.5708/34,99,-5,-13,-5,10,25,10/118,156,-6,-13,-6,12,2,12/118,156,-6,10,-6,12,2,12/"
                + "10,156,-6,-2,-6,12,4,12");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4762F)
                .legLengths(13.65F, 19.95F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null);
    }
}
