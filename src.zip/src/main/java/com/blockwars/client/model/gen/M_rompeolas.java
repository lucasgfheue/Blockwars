package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Tidebreaker (rompeolas). */
@SuppressWarnings("unused")
public final class M_rompeolas {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("rompeolas"), "main");

    private M_rompeolas() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-27F, -17F, -21F, 55F, 17F, 42F)
                .texOffs(80, 59).addBox(-23F, -19F, -17F, 46F, 3F, 34F)
                .texOffs(0, 174).addBox(-21F, -12F, -22F, 42F, 6F, 1F),
                PartPose.offsetAndRotation(0F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_hip_r0 = root.addOrReplaceChild("hip_r0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-27F, 8F, -13F, 0F, -0.5F, 0F));
        PartDefinition p_leg_r0 = p_hip_r0.addOrReplaceChild("leg_r0", CubeListBuilder.create()
                .texOffs(0, 99).addBox(-4F, 0F, -5F, 8F, 27F, 9F)
                .texOffs(176, 135).addBox(-5F, -1F, -6F, 10F, 6F, 12F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r0 = p_leg_r0.addOrReplaceChild("shin_r0", CubeListBuilder.create()
                .texOffs(194, 0).addBox(-3F, 0F, -3F, 6F, 40F, 6F)
                .texOffs(56, 135).addBox(-4F, 5F, -4F, 7F, 14F, 7F)
                .texOffs(198, 156).addBox(-2F, 37F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l0 = root.addOrReplaceChild("hip_l0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(27F, 8F, -13F, 0F, 0.5F, 0F));
        PartDefinition p_leg_l0 = p_hip_l0.addOrReplaceChild("leg_l0", CubeListBuilder.create()
                .texOffs(0, 99).mirror().addBox(-4F, 0F, -5F, 8F, 27F, 9F).mirror(false)
                .texOffs(176, 135).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l0 = p_leg_l0.addOrReplaceChild("shin_l0", CubeListBuilder.create()
                .texOffs(194, 0).mirror().addBox(-3F, 0F, -3F, 6F, 40F, 6F).mirror(false)
                .texOffs(56, 135).mirror().addBox(-4F, 5F, -4F, 7F, 14F, 7F).mirror(false)
                .texOffs(198, 156).mirror().addBox(-2F, 37F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r1 = root.addOrReplaceChild("hip_r1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-27F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_r1 = p_hip_r1.addOrReplaceChild("leg_r1", CubeListBuilder.create()
                .texOffs(0, 99).addBox(-4F, 0F, -5F, 8F, 27F, 9F)
                .texOffs(176, 135).addBox(-5F, -1F, -6F, 10F, 6F, 12F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r1 = p_leg_r1.addOrReplaceChild("shin_r1", CubeListBuilder.create()
                .texOffs(194, 0).addBox(-3F, 0F, -3F, 6F, 40F, 6F)
                .texOffs(56, 135).addBox(-4F, 5F, -4F, 7F, 14F, 7F)
                .texOffs(198, 156).addBox(-2F, 37F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l1 = root.addOrReplaceChild("hip_l1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(27F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_l1 = p_hip_l1.addOrReplaceChild("leg_l1", CubeListBuilder.create()
                .texOffs(0, 99).mirror().addBox(-4F, 0F, -5F, 8F, 27F, 9F).mirror(false)
                .texOffs(176, 135).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l1 = p_leg_l1.addOrReplaceChild("shin_l1", CubeListBuilder.create()
                .texOffs(194, 0).mirror().addBox(-3F, 0F, -3F, 6F, 40F, 6F).mirror(false)
                .texOffs(56, 135).mirror().addBox(-4F, 5F, -4F, 7F, 14F, 7F).mirror(false)
                .texOffs(198, 156).mirror().addBox(-2F, 37F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r2 = root.addOrReplaceChild("hip_r2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-27F, 8F, 13F, 0F, 0.5F, 0F));
        PartDefinition p_leg_r2 = p_hip_r2.addOrReplaceChild("leg_r2", CubeListBuilder.create()
                .texOffs(0, 99).addBox(-4F, 0F, -5F, 8F, 27F, 9F)
                .texOffs(176, 135).addBox(-5F, -1F, -6F, 10F, 6F, 12F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r2 = p_leg_r2.addOrReplaceChild("shin_r2", CubeListBuilder.create()
                .texOffs(194, 0).addBox(-3F, 0F, -3F, 6F, 40F, 6F)
                .texOffs(56, 135).addBox(-4F, 5F, -4F, 7F, 14F, 7F)
                .texOffs(198, 156).addBox(-2F, 37F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l2 = root.addOrReplaceChild("hip_l2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(27F, 8F, 13F, 0F, -0.5F, 0F));
        PartDefinition p_leg_l2 = p_hip_l2.addOrReplaceChild("leg_l2", CubeListBuilder.create()
                .texOffs(0, 99).mirror().addBox(-4F, 0F, -5F, 8F, 27F, 9F).mirror(false)
                .texOffs(176, 135).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l2 = p_leg_l2.addOrReplaceChild("shin_l2", CubeListBuilder.create()
                .texOffs(194, 0).mirror().addBox(-3F, 0F, -3F, 6F, 40F, 6F).mirror(false)
                .texOffs(56, 135).mirror().addBox(-4F, 5F, -4F, 7F, 14F, 7F).mirror(false)
                .texOffs(198, 156).mirror().addBox(-2F, 37F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(166, 156).addBox(-4F, -2F, -4F, 8F, 2F, 8F)
                .texOffs(0, 135).addBox(-7F, -10F, -6F, 15F, 8F, 13F)
                .texOffs(86, 174).addBox(-6F, -9F, -7F, 13F, 6F, 1F)
                .texOffs(150, 174).addBox(-6F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(150, 174).addBox(-2F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(150, 174).addBox(3F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(58, 156).addBox(-8F, -12F, -7F, 16F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -10F, -21F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(138, 99).addBox(-1F, -25F, -1F, 1F, 25F, 1F)
                .texOffs(158, 174).addBox(-1F, -26F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(142, 99).addBox(-9F, -6F, -9F, 19F, 6F, 19F),
                PartPose.offsetAndRotation(0F, -21F, -2F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon = p_turret.addOrReplaceChild("turret_cannon", CubeListBuilder.create()
                .texOffs(0, 59).addBox(-7F, -7F, -21F, 15F, 15F, 25F)
                .texOffs(122, 135).addBox(-5F, -8F, -17F, 10F, 1F, 17F)
                .texOffs(218, 99).addBox(7F, -4F, -17F, 1F, 8F, 17F),
                PartPose.offsetAndRotation(0F, -7F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon_barrel = p_turret_cannon.addOrReplaceChild("turret_cannon_barrel", CubeListBuilder.create()
                .texOffs(74, 99).addBox(-4F, -4F, -25F, 7F, 7F, 25F)
                .texOffs(220, 135).addBox(-6F, -6F, -29F, 12F, 12F, 6F),
                PartPose.offsetAndRotation(0F, 0F, -21F, 0F, 0F, 0F));
        PartDefinition p_turret_cannon_flash = p_turret_cannon_barrel.addOrReplaceChild("turret_cannon_flash", CubeListBuilder.create()
                .texOffs(84, 135).addBox(-3F, -3F, -13F, 6F, 6F, 13F)
                .texOffs(114, 174).addBox(-7F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(0, 156).addBox(-1F, -7F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -29F, 0F, 0F, 0F));
        PartDefinition p_tank = p_body.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(34, 99).addBox(-5F, -13F, -5F, 10F, 25F, 10F)
                .texOffs(118, 156).addBox(-6F, -13F, -6F, 12F, 2F, 12F)
                .texOffs(118, 156).addBox(-6F, 10F, -6F, 12F, 2F, 12F)
                .texOffs(10, 156).addBox(-6F, -2F, -6F, 12F, 4F, 12F),
                PartPose.offsetAndRotation(0F, -4F, 23F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4762F)
                .legLengths(13.65F, 19.95F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_cannon/turret_cannon_barrel", "body/turret/turret_cannon/turret_cannon_barrel/turret_cannon_flash", null);
    }
}
