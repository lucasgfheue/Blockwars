package com.blockwars.client.model.gen;

import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds a generated mecha model from its compact description: parts separated by ';', each part
 * "name,parent,x,y,z,rx,ry,rz" (parent = index of an earlier part, -1 = root; pivot and rotation as in
 * PartPose.offsetAndRotation) followed by its boxes, each "/u,v,x,y,z,w,h,d" (texture offset, then addBox);
 * a box written "/!..." is mirrored. Makes exactly the calls the old generated code made.
 */
final class ModelData {
    private ModelData() {}

    static LayerDefinition build(int texWidth, int texHeight, String data) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        List<PartDefinition> parts = new ArrayList<>();
        for (String record : data.split(";")) {
            String[] boxes = record.split("/");
            String[] h = boxes[0].split(",");
            CubeListBuilder cubes = CubeListBuilder.create();
            for (int i = 1; i < boxes.length; i++) {
                boolean mirror = boxes[i].startsWith("!");
                String[] b = (mirror ? boxes[i].substring(1) : boxes[i]).split(",");
                cubes.texOffs(Integer.parseInt(b[0]), Integer.parseInt(b[1]));
                if (mirror) cubes.mirror();
                cubes.addBox(f(b[2]), f(b[3]), f(b[4]), f(b[5]), f(b[6]), f(b[7]));
                if (mirror) cubes.mirror(false);
            }
            int parent = Integer.parseInt(h[1]);
            PartDefinition owner = parent < 0 ? root : parts.get(parent);
            parts.add(owner.addOrReplaceChild(h[0], cubes,
                    PartPose.offsetAndRotation(f(h[2]), f(h[3]), f(h[4]), f(h[5]), f(h[6]), f(h[7]))));
        }
        return LayerDefinition.create(mesh, texWidth, texHeight);
    }

    private static float f(String s) {
        return Float.parseFloat(s);
    }
}
