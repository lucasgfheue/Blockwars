package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for ECLIPSE · Singularity Engine (eclipse). */
@SuppressWarnings("unused")
public final class M_eclipse {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("eclipse"), "main");

    private M_eclipse() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_core = root.addOrReplaceChild("core", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-14F, -46F, -14F, 29F, 29F, 29F)
                .texOffs(76, 58).addBox(-17F, -41F, -10F, 34F, 19F, 19F)
                .texOffs(0, 58).addBox(-10F, -48F, -10F, 19F, 34F, 19F)
                .texOffs(116, 0).addBox(-10F, -41F, -17F, 19F, 19F, 34F)
                .texOffs(80, 154).addBox(-2F, -34F, -18F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -15F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_core.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(202, 111).addBox(-4F, -5F, -4F, 7F, 5F, 7F),
                PartPose.offsetAndRotation(0F, -48F, 0F, 0F, 0F, 0F));
        PartDefinition p_ring0 = p_core.addOrReplaceChild("ring0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -29F, 0F, 1.5708F, 0F, 0F));
        PartDefinition p_ring0_s0 = p_ring0.addOrReplaceChild("ring0_s0", CubeListBuilder.create()
                .texOffs(108, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(36F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring0_s1 = p_ring0.addOrReplaceChild("ring0_s1", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(32F, 16F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring0_s2 = p_ring0.addOrReplaceChild("ring0_s2", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(22F, 28F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring0_s3 = p_ring0.addOrReplaceChild("ring0_s3", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(8F, 35F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring0_s4 = p_ring0.addOrReplaceChild("ring0_s4", CubeListBuilder.create()
                .texOffs(108, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(-8F, 35F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring0_s5 = p_ring0.addOrReplaceChild("ring0_s5", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(-22F, 28F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring0_s6 = p_ring0.addOrReplaceChild("ring0_s6", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(-32F, 16F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring0_s7 = p_ring0.addOrReplaceChild("ring0_s7", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(-36F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring0_s8 = p_ring0.addOrReplaceChild("ring0_s8", CubeListBuilder.create()
                .texOffs(108, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(-32F, -16F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring0_s9 = p_ring0.addOrReplaceChild("ring0_s9", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(-22F, -28F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring0_s10 = p_ring0.addOrReplaceChild("ring0_s10", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(-8F, -35F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring0_s11 = p_ring0.addOrReplaceChild("ring0_s11", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(8F, -35F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring0_s12 = p_ring0.addOrReplaceChild("ring0_s12", CubeListBuilder.create()
                .texOffs(108, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(22F, -28F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring0_s13 = p_ring0.addOrReplaceChild("ring0_s13", CubeListBuilder.create()
                .texOffs(156, 145).addBox(-9F, -2F, -2F, 19F, 4F, 5F),
                PartPose.offsetAndRotation(32F, -16F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring1 = p_core.addOrReplaceChild("ring1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -29F, 0F, 0.4F, 0.3F, 0F));
        PartDefinition p_ring1_s0 = p_ring1.addOrReplaceChild("ring1_s0", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(43F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring1_s1 = p_ring1.addOrReplaceChild("ring1_s1", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(39F, 19F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring1_s2 = p_ring1.addOrReplaceChild("ring1_s2", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(27F, 34F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring1_s3 = p_ring1.addOrReplaceChild("ring1_s3", CubeListBuilder.create()
                .texOffs(54, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(10F, 42F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring1_s4 = p_ring1.addOrReplaceChild("ring1_s4", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(-10F, 42F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring1_s5 = p_ring1.addOrReplaceChild("ring1_s5", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(-27F, 34F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring1_s6 = p_ring1.addOrReplaceChild("ring1_s6", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(-39F, 19F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring1_s7 = p_ring1.addOrReplaceChild("ring1_s7", CubeListBuilder.create()
                .texOffs(54, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(-43F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring1_s8 = p_ring1.addOrReplaceChild("ring1_s8", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(-39F, -19F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring1_s9 = p_ring1.addOrReplaceChild("ring1_s9", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(-27F, -34F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring1_s10 = p_ring1.addOrReplaceChild("ring1_s10", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(-10F, -42F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring1_s11 = p_ring1.addOrReplaceChild("ring1_s11", CubeListBuilder.create()
                .texOffs(54, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(10F, -42F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring1_s12 = p_ring1.addOrReplaceChild("ring1_s12", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(27F, -34F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring1_s13 = p_ring1.addOrReplaceChild("ring1_s13", CubeListBuilder.create()
                .texOffs(0, 145).addBox(-11F, -2F, -2F, 22F, 4F, 5F),
                PartPose.offsetAndRotation(39F, -19F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring2 = p_core.addOrReplaceChild("ring2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -29F, 0F, 1.5708F, 0.6F, 0F));
        PartDefinition p_ring2_s0 = p_ring2.addOrReplaceChild("ring2_s0", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(50F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring2_s1 = p_ring2.addOrReplaceChild("ring2_s1", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(45F, 22F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring2_s2 = p_ring2.addOrReplaceChild("ring2_s2", CubeListBuilder.create()
                .texOffs(192, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(31F, 39F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring2_s3 = p_ring2.addOrReplaceChild("ring2_s3", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(11F, 49F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring2_s4 = p_ring2.addOrReplaceChild("ring2_s4", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(-11F, 49F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring2_s5 = p_ring2.addOrReplaceChild("ring2_s5", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(-31F, 39F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring2_s6 = p_ring2.addOrReplaceChild("ring2_s6", CubeListBuilder.create()
                .texOffs(192, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(-45F, 22F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring2_s7 = p_ring2.addOrReplaceChild("ring2_s7", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(-50F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring2_s8 = p_ring2.addOrReplaceChild("ring2_s8", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(-45F, -22F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring2_s9 = p_ring2.addOrReplaceChild("ring2_s9", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(-31F, -39F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring2_s10 = p_ring2.addOrReplaceChild("ring2_s10", CubeListBuilder.create()
                .texOffs(192, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(-11F, -49F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring2_s11 = p_ring2.addOrReplaceChild("ring2_s11", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(11F, -49F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring2_s12 = p_ring2.addOrReplaceChild("ring2_s12", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(31F, -39F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring2_s13 = p_ring2.addOrReplaceChild("ring2_s13", CubeListBuilder.create()
                .texOffs(132, 136).addBox(-13F, -2F, -2F, 25F, 4F, 5F),
                PartPose.offsetAndRotation(45F, -22F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_ring3 = p_core.addOrReplaceChild("ring3", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -29F, 0F, 1.2F, 0.9F, 0F));
        PartDefinition p_ring3_s0 = p_ring3.addOrReplaceChild("ring3_s0", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(58F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_ring3_s1 = p_ring3.addOrReplaceChild("ring3_s1", CubeListBuilder.create()
                .texOffs(66, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(52F, 25F, 0F, 0F, 0F, 2.0196F));
        PartDefinition p_ring3_s2 = p_ring3.addOrReplaceChild("ring3_s2", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(36F, 45F, 0F, 0F, 0F, 2.4684F));
        PartDefinition p_ring3_s3 = p_ring3.addOrReplaceChild("ring3_s3", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(13F, 56F, 0F, 0F, 0F, 2.9172F));
        PartDefinition p_ring3_s4 = p_ring3.addOrReplaceChild("ring3_s4", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(-13F, 56F, 0F, 0F, 0F, 3.366F));
        PartDefinition p_ring3_s5 = p_ring3.addOrReplaceChild("ring3_s5", CubeListBuilder.create()
                .texOffs(66, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(-36F, 45F, 0F, 0F, 0F, 3.8148F));
        PartDefinition p_ring3_s6 = p_ring3.addOrReplaceChild("ring3_s6", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(-52F, 25F, 0F, 0F, 0F, 4.2636F));
        PartDefinition p_ring3_s7 = p_ring3.addOrReplaceChild("ring3_s7", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(-58F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_ring3_s8 = p_ring3.addOrReplaceChild("ring3_s8", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(-52F, -25F, 0F, 0F, 0F, 5.1612F));
        PartDefinition p_ring3_s9 = p_ring3.addOrReplaceChild("ring3_s9", CubeListBuilder.create()
                .texOffs(66, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(-36F, -45F, 0F, 0F, 0F, 5.61F));
        PartDefinition p_ring3_s10 = p_ring3.addOrReplaceChild("ring3_s10", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(-13F, -56F, 0F, 0F, 0F, 6.0588F));
        PartDefinition p_ring3_s11 = p_ring3.addOrReplaceChild("ring3_s11", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(13F, -56F, 0F, 0F, 0F, 6.5076F));
        PartDefinition p_ring3_s12 = p_ring3.addOrReplaceChild("ring3_s12", CubeListBuilder.create()
                .texOffs(0, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(36F, -45F, 0F, 0F, 0F, 6.9564F));
        PartDefinition p_ring3_s13 = p_ring3.addOrReplaceChild("ring3_s13", CubeListBuilder.create()
                .texOffs(66, 136).addBox(-14F, -2F, -2F, 28F, 4F, 5F),
                PartPose.offsetAndRotation(52F, -25F, 0F, 0F, 0F, 7.4052F));
        PartDefinition p_float_r = p_core.addOrReplaceChild("float_r", CubeListBuilder.create()
                .texOffs(182, 58).addBox(-6F, -8F, -7F, 12F, 17F, 14F)
                .texOffs(204, 145).addBox(-4F, 8F, -4F, 7F, 1F, 7F),
                PartPose.offsetAndRotation(-41F, -24F, -5F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter = p_float_r.addOrReplaceChild("float_r_emitter", CubeListBuilder.create()
                .texOffs(0, 111).addBox(-5F, -5F, -12F, 11F, 11F, 14F)
                .texOffs(130, 111).addBox(-1F, 5F, -20F, 2F, 2F, 12F)
                .texOffs(130, 111).addBox(-6F, -4F, -20F, 2F, 2F, 12F)
                .texOffs(130, 111).addBox(4F, -4F, -20F, 2F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 5F, -5F, 0F, 0F, 0F));
        PartDefinition p_float_r_emitter_orb = p_float_r_emitter.addOrReplaceChild("float_r_emitter_orb", CubeListBuilder.create()
                .texOffs(158, 111).addBox(-4F, -4F, -4F, 7F, 7F, 7F)
                .texOffs(186, 111).addBox(-2F, -5F, -2F, 4F, 10F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -18F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_float_l = p_core.addOrReplaceChild("float_l", CubeListBuilder.create()
                .texOffs(182, 58).mirror().addBox(-6F, -8F, -7F, 12F, 17F, 14F).mirror(false)
                .texOffs(204, 145).addBox(-4F, 8F, -4F, 7F, 1F, 7F),
                PartPose.offsetAndRotation(41F, -24F, -5F, 0F, 0F, 0F));
        PartDefinition p_float_l_emitter = p_float_l.addOrReplaceChild("float_l_emitter", CubeListBuilder.create()
                .texOffs(0, 111).addBox(-5F, -5F, -12F, 11F, 11F, 14F)
                .texOffs(130, 111).addBox(-1F, 5F, -20F, 2F, 2F, 12F)
                .texOffs(130, 111).addBox(-6F, -4F, -20F, 2F, 2F, 12F)
                .texOffs(130, 111).addBox(4F, -4F, -20F, 2F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 5F, -5F, 0F, 0F, 0F));
        PartDefinition p_float_l_emitter_orb = p_float_l_emitter.addOrReplaceChild("float_l_emitter_orb", CubeListBuilder.create()
                .texOffs(158, 111).addBox(-4F, -4F, -4F, 7F, 7F, 7F)
                .texOffs(186, 111).addBox(-2F, -5F, -2F, 4F, 10F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -18F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_jet_r = p_core.addOrReplaceChild("jet_r", CubeListBuilder.create()
                .texOffs(90, 111).addBox(-5F, -2F, -5F, 10F, 5F, 10F),
                PartPose.offsetAndRotation(-10F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_r = p_jet_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(50, 111).addBox(-3F, 0F, -3F, 6F, 14F, 6F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_jet_l = p_core.addOrReplaceChild("jet_l", CubeListBuilder.create()
                .texOffs(90, 111).addBox(-5F, -2F, -5F, 10F, 5F, 10F),
                PartPose.offsetAndRotation(10F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition p_flame_l = p_jet_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(50, 111).addBox(-3F, 0F, -3F, 6F, 14F, 6F),
                PartPose.offsetAndRotation(0F, 2F, 0F, 0F, 0F, 0F));
        PartDefinition p_halo = p_core.addOrReplaceChild("halo", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -58F, 24F, 0F, 0F, 0F));
        PartDefinition p_halo_s0 = p_halo.addOrReplaceChild("halo_s0", CubeListBuilder.create()
                .texOffs(0, 154).addBox(-9F, -2F, -1F, 18F, 4F, 2F),
                PartPose.offsetAndRotation(22F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_halo_s1 = p_halo.addOrReplaceChild("halo_s1", CubeListBuilder.create()
                .texOffs(40, 154).addBox(-9F, -2F, -1F, 18F, 4F, 2F),
                PartPose.offsetAndRotation(15F, 15F, 0F, 0F, 0F, 2.3562F));
        PartDefinition p_halo_s2 = p_halo.addOrReplaceChild("halo_s2", CubeListBuilder.create()
                .texOffs(0, 154).addBox(-9F, -2F, -1F, 18F, 4F, 2F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 3.1416F));
        PartDefinition p_halo_s3 = p_halo.addOrReplaceChild("halo_s3", CubeListBuilder.create()
                .texOffs(40, 154).addBox(-9F, -2F, -1F, 18F, 4F, 2F),
                PartPose.offsetAndRotation(-15F, 15F, 0F, 0F, 0F, 3.927F));
        PartDefinition p_halo_s4 = p_halo.addOrReplaceChild("halo_s4", CubeListBuilder.create()
                .texOffs(0, 154).addBox(-9F, -2F, -1F, 18F, 4F, 2F),
                PartPose.offsetAndRotation(-22F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_halo_s5 = p_halo.addOrReplaceChild("halo_s5", CubeListBuilder.create()
                .texOffs(40, 154).addBox(-9F, -2F, -1F, 18F, 4F, 2F),
                PartPose.offsetAndRotation(-15F, -15F, 0F, 0F, 0F, 5.4978F));
        PartDefinition p_halo_s6 = p_halo.addOrReplaceChild("halo_s6", CubeListBuilder.create()
                .texOffs(0, 154).addBox(-9F, -2F, -1F, 18F, 4F, 2F),
                PartPose.offsetAndRotation(0F, -22F, 0F, 0F, 0F, 6.2832F));
        PartDefinition p_halo_s7 = p_halo.addOrReplaceChild("halo_s7", CubeListBuilder.create()
                .texOffs(40, 154).addBox(-9F, -2F, -1F, 18F, 4F, 2F),
                PartPose.offsetAndRotation(15F, -15F, 0F, 0F, 0F, 7.0686F));
        PartDefinition p_hspike0 = p_core.addOrReplaceChild("hspike0", CubeListBuilder.create()
                .texOffs(74, 111).addBox(-2F, -17F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(12F, -29F, 12F, 0F, -0.7854F, 1.5708F));
        PartDefinition p_hspike1 = p_core.addOrReplaceChild("hspike1", CubeListBuilder.create()
                .texOffs(74, 111).addBox(-2F, -17F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(-12F, -29F, 12F, 0F, -2.3562F, 1.5708F));
        PartDefinition p_hspike2 = p_core.addOrReplaceChild("hspike2", CubeListBuilder.create()
                .texOffs(74, 111).addBox(-2F, -17F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(-12F, -29F, -12F, 0F, -3.927F, 1.5708F));
        PartDefinition p_hspike3 = p_core.addOrReplaceChild("hspike3", CubeListBuilder.create()
                .texOffs(74, 111).addBox(-2F, -17F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(12F, -29F, -12F, 0F, -5.4978F, 1.5708F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HOVER).parts("core", "core", "core/head").walkRate(0F)
                .arm("core/float_r", null, -1, true)
                .arm("core/float_l", null, 1, true)
                .spin("core/ring0", 2, 0.05F, 2)
                .spin("core/ring1", 2, -0.07F, 2)
                .spin("core/ring2", 2, 0.09F, 2)
                .spin("core/ring3", 2, -0.11F, 2)
                .spin("core/halo", 2, 0.03F, 0)
                .spin("core/float_r/float_r_emitter/float_r_emitter_orb", 2, 0.25F, 0)
                .spin("core/float_l/float_l_emitter/float_l_emitter_orb", 2, 0.25F, 0)
                .flame("core/jet_r/flame_r")
                .flame("core/jet_l/flame_l")
                .primary(Rig.MountKind.ARM, "core/float_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "core/float_l", null, null, null);
    }
}
