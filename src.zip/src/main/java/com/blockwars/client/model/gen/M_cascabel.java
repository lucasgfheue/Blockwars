package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Rattler (cascabel). */
@SuppressWarnings("unused")
public final class M_cascabel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("cascabel"), "main");

    private M_cascabel() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "body,-1,0,10,0,0,0,0/0,0,-18,-20,-18,36,20,36/0,96,-14,-22,-14,28,3,28/0,56,-20,-16,-14,40,12,28;hip_r0,-1,-20,10,-12,0,-0.5,0;"
                + "leg_r0,1,0,-8,0,0,0,2.15/136,56,-4,0,-4,8,26,9/116,127,-5,-1,-6,10,6,11;shin_r0,2,0,26,0,0,0,-1.75/144,0,-3,0,-3,6,38,6/"
                + "52,127,-4,5,-4,7,13,7/200,151,-2,35,-2,4,4,4;hip_l0,-1,20,10,-12,0,0.5,0;leg_l0,4,0,-8,0,0,0,-2.15/!136,56,-4,0,-4,8,26,9/"
                + "!116,127,-5,-1,-6,10,6,11;shin_l0,5,0,26,0,0,0,1.75/!144,0,-3,0,-3,6,38,6/!52,127,-4,5,-4,7,13,7/!200,151,-2,35,-2,4,4,4;"
                + "hip_r1,-1,-20,10,0,0,0,0;leg_r1,7,0,-8,0,0,0,2.15/136,56,-4,0,-4,8,26,9/116,127,-5,-1,-6,10,6,11;shin_r1,8,0,26,0,0,0,-1.75/"
                + "144,0,-3,0,-3,6,38,6/52,127,-4,5,-4,7,13,7/200,151,-2,35,-2,4,4,4;hip_l1,-1,20,10,0,0,0,0;leg_l1,10,0,-8,0,0,0,-2.15/"
                + "!136,56,-4,0,-4,8,26,9/!116,127,-5,-1,-6,10,6,11;shin_l1,11,0,26,0,0,0,1.75/!144,0,-3,0,-3,6,38,6/!52,127,-4,5,-4,7,13,7/"
                + "!200,151,-2,35,-2,4,4,4;hip_r2,-1,-20,10,12,0,0.5,0;leg_r2,13,0,-8,0,0,0,2.15/136,56,-4,0,-4,8,26,9/116,127,-5,-1,-6,10,6,11;"
                + "shin_r2,14,0,26,0,0,0,-1.75/144,0,-3,0,-3,6,38,6/52,127,-4,5,-4,7,13,7/200,151,-2,35,-2,4,4,4;hip_l2,-1,20,10,12,0,-0.5,0;"
                + "leg_l2,16,0,-8,0,0,0,-2.15/!136,56,-4,0,-4,8,26,9/!116,127,-5,-1,-6,10,6,11;shin_l2,17,0,26,0,0,0,1.75/"
                + "!144,0,-3,0,-3,6,38,6/!52,127,-4,5,-4,7,13,7/!200,151,-2,35,-2,4,4,4;head,0,0,-10,-20,0,0,0/132,151,-4,-4,-4,8,4,8/"
                + "0,127,-6,-14,-6,12,10,14/164,151,-4,-13,-7,8,8,1/216,151,-2,-11,-8,4,4,1/80,151,-4,-15,-5,8,1,12;antenna,19,5,-12,4,-0.2,0,0.15/"
                + "164,96,0,-24,0,1,24,1/226,151,-1,-25,-1,2,2,2;turret,0,0,-20,-2,0,0,0/168,96,-9,-6,-9,18,6,18;turret_flamer,21,0,-8,-4,0,0,0/"
                + "112,96,-4,-4,-15,8,8,18/80,127,-3,4,-6,6,6,12/0,151,-3,6,-6,6,2,12;turret_flamer_barrel,22,0,-1,-16,0,0,0/"
                + "158,127,-2,-2,-12,4,4,12/182,151,-3,-3,-14,6,6,3/234,151,-1,3,-14,2,1,2;tank,0,0,-4,22,0,0,1.5708/170,56,-5,-12,-5,10,24,10/"
                + "36,151,-6,-12,-6,11,2,11/36,151,-6,10,-6,11,2,11/190,127,-6,-2,-6,11,4,11;bspike0,0,0,-20,-12,0.5,0,0/"
                + "120,151,-2,-10,-2,3,10,3;bspike1,0,0,-20,0,0.5,0,0/120,151,-2,-10,-2,3,10,3;bspike2,0,0,-20,12,0.5,0,0/"
                + "120,151,-2,-10,-2,3,10,3");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.5F)
                .legLengths(13F, 19F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_flamer/turret_flamer_barrel", null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_flamer/turret_flamer_barrel", null, null);
    }
}
