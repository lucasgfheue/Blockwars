package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Rattler (cascabel). */
@SuppressWarnings("unused")
public final class M_cascabel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("cascabel"), "main");

    private M_cascabel() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-18F, -20F, -18F, 36F, 20F, 36F)
                .texOffs(0, 96).addBox(-14F, -22F, -14F, 28F, 3F, 28F)
                .texOffs(0, 56).addBox(-20F, -16F, -14F, 40F, 12F, 28F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition p_hip_r0 = root.addOrReplaceChild("hip_r0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-20F, 10F, -12F, 0F, -0.5F, 0F));
        PartDefinition p_leg_r0 = p_hip_r0.addOrReplaceChild("leg_r0", CubeListBuilder.create()
                .texOffs(136, 56).addBox(-4F, 0F, -4F, 8F, 26F, 9F)
                .texOffs(116, 127).addBox(-5F, -1F, -6F, 10F, 6F, 11F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r0 = p_leg_r0.addOrReplaceChild("shin_r0", CubeListBuilder.create()
                .texOffs(144, 0).addBox(-3F, 0F, -3F, 6F, 38F, 6F)
                .texOffs(52, 127).addBox(-4F, 5F, -4F, 7F, 13F, 7F)
                .texOffs(200, 151).addBox(-2F, 35F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l0 = root.addOrReplaceChild("hip_l0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(20F, 10F, -12F, 0F, 0.5F, 0F));
        PartDefinition p_leg_l0 = p_hip_l0.addOrReplaceChild("leg_l0", CubeListBuilder.create()
                .texOffs(136, 56).mirror().addBox(-4F, 0F, -4F, 8F, 26F, 9F).mirror(false)
                .texOffs(116, 127).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 11F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l0 = p_leg_l0.addOrReplaceChild("shin_l0", CubeListBuilder.create()
                .texOffs(144, 0).mirror().addBox(-3F, 0F, -3F, 6F, 38F, 6F).mirror(false)
                .texOffs(52, 127).mirror().addBox(-4F, 5F, -4F, 7F, 13F, 7F).mirror(false)
                .texOffs(200, 151).mirror().addBox(-2F, 35F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r1 = root.addOrReplaceChild("hip_r1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-20F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_r1 = p_hip_r1.addOrReplaceChild("leg_r1", CubeListBuilder.create()
                .texOffs(136, 56).addBox(-4F, 0F, -4F, 8F, 26F, 9F)
                .texOffs(116, 127).addBox(-5F, -1F, -6F, 10F, 6F, 11F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r1 = p_leg_r1.addOrReplaceChild("shin_r1", CubeListBuilder.create()
                .texOffs(144, 0).addBox(-3F, 0F, -3F, 6F, 38F, 6F)
                .texOffs(52, 127).addBox(-4F, 5F, -4F, 7F, 13F, 7F)
                .texOffs(200, 151).addBox(-2F, 35F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l1 = root.addOrReplaceChild("hip_l1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(20F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_l1 = p_hip_l1.addOrReplaceChild("leg_l1", CubeListBuilder.create()
                .texOffs(136, 56).mirror().addBox(-4F, 0F, -4F, 8F, 26F, 9F).mirror(false)
                .texOffs(116, 127).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 11F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l1 = p_leg_l1.addOrReplaceChild("shin_l1", CubeListBuilder.create()
                .texOffs(144, 0).mirror().addBox(-3F, 0F, -3F, 6F, 38F, 6F).mirror(false)
                .texOffs(52, 127).mirror().addBox(-4F, 5F, -4F, 7F, 13F, 7F).mirror(false)
                .texOffs(200, 151).mirror().addBox(-2F, 35F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r2 = root.addOrReplaceChild("hip_r2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-20F, 10F, 12F, 0F, 0.5F, 0F));
        PartDefinition p_leg_r2 = p_hip_r2.addOrReplaceChild("leg_r2", CubeListBuilder.create()
                .texOffs(136, 56).addBox(-4F, 0F, -4F, 8F, 26F, 9F)
                .texOffs(116, 127).addBox(-5F, -1F, -6F, 10F, 6F, 11F),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r2 = p_leg_r2.addOrReplaceChild("shin_r2", CubeListBuilder.create()
                .texOffs(144, 0).addBox(-3F, 0F, -3F, 6F, 38F, 6F)
                .texOffs(52, 127).addBox(-4F, 5F, -4F, 7F, 13F, 7F)
                .texOffs(200, 151).addBox(-2F, 35F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l2 = root.addOrReplaceChild("hip_l2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(20F, 10F, 12F, 0F, -0.5F, 0F));
        PartDefinition p_leg_l2 = p_hip_l2.addOrReplaceChild("leg_l2", CubeListBuilder.create()
                .texOffs(136, 56).mirror().addBox(-4F, 0F, -4F, 8F, 26F, 9F).mirror(false)
                .texOffs(116, 127).mirror().addBox(-5F, -1F, -6F, 10F, 6F, 11F).mirror(false),
                PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l2 = p_leg_l2.addOrReplaceChild("shin_l2", CubeListBuilder.create()
                .texOffs(144, 0).mirror().addBox(-3F, 0F, -3F, 6F, 38F, 6F).mirror(false)
                .texOffs(52, 127).mirror().addBox(-4F, 5F, -4F, 7F, 13F, 7F).mirror(false)
                .texOffs(200, 151).mirror().addBox(-2F, 35F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(132, 151).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(0, 127).addBox(-6F, -14F, -6F, 12F, 10F, 14F)
                .texOffs(164, 151).addBox(-4F, -13F, -7F, 8F, 8F, 1F)
                .texOffs(216, 151).addBox(-2F, -11F, -8F, 4F, 4F, 1F)
                .texOffs(80, 151).addBox(-4F, -15F, -5F, 8F, 1F, 12F),
                PartPose.offsetAndRotation(0F, -10F, -20F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(164, 96).addBox(0F, -24F, 0F, 1F, 24F, 1F)
                .texOffs(226, 151).addBox(-1F, -25F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -12F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(168, 96).addBox(-9F, -6F, -9F, 18F, 6F, 18F),
                PartPose.offsetAndRotation(0F, -20F, -2F, 0F, 0F, 0F));
        PartDefinition p_turret_flamer = p_turret.addOrReplaceChild("turret_flamer", CubeListBuilder.create()
                .texOffs(112, 96).addBox(-4F, -4F, -15F, 8F, 8F, 18F)
                .texOffs(80, 127).addBox(-3F, 4F, -6F, 6F, 6F, 12F)
                .texOffs(0, 151).addBox(-3F, 6F, -6F, 6F, 2F, 12F),
                PartPose.offsetAndRotation(0F, -8F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_flamer_barrel = p_turret_flamer.addOrReplaceChild("turret_flamer_barrel", CubeListBuilder.create()
                .texOffs(158, 127).addBox(-2F, -2F, -12F, 4F, 4F, 12F)
                .texOffs(182, 151).addBox(-3F, -3F, -14F, 6F, 6F, 3F)
                .texOffs(234, 151).addBox(-1F, 3F, -14F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -1F, -16F, 0F, 0F, 0F));
        PartDefinition p_tank = p_body.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(170, 56).addBox(-5F, -12F, -5F, 10F, 24F, 10F)
                .texOffs(36, 151).addBox(-6F, -12F, -6F, 11F, 2F, 11F)
                .texOffs(36, 151).addBox(-6F, 10F, -6F, 11F, 2F, 11F)
                .texOffs(190, 127).addBox(-6F, -2F, -6F, 11F, 4F, 11F),
                PartPose.offsetAndRotation(0F, -4F, 22F, 0F, 0F, 1.5708F));
        PartDefinition p_bspike0 = p_body.addOrReplaceChild("bspike0", CubeListBuilder.create()
                .texOffs(120, 151).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -20F, -12F, 0.5F, 0F, 0F));
        PartDefinition p_bspike1 = p_body.addOrReplaceChild("bspike1", CubeListBuilder.create()
                .texOffs(120, 151).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -20F, 0F, 0.5F, 0F, 0F));
        PartDefinition p_bspike2 = p_body.addOrReplaceChild("bspike2", CubeListBuilder.create()
                .texOffs(120, 151).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -20F, 12F, 0.5F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.5F)
                .legLengths(13F, 19F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_flamer/turret_flamer_barrel", null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_flamer/turret_flamer_barrel", null, null);
    }
}
