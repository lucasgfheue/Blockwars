package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Lancer (lancero). */
@SuppressWarnings("unused")
public final class M_lancero {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("lancero"), "main");

    private M_lancero() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-30,0,0,0,0/0,148,-12,-5,-8,24,10,16/0,174,-13,-4,-9,26,5,18/218,233,-3,-2,-10,6,6,1;thigh_r,-1,-10,-30,0,0,0,0/"
                + "88,87,-5,0,-5,10,22,10/138,197,-6,2,-8,12,15,4/88,174,-6,2,-5,2,13,10;shin_r,1,0,22,0,0,0,0/124,50,-6,0,-6,12,23,12/"
                + "82,233,-5,-5,-9,10,8,4/108,246,-2,-2,-10,3,3,1/82,216,-4,7,6,8,12,3;foot_r,2,0,23,0,0,0,0/110,233,-4,-1,-4,7,4,7/"
                + "130,119,-8,3,-13,17,6,21/44,246,-8,5,-14,15,3,1;thigh_l,-1,10,-30,0,0,0,0/!88,87,-5,0,-5,10,22,10/!138,197,-6,2,-8,12,15,4/"
                + "!88,174,4,2,-5,2,13,10;shin_l,4,0,22,0,0,0,0/!124,50,-6,0,-6,12,23,12/!82,233,-5,-5,-9,10,8,4/!108,246,-2,-2,-10,3,3,1/"
                + "!82,216,-4,7,6,8,12,3;foot_l,5,0,23,0,0,0,0/!110,233,-4,-1,-4,7,4,7/!130,119,-8,3,-13,17,6,21/!44,246,-8,5,-14,15,3,1;"
                + "torso,0,0,-5,0,0,0,0/112,174,-9,-10,-6,18,10,12/0,87,-13,-21,-9,26,14,18/0,50,-20,-32,-12,40,15,22/0,197,-12,-34,-8,24,4,15/"
                + "150,216,-10,-30,-14,20,10,3;head,7,0,-34,-2,0,0,0/50,233,-4,-4,-4,8,4,8/140,148,-6,-14,-6,12,10,14/182,233,-4,-13,-7,8,8,1/"
                + "34,246,-2,-11,-8,4,4,1/196,216,-4,-15,-5,8,1,12;antenna,8,5,-12,4,-0.2,0,0.15/136,148,0,-24,0,1,24,1/"
                + "116,246,-1,-25,-1,2,2,2;shoulder_r,7,-26,-27,0,0,0,0/172,174,-5,-5,-5,10,10,10/80,148,-8,-9,-7,14,12,14/"
                + "78,197,-8,-5,-8,15,4,15/98,119,-4,2,-4,8,20,8;forearm_r,10,0,21,0,-0.25,0,0/56,119,-5,0,-6,10,18,11/104,216,-6,17,-6,11,2,12;"
                + "forearm_r_rail,11,0,23,-2,0,0,0/128,87,-5,-5,-16,10,10,20/0,233,-2,-6,-10,4,1,12;forearm_r_rail_barrel,12,0,0,-14,0,0,0/"
                + "0,0,-5,-3,-44,3,6,44/0,0,2,-3,-44,3,6,44/94,0,-1,-1,-43,2,2,42/138,233,-5,-4,-45,10,8,2;forearm_r_rail_flash,13,0,0,-46,0,0,0/"
                + "214,197,-3,-3,-12,6,6,12/0,246,-7,-1,-4,14,2,3/0,216,-1,-7,-4,2,14,3;shoulder_l,7,26,-27,0,0,0,0/!172,174,-5,-5,-5,10,10,10/"
                + "!80,148,-6,-9,-7,14,12,14/!78,197,-6,-5,-8,15,4,15/!98,119,-4,2,-4,8,20,8;forearm_l,15,0,21,0,-0.25,0,0/"
                + "!56,119,-5,0,-6,10,18,11/!104,216,-6,17,-6,11,2,12;forearm_l_gun,16,0,23,-2,0,0,0/0,119,-4,-4,-18,8,9,20/"
                + "170,197,-3,-6,-16,6,2,16/162,233,-2,4,-3,4,4,6;forearm_l_gun_barrel,17,0,-1,-18,0,0,0/212,174,-2,-2,-16,4,4,16/"
                + "200,233,-3,-3,-18,6,6,3;forearm_l_gun_flash,18,0,0,-18,0,0,0/214,197,-3,-3,-12,6,6,12/0,246,-7,-1,-4,14,2,3/"
                + "0,216,-1,-7,-4,2,14,3;reactor,7,0,-18,17,0,0,0/188,87,-9,-10,-5,18,20,10/32,233,-4,-6,5,8,12,1/18,216,-10,-8,-5,20,3,12/"
                + "18,216,-10,6,-5,20,3,12;reactor_ring,20,0,0,6,0,0,0/76,246,-7,-1,-1,14,2,2/10,216,-1,-7,-1,2,14,2");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/reactor/reactor_ring", 2, 0.15F, 0)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel/forearm_r_rail_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
