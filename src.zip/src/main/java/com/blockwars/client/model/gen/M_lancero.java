package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Lancer (lancero). */
@SuppressWarnings("unused")
public final class M_lancero {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("lancero"), "main");

    private M_lancero() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 148).addBox(-12F, -5F, -8F, 24F, 10F, 16F)
                .texOffs(0, 174).addBox(-13F, -4F, -9F, 26F, 5F, 18F)
                .texOffs(218, 233).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(88, 87).addBox(-5F, 0F, -5F, 10F, 22F, 10F)
                .texOffs(138, 197).addBox(-6F, 2F, -8F, 12F, 15F, 4F)
                .texOffs(88, 174).addBox(-6F, 2F, -5F, 2F, 13F, 10F),
                PartPose.offsetAndRotation(-10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(124, 50).addBox(-6F, 0F, -6F, 12F, 23F, 12F)
                .texOffs(82, 233).addBox(-5F, -5F, -9F, 10F, 8F, 4F)
                .texOffs(108, 246).addBox(-2F, -2F, -10F, 3F, 3F, 1F)
                .texOffs(82, 216).addBox(-4F, 7F, 6F, 8F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(110, 233).addBox(-4F, -1F, -4F, 7F, 4F, 7F)
                .texOffs(130, 119).addBox(-8F, 3F, -13F, 17F, 6F, 21F)
                .texOffs(44, 246).addBox(-8F, 5F, -14F, 15F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(88, 87).mirror().addBox(-5F, 0F, -5F, 10F, 22F, 10F).mirror(false)
                .texOffs(138, 197).mirror().addBox(-6F, 2F, -8F, 12F, 15F, 4F).mirror(false)
                .texOffs(88, 174).mirror().addBox(4F, 2F, -5F, 2F, 13F, 10F).mirror(false),
                PartPose.offsetAndRotation(10F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(124, 50).mirror().addBox(-6F, 0F, -6F, 12F, 23F, 12F).mirror(false)
                .texOffs(82, 233).mirror().addBox(-5F, -5F, -9F, 10F, 8F, 4F).mirror(false)
                .texOffs(108, 246).mirror().addBox(-2F, -2F, -10F, 3F, 3F, 1F).mirror(false)
                .texOffs(82, 216).mirror().addBox(-4F, 7F, 6F, 8F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(110, 233).mirror().addBox(-4F, -1F, -4F, 7F, 4F, 7F).mirror(false)
                .texOffs(130, 119).mirror().addBox(-8F, 3F, -13F, 17F, 6F, 21F).mirror(false)
                .texOffs(44, 246).mirror().addBox(-8F, 5F, -14F, 15F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(112, 174).addBox(-9F, -10F, -6F, 18F, 10F, 12F)
                .texOffs(0, 87).addBox(-13F, -21F, -9F, 26F, 14F, 18F)
                .texOffs(0, 50).addBox(-20F, -32F, -12F, 40F, 15F, 22F)
                .texOffs(0, 197).addBox(-12F, -34F, -8F, 24F, 4F, 15F)
                .texOffs(150, 216).addBox(-10F, -30F, -14F, 20F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(50, 233).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(140, 148).addBox(-6F, -14F, -6F, 12F, 10F, 14F)
                .texOffs(182, 233).addBox(-4F, -13F, -7F, 8F, 8F, 1F)
                .texOffs(34, 246).addBox(-2F, -11F, -8F, 4F, 4F, 1F)
                .texOffs(196, 216).addBox(-4F, -15F, -5F, 8F, 1F, 12F),
                PartPose.offsetAndRotation(0F, -34F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(136, 148).addBox(0F, -24F, 0F, 1F, 24F, 1F)
                .texOffs(116, 246).addBox(-1F, -25F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -12F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(172, 174).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(80, 148).addBox(-8F, -9F, -7F, 14F, 12F, 14F)
                .texOffs(78, 197).addBox(-8F, -5F, -8F, 15F, 4F, 15F)
                .texOffs(98, 119).addBox(-4F, 2F, -4F, 8F, 20F, 8F),
                PartPose.offsetAndRotation(-26F, -27F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(56, 119).addBox(-5F, 0F, -6F, 10F, 18F, 11F)
                .texOffs(104, 216).addBox(-6F, 17F, -6F, 11F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_rail = p_forearm_r.addOrReplaceChild("forearm_r_rail", CubeListBuilder.create()
                .texOffs(128, 87).addBox(-5F, -5F, -16F, 10F, 10F, 20F)
                .texOffs(0, 233).addBox(-2F, -6F, -10F, 4F, 1F, 12F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_rail_barrel = p_forearm_r_rail.addOrReplaceChild("forearm_r_rail_barrel", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5F, -3F, -44F, 3F, 6F, 44F)
                .texOffs(0, 0).addBox(2F, -3F, -44F, 3F, 6F, 44F)
                .texOffs(94, 0).addBox(-1F, -1F, -43F, 2F, 2F, 42F)
                .texOffs(138, 233).addBox(-5F, -4F, -45F, 10F, 8F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -14F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_rail_flash = p_forearm_r_rail_barrel.addOrReplaceChild("forearm_r_rail_flash", CubeListBuilder.create()
                .texOffs(214, 197).addBox(-3F, -3F, -12F, 6F, 6F, 12F)
                .texOffs(0, 246).addBox(-7F, -1F, -4F, 14F, 2F, 3F)
                .texOffs(0, 216).addBox(-1F, -7F, -4F, 2F, 14F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -46F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(172, 174).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(80, 148).mirror().addBox(-6F, -9F, -7F, 14F, 12F, 14F).mirror(false)
                .texOffs(78, 197).mirror().addBox(-6F, -5F, -8F, 15F, 4F, 15F).mirror(false)
                .texOffs(98, 119).mirror().addBox(-4F, 2F, -4F, 8F, 20F, 8F).mirror(false),
                PartPose.offsetAndRotation(26F, -27F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(56, 119).mirror().addBox(-5F, 0F, -6F, 10F, 18F, 11F).mirror(false)
                .texOffs(104, 216).mirror().addBox(-6F, 17F, -6F, 11F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_gun = p_forearm_l.addOrReplaceChild("forearm_l_gun", CubeListBuilder.create()
                .texOffs(0, 119).addBox(-4F, -4F, -18F, 8F, 9F, 20F)
                .texOffs(170, 197).addBox(-3F, -6F, -16F, 6F, 2F, 16F)
                .texOffs(162, 233).addBox(-2F, 4F, -3F, 4F, 4F, 6F),
                PartPose.offsetAndRotation(0F, 23F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_barrel = p_forearm_l_gun.addOrReplaceChild("forearm_l_gun_barrel", CubeListBuilder.create()
                .texOffs(212, 174).addBox(-2F, -2F, -16F, 4F, 4F, 16F)
                .texOffs(200, 233).addBox(-3F, -3F, -18F, 6F, 6F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -18F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_flash = p_forearm_l_gun_barrel.addOrReplaceChild("forearm_l_gun_flash", CubeListBuilder.create()
                .texOffs(214, 197).addBox(-3F, -3F, -12F, 6F, 6F, 12F)
                .texOffs(0, 246).addBox(-7F, -1F, -4F, 14F, 2F, 3F)
                .texOffs(0, 216).addBox(-1F, -7F, -4F, 2F, 14F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -18F, 0F, 0F, 0F));
        PartDefinition p_reactor = p_torso.addOrReplaceChild("reactor", CubeListBuilder.create()
                .texOffs(188, 87).addBox(-9F, -10F, -5F, 18F, 20F, 10F)
                .texOffs(32, 233).addBox(-4F, -6F, 5F, 8F, 12F, 1F)
                .texOffs(18, 216).addBox(-10F, -8F, -5F, 20F, 3F, 12F)
                .texOffs(18, 216).addBox(-10F, 6F, -5F, 20F, 3F, 12F),
                PartPose.offsetAndRotation(0F, -18F, 17F, 0F, 0F, 0F));
        PartDefinition p_reactor_ring = p_reactor.addOrReplaceChild("reactor_ring", CubeListBuilder.create()
                .texOffs(76, 246).addBox(-7F, -1F, -1F, 14F, 2F, 2F)
                .texOffs(10, 216).addBox(-1F, -7F, -1F, 2F, 14F, 2F),
                PartPose.offsetAndRotation(0F, 0F, 6F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.33F)
                .legLengths(11F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/reactor/reactor_ring", 2, 0.15F, 0)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel/forearm_r_rail_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
