package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Mirage (espejismo). */
@SuppressWarnings("unused")
public final class M_espejismo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("espejismo"), "main");

    private M_espejismo() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 53).addBox(-10F, -5F, -8F, 21F, 10F, 15F)
                .texOffs(0, 78).addBox(-11F, -4F, -9F, 23F, 5F, 17F)
                .texOffs(0, 133).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(126, 0).addBox(-3F, 0F, -3F, 7F, 29F, 7F)
                .texOffs(144, 53).addBox(-4F, 2F, -6F, 9F, 21F, 4F)
                .texOffs(170, 53).addBox(-4F, 2F, -3F, 2F, 18F, 7F),
                PartPose.offsetAndRotation(-9F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(18, 0).addBox(-4F, 0F, -4F, 9F, 30F, 9F)
                .texOffs(130, 120).addBox(-3F, -5F, -7F, 7F, 8F, 4F)
                .texOffs(140, 100).addBox(-2F, 9F, 4F, 5F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(208, 120).addBox(-2F, -1F, -2F, 5F, 4F, 5F)
                .texOffs(188, 53).addBox(-7F, 3F, -10F, 13F, 6F, 17F)
                .texOffs(106, 133).addBox(-6F, 5F, -11F, 11F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 30F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(126, 0).mirror().addBox(-3F, 0F, -3F, 7F, 29F, 7F).mirror(false)
                .texOffs(144, 53).mirror().addBox(-4F, 2F, -6F, 9F, 21F, 4F).mirror(false)
                .texOffs(170, 53).mirror().addBox(2F, 2F, -3F, 2F, 18F, 7F).mirror(false),
                PartPose.offsetAndRotation(9F, -44F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(18, 0).mirror().addBox(-4F, 0F, -4F, 9F, 30F, 9F).mirror(false)
                .texOffs(130, 120).mirror().addBox(-3F, -5F, -7F, 7F, 8F, 4F).mirror(false)
                .texOffs(140, 100).mirror().addBox(-2F, 9F, 4F, 5F, 15F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(208, 120).mirror().addBox(-2F, -1F, -2F, 5F, 4F, 5F).mirror(false)
                .texOffs(188, 53).mirror().addBox(-7F, 3F, -10F, 13F, 6F, 17F).mirror(false)
                .texOffs(106, 133).mirror().addBox(-6F, 5F, -11F, 11F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 30F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(132, 78).addBox(-7F, -11F, -5F, 14F, 11F, 10F)
                .texOffs(154, 0).addBox(-15F, -34F, -8F, 30F, 10F, 15F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso_gem = p_torso.addOrReplaceChild("torso_gem", CubeListBuilder.create()
                .texOffs(54, 0).addBox(-9F, -9F, -9F, 18F, 18F, 18F),
                PartPose.offsetAndRotation(0F, -21F, 0F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(176, 100).addBox(-5F, -4F, -5F, 10F, 4F, 10F)
                .texOffs(80, 100).addBox(-8F, -6F, -8F, 15F, 3F, 15F)
                .texOffs(80, 78).addBox(-7F, -15F, -7F, 13F, 9F, 13F)
                .texOffs(42, 120).addBox(-5F, -17F, -5F, 10F, 2F, 10F)
                .texOffs(228, 120).addBox(-2F, -11F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, -34F, -2F, 0F, 0F, 0F));
        PartDefinition p_crest = p_head.addOrReplaceChild("crest", CubeListBuilder.create()
                .texOffs(212, 78).addBox(-1F, -15F, -3F, 2F, 15F, 6F)
                .texOffs(152, 120).addBox(0F, -13F, -4F, 1F, 11F, 1F),
                PartPose.offsetAndRotation(0F, -15F, -2F, -0.8F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(0, 100).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(112, 53).addBox(-4F, 2F, -4F, 8F, 17F, 8F),
                PartPose.offsetAndRotation(-21F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(72, 53).addBox(-5F, 0F, -5F, 10F, 15F, 10F)
                .texOffs(0, 120).addBox(-5F, 14F, -6F, 10F, 2F, 11F),
                PartPose.offsetAndRotation(0F, 18F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_emitter = p_forearm_r.addOrReplaceChild("forearm_r_emitter", CubeListBuilder.create()
                .texOffs(40, 100).addBox(-4F, -4F, -10F, 9F, 9F, 11F)
                .texOffs(82, 120).addBox(-1F, 4F, -16F, 2F, 2F, 10F)
                .texOffs(82, 120).addBox(-5F, -3F, -16F, 2F, 2F, 10F)
                .texOffs(82, 120).addBox(3F, -3F, -16F, 2F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 20F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_emitter_orb = p_forearm_r_emitter.addOrReplaceChild("forearm_r_emitter_orb", CubeListBuilder.create()
                .texOffs(106, 120).addBox(-3F, -3F, -3F, 6F, 6F, 6F)
                .texOffs(156, 120).addBox(-1F, -4F, -1F, 3F, 8F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -14F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(0, 100).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(112, 53).mirror().addBox(-4F, 2F, -4F, 8F, 17F, 8F).mirror(false),
                PartPose.offsetAndRotation(21F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(72, 53).mirror().addBox(-5F, 0F, -5F, 10F, 15F, 10F).mirror(false)
                .texOffs(0, 120).mirror().addBox(-5F, 14F, -6F, 10F, 2F, 11F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_blade = p_forearm_l.addOrReplaceChild("forearm_l_blade", CubeListBuilder.create()
                .texOffs(168, 120).addBox(-1F, -6F, -1F, 3F, 8F, 3F)
                .texOffs(14, 133).addBox(-5F, 1F, -2F, 10F, 2F, 4F)
                .texOffs(0, 0).addBox(-1F, 3F, -3F, 2F, 46F, 7F),
                PartPose.offsetAndRotation(0F, 18F, -2F, -1.15F, 0F, 0F));
        PartDefinition p_halo = p_torso.addOrReplaceChild("halo", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0F, -46F, 15F, 0F, 0F, 0F));
        PartDefinition p_halo_s0 = p_halo.addOrReplaceChild("halo_s0", CubeListBuilder.create()
                .texOffs(42, 133).addBox(-7F, -1F, -1F, 14F, 3F, 2F),
                PartPose.offsetAndRotation(17F, 0F, 0F, 0F, 0F, 1.5708F));
        PartDefinition p_halo_s1 = p_halo.addOrReplaceChild("halo_s1", CubeListBuilder.create()
                .texOffs(74, 133).addBox(-7F, -1F, -1F, 14F, 3F, 2F),
                PartPose.offsetAndRotation(12F, 12F, 0F, 0F, 0F, 2.3562F));
        PartDefinition p_halo_s2 = p_halo.addOrReplaceChild("halo_s2", CubeListBuilder.create()
                .texOffs(42, 133).addBox(-7F, -1F, -1F, 14F, 3F, 2F),
                PartPose.offsetAndRotation(0F, 17F, 0F, 0F, 0F, 3.1416F));
        PartDefinition p_halo_s3 = p_halo.addOrReplaceChild("halo_s3", CubeListBuilder.create()
                .texOffs(74, 133).addBox(-7F, -1F, -1F, 14F, 3F, 2F),
                PartPose.offsetAndRotation(-12F, 12F, 0F, 0F, 0F, 3.927F));
        PartDefinition p_halo_s4 = p_halo.addOrReplaceChild("halo_s4", CubeListBuilder.create()
                .texOffs(42, 133).addBox(-7F, -1F, -1F, 14F, 3F, 2F),
                PartPose.offsetAndRotation(-17F, 0F, 0F, 0F, 0F, 4.7124F));
        PartDefinition p_halo_s5 = p_halo.addOrReplaceChild("halo_s5", CubeListBuilder.create()
                .texOffs(74, 133).addBox(-7F, -1F, -1F, 14F, 3F, 2F),
                PartPose.offsetAndRotation(-12F, -12F, 0F, 0F, 0F, 5.4978F));
        PartDefinition p_halo_s6 = p_halo.addOrReplaceChild("halo_s6", CubeListBuilder.create()
                .texOffs(42, 133).addBox(-7F, -1F, -1F, 14F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -17F, 0F, 0F, 0F, 6.2832F));
        PartDefinition p_halo_s7 = p_halo.addOrReplaceChild("halo_s7", CubeListBuilder.create()
                .texOffs(74, 133).addBox(-7F, -1F, -1F, 14F, 3F, 2F),
                PartPose.offsetAndRotation(12F, -12F, 0F, 0F, 0F, 7.0686F));
        PartDefinition p_thr_r = p_torso.addOrReplaceChild("thr_r", CubeListBuilder.create()
                .texOffs(180, 78).addBox(-4F, -7F, -4F, 8F, 13F, 8F)
                .texOffs(180, 120).addBox(-3F, 7F, -3F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(-9F, -23F, 13F, 0.35F, 0F, 0F));
        PartDefinition p_flame_r = p_thr_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(156, 100).addBox(-2F, 0F, -2F, 5F, 11F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition p_thr_l = p_torso.addOrReplaceChild("thr_l", CubeListBuilder.create()
                .texOffs(180, 78).addBox(-4F, -7F, -4F, 8F, 13F, 8F)
                .texOffs(180, 120).addBox(-3F, 7F, -3F, 7F, 3F, 7F),
                PartPose.offsetAndRotation(9F, -23F, 13F, 0.35F, 0F, 0F));
        PartDefinition p_flame_l = p_thr_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(156, 100).addBox(-2F, 0F, -2F, 5F, 11F, 5F),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3474F)
                .legLengths(14.725F, 15.2F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/torso_gem", 1, 0.02F, 0)
                .spin("hips/torso/halo", 2, 0.03F, 0)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
