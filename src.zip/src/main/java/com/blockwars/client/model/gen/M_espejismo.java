package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Mirage (espejismo). */
@SuppressWarnings("unused")
public final class M_espejismo {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("espejismo"), "main");

    private M_espejismo() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-44,0,0,0,0/0,53,-10,-5,-8,21,10,15/0,78,-11,-4,-9,23,5,17/0,133,-3,-2,-10,6,6,1;thigh_r,-1,-9,-44,0,0,0,0/"
                + "126,0,-3,0,-3,7,29,7/144,53,-4,2,-6,9,21,4/170,53,-4,2,-3,2,18,7;shin_r,1,0,29,0,0,0,0/18,0,-4,0,-4,9,30,9/"
                + "130,120,-3,-5,-7,7,8,4/140,100,-2,9,4,5,15,3;foot_r,2,0,30,0,0,0,0/208,120,-2,-1,-2,5,4,5/188,53,-7,3,-10,13,6,17/"
                + "106,133,-6,5,-11,11,3,1;thigh_l,-1,9,-44,0,0,0,0/!126,0,-3,0,-3,7,29,7/!144,53,-4,2,-6,9,21,4/!170,53,2,2,-3,2,18,7;"
                + "shin_l,4,0,29,0,0,0,0/!18,0,-4,0,-4,9,30,9/!130,120,-3,-5,-7,7,8,4/!140,100,-2,9,4,5,15,3;foot_l,5,0,30,0,0,0,0/"
                + "!208,120,-2,-1,-2,5,4,5/!188,53,-7,3,-10,13,6,17/!106,133,-6,5,-11,11,3,1;torso,0,0,-5,0,0,0,0/132,78,-7,-11,-5,14,11,10/"
                + "154,0,-15,-34,-8,30,10,15;torso_gem,7,0,-21,0,0.7854,0.7854,0/54,0,-9,-9,-9,18,18,18;head,7,0,-34,-2,0,0,0/"
                + "176,100,-5,-4,-5,10,4,10/80,100,-8,-6,-8,15,3,15/80,78,-7,-15,-7,13,9,13/42,120,-5,-17,-5,10,2,10/228,120,-2,-11,-2,4,4,4;"
                + "crest,9,0,-15,-2,-0.8,0,0/212,78,-1,-15,-3,2,15,6/152,120,0,-13,-4,1,11,1;shoulder_r,7,-21,-28,0,0,0,0/"
                + "0,100,-5,-5,-5,10,10,10/112,53,-4,2,-4,8,17,8;forearm_r,11,0,18,0,-0.25,0,0/72,53,-5,0,-5,10,15,10/0,120,-5,14,-6,10,2,11;"
                + "forearm_r_emitter,12,0,20,-2,0,0,0/40,100,-4,-4,-10,9,9,11/82,120,-1,4,-16,2,2,10/82,120,-5,-3,-16,2,2,10/"
                + "82,120,3,-3,-16,2,2,10;forearm_r_emitter_orb,13,0,0,-14,0.7854,0.7854,0/106,120,-3,-3,-3,6,6,6/156,120,-1,-4,-1,3,8,3;"
                + "shoulder_l,7,21,-28,0,0,0,0/!0,100,-5,-5,-5,10,10,10/!112,53,-4,2,-4,8,17,8;forearm_l,15,0,18,0,-0.25,0,0/"
                + "!72,53,-5,0,-5,10,15,10/!0,120,-5,14,-6,10,2,11;forearm_l_blade,16,0,18,-2,-1.15,0,0/168,120,-1,-6,-1,3,8,3/"
                + "14,133,-5,1,-2,10,2,4/0,0,-1,3,-3,2,46,7;halo,7,0,-46,15,0,0,0;halo_s0,18,17,0,0,0,0,1.5708/42,133,-7,-1,-1,14,3,2;"
                + "halo_s1,18,12,12,0,0,0,2.3562/74,133,-7,-1,-1,14,3,2;halo_s2,18,0,17,0,0,0,3.1416/42,133,-7,-1,-1,14,3,2;"
                + "halo_s3,18,-12,12,0,0,0,3.927/74,133,-7,-1,-1,14,3,2;halo_s4,18,-17,0,0,0,0,4.7124/42,133,-7,-1,-1,14,3,2;"
                + "halo_s5,18,-12,-12,0,0,0,5.4978/74,133,-7,-1,-1,14,3,2;halo_s6,18,0,-17,0,0,0,6.2832/42,133,-7,-1,-1,14,3,2;"
                + "halo_s7,18,12,-12,0,0,0,7.0686/74,133,-7,-1,-1,14,3,2;thr_r,7,-9,-23,13,0.35,0,0/180,78,-4,-7,-4,8,13,8/"
                + "180,120,-3,7,-3,7,3,7;flame_r,27,0,10,0,0,0,0/156,100,-2,0,-2,5,11,5;thr_l,7,9,-23,13,0.35,0,0/180,78,-4,-7,-4,8,13,8/"
                + "180,120,-3,7,-3,7,3,7;flame_l,29,0,10,0,0,0,0/156,100,-2,0,-2,5,11,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3474F)
                .legLengths(14.725F, 15.2F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/torso_gem", 1, 0.02F, 0)
                .spin("hips/torso/halo", 2, 0.03F, 0)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
