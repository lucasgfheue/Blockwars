package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Demolisher (demoledor). */
@SuppressWarnings("unused")
public final class M_demoledor {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("demoledor"), "main");

    private M_demoledor() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "body,-1,0,-22,0,0,0,0/0,0,-21,-32,-34,41,32,69/220,0,-17,-35,-29,33,3,59/266,169,-17,-18,-36,33,5,1/70,169,-12,-23,34,25,13,1;"
                + "leg_fr,-1,-24,-22,-25,0,0,0.12/404,0,-9,-2,-10,18,23,21/314,101,-10,-6,-12,21,9,23;shin_fr,1,0,18,0,0,0,-0.12/"
                + "166,101,-7,0,-7,14,21,14/122,169,-6,2,-9,12,12,2;foot_fr,2,0,21,0,0,0,0/222,101,-10,0,-15,21,7,25/346,169,-9,3,-16,18,3,1;"
                + "leg_fl,-1,24,-22,-25,0,0,-0.12/!404,0,-9,-2,-10,18,23,21/!314,101,-10,-6,-12,21,9,23;shin_fl,4,0,18,0,0,0,0.12/"
                + "!166,101,-7,0,-7,14,21,14/!122,169,-6,2,-9,12,12,2;foot_fl,5,0,21,0,0,0,0/!222,101,-10,0,-15,21,7,25/"
                + "!346,169,-9,3,-16,18,3,1;leg_br,-1,-24,-22,25,0,0,0.12/404,0,-9,-2,-10,18,23,21/314,101,-10,-6,-12,21,9,23;"
                + "shin_br,7,0,18,0,0,0,-0.12/166,101,-7,0,-7,14,21,14/122,169,-6,2,-9,12,12,2;foot_br,8,0,21,0,0,0,0/222,101,-10,0,-15,21,7,25/"
                + "346,169,-9,3,-16,18,3,1;leg_bl,-1,24,-22,25,0,0,-0.12/!404,0,-9,-2,-10,18,23,21/!314,101,-10,-6,-12,21,9,23;"
                + "shin_bl,10,0,18,0,0,0,0.12/!166,101,-7,0,-7,14,21,14/!122,169,-6,2,-9,12,12,2;foot_bl,11,0,21,0,0,0,0/"
                + "!222,101,-10,0,-15,21,7,25/!346,169,-9,3,-16,18,3,1;head,0,0,-19,-37,0,0,0/430,138,-7,-5,-7,14,5,14/0,101,-12,-21,-9,23,16,21/"
                + "228,169,-9,-18,-10,18,9,1/332,138,-12,-18,-6,1,9,14/332,138,11,-18,-6,1,9,14/240,138,-12,-22,-10,24,1,22/"
                + "392,169,-12,-6,-10,23,2,1/472,169,-9,-23,-8,2,1,2/472,169,7,-23,-8,2,1,2;antenna,13,6,-14,5,-0.2,0,0.15/"
                + "236,138,-1,-28,-1,1,28,1/384,169,-1,-29,-1,2,2,2;turret,0,0,-34,-5,0,0,0/66,138,-10,-7,-12,21,7,23/362,138,-8,-8,-9,16,1,18;"
                + "turret_hammer,15,0,-12,-5,-1.2,0,0/482,0,-2,-5,-2,5,37,5/88,101,-8,28,-12,16,14,23/154,138,-9,32,-12,17,5,24/"
                + "178,169,-7,29,-13,14,12,1;beacon,0,-12,-37,34,0,0,0/208,169,-2,-1,-2,5,7,5/150,169,-3,-7,-3,7,7,7;beacon_spin,17,0,-3,0,0,0,0/"
                + "334,169,-2,-2,-4,5,5,1/334,169,-2,-2,3,5,5,1;cargo0,0,-9,-21,44,0,0,0/402,101,-9,-7,-8,17,15,16/440,169,-8,-1,-9,15,2,1/"
                + "0,169,-9,-8,-9,18,1,17;cargo1,0,9,-21,44,0,0,0/402,101,-9,-7,-8,17,15,16/440,169,-8,-1,-9,15,2,1/0,169,-9,-8,-9,18,1,17;"
                + "cargo2,0,0,-37,44,0,0,0/0,138,-9,-7,-8,17,15,16/440,169,-8,-1,-9,15,2,1/0,169,-9,-8,-9,18,1,17");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.3478F)
                .legLengths(9.2F, 10.35F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .spin("body/beacon/beacon_spin", 1, 0.35F, 0)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", null, null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", null, null, null);
    }
}
