package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Demolisher (demoledor). */
@SuppressWarnings("unused")
public final class M_demoledor {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("demoledor"), "main");

    private M_demoledor() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-21F, -32F, -34F, 41F, 32F, 69F)
                .texOffs(220, 0).addBox(-17F, -35F, -29F, 33F, 3F, 59F)
                .texOffs(266, 169).addBox(-17F, -18F, -36F, 33F, 5F, 1F)
                .texOffs(70, 169).addBox(-12F, -23F, 34F, 25F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -22F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create()
                .texOffs(404, 0).addBox(-9F, -2F, -10F, 18F, 23F, 21F)
                .texOffs(314, 101).addBox(-10F, -6F, -12F, 21F, 9F, 23F),
                PartPose.offsetAndRotation(-24F, -22F, -25F, 0F, 0F, 0.12F));
        PartDefinition p_shin_fr = p_leg_fr.addOrReplaceChild("shin_fr", CubeListBuilder.create()
                .texOffs(166, 101).addBox(-7F, 0F, -7F, 14F, 21F, 14F)
                .texOffs(122, 169).addBox(-6F, 2F, -9F, 12F, 12F, 2F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_fr = p_shin_fr.addOrReplaceChild("foot_fr", CubeListBuilder.create()
                .texOffs(222, 101).addBox(-10F, 0F, -15F, 21F, 7F, 25F)
                .texOffs(346, 169).addBox(-9F, 3F, -16F, 18F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create()
                .texOffs(404, 0).mirror().addBox(-9F, -2F, -10F, 18F, 23F, 21F).mirror(false)
                .texOffs(314, 101).mirror().addBox(-10F, -6F, -12F, 21F, 9F, 23F).mirror(false),
                PartPose.offsetAndRotation(24F, -22F, -25F, 0F, 0F, -0.12F));
        PartDefinition p_shin_fl = p_leg_fl.addOrReplaceChild("shin_fl", CubeListBuilder.create()
                .texOffs(166, 101).mirror().addBox(-7F, 0F, -7F, 14F, 21F, 14F).mirror(false)
                .texOffs(122, 169).mirror().addBox(-6F, 2F, -9F, 12F, 12F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_fl = p_shin_fl.addOrReplaceChild("foot_fl", CubeListBuilder.create()
                .texOffs(222, 101).mirror().addBox(-10F, 0F, -15F, 21F, 7F, 25F).mirror(false)
                .texOffs(346, 169).mirror().addBox(-9F, 3F, -16F, 18F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create()
                .texOffs(404, 0).addBox(-9F, -2F, -10F, 18F, 23F, 21F)
                .texOffs(314, 101).addBox(-10F, -6F, -12F, 21F, 9F, 23F),
                PartPose.offsetAndRotation(-24F, -22F, 25F, 0F, 0F, 0.12F));
        PartDefinition p_shin_br = p_leg_br.addOrReplaceChild("shin_br", CubeListBuilder.create()
                .texOffs(166, 101).addBox(-7F, 0F, -7F, 14F, 21F, 14F)
                .texOffs(122, 169).addBox(-6F, 2F, -9F, 12F, 12F, 2F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_br = p_shin_br.addOrReplaceChild("foot_br", CubeListBuilder.create()
                .texOffs(222, 101).addBox(-10F, 0F, -15F, 21F, 7F, 25F)
                .texOffs(346, 169).addBox(-9F, 3F, -16F, 18F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create()
                .texOffs(404, 0).mirror().addBox(-9F, -2F, -10F, 18F, 23F, 21F).mirror(false)
                .texOffs(314, 101).mirror().addBox(-10F, -6F, -12F, 21F, 9F, 23F).mirror(false),
                PartPose.offsetAndRotation(24F, -22F, 25F, 0F, 0F, -0.12F));
        PartDefinition p_shin_bl = p_leg_bl.addOrReplaceChild("shin_bl", CubeListBuilder.create()
                .texOffs(166, 101).mirror().addBox(-7F, 0F, -7F, 14F, 21F, 14F).mirror(false)
                .texOffs(122, 169).mirror().addBox(-6F, 2F, -9F, 12F, 12F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_bl = p_shin_bl.addOrReplaceChild("foot_bl", CubeListBuilder.create()
                .texOffs(222, 101).mirror().addBox(-10F, 0F, -15F, 21F, 7F, 25F).mirror(false)
                .texOffs(346, 169).mirror().addBox(-9F, 3F, -16F, 18F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(430, 138).addBox(-7F, -5F, -7F, 14F, 5F, 14F)
                .texOffs(0, 101).addBox(-12F, -21F, -9F, 23F, 16F, 21F)
                .texOffs(228, 169).addBox(-9F, -18F, -10F, 18F, 9F, 1F)
                .texOffs(332, 138).addBox(-12F, -18F, -6F, 1F, 9F, 14F)
                .texOffs(332, 138).addBox(11F, -18F, -6F, 1F, 9F, 14F)
                .texOffs(240, 138).addBox(-12F, -22F, -10F, 24F, 1F, 22F)
                .texOffs(392, 169).addBox(-12F, -6F, -10F, 23F, 2F, 1F)
                .texOffs(472, 169).addBox(-9F, -23F, -8F, 2F, 1F, 2F)
                .texOffs(472, 169).addBox(7F, -23F, -8F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -19F, -37F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(236, 138).addBox(-1F, -28F, -1F, 1F, 28F, 1F)
                .texOffs(384, 169).addBox(-1F, -29F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -14F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(66, 138).addBox(-10F, -7F, -12F, 21F, 7F, 23F)
                .texOffs(362, 138).addBox(-8F, -8F, -9F, 16F, 1F, 18F),
                PartPose.offsetAndRotation(0F, -34F, -5F, 0F, 0F, 0F));
        PartDefinition p_turret_hammer = p_turret.addOrReplaceChild("turret_hammer", CubeListBuilder.create()
                .texOffs(482, 0).addBox(-2F, -5F, -2F, 5F, 37F, 5F)
                .texOffs(88, 101).addBox(-8F, 28F, -12F, 16F, 14F, 23F)
                .texOffs(154, 138).addBox(-9F, 32F, -12F, 17F, 5F, 24F)
                .texOffs(178, 169).addBox(-7F, 29F, -13F, 14F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -12F, -5F, -1.2F, 0F, 0F));
        PartDefinition p_beacon = p_body.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(208, 169).addBox(-2F, -1F, -2F, 5F, 7F, 5F)
                .texOffs(150, 169).addBox(-3F, -7F, -3F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(-12F, -37F, 34F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(334, 169).addBox(-2F, -2F, -4F, 5F, 5F, 1F)
                .texOffs(334, 169).addBox(-2F, -2F, 3F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0F));
        PartDefinition p_cargo0 = p_body.addOrReplaceChild("cargo0", CubeListBuilder.create()
                .texOffs(402, 101).addBox(-9F, -7F, -8F, 17F, 15F, 16F)
                .texOffs(440, 169).addBox(-8F, -1F, -9F, 15F, 2F, 1F)
                .texOffs(0, 169).addBox(-9F, -8F, -9F, 18F, 1F, 17F),
                PartPose.offsetAndRotation(-9F, -21F, 44F, 0F, 0F, 0F));
        PartDefinition p_cargo1 = p_body.addOrReplaceChild("cargo1", CubeListBuilder.create()
                .texOffs(402, 101).addBox(-9F, -7F, -8F, 17F, 15F, 16F)
                .texOffs(440, 169).addBox(-8F, -1F, -9F, 15F, 2F, 1F)
                .texOffs(0, 169).addBox(-9F, -8F, -9F, 18F, 1F, 17F),
                PartPose.offsetAndRotation(9F, -21F, 44F, 0F, 0F, 0F));
        PartDefinition p_cargo2 = p_body.addOrReplaceChild("cargo2", CubeListBuilder.create()
                .texOffs(0, 138).addBox(-9F, -7F, -8F, 17F, 15F, 16F)
                .texOffs(440, 169).addBox(-8F, -1F, -9F, 15F, 2F, 1F)
                .texOffs(0, 169).addBox(-9F, -8F, -9F, 18F, 1F, 17F),
                PartPose.offsetAndRotation(0F, -37F, 44F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.3478F)
                .legLengths(9.2F, 10.35F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .spin("body/beacon/beacon_spin", 1, 0.35F, 0)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", null, null, null)
                .secondary(Rig.MountKind.TURRET, "body/turret", null, null, null);
    }
}
