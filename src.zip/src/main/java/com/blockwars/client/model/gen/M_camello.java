package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Camel (camello). */
@SuppressWarnings("unused")
public final class M_camello {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("camello"), "main");

    private M_camello() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "body,-1,0,-22,0,0,0,0/0,0,-21,-32,-34,41,32,69/220,0,-17,-35,-29,33,3,59/292,176,-17,-18,-36,33,5,1/212,176,-12,-23,34,25,13,1;"
                + "leg_fr,-1,-24,-22,-25,0,0,0.12/0,101,-9,-2,-10,18,23,21/298,101,-10,-6,-12,21,9,23;shin_fr,1,0,18,0,0,0,-0.12/"
                + "78,101,-7,0,-7,14,21,14/264,176,-6,2,-9,12,12,2;foot_fr,2,0,21,0,0,0,0/206,101,-10,0,-15,21,7,25/360,176,-9,3,-16,18,3,1;"
                + "leg_fl,-1,24,-22,-25,0,0,-0.12/!0,101,-9,-2,-10,18,23,21/!298,101,-10,-6,-12,21,9,23;shin_fl,4,0,18,0,0,0,0.12/"
                + "!78,101,-7,0,-7,14,21,14/!264,176,-6,2,-9,12,12,2;foot_fl,5,0,21,0,0,0,0/!206,101,-10,0,-15,21,7,25/!360,176,-9,3,-16,18,3,1;"
                + "leg_br,-1,-24,-22,25,0,0,0.12/0,101,-9,-2,-10,18,23,21/298,101,-10,-6,-12,21,9,23;shin_br,7,0,18,0,0,0,-0.12/"
                + "78,101,-7,0,-7,14,21,14/264,176,-6,2,-9,12,12,2;foot_br,8,0,21,0,0,0,0/206,101,-10,0,-15,21,7,25/360,176,-9,3,-16,18,3,1;"
                + "leg_bl,-1,24,-22,25,0,0,-0.12/!0,101,-9,-2,-10,18,23,21/!298,101,-10,-6,-12,21,9,23;shin_bl,10,0,18,0,0,0,0.12/"
                + "!78,101,-7,0,-7,14,21,14/!264,176,-6,2,-9,12,12,2;foot_bl,11,0,21,0,0,0,0/!206,101,-10,0,-15,21,7,25/"
                + "!360,176,-9,3,-16,18,3,1;head,0,0,-19,-37,0,0,0/134,101,-9,-15,-14,18,16,18/70,176,-7,-9,-22,14,9,9/460,176,-7,-12,-15,3,2,1/"
                + "460,176,3,-12,-15,3,2,1;jaw,13,0,1,-9,0,0,0/116,176,-6,0,-14,12,3,14/438,176,-5,-1,-14,9,1,2;antenna,13,6,-14,5,-0.2,0,0.15/"
                + "256,145,-1,-28,-1,1,28,1/398,176,-1,-29,-1,2,2,2;turret,0,0,-34,-5,0,0,0/66,145,-10,-7,-12,21,7,23/392,145,-8,-8,-9,16,1,18;"
                + "turret_pod,16,0,-12,-5,0,0,0/404,0,-12,-18,-14,23,18,28/154,145,-12,-20,-14,23,1,28/168,176,-10,-17,-15,21,16,1;"
                + "cargo0,0,-9,-21,44,0,0,0/386,101,-9,-7,-8,17,15,16/406,176,-8,-1,-9,15,2,1/0,176,-9,-8,-9,18,1,17;cargo1,0,9,-21,44,0,0,0/"
                + "386,101,-9,-7,-8,17,15,16/406,176,-8,-1,-9,15,2,1/0,176,-9,-8,-9,18,1,17;cargo2,0,0,-37,44,0,0,0/0,145,-9,-7,-8,17,15,16/"
                + "406,176,-8,-1,-9,15,2,1/0,176,-9,-8,-9,18,1,17;body_pod,0,0,-30,46,0,0,0/404,0,-12,-18,-14,23,18,28/154,145,-12,-20,-14,23,1,28/"
                + "168,176,-10,-17,-15,21,16,1;tail0,0,0,-19,34,0.5,0,0/260,145,-3,-3,-1,7,7,16;tail1,22,0,0,15,0.2,0,0/"
                + "306,145,-3,-3,-1,6,6,16;tail2,23,0,0,15,0.2,0,0/350,145,-2,-2,-1,5,5,16");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.3478F)
                .legLengths(9.2F, 10.35F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .sway("body/tail0", 1, 0.12F, 0F)
                .sway("body/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("body/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .jaw("body/head/jaw")
                .primary(Rig.MountKind.POD, "body/body_pod", null, null, null)
                .secondary(Rig.MountKind.POD, "body/body_pod", null, null, null);
    }
}
