package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Anchor (ancla). */
@SuppressWarnings("unused")
public final class M_ancla {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("ancla"), "main");

    private M_ancla() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(296, 60).addBox(-17F, -6F, -9F, 34F, 12F, 18F)
                .texOffs(160, 98).addBox(-18F, -5F, -10F, 37F, 6F, 21F)
                .texOffs(178, 146).addBox(-3F, -2F, -12F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(0, 60).addBox(-8F, 0F, -8F, 16F, 22F, 16F)
                .texOffs(408, 98).addBox(-9F, 2F, -12F, 18F, 15F, 5F)
                .texOffs(0, 98).addBox(-9F, 2F, -8F, 2F, 13F, 16F),
                PartPose.offsetAndRotation(-15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(206, 0).addBox(-9F, 0F, -9F, 18F, 23F, 18F)
                .texOffs(38, 146).addBox(-8F, -6F, -13F, 16F, 9F, 5F)
                .texOffs(0, 146).addBox(-7F, 7F, 9F, 14F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(346, 127).addBox(-6F, -1F, -6F, 11F, 5F, 11F)
                .texOffs(374, 0).addBox(-13F, 3F, -19F, 25F, 7F, 32F)
                .texOffs(240, 146).addBox(-12F, 6F, -20F, 23F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(0, 60).mirror().addBox(-8F, 0F, -8F, 16F, 22F, 16F).mirror(false)
                .texOffs(408, 98).mirror().addBox(-9F, 2F, -12F, 18F, 15F, 5F).mirror(false)
                .texOffs(0, 98).mirror().addBox(7F, 2F, -8F, 2F, 13F, 16F).mirror(false),
                PartPose.offsetAndRotation(15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(206, 0).mirror().addBox(-9F, 0F, -9F, 18F, 23F, 18F).mirror(false)
                .texOffs(38, 146).mirror().addBox(-8F, -6F, -13F, 16F, 9F, 5F).mirror(false)
                .texOffs(0, 146).mirror().addBox(-7F, 7F, 9F, 14F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(346, 127).mirror().addBox(-6F, -1F, -6F, 11F, 5F, 11F).mirror(false)
                .texOffs(374, 0).mirror().addBox(-13F, 3F, -19F, 25F, 7F, 32F).mirror(false)
                .texOffs(240, 146).mirror().addBox(-12F, 6F, -20F, 23F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(400, 60).addBox(-14F, -12F, -8F, 28F, 12F, 17F)
                .texOffs(0, 0).addBox(-25F, -41F, -14F, 51F, 32F, 28F)
                .texOffs(0, 127).addBox(-18F, -34F, -15F, 35F, 18F, 1F)
                .texOffs(40, 98).addBox(-19F, -40F, -11F, 38F, 5F, 22F)
                .texOffs(116, 146).addBox(-15F, -27F, 14F, 30F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(80, 146).addBox(-5F, -5F, -5F, 9F, 5F, 9F)
                .texOffs(64, 60).addBox(-8F, -21F, -9F, 16F, 16F, 18F)
                .texOffs(256, 127).addBox(-9F, -21F, -10F, 17F, 16F, 1F)
                .texOffs(296, 146).addBox(-6F, -14F, -10F, 12F, 2F, 1F)
                .texOffs(322, 146).addBox(-5F, -13F, -11F, 9F, 1F, 1F)
                .texOffs(442, 127).addBox(-2F, -22F, -5F, 5F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -41F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(36, 98).addBox(-1F, -28F, -1F, 1F, 28F, 1F)
                .texOffs(288, 146).addBox(-1F, -29F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -14F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(276, 98).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(182, 60).addBox(-12F, -12F, -10F, 18F, 12F, 21F)
                .texOffs(72, 127).addBox(-10F, -13F, -9F, 16F, 1F, 18F)
                .texOffs(260, 60).addBox(-5F, 2F, -5F, 9F, 23F, 9F),
                PartPose.offsetAndRotation(-32F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(132, 60).addBox(-6F, 0F, -6F, 12F, 21F, 13F)
                .texOffs(292, 127).addBox(-6F, 20F, -7F, 13F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_crane = p_forearm_r.addOrReplaceChild("forearm_r_crane", CubeListBuilder.create()
                .texOffs(178, 0).addBox(-3F, 0F, -3F, 7F, 41F, 7F)
                .texOffs(158, 0).addBox(-2F, -1F, -2F, 5F, 44F, 5F),
                PartPose.offsetAndRotation(0F, 24F, -2F, -0.9F, 0F, 0F));
        PartDefinition p_forearm_r_crane_hook = p_forearm_r_crane.addOrReplaceChild("forearm_r_crane_hook", CubeListBuilder.create()
                .texOffs(34, 146).addBox(-1F, 0F, -1F, 1F, 14F, 1F)
                .texOffs(220, 146).addBox(-3F, 13F, -2F, 7F, 3F, 3F)
                .texOffs(210, 146).addBox(1F, 15F, -2F, 2F, 5F, 3F),
                PartPose.offsetAndRotation(0F, 41F, 0F, 0.9F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(276, 98).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(182, 60).mirror().addBox(-7F, -12F, -10F, 18F, 12F, 21F).mirror(false)
                .texOffs(72, 127).mirror().addBox(-6F, -13F, -9F, 16F, 1F, 18F).mirror(false)
                .texOffs(260, 60).mirror().addBox(-5F, 2F, -5F, 9F, 23F, 9F).mirror(false),
                PartPose.offsetAndRotation(32F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(132, 60).mirror().addBox(-6F, 0F, -6F, 12F, 21F, 13F).mirror(false)
                .texOffs(292, 127).mirror().addBox(-6F, 20F, -7F, 13F, 2F, 14F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_claw = p_forearm_l.addOrReplaceChild("forearm_l_claw", CubeListBuilder.create()
                .texOffs(140, 127).addBox(-6F, -1F, -6F, 12F, 7F, 12F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_claw_f0 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f0", CubeListBuilder.create()
                .texOffs(188, 127).addBox(-2F, 0F, -2F, 3F, 14F, 5F)
                .texOffs(194, 146).addBox(-2F, 13F, -2F, 3F, 3F, 5F),
                PartPose.offsetAndRotation(-4F, 6F, -2F, 0F, 0F, 0.25F));
        PartDefinition p_forearm_l_claw_f1 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f1", CubeListBuilder.create()
                .texOffs(188, 127).addBox(-2F, 0F, -2F, 3F, 14F, 5F)
                .texOffs(194, 146).addBox(-2F, 13F, -2F, 3F, 3F, 5F),
                PartPose.offsetAndRotation(4F, 6F, -2F, 0F, 0F, -0.25F));
        PartDefinition p_forearm_l_claw_f2 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f2", CubeListBuilder.create()
                .texOffs(188, 127).addBox(-2F, 0F, -2F, 3F, 14F, 5F)
                .texOffs(194, 146).addBox(-2F, 13F, -2F, 3F, 3F, 5F),
                PartPose.offsetAndRotation(0F, 6F, 4F, 0.25F, 0F, 0F));
        PartDefinition p_spool = p_torso.addOrReplaceChild("spool", CubeListBuilder.create()
                .texOffs(278, 0).addBox(-6F, -14F, -6F, 12F, 28F, 12F)
                .texOffs(324, 98).addBox(-10F, -16F, -10F, 21F, 2F, 21F)
                .texOffs(324, 98).addBox(-10F, 14F, -10F, 21F, 2F, 21F),
                PartPose.offsetAndRotation(0F, -25F, 23F, 0F, 0F, 1.5708F));
        PartDefinition p_tank = p_torso.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(326, 0).addBox(-6F, -14F, -6F, 12F, 28F, 12F)
                .texOffs(390, 127).addBox(-6F, -14F, -6F, 13F, 2F, 13F)
                .texOffs(390, 127).addBox(-6F, 12F, -6F, 13F, 2F, 13F)
                .texOffs(204, 127).addBox(-6F, -2F, -6F, 13F, 5F, 13F),
                PartPose.offsetAndRotation(0F, -23F, 21F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.287F)
                .legLengths(10.925F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/spool", 1, 0F, 1)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/torso/shoulder_r/forearm_r/forearm_r_crane/forearm_r_crane_hook", 0, 0.1F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
