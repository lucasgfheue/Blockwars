package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Anchor (ancla). */
@SuppressWarnings("unused")
public final class M_ancla {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("ancla"), "main");

    private M_ancla() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-31,0,0,0,0/296,60,-17,-6,-9,34,12,18/160,98,-18,-5,-10,37,6,21/178,146,-3,-2,-12,7,7,1;thigh_r,-1,-15,-31,0,0,0,0/"
                + "0,60,-8,0,-8,16,22,16/408,98,-9,2,-12,18,15,5/0,98,-9,2,-8,2,13,16;shin_r,1,0,22,0,0,0,0/206,0,-9,0,-9,18,23,18/"
                + "38,146,-8,-6,-13,16,9,5/0,146,-7,7,9,14,12,3;foot_r,2,0,23,0,0,0,0/346,127,-6,-1,-6,11,5,11/374,0,-13,3,-19,25,7,32/"
                + "240,146,-12,6,-20,23,3,1;thigh_l,-1,15,-31,0,0,0,0/!0,60,-8,0,-8,16,22,16/!408,98,-9,2,-12,18,15,5/!0,98,7,2,-8,2,13,16;"
                + "shin_l,4,0,22,0,0,0,0/!206,0,-9,0,-9,18,23,18/!38,146,-8,-6,-13,16,9,5/!0,146,-7,7,9,14,12,3;foot_l,5,0,23,0,0,0,0/"
                + "!346,127,-6,-1,-6,11,5,11/!374,0,-13,3,-19,25,7,32/!240,146,-12,6,-20,23,3,1;torso,0,0,-6,0,0,0,0/400,60,-14,-12,-8,28,12,17/"
                + "0,0,-25,-41,-14,51,32,28/0,127,-18,-34,-15,35,18,1/40,98,-19,-40,-11,38,5,22/116,146,-15,-27,14,30,12,1;"
                + "head,7,0,-41,-2,0,0,0/80,146,-5,-5,-5,9,5,9/64,60,-8,-21,-9,16,16,18/256,127,-9,-21,-10,17,16,1/296,146,-6,-14,-10,12,2,1/"
                + "322,146,-5,-13,-11,9,1,1/442,127,-2,-22,-5,5,1,14;antenna,8,6,-14,5,-0.2,0,0.15/36,98,-1,-28,-1,1,28,1/"
                + "288,146,-1,-29,-1,2,2,2;shoulder_r,7,-32,-33,0,0,0,0/276,98,-6,-6,-6,12,12,12/182,60,-12,-12,-10,18,12,21/"
                + "72,127,-10,-13,-9,16,1,18/260,60,-5,2,-5,9,23,9;forearm_r,10,0,24,0,-0.25,0,0/132,60,-6,0,-6,12,21,13/"
                + "292,127,-6,20,-7,13,2,14;forearm_r_crane,11,0,24,-2,-0.9,0,0/178,0,-3,0,-3,7,41,7/158,0,-2,-1,-2,5,44,5;"
                + "forearm_r_crane_hook,12,0,41,0,0.9,0,0/34,146,-1,0,-1,1,14,1/220,146,-3,13,-2,7,3,3/210,146,1,15,-2,2,5,3;"
                + "shoulder_l,7,32,-33,0,0,0,0/!276,98,-6,-6,-6,12,12,12/!182,60,-7,-12,-10,18,12,21/!72,127,-6,-13,-9,16,1,18/"
                + "!260,60,-5,2,-5,9,23,9;forearm_l,14,0,24,0,-0.25,0,0/!132,60,-6,0,-6,12,21,13/!292,127,-6,20,-7,13,2,14;"
                + "forearm_l_claw,15,0,24,-2,0,0,0/140,127,-6,-1,-6,12,7,12;forearm_l_claw_f0,16,-4,6,-2,0,0,0.25/188,127,-2,0,-2,3,14,5/"
                + "194,146,-2,13,-2,3,3,5;forearm_l_claw_f1,16,4,6,-2,0,0,-0.25/188,127,-2,0,-2,3,14,5/194,146,-2,13,-2,3,3,5;"
                + "forearm_l_claw_f2,16,0,6,4,0.25,0,0/188,127,-2,0,-2,3,14,5/194,146,-2,13,-2,3,3,5;spool,7,0,-25,23,0,0,1.5708/"
                + "278,0,-6,-14,-6,12,28,12/324,98,-10,-16,-10,21,2,21/324,98,-10,14,-10,21,2,21;tank,7,0,-23,21,0,0,1.5708/"
                + "326,0,-6,-14,-6,12,28,12/390,127,-6,-14,-6,13,2,13/390,127,-6,12,-6,13,2,13/204,127,-6,-2,-6,13,5,13");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.287F)
                .legLengths(10.925F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/spool", 1, 0F, 1)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/torso/shoulder_r/forearm_r/forearm_r_crane/forearm_r_crane_hook", 0, 0.1F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
