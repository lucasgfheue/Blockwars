package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Black Tide (marea). */
@SuppressWarnings("unused")
public final class M_marea {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("marea"), "main");

    private M_marea() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-20F, -22F, -20F, 40F, 22F, 40F)
                .texOffs(82, 110).addBox(-15F, -25F, -15F, 31F, 3F, 31F)
                .texOffs(96, 62).addBox(-22F, -18F, -15F, 44F, 13F, 31F),
                PartPose.offsetAndRotation(0F, 9F, 0F, 0F, 0F, 0F));
        PartDefinition p_hip_r0 = root.addOrReplaceChild("hip_r0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-22F, 9F, -13F, 0F, -0.5F, 0F));
        PartDefinition p_leg_r0 = p_hip_r0.addOrReplaceChild("leg_r0", CubeListBuilder.create()
                .texOffs(0, 110).addBox(-4F, 0F, -5F, 9F, 29F, 10F)
                .texOffs(96, 182).addBox(-6F, -1F, -6F, 11F, 7F, 12F),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r0 = p_leg_r0.addOrReplaceChild("shin_r0", CubeListBuilder.create()
                .texOffs(160, 0).addBox(-3F, 0F, -3F, 7F, 42F, 7F)
                .texOffs(196, 149).addBox(-4F, 5F, -4F, 8F, 15F, 8F)
                .texOffs(0, 220).addBox(-2F, 38F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l0 = root.addOrReplaceChild("hip_l0", CubeListBuilder.create(),
                PartPose.offsetAndRotation(22F, 9F, -13F, 0F, 0.5F, 0F));
        PartDefinition p_leg_l0 = p_hip_l0.addOrReplaceChild("leg_l0", CubeListBuilder.create()
                .texOffs(0, 110).mirror().addBox(-4F, 0F, -5F, 9F, 29F, 10F).mirror(false)
                .texOffs(96, 182).mirror().addBox(-6F, -1F, -6F, 11F, 7F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l0 = p_leg_l0.addOrReplaceChild("shin_l0", CubeListBuilder.create()
                .texOffs(160, 0).mirror().addBox(-3F, 0F, -3F, 7F, 42F, 7F).mirror(false)
                .texOffs(196, 149).mirror().addBox(-4F, 5F, -4F, 8F, 15F, 8F).mirror(false)
                .texOffs(0, 220).mirror().addBox(-2F, 38F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r1 = root.addOrReplaceChild("hip_r1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-22F, 9F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_r1 = p_hip_r1.addOrReplaceChild("leg_r1", CubeListBuilder.create()
                .texOffs(0, 110).addBox(-4F, 0F, -5F, 9F, 29F, 10F)
                .texOffs(96, 182).addBox(-6F, -1F, -6F, 11F, 7F, 12F),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r1 = p_leg_r1.addOrReplaceChild("shin_r1", CubeListBuilder.create()
                .texOffs(160, 0).addBox(-3F, 0F, -3F, 7F, 42F, 7F)
                .texOffs(196, 149).addBox(-4F, 5F, -4F, 8F, 15F, 8F)
                .texOffs(0, 220).addBox(-2F, 38F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l1 = root.addOrReplaceChild("hip_l1", CubeListBuilder.create(),
                PartPose.offsetAndRotation(22F, 9F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_l1 = p_hip_l1.addOrReplaceChild("leg_l1", CubeListBuilder.create()
                .texOffs(0, 110).mirror().addBox(-4F, 0F, -5F, 9F, 29F, 10F).mirror(false)
                .texOffs(96, 182).mirror().addBox(-6F, -1F, -6F, 11F, 7F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l1 = p_leg_l1.addOrReplaceChild("shin_l1", CubeListBuilder.create()
                .texOffs(160, 0).mirror().addBox(-3F, 0F, -3F, 7F, 42F, 7F).mirror(false)
                .texOffs(196, 149).mirror().addBox(-4F, 5F, -4F, 8F, 15F, 8F).mirror(false)
                .texOffs(0, 220).mirror().addBox(-2F, 38F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_hip_r2 = root.addOrReplaceChild("hip_r2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-22F, 9F, 13F, 0F, 0.5F, 0F));
        PartDefinition p_leg_r2 = p_hip_r2.addOrReplaceChild("leg_r2", CubeListBuilder.create()
                .texOffs(0, 110).addBox(-4F, 0F, -5F, 9F, 29F, 10F)
                .texOffs(96, 182).addBox(-6F, -1F, -6F, 11F, 7F, 12F),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, 2.15F));
        PartDefinition p_shin_r2 = p_leg_r2.addOrReplaceChild("shin_r2", CubeListBuilder.create()
                .texOffs(160, 0).addBox(-3F, 0F, -3F, 7F, 42F, 7F)
                .texOffs(196, 149).addBox(-4F, 5F, -4F, 8F, 15F, 8F)
                .texOffs(0, 220).addBox(-2F, 38F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, -1.75F));
        PartDefinition p_hip_l2 = root.addOrReplaceChild("hip_l2", CubeListBuilder.create(),
                PartPose.offsetAndRotation(22F, 9F, 13F, 0F, -0.5F, 0F));
        PartDefinition p_leg_l2 = p_hip_l2.addOrReplaceChild("leg_l2", CubeListBuilder.create()
                .texOffs(0, 110).mirror().addBox(-4F, 0F, -5F, 9F, 29F, 10F).mirror(false)
                .texOffs(96, 182).mirror().addBox(-6F, -1F, -6F, 11F, 7F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, -9F, 0F, 0F, 0F, -2.15F));
        PartDefinition p_shin_l2 = p_leg_l2.addOrReplaceChild("shin_l2", CubeListBuilder.create()
                .texOffs(160, 0).mirror().addBox(-3F, 0F, -3F, 7F, 42F, 7F).mirror(false)
                .texOffs(196, 149).mirror().addBox(-4F, 5F, -4F, 8F, 15F, 8F).mirror(false)
                .texOffs(0, 220).mirror().addBox(-2F, 38F, -2F, 4F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 1.75F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(188, 204).addBox(-4F, -2F, -4F, 9F, 2F, 9F)
                .texOffs(0, 182).addBox(-8F, -11F, -7F, 15F, 9F, 13F)
                .texOffs(224, 204).addBox(-7F, -10F, -7F, 13F, 7F, 1F)
                .texOffs(52, 220).addBox(-6F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(52, 220).addBox(-2F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(52, 220).addBox(3F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(80, 204).addBox(-8F, -12F, -7F, 16F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -11F, -22F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(132, 149).addBox(-1F, -26F, -1F, 1F, 26F, 1F)
                .texOffs(60, 220).addBox(-1F, -28F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(52, 149).addBox(-10F, -7F, -10F, 20F, 7F, 20F),
                PartPose.offsetAndRotation(0F, -22F, -2F, 0F, 0F, 0F));
        PartDefinition p_turret_mortar = p_turret.addOrReplaceChild("turret_mortar", CubeListBuilder.create()
                .texOffs(136, 149).addBox(-8F, -6F, -8F, 15F, 11F, 15F),
                PartPose.offsetAndRotation(0F, -11F, -4F, -0.55F, 0F, 0F));
        PartDefinition p_turret_mortar_barrel = p_turret_mortar.addOrReplaceChild("turret_mortar_barrel", CubeListBuilder.create()
                .texOffs(0, 62).addBox(-7F, -7F, -35F, 13F, 13F, 35F)
                .texOffs(48, 204).addBox(-7F, -7F, -32F, 14F, 14F, 2F)
                .texOffs(142, 182).addBox(-8F, -8F, -38F, 15F, 15F, 4F),
                PartPose.offsetAndRotation(0F, -4F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_mortar_flash = p_turret_mortar_barrel.addOrReplaceChild("turret_mortar_flash", CubeListBuilder.create()
                .texOffs(56, 182).addBox(-3F, -3F, -13F, 7F, 7F, 13F)
                .texOffs(16, 220).addBox(-8F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(180, 182).addBox(-1F, -8F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -37F, 0F, 0F, 0F));
        PartDefinition p_drum = p_body.addOrReplaceChild("drum", CubeListBuilder.create()
                .texOffs(0, 149).addBox(-7F, -10F, -7F, 13F, 20F, 13F)
                .texOffs(190, 182).addBox(-7F, -1F, -7F, 14F, 2F, 14F),
                PartPose.offsetAndRotation(0F, -9F, 24F, 0F, 0F, 1.5708F));
        PartDefinition p_tank = p_body.addOrReplaceChild("tank", CubeListBuilder.create()
                .texOffs(38, 110).addBox(-6F, -13F, -6F, 11F, 26F, 11F)
                .texOffs(140, 204).addBox(-6F, -13F, -6F, 12F, 2F, 12F)
                .texOffs(140, 204).addBox(-6F, 11F, -6F, 12F, 2F, 12F)
                .texOffs(0, 204).addBox(-6F, -2F, -6F, 12F, 4F, 12F),
                PartPose.offsetAndRotation(0F, -4F, 24F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4545F)
                .legLengths(14.3F, 20.9F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_mortar/turret_mortar_barrel", "body/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_mortar/turret_mortar_barrel", "body/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null);
    }
}
