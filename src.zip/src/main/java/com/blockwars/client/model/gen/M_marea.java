package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Black Tide (marea). */
@SuppressWarnings("unused")
public final class M_marea {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("marea"), "main");

    private M_marea() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "body,-1,0,9,0,0,0,0/0,0,-20,-22,-20,40,22,40/82,110,-15,-25,-15,31,3,31/96,62,-22,-18,-15,44,13,31;hip_r0,-1,-22,9,-13,0,-0.5,0;"
                + "leg_r0,1,0,-9,0,0,0,2.15/0,110,-4,0,-5,9,29,10/96,182,-6,-1,-6,11,7,12;shin_r0,2,0,29,0,0,0,-1.75/160,0,-3,0,-3,7,42,7/"
                + "196,149,-4,5,-4,8,15,8/0,220,-2,38,-2,4,4,4;hip_l0,-1,22,9,-13,0,0.5,0;leg_l0,4,0,-9,0,0,0,-2.15/!0,110,-4,0,-5,9,29,10/"
                + "!96,182,-6,-1,-6,11,7,12;shin_l0,5,0,29,0,0,0,1.75/!160,0,-3,0,-3,7,42,7/!196,149,-4,5,-4,8,15,8/!0,220,-2,38,-2,4,4,4;"
                + "hip_r1,-1,-22,9,0,0,0,0;leg_r1,7,0,-9,0,0,0,2.15/0,110,-4,0,-5,9,29,10/96,182,-6,-1,-6,11,7,12;shin_r1,8,0,29,0,0,0,-1.75/"
                + "160,0,-3,0,-3,7,42,7/196,149,-4,5,-4,8,15,8/0,220,-2,38,-2,4,4,4;hip_l1,-1,22,9,0,0,0,0;leg_l1,10,0,-9,0,0,0,-2.15/"
                + "!0,110,-4,0,-5,9,29,10/!96,182,-6,-1,-6,11,7,12;shin_l1,11,0,29,0,0,0,1.75/!160,0,-3,0,-3,7,42,7/!196,149,-4,5,-4,8,15,8/"
                + "!0,220,-2,38,-2,4,4,4;hip_r2,-1,-22,9,13,0,0.5,0;leg_r2,13,0,-9,0,0,0,2.15/0,110,-4,0,-5,9,29,10/96,182,-6,-1,-6,11,7,12;"
                + "shin_r2,14,0,29,0,0,0,-1.75/160,0,-3,0,-3,7,42,7/196,149,-4,5,-4,8,15,8/0,220,-2,38,-2,4,4,4;hip_l2,-1,22,9,13,0,-0.5,0;"
                + "leg_l2,16,0,-9,0,0,0,-2.15/!0,110,-4,0,-5,9,29,10/!96,182,-6,-1,-6,11,7,12;shin_l2,17,0,29,0,0,0,1.75/"
                + "!160,0,-3,0,-3,7,42,7/!196,149,-4,5,-4,8,15,8/!0,220,-2,38,-2,4,4,4;head,0,0,-11,-22,0,0,0/188,204,-4,-2,-4,9,2,9/"
                + "0,182,-8,-11,-7,15,9,13/224,204,-7,-10,-7,13,7,1/52,220,-6,-8,-8,3,3,1/52,220,-2,-8,-8,3,3,1/52,220,3,-8,-8,3,3,1/"
                + "80,204,-8,-12,-7,16,1,14;antenna,19,6,-13,4,-0.2,0,0.15/132,149,-1,-26,-1,1,26,1/60,220,-1,-28,-1,2,2,2;"
                + "turret,0,0,-22,-2,0,0,0/52,149,-10,-7,-10,20,7,20;turret_mortar,21,0,-11,-4,-0.55,0,0/136,149,-8,-6,-8,15,11,15;"
                + "turret_mortar_barrel,22,0,-4,-4,0,0,0/0,62,-7,-7,-35,13,13,35/48,204,-7,-7,-32,14,14,2/142,182,-8,-8,-38,15,15,4;"
                + "turret_mortar_flash,23,0,0,-37,0,0,0/56,182,-3,-3,-13,7,7,13/16,220,-8,-1,-4,15,2,3/180,182,-1,-8,-4,2,15,3;"
                + "drum,0,0,-9,24,0,0,1.5708/0,149,-7,-10,-7,13,20,13/190,182,-7,-1,-7,14,2,14;tank,0,0,-4,24,0,0,1.5708/"
                + "38,110,-6,-13,-6,11,26,11/140,204,-6,-13,-6,12,2,12/140,204,-6,11,-6,12,2,12/0,204,-6,-2,-6,12,4,12");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.HEXA).parts("body", "body", "body/head").walkRate(0.4545F)
                .legLengths(14.3F, 20.9F)
                .leg("hip_r0", "hip_r0/leg_r0", "hip_r0/leg_r0/shin_r0", -1, 0F, 2)
                .leg("hip_l0", "hip_l0/leg_l0", "hip_l0/leg_l0/shin_l0", 1, 3.1416F, 2)
                .leg("hip_r1", "hip_r1/leg_r1", "hip_r1/leg_r1/shin_r1", -1, 3.1416F, 2)
                .leg("hip_l1", "hip_l1/leg_l1", "hip_l1/leg_l1/shin_l1", 1, 0F, 2)
                .leg("hip_r2", "hip_r2/leg_r2", "hip_r2/leg_r2/shin_r2", -1, 0F, 2)
                .leg("hip_l2", "hip_l2/leg_l2", "hip_l2/leg_l2/shin_l2", 1, 3.1416F, 2)
                .sway("body/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_mortar/turret_mortar_barrel", "body/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_mortar/turret_mortar_barrel", "body/turret/turret_mortar/turret_mortar_barrel/turret_mortar_flash", null);
    }
}
