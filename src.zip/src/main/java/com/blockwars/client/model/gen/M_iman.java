package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Lodestone (iman). */
@SuppressWarnings("unused")
public final class M_iman {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("iman"), "main");

    private M_iman() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 96).addBox(-16F, -5F, -8F, 32F, 10F, 17F)
                .texOffs(336, 96).addBox(-17F, -5F, -9F, 34F, 5F, 19F)
                .texOffs(322, 144).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(444, 0).addBox(-7F, 0F, -7F, 15F, 20F, 15F)
                .texOffs(252, 123).addBox(-8F, 2F, -10F, 17F, 14F, 4F)
                .texOffs(98, 96).addBox(-8F, 2F, -7F, 2F, 12F, 15F),
                PartPose.offsetAndRotation(-14F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(272, 0).addBox(-8F, 0F, -8F, 17F, 21F, 17F)
                .texOffs(90, 144).addBox(-7F, -5F, -12F, 15F, 8F, 4F)
                .texOffs(58, 144).addBox(-6F, 6F, 8F, 13F, 10F, 3F),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(404, 123).addBox(-5F, -1F, -5F, 10F, 4F, 10F)
                .texOffs(340, 0).addBox(-12F, 3F, -17F, 23F, 6F, 29F)
                .texOffs(368, 144).addBox(-10F, 5F, -18F, 21F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(444, 0).mirror().addBox(-7F, 0F, -7F, 15F, 20F, 15F).mirror(false)
                .texOffs(252, 123).mirror().addBox(-8F, 2F, -10F, 17F, 14F, 4F).mirror(false)
                .texOffs(98, 96).mirror().addBox(6F, 2F, -7F, 2F, 12F, 15F).mirror(false),
                PartPose.offsetAndRotation(14F, -26F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(272, 0).mirror().addBox(-8F, 0F, -8F, 17F, 21F, 17F).mirror(false)
                .texOffs(90, 144).mirror().addBox(-7F, -5F, -12F, 15F, 8F, 4F).mirror(false)
                .texOffs(58, 144).mirror().addBox(-6F, 6F, 8F, 13F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(404, 123).mirror().addBox(-5F, -1F, -5F, 10F, 4F, 10F).mirror(false)
                .texOffs(340, 0).mirror().addBox(-12F, 3F, -17F, 23F, 6F, 29F).mirror(false)
                .texOffs(368, 144).mirror().addBox(-10F, 5F, -18F, 21F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(392, 61).addBox(-13F, -10F, -9F, 25F, 10F, 18F)
                .texOffs(0, 0).addBox(-18F, -40F, -15F, 37F, 32F, 29F)
                .texOffs(132, 0).addBox(-23F, -37F, -12F, 46F, 25F, 24F)
                .texOffs(248, 61).addBox(-24F, -15F, -12F, 47F, 3F, 25F)
                .texOffs(248, 61).addBox(-24F, -28F, -12F, 47F, 3F, 25F)
                .texOffs(336, 144).addBox(-13F, -23F, -16F, 6F, 6F, 1F)
                .texOffs(350, 144).addBox(5F, -20F, -16F, 8F, 4F, 1F)
                .texOffs(188, 96).addBox(-14F, -39F, -10F, 28F, 4F, 21F)
                .texOffs(0, 144).addBox(-14F, -26F, 15F, 28F, 12F, 1F)
                .texOffs(240, 144).addBox(-4F, -32F, -16F, 8F, 8F, 2F)
                .texOffs(444, 123).addBox(-6F, -34F, -15F, 13F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(144, 144).addBox(-4F, -2F, -4F, 8F, 2F, 8F)
                .texOffs(76, 123).addBox(-7F, -10F, -6F, 15F, 8F, 13F)
                .texOffs(294, 144).addBox(-6F, -9F, -7F, 13F, 6F, 1F)
                .texOffs(412, 144).addBox(-6F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(412, 144).addBox(-2F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(412, 144).addBox(3F, -8F, -8F, 3F, 3F, 1F)
                .texOffs(294, 123).addBox(-8F, -12F, -7F, 16F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -40F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(184, 96).addBox(-1F, -25F, -1F, 1F, 25F, 1F)
                .texOffs(420, 144).addBox(-1F, -26F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(148, 123).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(144, 61).addBox(-10F, -10F, -9F, 17F, 10F, 19F)
                .texOffs(188, 123).addBox(-9F, -12F, -8F, 15F, 1F, 17F)
                .texOffs(216, 61).addBox(-4F, 2F, -4F, 8F, 21F, 8F),
                PartPose.offsetAndRotation(-29F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(40, 61).addBox(-5F, 0F, -6F, 10F, 19F, 12F)
                .texOffs(354, 123).addBox(-6F, 18F, -6F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 22F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_magnet = p_forearm_r.addOrReplaceChild("forearm_r_magnet", CubeListBuilder.create()
                .texOffs(286, 96).addBox(-4F, -4F, -15F, 8F, 8F, 17F)
                .texOffs(84, 61).addBox(-14F, -14F, -18F, 27F, 27F, 3F)
                .texOffs(132, 96).addBox(-12F, -12F, -20F, 23F, 23F, 3F)
                .texOffs(260, 144).addBox(-4F, -4F, -21F, 8F, 8F, 1F)
                .texOffs(128, 144).addBox(-2F, 8F, -10F, 4F, 8F, 4F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(148, 123).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(144, 61).mirror().addBox(-6F, -10F, -9F, 17F, 10F, 19F).mirror(false)
                .texOffs(188, 123).mirror().addBox(-5F, -12F, -8F, 15F, 1F, 17F).mirror(false)
                .texOffs(216, 61).mirror().addBox(-4F, 2F, -4F, 8F, 21F, 8F).mirror(false),
                PartPose.offsetAndRotation(29F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(40, 61).mirror().addBox(-5F, 0F, -6F, 10F, 19F, 12F).mirror(false)
                .texOffs(354, 123).mirror().addBox(-6F, 18F, -6F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_magnet = p_forearm_l.addOrReplaceChild("forearm_l_magnet", CubeListBuilder.create()
                .texOffs(286, 96).addBox(-4F, -4F, -15F, 8F, 8F, 17F)
                .texOffs(84, 61).addBox(-14F, -14F, -18F, 27F, 27F, 3F)
                .texOffs(132, 96).addBox(-12F, -12F, -20F, 23F, 23F, 3F)
                .texOffs(260, 144).addBox(-4F, -4F, -21F, 8F, 8F, 1F)
                .texOffs(128, 144).addBox(-2F, 8F, -10F, 4F, 8F, 4F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_coil_r = p_torso.addOrReplaceChild("coil_r", CubeListBuilder.create()
                .texOffs(132, 123).addBox(-2F, -13F, -2F, 4F, 17F, 4F)
                .texOffs(176, 144).addBox(-4F, -5F, -4F, 8F, 2F, 8F)
                .texOffs(208, 144).addBox(-4F, -10F, -4F, 8F, 2F, 8F)
                .texOffs(176, 144).addBox(-4F, -16F, -4F, 8F, 2F, 8F)
                .texOffs(278, 144).addBox(-2F, -21F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(-14F, -36F, 19F, 0F, 0F, 0F));
        PartDefinition p_coil_l = p_torso.addOrReplaceChild("coil_l", CubeListBuilder.create()
                .texOffs(132, 123).addBox(-2F, -13F, -2F, 4F, 17F, 4F)
                .texOffs(176, 144).addBox(-4F, -5F, -4F, 8F, 2F, 8F)
                .texOffs(208, 144).addBox(-4F, -10F, -4F, 8F, 2F, 8F)
                .texOffs(176, 144).addBox(-4F, -16F, -4F, 8F, 2F, 8F)
                .texOffs(278, 144).addBox(-2F, -21F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(14F, -36F, 19F, 0F, 0F, 0F));
        PartDefinition p_spool = p_torso.addOrReplaceChild("spool", CubeListBuilder.create()
                .texOffs(0, 61).addBox(-5F, -13F, -5F, 10F, 25F, 10F)
                .texOffs(0, 123).addBox(-9F, -15F, -9F, 19F, 2F, 19F)
                .texOffs(0, 123).addBox(-9F, 13F, -9F, 19F, 2F, 19F),
                PartPose.offsetAndRotation(0F, -25F, 23F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3143F)
                .legLengths(9.975F, 10.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/spool", 1, 0F, 1)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
