package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Tower Crane (grua). */
@SuppressWarnings("unused")
public final class M_grua {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("grua"), "main");

    private M_grua() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(346, 53).addBox(-14F, -6F, -10F, 28F, 12F, 20F)
                .texOffs(138, 93).addBox(-15F, -6F, -11F, 30F, 6F, 22F)
                .texOffs(0, 149).addBox(-4F, -2F, -12F, 8F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -67F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(96, 0).addBox(-4F, 0F, -4F, 9F, 39F, 9F)
                .texOffs(0, 93).addBox(-6F, 2F, -8F, 11F, 27F, 5F)
                .texOffs(32, 93).addBox(-6F, 2F, -4F, 2F, 23F, 9F),
                PartPose.offsetAndRotation(-11F, -67F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(52, 0).addBox(-6F, 0F, -6F, 11F, 40F, 11F)
                .texOffs(394, 125).addBox(-4F, -6F, -9F, 9F, 10F, 5F)
                .texOffs(0, 125).addBox(-3F, 12F, 6F, 6F, 20F, 4F),
                PartPose.offsetAndRotation(0F, 39F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(484, 125).addBox(-3F, -1F, -3F, 6F, 5F, 6F)
                .texOffs(58, 93).addBox(-9F, 4F, -13F, 18F, 8F, 22F)
                .texOffs(192, 149).addBox(-8F, 6F, -14F, 15F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 40F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(96, 0).mirror().addBox(-4F, 0F, -4F, 9F, 39F, 9F).mirror(false)
                .texOffs(0, 93).mirror().addBox(-6F, 2F, -8F, 11F, 27F, 5F).mirror(false)
                .texOffs(32, 93).mirror().addBox(3F, 2F, -4F, 2F, 23F, 9F).mirror(false),
                PartPose.offsetAndRotation(11F, -67F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(52, 0).mirror().addBox(-6F, 0F, -6F, 11F, 40F, 11F).mirror(false)
                .texOffs(394, 125).mirror().addBox(-4F, -6F, -9F, 9F, 10F, 5F).mirror(false)
                .texOffs(0, 125).mirror().addBox(-3F, 12F, 6F, 6F, 20F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 39F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(484, 125).mirror().addBox(-3F, -1F, -3F, 6F, 5F, 6F).mirror(false)
                .texOffs(58, 93).mirror().addBox(-9F, 4F, -13F, 18F, 8F, 22F).mirror(false)
                .texOffs(192, 149).mirror().addBox(-8F, 6F, -14F, 15F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 40F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(346, 53).addBox(-14F, -12F, -10F, 28F, 12F, 20F)
                .texOffs(132, 0).addBox(-22F, -20F, -16F, 45F, 10F, 32F)
                .texOffs(0, 53).addBox(-15F, -35F, -8F, 30F, 20F, 20F)
                .texOffs(194, 53).addBox(-24F, -42F, -16F, 4F, 34F, 4F)
                .texOffs(194, 53).addBox(-24F, -42F, 12F, 4F, 34F, 4F)
                .texOffs(194, 53).addBox(21F, -42F, -16F, 4F, 34F, 4F)
                .texOffs(194, 53).addBox(21F, -42F, 12F, 4F, 34F, 4F)
                .texOffs(48, 149).addBox(-25F, -44F, -16F, 50F, 4F, 4F)
                .texOffs(48, 149).addBox(-25F, -44F, 12F, 50F, 4F, 4F)
                .texOffs(334, 0).addBox(-26F, -41F, -18F, 52F, 5F, 35F)
                .texOffs(222, 125).addBox(-19F, -34F, -14F, 38F, 18F, 1F)
                .texOffs(284, 149).addBox(-18F, -44F, -18F, 5F, 2F, 1F)
                .texOffs(284, 149).addBox(12F, -44F, -18F, 5F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(96, 125).addBox(-8F, -5F, -8F, 15F, 5F, 15F)
                .texOffs(100, 53).addBox(-12F, -22F, -10F, 25F, 18F, 22F)
                .texOffs(442, 125).addBox(-10F, -20F, -11F, 20F, 10F, 1F)
                .texOffs(342, 93).addBox(-13F, -20F, -6F, 1F, 10F, 15F)
                .texOffs(342, 93).addBox(12F, -20F, -6F, 1F, 10F, 15F)
                .texOffs(242, 93).addBox(-13F, -24F, -11F, 26F, 1F, 24F)
                .texOffs(232, 149).addBox(-12F, -7F, -11F, 25F, 2F, 1F)
                .texOffs(296, 149).addBox(-10F, -25F, -9F, 2F, 1F, 2F)
                .texOffs(296, 149).addBox(8F, -25F, -9F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -45F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(54, 93).addBox(-1F, -30F, -1F, 1F, 30F, 1F)
                .texOffs(224, 149).addBox(-1F, -31F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -15F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(462, 93).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(210, 53).addBox(-12F, -12F, -11F, 20F, 12F, 22F)
                .texOffs(20, 125).addBox(-11F, -14F, -10F, 18F, 1F, 20F)
                .texOffs(442, 53).addBox(-5F, 2F, -5F, 10F, 22F, 10F),
                PartPose.offsetAndRotation(-32F, -36F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(294, 53).addBox(-6F, 0F, -7F, 12F, 20F, 14F)
                .texOffs(300, 125).addBox(-7F, 19F, -8F, 14F, 2F, 15F),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_crane = p_forearm_r.addOrReplaceChild("forearm_r_crane", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4F, 0F, -4F, 8F, 45F, 8F)
                .texOffs(32, 0).addBox(-2F, -1F, -2F, 5F, 48F, 5F),
                PartPose.offsetAndRotation(0F, 24F, -2F, -0.9F, 0F, 0F));
        PartDefinition p_forearm_r_crane_hook = p_forearm_r_crane.addOrReplaceChild("forearm_r_crane_hook", CubeListBuilder.create()
                .texOffs(390, 125).addBox(-1F, 0F, -1F, 1F, 15F, 1F)
                .texOffs(156, 149).addBox(-4F, 14F, -2F, 8F, 4F, 4F)
                .texOffs(36, 149).addBox(1F, 16F, -2F, 2F, 5F, 4F),
                PartPose.offsetAndRotation(0F, 45F, 0F, 0.9F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(462, 93).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(210, 53).mirror().addBox(-8F, -12F, -11F, 20F, 12F, 22F).mirror(false)
                .texOffs(20, 125).mirror().addBox(-6F, -14F, -10F, 18F, 1F, 20F).mirror(false)
                .texOffs(442, 53).mirror().addBox(-5F, 2F, -5F, 10F, 22F, 10F).mirror(false),
                PartPose.offsetAndRotation(32F, -36F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(294, 53).mirror().addBox(-6F, 0F, -7F, 12F, 20F, 14F).mirror(false)
                .texOffs(300, 125).mirror().addBox(-7F, 19F, -8F, 14F, 2F, 15F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_claw = p_forearm_l.addOrReplaceChild("forearm_l_claw", CubeListBuilder.create()
                .texOffs(156, 125).addBox(-6F, -1F, -6F, 12F, 8F, 12F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_claw_f0 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f0", CubeListBuilder.create()
                .texOffs(204, 125).addBox(-2F, 0F, -2F, 4F, 15F, 5F)
                .texOffs(18, 149).addBox(-2F, 14F, -2F, 4F, 4F, 5F),
                PartPose.offsetAndRotation(-4F, 6F, -2F, 0F, 0F, 0.25F));
        PartDefinition p_forearm_l_claw_f1 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f1", CubeListBuilder.create()
                .texOffs(204, 125).addBox(-2F, 0F, -2F, 4F, 15F, 5F)
                .texOffs(18, 149).addBox(-2F, 14F, -2F, 4F, 4F, 5F),
                PartPose.offsetAndRotation(4F, 6F, -2F, 0F, 0F, -0.25F));
        PartDefinition p_forearm_l_claw_f2 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f2", CubeListBuilder.create()
                .texOffs(204, 125).addBox(-2F, 0F, -2F, 4F, 15F, 5F)
                .texOffs(18, 149).addBox(-2F, 14F, -2F, 4F, 4F, 5F),
                PartPose.offsetAndRotation(0F, 6F, 4F, 0.25F, 0F, 0F));
        PartDefinition p_beacon = p_torso.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(422, 125).addBox(-2F, -1F, -2F, 5F, 8F, 5F)
                .texOffs(358, 125).addBox(-4F, -8F, -4F, 8F, 8F, 8F),
                PartPose.offsetAndRotation(-15F, -50F, 16F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(180, 149).addBox(-2F, -2F, -5F, 5F, 5F, 1F)
                .texOffs(180, 149).addBox(-2F, -2F, 3F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        PartDefinition p_spool = p_torso.addOrReplaceChild("spool", CubeListBuilder.create()
                .texOffs(286, 0).addBox(-6F, -15F, -6F, 12F, 30F, 12F)
                .texOffs(374, 93).addBox(-11F, -18F, -11F, 22F, 2F, 22F)
                .texOffs(374, 93).addBox(-11F, 15F, -11F, 22F, 2F, 22F),
                PartPose.offsetAndRotation(0F, -28F, 26F, 0F, 0F, 1.5708F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.264F)
                .legLengths(19.375F, 20F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hips/torso/spool", 1, 0F, 1)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/torso/shoulder_r/forearm_r/forearm_r_crane/forearm_r_crane_hook", 0, 0.1F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
