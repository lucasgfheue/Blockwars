package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Tower Crane (grua). */
@SuppressWarnings("unused")
public final class M_grua {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("grua"), "main");

    private M_grua() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-67,0,0,0,0/346,53,-14,-6,-10,28,12,20/138,93,-15,-6,-11,30,6,22/0,149,-4,-2,-12,8,8,1;thigh_r,-1,-11,-67,0,0,0,0/"
                + "96,0,-4,0,-4,9,39,9/0,93,-6,2,-8,11,27,5/32,93,-6,2,-4,2,23,9;shin_r,1,0,39,0,0,0,0/52,0,-6,0,-6,11,40,11/"
                + "394,125,-4,-6,-9,9,10,5/0,125,-3,12,6,6,20,4;foot_r,2,0,40,0,0,0,0/484,125,-3,-1,-3,6,5,6/58,93,-9,4,-13,18,8,22/"
                + "192,149,-8,6,-14,15,4,1;thigh_l,-1,11,-67,0,0,0,0/!96,0,-4,0,-4,9,39,9/!0,93,-6,2,-8,11,27,5/!32,93,3,2,-4,2,23,9;"
                + "shin_l,4,0,39,0,0,0,0/!52,0,-6,0,-6,11,40,11/!394,125,-4,-6,-9,9,10,5/!0,125,-3,12,6,6,20,4;foot_l,5,0,40,0,0,0,0/"
                + "!484,125,-3,-1,-3,6,5,6/!58,93,-9,4,-13,18,8,22/!192,149,-8,6,-14,15,4,1;torso,0,0,-6,0,0,0,0/346,53,-14,-12,-10,28,12,20/"
                + "132,0,-22,-20,-16,45,10,32/0,53,-15,-35,-8,30,20,20/194,53,-24,-42,-16,4,34,4/194,53,-24,-42,12,4,34,4/"
                + "194,53,21,-42,-16,4,34,4/194,53,21,-42,12,4,34,4/48,149,-25,-44,-16,50,4,4/48,149,-25,-44,12,50,4,4/334,0,-26,-41,-18,52,5,35/"
                + "222,125,-19,-34,-14,38,18,1/284,149,-18,-44,-18,5,2,1/284,149,12,-44,-18,5,2,1;head,7,0,-45,-2,0,0,0/"
                + "96,125,-8,-5,-8,15,5,15/100,53,-12,-22,-10,25,18,22/442,125,-10,-20,-11,20,10,1/342,93,-13,-20,-6,1,10,15/"
                + "342,93,12,-20,-6,1,10,15/242,93,-13,-24,-11,26,1,24/232,149,-12,-7,-11,25,2,1/296,149,-10,-25,-9,2,1,2/"
                + "296,149,8,-25,-9,2,1,2;antenna,8,6,-15,5,-0.2,0,0.15/54,93,-1,-30,-1,1,30,1/224,149,-1,-31,-1,2,2,2;shoulder_r,7,-32,-36,0,0,0,0/"
                + "462,93,-6,-6,-6,12,12,12/210,53,-12,-12,-11,20,12,22/20,125,-11,-14,-10,18,1,20/442,53,-5,2,-5,10,22,10;"
                + "forearm_r,10,0,24,0,-0.25,0,0/294,53,-6,0,-7,12,20,14/300,125,-7,19,-8,14,2,15;forearm_r_crane,11,0,24,-2,-0.9,0,0/"
                + "0,0,-4,0,-4,8,45,8/32,0,-2,-1,-2,5,48,5;forearm_r_crane_hook,12,0,45,0,0.9,0,0/390,125,-1,0,-1,1,15,1/"
                + "156,149,-4,14,-2,8,4,4/36,149,1,16,-2,2,5,4;shoulder_l,7,32,-36,0,0,0,0/!462,93,-6,-6,-6,12,12,12/!210,53,-8,-12,-11,20,12,22/"
                + "!20,125,-6,-14,-10,18,1,20/!442,53,-5,2,-5,10,22,10;forearm_l,14,0,24,0,-0.25,0,0/!294,53,-6,0,-7,12,20,14/"
                + "!300,125,-7,19,-8,14,2,15;forearm_l_claw,15,0,24,-2,0,0,0/156,125,-6,-1,-6,12,8,12;forearm_l_claw_f0,16,-4,6,-2,0,0,0.25/"
                + "204,125,-2,0,-2,4,15,5/18,149,-2,14,-2,4,4,5;forearm_l_claw_f1,16,4,6,-2,0,0,-0.25/204,125,-2,0,-2,4,15,5/"
                + "18,149,-2,14,-2,4,4,5;forearm_l_claw_f2,16,0,6,4,0.25,0,0/204,125,-2,0,-2,4,15,5/18,149,-2,14,-2,4,4,5;"
                + "beacon,7,-15,-50,16,0,0,0/422,125,-2,-1,-2,5,8,5/358,125,-4,-8,-4,8,8,8;beacon_spin,20,0,-4,0,0,0,0/180,149,-2,-2,-5,5,5,1/"
                + "180,149,-2,-2,3,5,5,1;spool,7,0,-28,26,0,0,1.5708/286,0,-6,-15,-6,12,30,12/374,93,-11,-18,-11,22,2,22/"
                + "374,93,-11,15,-11,22,2,22");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.264F)
                .legLengths(19.375F, 20F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hips/torso/spool", 1, 0F, 1)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/torso/shoulder_r/forearm_r/forearm_r_crane/forearm_r_crane_hook", 0, 0.1F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
