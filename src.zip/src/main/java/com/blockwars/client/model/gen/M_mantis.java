package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Mantis (mantis). */
@SuppressWarnings("unused")
public final class M_mantis {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("mantis"), "main");

    private M_mantis() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-24,0,0,0,0/22,89,-12,-5,-8,24,10,16/0,116,-13,-4,-9,26,5,18/212,159,-3,-2,-10,6,6,1;thigh_r,0,-14,0,0,-0.55,0,0/"
                + "36,52,-6,0,-6,12,24,12/0,89,-7,4,-5,1,17,10;shin_r,1,0,22,0,1.15,0,0/0,52,-4,0,-4,9,28,9/178,116,-6,-4,-6,12,8,12/"
                + "134,139,-4,4,4,7,17,2;foot_r,2,0,28,0,-0.6,0,0/88,52,-8,0,-14,16,6,24/0,174,-7,2,-15,14,3,1/166,159,-3,0,8,6,4,8;"
                + "thigh_l,0,14,0,0,-0.55,0,0/!36,52,-6,0,-6,12,24,12/!0,89,6,4,-5,1,17,10;shin_l,4,0,22,0,1.15,0,0/!0,52,-4,0,-4,9,28,9/"
                + "!178,116,-6,-4,-6,12,8,12/!134,139,-4,4,4,7,17,2;foot_l,5,0,28,0,-0.6,0,0/!88,52,-8,0,-14,16,6,24/!0,174,-7,2,-15,14,3,1/"
                + "!166,159,-3,0,8,6,4,8;torso,0,0,-5,0,0,0,0/154,0,-11,-19,-9,22,19,18/30,0,-18,-30,-13,36,16,26/0,159,-10,-28,-15,20,13,2/"
                + "88,116,-11,-33,-6,22,6,16;head,7,0,-32,-2,0,0,0/134,159,-4,-4,-4,8,4,8/122,89,-6,-14,-6,12,10,14/194,159,-4,-13,-7,8,8,1/"
                + "226,159,-2,-11,-8,4,4,1/94,159,-4,-15,-5,8,1,12;antenna,8,5,-12,4,-0.2,0,0.15/118,89,0,-24,0,1,24,1/30,174,-1,-25,-1,2,2,2;"
                + "shoulder_r,7,-24,-25,0,0,0,0/0,139,-5,-5,-5,10,10,10/210,52,-4,2,-4,8,20,8;forearm_r,10,0,21,0,-0.25,0,0/"
                + "168,52,-5,0,-6,10,18,11/48,159,-6,17,-6,11,2,12;forearm_r_scythe,11,0,21,-2,-0.6,0,0/80,139,-2,-2,-2,4,16,4;"
                + "forearm_r_scythe_c1,12,0,14,0,-0.9,0,0/102,89,-1,0,-3,2,20,6;forearm_r_scythe_c2,13,0,20,0,-0.8,0,0/164,116,-1,0,-2,2,16,5/"
                + "44,159,0,1,-3,1,14,1;shoulder_l,7,24,-25,0,0,0,0/!0,139,-5,-5,-5,10,10,10/!210,52,-4,2,-4,8,20,8;forearm_l,15,0,21,0,-0.25,0,0/"
                + "!168,52,-5,0,-6,10,18,11/!48,159,-6,17,-6,11,2,12;forearm_l_scythe,16,0,21,-2,-0.6,0,0/80,139,-2,-2,-2,4,16,4;"
                + "forearm_l_scythe_c1,17,0,14,0,-0.9,0,0/102,89,-1,0,-3,2,20,6;forearm_l_scythe_c2,18,0,20,0,-0.8,0,0/164,116,-1,0,-2,2,16,5/"
                + "44,159,0,1,-3,1,14,1;wing0_r,7,-6,-32,15,0.4,-0.35,-0.65/0,0,-2,-40,-2,3,40,12/188,139,-2,-40,-2,4,4,13/"
                + "84,52,0,-37,10,1,34,1;wing0_l,7,6,-32,15,0.4,0.35,0.65/!0,0,-2,-40,-2,3,40,12/!188,139,-2,-40,-2,4,4,13/"
                + "!84,52,0,-37,10,1,34,1;tail0,0,0,2,9,0.5,0,0/40,139,-3,-3,-1,6,6,14;tail1,22,0,0,13,0.2,0,0/96,139,-2,-2,-1,5,5,14;"
                + "tail2,23,0,0,13,0.2,0,0/152,139,-2,-2,-1,4,4,14");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.REVERSE).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(12F, 14F)
                .leg("hips/thigh_r", "hips/thigh_r/shin_r", "hips/thigh_r/shin_r/foot_r", -1, 0F, 1)
                .leg("hips/thigh_l", "hips/thigh_l/shin_l", "hips/thigh_l/shin_l/foot_l", 1, 3.1416F, 1)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/tail0", 1, 0.12F, 0F)
                .sway("hips/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("hips/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .wing("hips/torso/wing0_r", -1)
                .wing("hips/torso/wing0_l", 1)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .primaryTwin(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
