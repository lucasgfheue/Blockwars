package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Mantis (mantis). */
@SuppressWarnings("unused")
public final class M_mantis {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("mantis"), "main");

    private M_mantis() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(22, 89).addBox(-12F, -5F, -8F, 24F, 10F, 16F)
                .texOffs(0, 116).addBox(-13F, -4F, -9F, 26F, 5F, 18F)
                .texOffs(212, 159).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -24F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = p_hips.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(36, 52).addBox(-6F, 0F, -6F, 12F, 24F, 12F)
                .texOffs(0, 89).addBox(-7F, 4F, -5F, 1F, 17F, 10F),
                PartPose.offsetAndRotation(-14F, 0F, 0F, -0.55F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(0, 52).addBox(-4F, 0F, -4F, 9F, 28F, 9F)
                .texOffs(178, 116).addBox(-6F, -4F, -6F, 12F, 8F, 12F)
                .texOffs(134, 139).addBox(-4F, 4F, 4F, 7F, 17F, 2F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 1.15F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(88, 52).addBox(-8F, 0F, -14F, 16F, 6F, 24F)
                .texOffs(0, 174).addBox(-7F, 2F, -15F, 14F, 3F, 1F)
                .texOffs(166, 159).addBox(-3F, 0F, 8F, 6F, 4F, 8F),
                PartPose.offsetAndRotation(0F, 28F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_thigh_l = p_hips.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(36, 52).mirror().addBox(-6F, 0F, -6F, 12F, 24F, 12F).mirror(false)
                .texOffs(0, 89).mirror().addBox(6F, 4F, -5F, 1F, 17F, 10F).mirror(false),
                PartPose.offsetAndRotation(14F, 0F, 0F, -0.55F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(0, 52).mirror().addBox(-4F, 0F, -4F, 9F, 28F, 9F).mirror(false)
                .texOffs(178, 116).mirror().addBox(-6F, -4F, -6F, 12F, 8F, 12F).mirror(false)
                .texOffs(134, 139).mirror().addBox(-4F, 4F, 4F, 7F, 17F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 1.15F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(88, 52).mirror().addBox(-8F, 0F, -14F, 16F, 6F, 24F).mirror(false)
                .texOffs(0, 174).mirror().addBox(-7F, 2F, -15F, 14F, 3F, 1F).mirror(false)
                .texOffs(166, 159).mirror().addBox(-3F, 0F, 8F, 6F, 4F, 8F).mirror(false),
                PartPose.offsetAndRotation(0F, 28F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(154, 0).addBox(-11F, -19F, -9F, 22F, 19F, 18F)
                .texOffs(30, 0).addBox(-18F, -30F, -13F, 36F, 16F, 26F)
                .texOffs(0, 159).addBox(-10F, -28F, -15F, 20F, 13F, 2F)
                .texOffs(88, 116).addBox(-11F, -33F, -6F, 22F, 6F, 16F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(134, 159).addBox(-4F, -4F, -4F, 8F, 4F, 8F)
                .texOffs(122, 89).addBox(-6F, -14F, -6F, 12F, 10F, 14F)
                .texOffs(194, 159).addBox(-4F, -13F, -7F, 8F, 8F, 1F)
                .texOffs(226, 159).addBox(-2F, -11F, -8F, 4F, 4F, 1F)
                .texOffs(94, 159).addBox(-4F, -15F, -5F, 8F, 1F, 12F),
                PartPose.offsetAndRotation(0F, -32F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(118, 89).addBox(0F, -24F, 0F, 1F, 24F, 1F)
                .texOffs(30, 174).addBox(-1F, -25F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -12F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(0, 139).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(210, 52).addBox(-4F, 2F, -4F, 8F, 20F, 8F),
                PartPose.offsetAndRotation(-24F, -25F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(168, 52).addBox(-5F, 0F, -6F, 10F, 18F, 11F)
                .texOffs(48, 159).addBox(-6F, 17F, -6F, 11F, 2F, 12F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_scythe = p_forearm_r.addOrReplaceChild("forearm_r_scythe", CubeListBuilder.create()
                .texOffs(80, 139).addBox(-2F, -2F, -2F, 4F, 16F, 4F),
                PartPose.offsetAndRotation(0F, 21F, -2F, -0.6F, 0F, 0F));
        PartDefinition p_forearm_r_scythe_c1 = p_forearm_r_scythe.addOrReplaceChild("forearm_r_scythe_c1", CubeListBuilder.create()
                .texOffs(102, 89).addBox(-1F, 0F, -3F, 2F, 20F, 6F),
                PartPose.offsetAndRotation(0F, 14F, 0F, -0.9F, 0F, 0F));
        PartDefinition p_forearm_r_scythe_c2 = p_forearm_r_scythe_c1.addOrReplaceChild("forearm_r_scythe_c2", CubeListBuilder.create()
                .texOffs(164, 116).addBox(-1F, 0F, -2F, 2F, 16F, 5F)
                .texOffs(44, 159).addBox(0F, 1F, -3F, 1F, 14F, 1F),
                PartPose.offsetAndRotation(0F, 20F, 0F, -0.8F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(0, 139).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(210, 52).mirror().addBox(-4F, 2F, -4F, 8F, 20F, 8F).mirror(false),
                PartPose.offsetAndRotation(24F, -25F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(168, 52).mirror().addBox(-5F, 0F, -6F, 10F, 18F, 11F).mirror(false)
                .texOffs(48, 159).mirror().addBox(-6F, 17F, -6F, 11F, 2F, 12F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_scythe = p_forearm_l.addOrReplaceChild("forearm_l_scythe", CubeListBuilder.create()
                .texOffs(80, 139).addBox(-2F, -2F, -2F, 4F, 16F, 4F),
                PartPose.offsetAndRotation(0F, 21F, -2F, -0.6F, 0F, 0F));
        PartDefinition p_forearm_l_scythe_c1 = p_forearm_l_scythe.addOrReplaceChild("forearm_l_scythe_c1", CubeListBuilder.create()
                .texOffs(102, 89).addBox(-1F, 0F, -3F, 2F, 20F, 6F),
                PartPose.offsetAndRotation(0F, 14F, 0F, -0.9F, 0F, 0F));
        PartDefinition p_forearm_l_scythe_c2 = p_forearm_l_scythe_c1.addOrReplaceChild("forearm_l_scythe_c2", CubeListBuilder.create()
                .texOffs(164, 116).addBox(-1F, 0F, -2F, 2F, 16F, 5F)
                .texOffs(44, 159).addBox(0F, 1F, -3F, 1F, 14F, 1F),
                PartPose.offsetAndRotation(0F, 20F, 0F, -0.8F, 0F, 0F));
        PartDefinition p_wing0_r = p_torso.addOrReplaceChild("wing0_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2F, -40F, -2F, 3F, 40F, 12F)
                .texOffs(188, 139).addBox(-2F, -40F, -2F, 4F, 4F, 13F)
                .texOffs(84, 52).addBox(0F, -37F, 10F, 1F, 34F, 1F),
                PartPose.offsetAndRotation(-6F, -32F, 15F, 0.4F, -0.35F, -0.65F));
        PartDefinition p_wing0_l = p_torso.addOrReplaceChild("wing0_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-2F, -40F, -2F, 3F, 40F, 12F).mirror(false)
                .texOffs(188, 139).mirror().addBox(-2F, -40F, -2F, 4F, 4F, 13F).mirror(false)
                .texOffs(84, 52).mirror().addBox(0F, -37F, 10F, 1F, 34F, 1F).mirror(false),
                PartPose.offsetAndRotation(6F, -32F, 15F, 0.4F, 0.35F, 0.65F));
        PartDefinition p_tail0 = p_hips.addOrReplaceChild("tail0", CubeListBuilder.create()
                .texOffs(40, 139).addBox(-3F, -3F, -1F, 6F, 6F, 14F),
                PartPose.offsetAndRotation(0F, 2F, 9F, 0.5F, 0F, 0F));
        PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create()
                .texOffs(96, 139).addBox(-2F, -2F, -1F, 5F, 5F, 14F),
                PartPose.offsetAndRotation(0F, 0F, 13F, 0.2F, 0F, 0F));
        PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create()
                .texOffs(152, 139).addBox(-2F, -2F, -1F, 4F, 4F, 14F),
                PartPose.offsetAndRotation(0F, 0F, 13F, 0.2F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.REVERSE).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(12F, 14F)
                .leg("hips/thigh_r", "hips/thigh_r/shin_r", "hips/thigh_r/shin_r/foot_r", -1, 0F, 1)
                .leg("hips/thigh_l", "hips/thigh_l/shin_l", "hips/thigh_l/shin_l/foot_l", 1, 3.1416F, 1)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/tail0", 1, 0.12F, 0F)
                .sway("hips/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("hips/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .wing("hips/torso/wing0_r", -1)
                .wing("hips/torso/wing0_l", 1)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .primaryTwin(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
