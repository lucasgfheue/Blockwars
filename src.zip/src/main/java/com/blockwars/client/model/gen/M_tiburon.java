package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Shark (tiburon). */
@SuppressWarnings("unused")
public final class M_tiburon {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("tiburon"), "main");

    private M_tiburon() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "base,-1,0,22,-34,0,0,0/0,0,-13,-23,-10,27,23,19/194,105,-14,-2,-7,28,4,13/202,82,-11,-25,-9,23,3,17;snout,0,0,-19,-11,-0.2,0,0/"
                + "92,0,-11,-19,-21,23,19,23/84,82,-10,-21,-17,19,3,19/236,123,-10,-8,-22,19,8,1/38,138,-8,-15,-22,4,3,1/"
                + "38,138,4,-15,-22,4,3,1;tusk_r,1,-10,-4,-19,0.3,0,-0.3/206,123,-1,-1,-3,3,10,3;tusk_l,1,10,-4,-19,0.3,0,0.3/"
                + "!206,123,-1,-1,-3,3,10,3;jaw,1,0,0,-10,0,0,0/230,42,-10,0,-15,19,4,19/0,138,-9,-2,-15,17,2,2;seg0,0,0,0,10,0,0,0/"
                + "184,0,-13,-23,0,27,23,17/306,42,-10,-20,-3,21,17,6/282,82,-11,-25,1,23,3,15/276,105,-14,-2,3,28,4,11/"
                + "288,123,-10,-13,17,21,4,1/218,123,-1,-30,6,3,6,6;seg1,5,0,0,17,0,0,0/272,0,-13,-23,0,25,23,17/360,42,-10,-20,-3,20,17,6/"
                + "358,82,-11,-25,1,21,3,15/354,105,-14,-2,3,27,4,11/332,123,-10,-13,17,20,4,1;seg2,6,0,0,17,0,0,0/356,0,-12,-23,0,24,23,17/"
                + "412,42,-9,-20,-3,18,17,6/430,82,-10,-25,1,20,3,15/430,105,-13,-2,3,26,4,11/374,123,-9,-13,17,18,4,1/218,123,-1,-30,6,3,6,6;"
                + "seg3,7,0,0,17,0,0,0/0,42,-11,-23,0,23,23,17/460,42,-8,-20,-3,17,17,6/0,105,-9,-25,1,19,3,15/0,123,-12,-2,3,25,4,11/"
                + "412,123,-8,-13,17,17,4,1;seg4,8,0,0,17,0,0,0/80,42,-11,-23,0,21,23,17/0,82,-8,-20,-3,16,17,6/68,105,-9,-25,1,17,3,15/"
                + "72,123,-12,-2,3,23,4,11/448,123,-8,-13,17,16,4,1/218,123,-1,-30,6,3,6,6;seg5,9,0,0,17,0,0,0/156,42,-10,-23,0,20,23,17/"
                + "44,82,-7,-20,-3,14,17,6/132,105,-8,-25,1,16,3,15/140,123,-11,-2,3,22,4,11/482,123,-7,-13,17,14,4,1;tailtip,10,0,-8,17,0.2,0,0/"
                + "160,82,-4,-4,-1,8,8,13/276,123,-2,-2,12,4,4,2");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.SERPENT).parts("base", "base", "base/snout").walkRate(0.4211F)
                .segment("base/seg0")
                .segment("base/seg0/seg1")
                .segment("base/seg0/seg1/seg2")
                .segment("base/seg0/seg1/seg2/seg3")
                .segment("base/seg0/seg1/seg2/seg3/seg4")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/tailtip")
                .jaw("base/snout/jaw")
                .primary(Rig.MountKind.BODY, "base/snout", null, null, null)
                .secondary(Rig.MountKind.BODY, "base/snout", null, null, null);
    }
}
