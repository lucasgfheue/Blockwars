package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Shark (tiburon). */
@SuppressWarnings("unused")
public final class M_tiburon {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("tiburon"), "main");

    private M_tiburon() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_base = root.addOrReplaceChild("base", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-13F, -23F, -10F, 27F, 23F, 19F)
                .texOffs(194, 105).addBox(-14F, -2F, -7F, 28F, 4F, 13F)
                .texOffs(202, 82).addBox(-11F, -25F, -9F, 23F, 3F, 17F),
                PartPose.offsetAndRotation(0F, 22F, -34F, 0F, 0F, 0F));
        PartDefinition p_snout = p_base.addOrReplaceChild("snout", CubeListBuilder.create()
                .texOffs(92, 0).addBox(-11F, -19F, -21F, 23F, 19F, 23F)
                .texOffs(84, 82).addBox(-10F, -21F, -17F, 19F, 3F, 19F)
                .texOffs(236, 123).addBox(-10F, -8F, -22F, 19F, 8F, 1F)
                .texOffs(38, 138).addBox(-8F, -15F, -22F, 4F, 3F, 1F)
                .texOffs(38, 138).addBox(4F, -15F, -22F, 4F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -19F, -11F, -0.2F, 0F, 0F));
        PartDefinition p_tusk_r = p_snout.addOrReplaceChild("tusk_r", CubeListBuilder.create()
                .texOffs(206, 123).addBox(-1F, -1F, -3F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(-10F, -4F, -19F, 0.3F, 0F, -0.3F));
        PartDefinition p_tusk_l = p_snout.addOrReplaceChild("tusk_l", CubeListBuilder.create()
                .texOffs(206, 123).mirror().addBox(-1F, -1F, -3F, 3F, 10F, 3F).mirror(false),
                PartPose.offsetAndRotation(10F, -4F, -19F, 0.3F, 0F, 0.3F));
        PartDefinition p_jaw = p_snout.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(230, 42).addBox(-10F, 0F, -15F, 19F, 4F, 19F)
                .texOffs(0, 138).addBox(-9F, -2F, -15F, 17F, 2F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -10F, 0F, 0F, 0F));
        PartDefinition p_seg0 = p_base.addOrReplaceChild("seg0", CubeListBuilder.create()
                .texOffs(184, 0).addBox(-13F, -23F, 0F, 27F, 23F, 17F)
                .texOffs(306, 42).addBox(-10F, -20F, -3F, 21F, 17F, 6F)
                .texOffs(282, 82).addBox(-11F, -25F, 1F, 23F, 3F, 15F)
                .texOffs(276, 105).addBox(-14F, -2F, 3F, 28F, 4F, 11F)
                .texOffs(288, 123).addBox(-10F, -13F, 17F, 21F, 4F, 1F)
                .texOffs(218, 123).addBox(-1F, -30F, 6F, 3F, 6F, 6F),
                PartPose.offsetAndRotation(0F, 0F, 10F, 0F, 0F, 0F));
        PartDefinition p_seg1 = p_seg0.addOrReplaceChild("seg1", CubeListBuilder.create()
                .texOffs(272, 0).addBox(-13F, -23F, 0F, 25F, 23F, 17F)
                .texOffs(360, 42).addBox(-10F, -20F, -3F, 20F, 17F, 6F)
                .texOffs(358, 82).addBox(-11F, -25F, 1F, 21F, 3F, 15F)
                .texOffs(354, 105).addBox(-14F, -2F, 3F, 27F, 4F, 11F)
                .texOffs(332, 123).addBox(-10F, -13F, 17F, 20F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 17F, 0F, 0F, 0F));
        PartDefinition p_seg2 = p_seg1.addOrReplaceChild("seg2", CubeListBuilder.create()
                .texOffs(356, 0).addBox(-12F, -23F, 0F, 24F, 23F, 17F)
                .texOffs(412, 42).addBox(-9F, -20F, -3F, 18F, 17F, 6F)
                .texOffs(430, 82).addBox(-10F, -25F, 1F, 20F, 3F, 15F)
                .texOffs(430, 105).addBox(-13F, -2F, 3F, 26F, 4F, 11F)
                .texOffs(374, 123).addBox(-9F, -13F, 17F, 18F, 4F, 1F)
                .texOffs(218, 123).addBox(-1F, -30F, 6F, 3F, 6F, 6F),
                PartPose.offsetAndRotation(0F, 0F, 17F, 0F, 0F, 0F));
        PartDefinition p_seg3 = p_seg2.addOrReplaceChild("seg3", CubeListBuilder.create()
                .texOffs(0, 42).addBox(-11F, -23F, 0F, 23F, 23F, 17F)
                .texOffs(460, 42).addBox(-8F, -20F, -3F, 17F, 17F, 6F)
                .texOffs(0, 105).addBox(-9F, -25F, 1F, 19F, 3F, 15F)
                .texOffs(0, 123).addBox(-12F, -2F, 3F, 25F, 4F, 11F)
                .texOffs(412, 123).addBox(-8F, -13F, 17F, 17F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 17F, 0F, 0F, 0F));
        PartDefinition p_seg4 = p_seg3.addOrReplaceChild("seg4", CubeListBuilder.create()
                .texOffs(80, 42).addBox(-11F, -23F, 0F, 21F, 23F, 17F)
                .texOffs(0, 82).addBox(-8F, -20F, -3F, 16F, 17F, 6F)
                .texOffs(68, 105).addBox(-9F, -25F, 1F, 17F, 3F, 15F)
                .texOffs(72, 123).addBox(-12F, -2F, 3F, 23F, 4F, 11F)
                .texOffs(448, 123).addBox(-8F, -13F, 17F, 16F, 4F, 1F)
                .texOffs(218, 123).addBox(-1F, -30F, 6F, 3F, 6F, 6F),
                PartPose.offsetAndRotation(0F, 0F, 17F, 0F, 0F, 0F));
        PartDefinition p_seg5 = p_seg4.addOrReplaceChild("seg5", CubeListBuilder.create()
                .texOffs(156, 42).addBox(-10F, -23F, 0F, 20F, 23F, 17F)
                .texOffs(44, 82).addBox(-7F, -20F, -3F, 14F, 17F, 6F)
                .texOffs(132, 105).addBox(-8F, -25F, 1F, 16F, 3F, 15F)
                .texOffs(140, 123).addBox(-11F, -2F, 3F, 22F, 4F, 11F)
                .texOffs(482, 123).addBox(-7F, -13F, 17F, 14F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 17F, 0F, 0F, 0F));
        PartDefinition p_tailtip = p_seg5.addOrReplaceChild("tailtip", CubeListBuilder.create()
                .texOffs(160, 82).addBox(-4F, -4F, -1F, 8F, 8F, 13F)
                .texOffs(276, 123).addBox(-2F, -2F, 12F, 4F, 4F, 2F),
                PartPose.offsetAndRotation(0F, -8F, 17F, 0.2F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.SERPENT).parts("base", "base", "base/snout").walkRate(0.4211F)
                .segment("base/seg0")
                .segment("base/seg0/seg1")
                .segment("base/seg0/seg1/seg2")
                .segment("base/seg0/seg1/seg2/seg3")
                .segment("base/seg0/seg1/seg2/seg3/seg4")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/tailtip")
                .jaw("base/snout/jaw")
                .primary(Rig.MountKind.BODY, "base/snout", null, null, null)
                .secondary(Rig.MountKind.BODY, "base/snout", null, null, null);
    }
}
