package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Pilgrim (peregrino). */
@SuppressWarnings("unused")
public final class M_peregrino {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("peregrino"), "main");

    private M_peregrino() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(234, 63).addBox(-14F, -6F, -10F, 28F, 12F, 20F)
                .texOffs(66, 102).addBox(-15F, -6F, -11F, 30F, 6F, 22F)
                .texOffs(492, 132).addBox(-4F, -2F, -12F, 8F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -67F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(270, 0).addBox(-4F, 0F, -4F, 9F, 39F, 9F)
                .texOffs(370, 63).addBox(-6F, 2F, -8F, 11F, 27F, 5F)
                .texOffs(402, 63).addBox(-6F, 2F, -4F, 2F, 23F, 9F),
                PartPose.offsetAndRotation(-11F, -67F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(226, 0).addBox(-6F, 0F, -6F, 11F, 40F, 11F)
                .texOffs(290, 132).addBox(-4F, -6F, -9F, 9F, 10F, 5F)
                .texOffs(430, 102).addBox(-3F, 12F, 6F, 6F, 20F, 4F),
                PartPose.offsetAndRotation(0F, 39F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(426, 132).addBox(-3F, -1F, -3F, 6F, 5F, 6F)
                .texOffs(428, 63).addBox(-9F, 4F, -13F, 18F, 8F, 22F)
                .texOffs(56, 150).addBox(-8F, 6F, -14F, 15F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 40F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(270, 0).mirror().addBox(-4F, 0F, -4F, 9F, 39F, 9F).mirror(false)
                .texOffs(370, 63).mirror().addBox(-6F, 2F, -8F, 11F, 27F, 5F).mirror(false)
                .texOffs(402, 63).mirror().addBox(3F, 2F, -4F, 2F, 23F, 9F).mirror(false),
                PartPose.offsetAndRotation(11F, -67F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(226, 0).mirror().addBox(-6F, 0F, -6F, 11F, 40F, 11F).mirror(false)
                .texOffs(290, 132).mirror().addBox(-4F, -6F, -9F, 9F, 10F, 5F).mirror(false)
                .texOffs(430, 102).mirror().addBox(-3F, 12F, 6F, 6F, 20F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 39F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(426, 132).mirror().addBox(-3F, -1F, -3F, 6F, 5F, 6F).mirror(false)
                .texOffs(428, 63).mirror().addBox(-9F, 4F, -13F, 18F, 8F, 22F).mirror(false)
                .texOffs(56, 150).mirror().addBox(-8F, 6F, -14F, 15F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 40F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(190, 102).addBox(-11F, -12F, -8F, 22F, 12F, 15F)
                .texOffs(0, 63).addBox(-16F, -26F, -11F, 32F, 17F, 22F)
                .texOffs(306, 0).addBox(-25F, -40F, -15F, 50F, 19F, 28F)
                .texOffs(284, 102).addBox(-15F, -42F, -10F, 30F, 5F, 19F)
                .texOffs(40, 132).addBox(-12F, -37F, -18F, 25F, 13F, 4F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(250, 132).addBox(-5F, -5F, -5F, 10F, 5F, 10F)
                .texOffs(0, 102).addBox(-8F, -18F, -8F, 15F, 12F, 18F)
                .texOffs(450, 132).addBox(-5F, -16F, -9F, 10F, 10F, 1F)
                .texOffs(44, 150).addBox(-2F, -14F, -10F, 5F, 5F, 1F)
                .texOffs(156, 132).addBox(-5F, -19F, -6F, 10F, 1F, 15F),
                PartPose.offsetAndRotation(0F, -42F, -2F, 0F, 0F, 0F));
        PartDefinition p_crest = p_head.addOrReplaceChild("crest", CubeListBuilder.create()
                .texOffs(170, 102).addBox(-1F, -20F, -4F, 2F, 20F, 8F)
                .texOffs(246, 132).addBox(-1F, -18F, -5F, 1F, 15F, 1F),
                PartPose.offsetAndRotation(0F, -20F, -2F, -0.8F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(424, 63).addBox(-1F, -30F, -1F, 1F, 30F, 1F)
                .texOffs(88, 150).addBox(-1F, -31F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -15F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(382, 102).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(330, 63).addBox(-5F, 2F, -5F, 10F, 22F, 10F),
                PartPose.offsetAndRotation(-32F, -34F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(182, 63).addBox(-6F, 0F, -7F, 12F, 20F, 14F)
                .texOffs(98, 132).addBox(-7F, 19F, -8F, 14F, 2F, 15F),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_rail = p_forearm_r.addOrReplaceChild("forearm_r_rail", CubeListBuilder.create()
                .texOffs(108, 63).addBox(-6F, -6F, -20F, 12F, 12F, 25F)
                .texOffs(206, 132).addBox(-2F, -8F, -12F, 5F, 1F, 15F),
                PartPose.offsetAndRotation(0F, 26F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_rail_barrel = p_forearm_r_rail.addOrReplaceChild("forearm_r_rail_barrel", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-6F, -4F, -55F, 4F, 8F, 55F)
                .texOffs(0, 0).addBox(2F, -4F, -55F, 4F, 8F, 55F)
                .texOffs(118, 0).addBox(-1F, -1F, -54F, 2F, 2F, 52F)
                .texOffs(398, 132).addBox(-6F, -5F, -56F, 12F, 10F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -18F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_rail_flash = p_forearm_r_rail_barrel.addOrReplaceChild("forearm_r_rail_flash", CubeListBuilder.create()
                .texOffs(450, 102).addBox(-4F, -4F, -15F, 8F, 8F, 15F)
                .texOffs(0, 150).addBox(-9F, -1F, -4F, 18F, 2F, 4F)
                .texOffs(496, 102).addBox(-1F, -9F, -4F, 2F, 18F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -58F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(382, 102).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(330, 63).mirror().addBox(-5F, 2F, -5F, 10F, 22F, 10F).mirror(false),
                PartPose.offsetAndRotation(32F, -34F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(182, 63).mirror().addBox(-6F, 0F, -7F, 12F, 20F, 14F).mirror(false)
                .texOffs(98, 132).mirror().addBox(-7F, 19F, -8F, 14F, 2F, 15F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_none = p_forearm_l.addOrReplaceChild("forearm_l_none", CubeListBuilder.create()
                .texOffs(0, 132).addBox(-5F, 0F, -5F, 10F, 8F, 10F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_coil_r = p_torso.addOrReplaceChild("coil_r", CubeListBuilder.create()
                .texOffs(264, 102).addBox(-2F, -15F, -2F, 5F, 20F, 5F)
                .texOffs(318, 132).addBox(-5F, -6F, -5F, 10F, 2F, 10F)
                .texOffs(358, 132).addBox(-5F, -12F, -5F, 10F, 2F, 10F)
                .texOffs(318, 132).addBox(-5F, -19F, -5F, 10F, 2F, 10F)
                .texOffs(472, 132).addBox(-2F, -25F, -2F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(-15F, -38F, 19F, 0F, 0F, 0F));
        PartDefinition p_coil_l = p_torso.addOrReplaceChild("coil_l", CubeListBuilder.create()
                .texOffs(264, 102).addBox(-2F, -15F, -2F, 5F, 20F, 5F)
                .texOffs(318, 132).addBox(-5F, -6F, -5F, 10F, 2F, 10F)
                .texOffs(358, 132).addBox(-5F, -12F, -5F, 10F, 2F, 10F)
                .texOffs(318, 132).addBox(-5F, -19F, -5F, 10F, 2F, 10F)
                .texOffs(472, 132).addBox(-2F, -25F, -2F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(15F, -38F, 19F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.264F)
                .legLengths(19.375F, 20F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel/forearm_r_rail_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel/forearm_r_rail_flash", null);
    }
}
