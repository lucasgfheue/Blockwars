package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Pilgrim (peregrino). */
@SuppressWarnings("unused")
public final class M_peregrino {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("peregrino"), "main");

    private M_peregrino() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-67,0,0,0,0/234,63,-14,-6,-10,28,12,20/66,102,-15,-6,-11,30,6,22/492,132,-4,-2,-12,8,8,1;thigh_r,-1,-11,-67,0,0,0,0/"
                + "270,0,-4,0,-4,9,39,9/370,63,-6,2,-8,11,27,5/402,63,-6,2,-4,2,23,9;shin_r,1,0,39,0,0,0,0/226,0,-6,0,-6,11,40,11/"
                + "290,132,-4,-6,-9,9,10,5/430,102,-3,12,6,6,20,4;foot_r,2,0,40,0,0,0,0/426,132,-3,-1,-3,6,5,6/428,63,-9,4,-13,18,8,22/"
                + "56,150,-8,6,-14,15,4,1;thigh_l,-1,11,-67,0,0,0,0/!270,0,-4,0,-4,9,39,9/!370,63,-6,2,-8,11,27,5/!402,63,3,2,-4,2,23,9;"
                + "shin_l,4,0,39,0,0,0,0/!226,0,-6,0,-6,11,40,11/!290,132,-4,-6,-9,9,10,5/!430,102,-3,12,6,6,20,4;foot_l,5,0,40,0,0,0,0/"
                + "!426,132,-3,-1,-3,6,5,6/!428,63,-9,4,-13,18,8,22/!56,150,-8,6,-14,15,4,1;torso,0,0,-6,0,0,0,0/190,102,-11,-12,-8,22,12,15/"
                + "0,63,-16,-26,-11,32,17,22/306,0,-25,-40,-15,50,19,28/284,102,-15,-42,-10,30,5,19/40,132,-12,-37,-18,25,13,4;"
                + "head,7,0,-42,-2,0,0,0/250,132,-5,-5,-5,10,5,10/0,102,-8,-18,-8,15,12,18/450,132,-5,-16,-9,10,10,1/44,150,-2,-14,-10,5,5,1/"
                + "156,132,-5,-19,-6,10,1,15;crest,8,0,-20,-2,-0.8,0,0/170,102,-1,-20,-4,2,20,8/246,132,-1,-18,-5,1,15,1;"
                + "antenna,8,6,-15,5,-0.2,0,0.15/424,63,-1,-30,-1,1,30,1/88,150,-1,-31,-1,2,2,2;shoulder_r,7,-32,-34,0,0,0,0/"
                + "382,102,-6,-6,-6,12,12,12/330,63,-5,2,-5,10,22,10;forearm_r,11,0,24,0,-0.25,0,0/182,63,-6,0,-7,12,20,14/"
                + "98,132,-7,19,-8,14,2,15;forearm_r_rail,12,0,26,-2,0,0,0/108,63,-6,-6,-20,12,12,25/206,132,-2,-8,-12,5,1,15;"
                + "forearm_r_rail_barrel,13,0,0,-18,0,0,0/0,0,-6,-4,-55,4,8,55/0,0,2,-4,-55,4,8,55/118,0,-1,-1,-54,2,2,52/"
                + "398,132,-6,-5,-56,12,10,2;forearm_r_rail_flash,14,0,0,-58,0,0,0/450,102,-4,-4,-15,8,8,15/0,150,-9,-1,-4,18,2,4/"
                + "496,102,-1,-9,-4,2,18,4;shoulder_l,7,32,-34,0,0,0,0/!382,102,-6,-6,-6,12,12,12/!330,63,-5,2,-5,10,22,10;"
                + "forearm_l,16,0,24,0,-0.25,0,0/!182,63,-6,0,-7,12,20,14/!98,132,-7,19,-8,14,2,15;forearm_l_none,17,0,24,-2,0,0,0/"
                + "0,132,-5,0,-5,10,8,10;coil_r,7,-15,-38,19,0,0,0/264,102,-2,-15,-2,5,20,5/318,132,-5,-6,-5,10,2,10/358,132,-5,-12,-5,10,2,10/"
                + "318,132,-5,-19,-5,10,2,10/472,132,-2,-25,-2,5,5,5;coil_l,7,15,-38,19,0,0,0/264,102,-2,-15,-2,5,20,5/318,132,-5,-6,-5,10,2,10/"
                + "358,132,-5,-12,-5,10,2,10/318,132,-5,-19,-5,10,2,10/472,132,-2,-25,-2,5,5,5");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.264F)
                .legLengths(19.375F, 20F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel/forearm_r_rail_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_rail/forearm_r_rail_barrel/forearm_r_rail_flash", null);
    }
}
