package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Stormcaller (llamatormentas). */
@SuppressWarnings("unused")
public final class M_llamatormentas {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("llamatormentas"), "main");

    private M_llamatormentas() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(84, 75).addBox(-13F, -6F, -9F, 26F, 11F, 18F)
                .texOffs(0, 105).addBox(-14F, -5F, -10F, 29F, 6F, 20F)
                .texOffs(0, 182).addBox(-3F, -2F, -11F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -35F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(188, 0).addBox(-6F, 0F, -6F, 11F, 24F, 11F)
                .texOffs(146, 131).addBox(-7F, 2F, -9F, 13F, 17F, 4F)
                .texOffs(98, 105).addBox(-7F, 2F, -6F, 2F, 15F, 11F),
                PartPose.offsetAndRotation(-11F, -35F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(136, 0).addBox(-7F, 0F, -7F, 13F, 25F, 13F)
                .texOffs(0, 169).addBox(-6F, -6F, -10F, 11F, 9F, 4F)
                .texOffs(0, 153).addBox(-4F, 8F, 7F, 9F, 13F, 3F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(56, 169).addBox(-4F, -1F, -4F, 8F, 4F, 8F)
                .texOffs(0, 75).addBox(-9F, 3F, -14F, 19F, 7F, 23F)
                .texOffs(52, 182).addBox(-8F, 6F, -15F, 16F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 25F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(188, 0).mirror().addBox(-6F, 0F, -6F, 11F, 24F, 11F).mirror(false)
                .texOffs(146, 131).mirror().addBox(-7F, 2F, -9F, 13F, 17F, 4F).mirror(false)
                .texOffs(98, 105).mirror().addBox(4F, 2F, -6F, 2F, 15F, 11F).mirror(false),
                PartPose.offsetAndRotation(11F, -35F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(136, 0).mirror().addBox(-7F, 0F, -7F, 13F, 25F, 13F).mirror(false)
                .texOffs(0, 169).mirror().addBox(-6F, -6F, -10F, 11F, 9F, 4F).mirror(false)
                .texOffs(0, 153).mirror().addBox(-4F, 8F, 7F, 9F, 13F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(56, 169).mirror().addBox(-4F, -1F, -4F, 8F, 4F, 8F).mirror(false)
                .texOffs(0, 75).mirror().addBox(-9F, 3F, -14F, 19F, 7F, 23F).mirror(false)
                .texOffs(52, 182).mirror().addBox(-8F, 6F, -15F, 16F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 25F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(142, 105).addBox(-10F, -11F, -7F, 20F, 11F, 13F)
                .texOffs(0, 41).addBox(-14F, -23F, -10F, 29F, 15F, 19F)
                .texOffs(0, 0).addBox(-22F, -35F, -13F, 44F, 17F, 24F)
                .texOffs(60, 131).addBox(-13F, -37F, -8F, 26F, 4F, 17F)
                .texOffs(86, 153).addBox(-11F, -33F, -16F, 22F, 11F, 3F)
                .texOffs(184, 169).addBox(-4F, -29F, -14F, 9F, 9F, 2F)
                .texOffs(136, 153).addBox(-7F, -31F, -13F, 13F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(196, 153).addBox(-4F, -4F, -4F, 9F, 4F, 9F)
                .texOffs(172, 75).addBox(-8F, -18F, -8F, 15F, 13F, 15F)
                .texOffs(94, 182).addBox(-6F, -12F, -8F, 11F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -37F, -2F, 0F, 0F, 0F));
        PartDefinition p_horn_r = p_head.addOrReplaceChild("horn_r", CubeListBuilder.create()
                .texOffs(24, 153).addBox(-2F, -13F, -2F, 3F, 13F, 3F)
                .texOffs(44, 182).addBox(-1F, -16F, 0F, 2F, 4F, 2F),
                PartPose.offsetAndRotation(-8F, -15F, 0F, 0.4F, 0F, -0.9F));
        PartDefinition p_horn_l = p_head.addOrReplaceChild("horn_l", CubeListBuilder.create()
                .texOffs(24, 153).mirror().addBox(-2F, -13F, -2F, 3F, 13F, 3F).mirror(false)
                .texOffs(44, 182).mirror().addBox(-1F, -16F, 0F, 2F, 4F, 2F).mirror(false),
                PartPose.offsetAndRotation(8F, -15F, 0F, 0.4F, 0F, 0.9F));
        PartDefinition p_crest = p_head.addOrReplaceChild("crest", CubeListBuilder.create()
                .texOffs(124, 105).addBox(-1F, -18F, -3F, 2F, 18F, 7F)
                .texOffs(192, 153).addBox(-1F, -15F, -4F, 1F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -18F, -2F, -0.8F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(232, 75).addBox(-1F, -26F, -1F, 1F, 26F, 1F)
                .texOffs(86, 182).addBox(-1F, -28F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(208, 105).addBox(-6F, -6F, -6F, 11F, 11F, 11F)
                .texOffs(172, 75).addBox(-9F, -10F, -8F, 15F, 13F, 15F)
                .texOffs(180, 131).addBox(-9F, -6F, -8F, 16F, 4F, 16F)
                .texOffs(142, 41).addBox(-4F, 2F, -4F, 9F, 22F, 9F),
                PartPose.offsetAndRotation(-29F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(96, 41).addBox(-6F, 0F, -6F, 11F, 20F, 12F)
                .texOffs(36, 153).addBox(-6F, 19F, -7F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_tesla = p_forearm_r.addOrReplaceChild("forearm_r_tesla", CubeListBuilder.create()
                .texOffs(0, 131).addBox(-4F, -4F, -11F, 9F, 9F, 13F)
                .texOffs(30, 169).addBox(-6F, -6F, -14F, 11F, 11F, 2F)
                .texOffs(32, 182).addBox(-2F, -2F, -16F, 4F, 4F, 2F)
                .texOffs(88, 169).addBox(-5F, -5F, -19F, 10F, 10F, 2F)
                .texOffs(32, 182).addBox(-2F, -2F, -21F, 4F, 4F, 2F)
                .texOffs(206, 169).addBox(-4F, -4F, -23F, 9F, 9F, 2F)
                .texOffs(32, 182).addBox(-2F, -2F, -25F, 4F, 4F, 2F)
                .texOffs(228, 169).addBox(-4F, -4F, -28F, 8F, 8F, 2F)
                .texOffs(32, 182).addBox(-2F, -2F, -30F, 4F, 4F, 2F),
                PartPose.offsetAndRotation(0F, 25F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_tesla_orb = p_forearm_r_tesla.addOrReplaceChild("forearm_r_tesla_orb", CubeListBuilder.create()
                .texOffs(164, 153).addBox(-3F, -3F, -3F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(0F, 0F, -34F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(208, 105).mirror().addBox(-6F, -6F, -6F, 11F, 11F, 11F).mirror(false)
                .texOffs(172, 75).mirror().addBox(-7F, -10F, -8F, 15F, 13F, 15F).mirror(false)
                .texOffs(180, 131).mirror().addBox(-7F, -6F, -8F, 16F, 4F, 16F).mirror(false)
                .texOffs(142, 41).mirror().addBox(-4F, 2F, -4F, 9F, 22F, 9F).mirror(false),
                PartPose.offsetAndRotation(29F, -30F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(96, 41).mirror().addBox(-6F, 0F, -6F, 11F, 20F, 12F).mirror(false)
                .texOffs(36, 153).mirror().addBox(-6F, 19F, -7F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_tesla = p_forearm_l.addOrReplaceChild("forearm_l_tesla", CubeListBuilder.create()
                .texOffs(0, 131).addBox(-4F, -4F, -11F, 9F, 9F, 13F)
                .texOffs(30, 169).addBox(-6F, -6F, -14F, 11F, 11F, 2F)
                .texOffs(32, 182).addBox(-2F, -2F, -16F, 4F, 4F, 2F)
                .texOffs(88, 169).addBox(-5F, -5F, -19F, 10F, 10F, 2F)
                .texOffs(32, 182).addBox(-2F, -2F, -21F, 4F, 4F, 2F)
                .texOffs(206, 169).addBox(-4F, -4F, -23F, 9F, 9F, 2F)
                .texOffs(32, 182).addBox(-2F, -2F, -25F, 4F, 4F, 2F)
                .texOffs(228, 169).addBox(-4F, -4F, -28F, 8F, 8F, 2F)
                .texOffs(32, 182).addBox(-2F, -2F, -30F, 4F, 4F, 2F),
                PartPose.offsetAndRotation(0F, 25F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_tesla_orb = p_forearm_l_tesla.addOrReplaceChild("forearm_l_tesla_orb", CubeListBuilder.create()
                .texOffs(164, 153).addBox(-3F, -3F, -3F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(0F, 0F, -34F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_coil_r = p_torso.addOrReplaceChild("coil_r", CubeListBuilder.create()
                .texOffs(44, 131).addBox(-2F, -13F, -2F, 4F, 18F, 4F)
                .texOffs(112, 169).addBox(-4F, -6F, -4F, 9F, 2F, 9F)
                .texOffs(148, 169).addBox(-4F, -11F, -4F, 9F, 2F, 9F)
                .texOffs(112, 169).addBox(-4F, -16F, -4F, 9F, 2F, 9F)
                .texOffs(16, 182).addBox(-2F, -22F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(-13F, -33F, 16F, 0F, 0F, 0F));
        PartDefinition p_coil_l = p_torso.addOrReplaceChild("coil_l", CubeListBuilder.create()
                .texOffs(44, 131).addBox(-2F, -13F, -2F, 4F, 18F, 4F)
                .texOffs(112, 169).addBox(-4F, -6F, -4F, 9F, 2F, 9F)
                .texOffs(148, 169).addBox(-4F, -11F, -4F, 9F, 2F, 9F)
                .texOffs(112, 169).addBox(-4F, -16F, -4F, 9F, 2F, 9F)
                .texOffs(16, 182).addBox(-2F, -22F, -2F, 4F, 4F, 4F),
                PartPose.offsetAndRotation(13F, -33F, 16F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(12.1F, 12.65F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_tesla/forearm_r_tesla_orb", 1, 0.4F, 0)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_tesla/forearm_l_tesla_orb", 1, 0.4F, 0)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
