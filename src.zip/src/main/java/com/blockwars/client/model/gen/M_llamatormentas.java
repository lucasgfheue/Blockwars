package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Stormcaller (llamatormentas). */
@SuppressWarnings("unused")
public final class M_llamatormentas {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("llamatormentas"), "main");

    private M_llamatormentas() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-35,0,0,0,0/84,75,-13,-6,-9,26,11,18/0,105,-14,-5,-10,29,6,20/0,182,-3,-2,-11,7,7,1;thigh_r,-1,-11,-35,0,0,0,0/"
                + "188,0,-6,0,-6,11,24,11/146,131,-7,2,-9,13,17,4/98,105,-7,2,-6,2,15,11;shin_r,1,0,24,0,0,0,0/136,0,-7,0,-7,13,25,13/"
                + "0,169,-6,-6,-10,11,9,4/0,153,-4,8,7,9,13,3;foot_r,2,0,25,0,0,0,0/56,169,-4,-1,-4,8,4,8/0,75,-9,3,-14,19,7,23/"
                + "52,182,-8,6,-15,16,3,1;thigh_l,-1,11,-35,0,0,0,0/!188,0,-6,0,-6,11,24,11/!146,131,-7,2,-9,13,17,4/!98,105,4,2,-6,2,15,11;"
                + "shin_l,4,0,24,0,0,0,0/!136,0,-7,0,-7,13,25,13/!0,169,-6,-6,-10,11,9,4/!0,153,-4,8,7,9,13,3;foot_l,5,0,25,0,0,0,0/"
                + "!56,169,-4,-1,-4,8,4,8/!0,75,-9,3,-14,19,7,23/!52,182,-8,6,-15,16,3,1;torso,0,0,-6,0,0,0,0/142,105,-10,-11,-7,20,11,13/"
                + "0,41,-14,-23,-10,29,15,19/0,0,-22,-35,-13,44,17,24/60,131,-13,-37,-8,26,4,17/86,153,-11,-33,-16,22,11,3/"
                + "184,169,-4,-29,-14,9,9,2/136,153,-7,-31,-13,13,13,1;head,7,0,-37,-2,0,0,0/196,153,-4,-4,-4,9,4,9/172,75,-8,-18,-8,15,13,15/"
                + "94,182,-6,-12,-8,11,2,1;horn_r,8,-8,-15,0,0.4,0,-0.9/24,153,-2,-13,-2,3,13,3/44,182,-1,-16,0,2,4,2;horn_l,8,8,-15,0,0.4,0,0.9/"
                + "!24,153,-2,-13,-2,3,13,3/!44,182,-1,-16,0,2,4,2;crest,8,0,-18,-2,-0.8,0,0/124,105,-1,-18,-3,2,18,7/192,153,-1,-15,-4,1,13,1;"
                + "antenna,8,6,-13,4,-0.2,0,0.15/232,75,-1,-26,-1,1,26,1/86,182,-1,-28,-1,2,2,2;shoulder_r,7,-29,-30,0,0,0,0/"
                + "208,105,-6,-6,-6,11,11,11/172,75,-9,-10,-8,15,13,15/180,131,-9,-6,-8,16,4,16/142,41,-4,2,-4,9,22,9;forearm_r,13,0,23,0,-0.25,0,0/"
                + "96,41,-6,0,-6,11,20,12/36,153,-6,19,-7,12,2,13;forearm_r_tesla,14,0,25,-2,0,0,0/0,131,-4,-4,-11,9,9,13/"
                + "30,169,-6,-6,-14,11,11,2/32,182,-2,-2,-16,4,4,2/88,169,-5,-5,-19,10,10,2/32,182,-2,-2,-21,4,4,2/206,169,-4,-4,-23,9,9,2/"
                + "32,182,-2,-2,-25,4,4,2/228,169,-4,-4,-28,8,8,2/32,182,-2,-2,-30,4,4,2;forearm_r_tesla_orb,15,0,0,-34,0.7854,0.7854,0/"
                + "164,153,-3,-3,-3,7,7,7;shoulder_l,7,29,-30,0,0,0,0/!208,105,-6,-6,-6,11,11,11/!172,75,-7,-10,-8,15,13,15/"
                + "!180,131,-7,-6,-8,16,4,16/!142,41,-4,2,-4,9,22,9;forearm_l,17,0,23,0,-0.25,0,0/!96,41,-6,0,-6,11,20,12/"
                + "!36,153,-6,19,-7,12,2,13;forearm_l_tesla,18,0,25,-2,0,0,0/0,131,-4,-4,-11,9,9,13/30,169,-6,-6,-14,11,11,2/"
                + "32,182,-2,-2,-16,4,4,2/88,169,-5,-5,-19,10,10,2/32,182,-2,-2,-21,4,4,2/206,169,-4,-4,-23,9,9,2/32,182,-2,-2,-25,4,4,2/"
                + "228,169,-4,-4,-28,8,8,2/32,182,-2,-2,-30,4,4,2;forearm_l_tesla_orb,19,0,0,-34,0.7854,0.7854,0/164,153,-3,-3,-3,7,7,7;"
                + "coil_r,7,-13,-33,16,0,0,0/44,131,-2,-13,-2,4,18,4/112,169,-4,-6,-4,9,2,9/148,169,-4,-11,-4,9,2,9/112,169,-4,-16,-4,9,2,9/"
                + "16,182,-2,-22,-2,4,4,4;coil_l,7,13,-33,16,0,0,0/44,131,-2,-13,-2,4,18,4/112,169,-4,-6,-4,9,2,9/148,169,-4,-11,-4,9,2,9/"
                + "112,169,-4,-16,-4,9,2,9/16,182,-2,-22,-2,4,4,4");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(12.1F, 12.65F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_tesla/forearm_r_tesla_orb", 1, 0.4F, 0)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_tesla/forearm_l_tesla_orb", 1, 0.4F, 0)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
