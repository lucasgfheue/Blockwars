package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for HELIOS · Walking Reactor (helios). */
@SuppressWarnings("unused")
public final class M_helios {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("helios"), "main");

    private M_helios() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(216, 113).addBox(-20F, -7F, -11F, 40F, 14F, 22F)
                .texOffs(0, 152).addBox(-22F, -6F, -12F, 43F, 7F, 24F)
                .texOffs(472, 209).addBox(-4F, -3F, -14F, 8F, 8F, 1F),
                PartPose.offsetAndRotation(0F, -41F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(134, 68).addBox(-9F, 0F, -9F, 19F, 26F, 19F)
                .texOffs(168, 183).addBox(-11F, 3F, -14F, 22F, 18F, 5F)
                .texOffs(416, 113).addBox(-11F, 3F, -9F, 3F, 15F, 19F),
                PartPose.offsetAndRotation(-18F, -41F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(340, 0).addBox(-11F, 0F, -11F, 22F, 27F, 22F)
                .texOffs(204, 209).addBox(-9F, -7F, -15F, 19F, 11F, 5F)
                .texOffs(120, 227).addBox(-2F, -3F, -16F, 4F, 4F, 1F)
                .texOffs(0, 209).addBox(-8F, 8F, 11F, 16F, 14F, 4F),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(438, 183).addBox(-7F, -1F, -7F, 13F, 5F, 13F)
                .texOffs(0, 68).addBox(-15F, 4F, -22F, 30F, 8F, 37F)
                .texOffs(64, 227).addBox(-14F, 7F, -24F, 27F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(134, 68).mirror().addBox(-9F, 0F, -9F, 19F, 26F, 19F).mirror(false)
                .texOffs(168, 183).mirror().addBox(-11F, 3F, -14F, 22F, 18F, 5F).mirror(false)
                .texOffs(416, 113).mirror().addBox(8F, 3F, -9F, 3F, 15F, 19F).mirror(false),
                PartPose.offsetAndRotation(18F, -41F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(340, 0).mirror().addBox(-11F, 0F, -11F, 22F, 27F, 22F).mirror(false)
                .texOffs(204, 209).mirror().addBox(-9F, -7F, -15F, 19F, 11F, 5F).mirror(false)
                .texOffs(120, 227).mirror().addBox(-2F, -3F, -16F, 4F, 4F, 1F).mirror(false)
                .texOffs(0, 209).mirror().addBox(-8F, 8F, 11F, 16F, 14F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 26F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(438, 183).mirror().addBox(-7F, -1F, -7F, 13F, 5F, 13F).mirror(false)
                .texOffs(0, 68).mirror().addBox(-15F, 4F, -22F, 30F, 8F, 37F).mirror(false)
                .texOffs(64, 227).mirror().addBox(-14F, 7F, -24F, 27F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 27F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(102, 113).addBox(-17F, -14F, -11F, 34F, 14F, 23F)
                .texOffs(166, 0).addBox(-28F, -46F, -15F, 57F, 35F, 30F)
                .texOffs(0, 0).addBox(-23F, -43F, -19F, 45F, 30F, 38F)
                .texOffs(286, 68).addBox(-29F, -32F, -16F, 58F, 7F, 32F)
                .texOffs(134, 152).addBox(-20F, -49F, -13F, 40F, 5F, 26F)
                .texOffs(388, 209).addBox(-5F, -38F, -21F, 11F, 11F, 3F)
                .texOffs(112, 209).addBox(-8F, -40F, -20F, 16F, 16F, 1F),
                PartPose.offsetAndRotation(0F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(40, 209).addBox(-2F, -14F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(-26F, -46F, 5F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(40, 209).addBox(-2F, -14F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(-26F, -46F, 14F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(40, 209).addBox(-2F, -14F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(26F, -46F, 5F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(40, 209).addBox(-2F, -14F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(26F, -46F, 14F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(382, 183).addBox(-7F, -5F, -7F, 14F, 5F, 14F)
                .texOffs(0, 183).addBox(-11F, -9F, -11F, 22F, 4F, 22F)
                .texOffs(266, 152).addBox(-9F, -21F, -9F, 19F, 12F, 19F)
                .texOffs(56, 209).addBox(-7F, -24F, -7F, 14F, 3F, 14F)
                .texOffs(452, 209).addBox(-3F, -16F, -3F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(0F, -49F, -3F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(342, 152).addBox(-7F, -7F, -7F, 14F, 14F, 14F)
                .texOffs(340, 113).addBox(-11F, -12F, -9F, 19F, 16F, 19F)
                .texOffs(88, 183).addBox(-11F, -7F, -10F, 20F, 5F, 20F)
                .texOffs(58, 113).addBox(-5F, 3F, -5F, 11F, 27F, 11F),
                PartPose.offsetAndRotation(-36F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(0, 113).addBox(-7F, 0F, -7F, 14F, 24F, 15F)
                .texOffs(320, 183).addBox(-7F, 23F, -8F, 15F, 3F, 16F),
                PartPose.offsetAndRotation(0F, 28F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_emitter = p_forearm_r.addOrReplaceChild("forearm_r_emitter", CubeListBuilder.create()
                .texOffs(398, 152).addBox(-6F, -6F, -14F, 12F, 12F, 16F)
                .texOffs(146, 209).addBox(-1F, 5F, -23F, 3F, 3F, 14F)
                .texOffs(146, 209).addBox(-7F, -5F, -23F, 3F, 3F, 14F)
                .texOffs(146, 209).addBox(4F, -5F, -23F, 3F, 3F, 14F),
                PartPose.offsetAndRotation(0F, 31F, -3F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_emitter_orb = p_forearm_r_emitter.addOrReplaceChild("forearm_r_emitter_orb", CubeListBuilder.create()
                .texOffs(252, 209).addBox(-4F, -4F, -4F, 8F, 8F, 8F)
                .texOffs(284, 209).addBox(-2F, -5F, -2F, 4F, 11F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(342, 152).mirror().addBox(-7F, -7F, -7F, 14F, 14F, 14F).mirror(false)
                .texOffs(340, 113).mirror().addBox(-8F, -12F, -9F, 19F, 16F, 19F).mirror(false)
                .texOffs(88, 183).mirror().addBox(-9F, -7F, -10F, 20F, 5F, 20F).mirror(false)
                .texOffs(58, 113).mirror().addBox(-5F, 3F, -5F, 11F, 27F, 11F).mirror(false),
                PartPose.offsetAndRotation(36F, -39F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(0, 113).mirror().addBox(-7F, 0F, -7F, 14F, 24F, 15F).mirror(false)
                .texOffs(320, 183).mirror().addBox(-7F, 23F, -8F, 15F, 3F, 16F).mirror(false),
                PartPose.offsetAndRotation(0F, 28F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_emitter = p_forearm_l.addOrReplaceChild("forearm_l_emitter", CubeListBuilder.create()
                .texOffs(398, 152).addBox(-6F, -6F, -14F, 12F, 12F, 16F)
                .texOffs(146, 209).addBox(-1F, 5F, -23F, 3F, 3F, 14F)
                .texOffs(146, 209).addBox(-7F, -5F, -23F, 3F, 3F, 14F)
                .texOffs(146, 209).addBox(4F, -5F, -23F, 3F, 3F, 14F),
                PartPose.offsetAndRotation(0F, 31F, -3F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_emitter_orb = p_forearm_l_emitter.addOrReplaceChild("forearm_l_emitter_orb", CubeListBuilder.create()
                .texOffs(252, 209).addBox(-4F, -4F, -4F, 8F, 8F, 8F)
                .texOffs(284, 209).addBox(-2F, -5F, -2F, 4F, 11F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0.7854F, 0.7854F, 0F));
        PartDefinition p_reactor = p_torso.addOrReplaceChild("reactor", CubeListBuilder.create()
                .texOffs(210, 68).addBox(-12F, -14F, -7F, 24F, 27F, 14F)
                .texOffs(180, 209).addBox(-5F, -8F, 6F, 11F, 16F, 1F)
                .texOffs(234, 183).addBox(-14F, -11F, -7F, 27F, 4F, 16F)
                .texOffs(234, 183).addBox(-14F, 7F, -7F, 27F, 4F, 16F),
                PartPose.offsetAndRotation(0F, -27F, 27F, 0F, 0F, 0F));
        PartDefinition p_reactor_ring = p_reactor.addOrReplaceChild("reactor_ring", CubeListBuilder.create()
                .texOffs(0, 227).addBox(-9F, -1F, -1F, 19F, 3F, 3F)
                .texOffs(222, 183).addBox(-1F, -9F, -1F, 3F, 19F, 3F),
                PartPose.offsetAndRotation(0F, 0F, 8F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(460, 113).addBox(-4F, -23F, -4F, 8F, 24F, 8F)
                .texOffs(416, 209).addBox(-5F, -25F, -5F, 9F, 3F, 9F)
                .texOffs(44, 227).addBox(-3F, -26F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(-17F, -43F, 24F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(460, 113).addBox(-4F, -23F, -4F, 8F, 24F, 8F)
                .texOffs(416, 209).addBox(-5F, -25F, -5F, 9F, 3F, 9F)
                .texOffs(44, 227).addBox(-3F, -26F, -3F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(17F, -43F, 24F, -0.15F, 0F, -0.1F));
        PartDefinition p_coil_r = p_torso.addOrReplaceChild("coil_r", CubeListBuilder.create()
                .texOffs(454, 152).addBox(-3F, -16F, -3F, 5F, 22F, 5F)
                .texOffs(300, 209).addBox(-5F, -7F, -5F, 11F, 3F, 11F)
                .texOffs(344, 209).addBox(-5F, -14F, -5F, 11F, 3F, 11F)
                .texOffs(300, 209).addBox(-5F, -20F, -5F, 11F, 3F, 11F)
                .texOffs(452, 209).addBox(-3F, -27F, -3F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(-17F, -43F, 24F, 0F, 0F, 0F));
        PartDefinition p_coil_l = p_torso.addOrReplaceChild("coil_l", CubeListBuilder.create()
                .texOffs(454, 152).addBox(-3F, -16F, -3F, 5F, 22F, 5F)
                .texOffs(300, 209).addBox(-5F, -7F, -5F, 11F, 3F, 11F)
                .texOffs(344, 209).addBox(-5F, -14F, -5F, 11F, 3F, 11F)
                .texOffs(300, 209).addBox(-5F, -20F, -5F, 11F, 3F, 11F)
                .texOffs(452, 209).addBox(-3F, -27F, -3F, 5F, 5F, 5F),
                PartPose.offsetAndRotation(17F, -43F, 24F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2444F)
                .legLengths(12.825F, 13.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/reactor/reactor_ring", 2, 0.15F, 0)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_emitter/forearm_r_emitter_orb", 2, 0.25F, 0)
                .spin("hips/torso/shoulder_l/forearm_l/forearm_l_emitter/forearm_l_emitter_orb", 2, 0.25F, 0)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", null, null, null);
    }
}
