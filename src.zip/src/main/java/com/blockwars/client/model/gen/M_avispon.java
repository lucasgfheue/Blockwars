package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Hornet (avispon). */
@SuppressWarnings("unused")
public final class M_avispon {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("avispon"), "main");

    private M_avispon() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-17,0,0,0,0/0,61,-10,-4,-7,20,8,14/0,83,-11,-4,-8,22,4,15/72,134,-3,-2,-8,5,5,1;thigh_r,0,-12,0,0,-0.55,0,0/"
                + "212,0,-5,0,-5,10,20,10/68,61,-6,3,-4,1,14,8;shin_r,1,0,19,0,1.15,0,0/180,0,-4,0,-4,8,24,8/152,83,-5,-3,-5,10,7,10/"
                + "202,102,-3,4,4,6,14,2;foot_r,2,0,24,0,-0.6,0,0/74,34,-7,0,-12,14,5,20/114,134,-6,2,-13,12,3,1/228,119,-3,0,7,5,3,7;"
                + "thigh_l,0,12,0,0,-0.55,0,0/!212,0,-5,0,-5,10,20,10/!68,61,5,3,-4,1,14,8;shin_l,4,0,19,0,1.15,0,0/!180,0,-4,0,-4,8,24,8/"
                + "!152,83,-5,-3,-5,10,7,10/!202,102,-3,4,4,6,14,2;foot_l,5,0,24,0,-0.6,0,0/!74,34,-7,0,-12,14,5,20/!114,134,-6,2,-13,12,3,1/"
                + "!228,119,-3,0,7,5,3,7;torso,0,0,-4,0,0,0,0/102,83,-8,-8,-5,15,8,10/0,34,-11,-18,-7,22,12,15/74,0,-17,-27,-10,34,13,19/"
                + "34,102,-10,-29,-7,20,3,13/88,119,-8,-25,-12,17,9,3;head,7,0,-29,-2,0,0,0/200,119,-3,-3,-3,7,3,7/164,61,-5,-12,-5,10,8,12/"
                + "24,134,-3,-11,-6,7,7,1/140,134,-2,-9,-7,3,3,1/166,119,-3,-13,-4,7,1,10;antenna,8,4,-10,3,-0.2,0,0.15/"
                + "160,61,0,-20,0,1,20,1/148,134,-1,-21,-1,2,2,2;shoulder_r,7,-22,-23,0,0,0,0/138,102,-4,-4,-4,8,8,8/224,34,-3,2,-3,7,17,7;"
                + "shoulder_r_pod,10,-2,-5,0,0,0,0/0,0,-8,-14,-10,17,14,20/86,61,-8,-14,-10,17,1,20/56,119,-8,-13,-11,15,12,1;"
                + "forearm_r,10,0,18,0,-0.25,0,0/190,34,-4,0,-5,8,15,9/128,119,-5,14,-5,9,2,10;forearm_r_gun,12,0,20,-2,0,0,0/"
                + "142,34,-3,-4,-15,7,8,17/100,102,-3,-6,-14,5,2,14/40,134,-2,3,-3,3,3,5;forearm_r_gun_barrel,13,0,-1,-15,0,0,0/"
                + "192,83,-2,-2,-14,3,3,14/56,134,-3,-3,-15,5,5,3;forearm_r_gun_flash,14,0,0,-15,0,0,0/218,102,-3,-3,-10,5,5,10/"
                + "84,134,-6,-1,-3,12,2,3/30,119,-1,-6,-3,2,12,3;shoulder_l,7,22,-23,0,0,0,0/!138,102,-4,-4,-4,8,8,8/!224,34,-3,2,-3,7,17,7;"
                + "shoulder_l_pod,16,2,-5,0,0,0,0/0,0,-8,-14,-10,17,14,20/86,61,-8,-14,-10,17,1,20/56,119,-8,-13,-11,15,12,1;"
                + "forearm_l,16,0,18,0,-0.25,0,0/!190,34,-4,0,-5,8,15,9/!128,119,-5,14,-5,9,2,10;forearm_l_gun,18,0,20,-2,0,0,0/"
                + "142,34,-3,-4,-15,7,8,17/100,102,-3,-6,-14,5,2,14/40,134,-2,3,-3,3,3,5;forearm_l_gun_barrel,19,0,-1,-15,0,0,0/"
                + "192,83,-2,-2,-14,3,3,14/56,134,-3,-3,-15,5,5,3;forearm_l_gun_flash,20,0,0,-15,0,0,0/218,102,-3,-3,-10,5,5,10/"
                + "84,134,-6,-1,-3,12,2,3/30,119,-1,-6,-3,2,12,3;thr_r,7,-10,-19,13,0.35,0,0/74,83,-3,-6,-3,7,12,7/0,134,-3,6,-3,6,3,6;"
                + "flame_r,22,0,8,0,0,0,0/40,119,-2,0,-2,4,10,4;thr_l,7,10,-19,13,0.35,0,0/74,83,-3,-6,-3,7,12,7/0,134,-3,6,-3,6,3,6;"
                + "flame_l,24,0,8,0,0,0,0/40,119,-2,0,-2,4,10,4;tail0,0,0,2,8,0.5,0,0/0,102,-3,-3,-1,5,5,12;tail1,26,0,0,11,0.2,0,0/"
                + "170,102,-2,-2,-1,4,4,12;tail2,27,0,0,11,0.2,0,0/0,119,-2,-2,-1,3,3,12");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.REVERSE).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3529F)
                .legLengths(10.2F, 11.9F)
                .leg("hips/thigh_r", "hips/thigh_r/shin_r", "hips/thigh_r/shin_r/foot_r", -1, 0F, 1)
                .leg("hips/thigh_l", "hips/thigh_l/shin_l", "hips/thigh_l/shin_l/foot_l", 1, 3.1416F, 1)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/tail0", 1, 0.12F, 0F)
                .sway("hips/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("hips/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gun/forearm_r_gun_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gun/forearm_r_gun_barrel/forearm_r_gun_flash", null)
                .primaryTwin(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r/shoulder_r_pod", null, null, null);
    }
}
