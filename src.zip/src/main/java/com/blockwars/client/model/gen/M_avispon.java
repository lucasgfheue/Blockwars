package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Hornet (avispon). */
@SuppressWarnings("unused")
public final class M_avispon {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("avispon"), "main");

    private M_avispon() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 61).addBox(-10F, -4F, -7F, 20F, 8F, 14F)
                .texOffs(0, 83).addBox(-11F, -4F, -8F, 22F, 4F, 15F)
                .texOffs(72, 134).addBox(-3F, -2F, -8F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -17F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = p_hips.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(212, 0).addBox(-5F, 0F, -5F, 10F, 20F, 10F)
                .texOffs(68, 61).addBox(-6F, 3F, -4F, 1F, 14F, 8F),
                PartPose.offsetAndRotation(-12F, 0F, 0F, -0.55F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(180, 0).addBox(-4F, 0F, -4F, 8F, 24F, 8F)
                .texOffs(152, 83).addBox(-5F, -3F, -5F, 10F, 7F, 10F)
                .texOffs(202, 102).addBox(-3F, 4F, 4F, 6F, 14F, 2F),
                PartPose.offsetAndRotation(0F, 19F, 0F, 1.15F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(74, 34).addBox(-7F, 0F, -12F, 14F, 5F, 20F)
                .texOffs(114, 134).addBox(-6F, 2F, -13F, 12F, 3F, 1F)
                .texOffs(228, 119).addBox(-3F, 0F, 7F, 5F, 3F, 7F),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_thigh_l = p_hips.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(212, 0).mirror().addBox(-5F, 0F, -5F, 10F, 20F, 10F).mirror(false)
                .texOffs(68, 61).mirror().addBox(5F, 3F, -4F, 1F, 14F, 8F).mirror(false),
                PartPose.offsetAndRotation(12F, 0F, 0F, -0.55F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(180, 0).mirror().addBox(-4F, 0F, -4F, 8F, 24F, 8F).mirror(false)
                .texOffs(152, 83).mirror().addBox(-5F, -3F, -5F, 10F, 7F, 10F).mirror(false)
                .texOffs(202, 102).mirror().addBox(-3F, 4F, 4F, 6F, 14F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 19F, 0F, 1.15F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(74, 34).mirror().addBox(-7F, 0F, -12F, 14F, 5F, 20F).mirror(false)
                .texOffs(114, 134).mirror().addBox(-6F, 2F, -13F, 12F, 3F, 1F).mirror(false)
                .texOffs(228, 119).mirror().addBox(-3F, 0F, 7F, 5F, 3F, 7F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.6F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(102, 83).addBox(-8F, -8F, -5F, 15F, 8F, 10F)
                .texOffs(0, 34).addBox(-11F, -18F, -7F, 22F, 12F, 15F)
                .texOffs(74, 0).addBox(-17F, -27F, -10F, 34F, 13F, 19F)
                .texOffs(34, 102).addBox(-10F, -29F, -7F, 20F, 3F, 13F)
                .texOffs(88, 119).addBox(-8F, -25F, -12F, 17F, 9F, 3F),
                PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(200, 119).addBox(-3F, -3F, -3F, 7F, 3F, 7F)
                .texOffs(164, 61).addBox(-5F, -12F, -5F, 10F, 8F, 12F)
                .texOffs(24, 134).addBox(-3F, -11F, -6F, 7F, 7F, 1F)
                .texOffs(140, 134).addBox(-2F, -9F, -7F, 3F, 3F, 1F)
                .texOffs(166, 119).addBox(-3F, -13F, -4F, 7F, 1F, 10F),
                PartPose.offsetAndRotation(0F, -29F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(160, 61).addBox(0F, -20F, 0F, 1F, 20F, 1F)
                .texOffs(148, 134).addBox(-1F, -21F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(4F, -10F, 3F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(138, 102).addBox(-4F, -4F, -4F, 8F, 8F, 8F)
                .texOffs(224, 34).addBox(-3F, 2F, -3F, 7F, 17F, 7F),
                PartPose.offsetAndRotation(-22F, -23F, 0F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r_pod = p_shoulder_r.addOrReplaceChild("shoulder_r_pod", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-8F, -14F, -10F, 17F, 14F, 20F)
                .texOffs(86, 61).addBox(-8F, -14F, -10F, 17F, 1F, 20F)
                .texOffs(56, 119).addBox(-8F, -13F, -11F, 15F, 12F, 1F),
                PartPose.offsetAndRotation(-2F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(190, 34).addBox(-4F, 0F, -5F, 8F, 15F, 9F)
                .texOffs(128, 119).addBox(-5F, 14F, -5F, 9F, 2F, 10F),
                PartPose.offsetAndRotation(0F, 18F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_gun = p_forearm_r.addOrReplaceChild("forearm_r_gun", CubeListBuilder.create()
                .texOffs(142, 34).addBox(-3F, -4F, -15F, 7F, 8F, 17F)
                .texOffs(100, 102).addBox(-3F, -6F, -14F, 5F, 2F, 14F)
                .texOffs(40, 134).addBox(-2F, 3F, -3F, 3F, 3F, 5F),
                PartPose.offsetAndRotation(0F, 20F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gun_barrel = p_forearm_r_gun.addOrReplaceChild("forearm_r_gun_barrel", CubeListBuilder.create()
                .texOffs(192, 83).addBox(-2F, -2F, -14F, 3F, 3F, 14F)
                .texOffs(56, 134).addBox(-3F, -3F, -15F, 5F, 5F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -15F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gun_flash = p_forearm_r_gun_barrel.addOrReplaceChild("forearm_r_gun_flash", CubeListBuilder.create()
                .texOffs(218, 102).addBox(-3F, -3F, -10F, 5F, 5F, 10F)
                .texOffs(84, 134).addBox(-6F, -1F, -3F, 12F, 2F, 3F)
                .texOffs(30, 119).addBox(-1F, -6F, -3F, 2F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(138, 102).mirror().addBox(-4F, -4F, -4F, 8F, 8F, 8F).mirror(false)
                .texOffs(224, 34).mirror().addBox(-3F, 2F, -3F, 7F, 17F, 7F).mirror(false),
                PartPose.offsetAndRotation(22F, -23F, 0F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l_pod = p_shoulder_l.addOrReplaceChild("shoulder_l_pod", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-8F, -14F, -10F, 17F, 14F, 20F)
                .texOffs(86, 61).addBox(-8F, -14F, -10F, 17F, 1F, 20F)
                .texOffs(56, 119).addBox(-8F, -13F, -11F, 15F, 12F, 1F),
                PartPose.offsetAndRotation(2F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(190, 34).mirror().addBox(-4F, 0F, -5F, 8F, 15F, 9F).mirror(false)
                .texOffs(128, 119).mirror().addBox(-5F, 14F, -5F, 9F, 2F, 10F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_gun = p_forearm_l.addOrReplaceChild("forearm_l_gun", CubeListBuilder.create()
                .texOffs(142, 34).addBox(-3F, -4F, -15F, 7F, 8F, 17F)
                .texOffs(100, 102).addBox(-3F, -6F, -14F, 5F, 2F, 14F)
                .texOffs(40, 134).addBox(-2F, 3F, -3F, 3F, 3F, 5F),
                PartPose.offsetAndRotation(0F, 20F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_barrel = p_forearm_l_gun.addOrReplaceChild("forearm_l_gun_barrel", CubeListBuilder.create()
                .texOffs(192, 83).addBox(-2F, -2F, -14F, 3F, 3F, 14F)
                .texOffs(56, 134).addBox(-3F, -3F, -15F, 5F, 5F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -15F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_flash = p_forearm_l_gun_barrel.addOrReplaceChild("forearm_l_gun_flash", CubeListBuilder.create()
                .texOffs(218, 102).addBox(-3F, -3F, -10F, 5F, 5F, 10F)
                .texOffs(84, 134).addBox(-6F, -1F, -3F, 12F, 2F, 3F)
                .texOffs(30, 119).addBox(-1F, -6F, -3F, 2F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -15F, 0F, 0F, 0F));
        PartDefinition p_thr_r = p_torso.addOrReplaceChild("thr_r", CubeListBuilder.create()
                .texOffs(74, 83).addBox(-3F, -6F, -3F, 7F, 12F, 7F)
                .texOffs(0, 134).addBox(-3F, 6F, -3F, 6F, 3F, 6F),
                PartPose.offsetAndRotation(-10F, -19F, 13F, 0.35F, 0F, 0F));
        PartDefinition p_flame_r = p_thr_r.addOrReplaceChild("flame_r", CubeListBuilder.create()
                .texOffs(40, 119).addBox(-2F, 0F, -2F, 4F, 10F, 4F),
                PartPose.offsetAndRotation(0F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_thr_l = p_torso.addOrReplaceChild("thr_l", CubeListBuilder.create()
                .texOffs(74, 83).addBox(-3F, -6F, -3F, 7F, 12F, 7F)
                .texOffs(0, 134).addBox(-3F, 6F, -3F, 6F, 3F, 6F),
                PartPose.offsetAndRotation(10F, -19F, 13F, 0.35F, 0F, 0F));
        PartDefinition p_flame_l = p_thr_l.addOrReplaceChild("flame_l", CubeListBuilder.create()
                .texOffs(40, 119).addBox(-2F, 0F, -2F, 4F, 10F, 4F),
                PartPose.offsetAndRotation(0F, 8F, 0F, 0F, 0F, 0F));
        PartDefinition p_tail0 = p_hips.addOrReplaceChild("tail0", CubeListBuilder.create()
                .texOffs(0, 102).addBox(-3F, -3F, -1F, 5F, 5F, 12F),
                PartPose.offsetAndRotation(0F, 2F, 8F, 0.5F, 0F, 0F));
        PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create()
                .texOffs(170, 102).addBox(-2F, -2F, -1F, 4F, 4F, 12F),
                PartPose.offsetAndRotation(0F, 0F, 11F, 0.2F, 0F, 0F));
        PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create()
                .texOffs(0, 119).addBox(-2F, -2F, -1F, 3F, 3F, 12F),
                PartPose.offsetAndRotation(0F, 0F, 11F, 0.2F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.REVERSE).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3529F)
                .legLengths(10.2F, 11.9F)
                .leg("hips/thigh_r", "hips/thigh_r/shin_r", "hips/thigh_r/shin_r/foot_r", -1, 0F, 1)
                .leg("hips/thigh_l", "hips/thigh_l/shin_l", "hips/thigh_l/shin_l/foot_l", 1, 3.1416F, 1)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .sway("hips/tail0", 1, 0.12F, 0F)
                .sway("hips/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("hips/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .flame("hips/torso/thr_r/flame_r")
                .flame("hips/torso/thr_l/flame_l")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gun/forearm_r_gun_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gun/forearm_r_gun_barrel/forearm_r_gun_flash", null)
                .primaryTwin(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r/shoulder_r_pod", null, null, null);
    }
}
