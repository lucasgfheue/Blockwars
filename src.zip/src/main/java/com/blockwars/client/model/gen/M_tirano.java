package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for TYRANT · Autonomous Command AI (tirano). */
@SuppressWarnings("unused")
public final class M_tirano {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("tirano"), "main");

    private M_tirano() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hips,-1,0,-46,0,0,0,0/128,128,-22,-7,-12,44,14,23/0,204,-23,-7,-13,46,7,26/80,279,-4,-3,-14,9,9,1;thigh_r,-1,-19,-46,0,0,0,0/"
                + "236,76,-10,0,-10,20,28,20/352,204,-12,3,-14,23,19,6/262,128,-12,3,-10,3,17,20;shin_r,1,0,28,0,0,0,0/0,76,-12,0,-12,23,29,23/"
                + "58,261,-10,-7,-16,20,12,6/234,279,-2,-4,-17,4,4,1/158,261,-9,9,12,17,14,4;foot_r,2,0,29,0,0,0,0/452,237,-7,-1,-7,14,6,14/"
                + "92,76,-16,4,-24,32,9,40/174,279,-14,7,-25,29,4,1;thigh_l,-1,19,-46,0,0,0,0/!236,76,-10,0,-10,20,28,20/"
                + "!352,204,-12,3,-14,23,19,6/!262,128,9,3,-10,3,17,20;shin_l,4,0,28,0,0,0,0/!0,76,-12,0,-12,23,29,23/!58,261,-10,-7,-16,20,12,6/"
                + "!234,279,-2,-4,-17,4,4,1/!158,261,-9,9,12,17,14,4;foot_l,5,0,29,0,0,0,0/!452,237,-7,-1,-7,14,6,14/!92,76,-16,4,-24,32,9,40/"
                + "!174,279,-14,7,-25,29,4,1;torso,0,0,-7,0,0,0,0/0,169,-18,-14,-10,35,14,21/0,0,-32,-52,-17,64,41,35/118,237,-22,-43,-19,45,22,1/"
                + "160,169,-24,-51,-14,48,6,28/324,261,-19,-34,17,38,16,1/0,279,-6,-41,-20,12,12,3/200,261,-9,-44,-18,17,17,1;"
                + "tspike_r0,7,-29,-49,6,0.5,0,-0.5/308,261,-2,-14,-2,4,14,4;tspike_r1,7,-29,-49,14,0.5,0,-0.5/308,261,-2,-14,-2,4,14,4;"
                + "tspike_l0,7,29,-49,6,0.5,0,0.5/308,261,-2,-14,-2,4,14,4;tspike_l1,7,29,-49,14,0.5,0,0.5/308,261,-2,-14,-2,4,14,4;"
                + "head,7,0,-52,-3,0,0,0/110,261,-6,-6,-6,12,6,12/312,169,-9,-20,-9,17,14,20/54,279,-6,-19,-10,12,12,1/148,279,-3,-16,-11,6,6,1/"
                + "0,261,-6,-22,-7,12,1,17;antenna,12,7,-17,6,-0.2,0,0.15/436,128,-1,-35,-1,1,35,1/162,279,-1,-36,-1,3,3,3;"
                + "shoulder_r,7,-41,-42,0,0,0,0/208,204,-7,-7,-7,14,14,14/0,128,-6,3,-6,12,29,12;shoulder_r_pod,14,-3,-9,0,0,0,0/"
                + "250,0,-14,-23,-17,29,23,35/308,128,-14,-25,-17,29,1,35/210,237,-13,-22,-19,26,20,1;forearm_r,14,0,30,0,-0.25,0,0/"
                + "406,76,-7,0,-8,14,26,16/264,237,-8,25,-9,16,3,17;forearm_r_gatling,16,0,33,-3,0,0,0/48,128,-9,-9,-20,17,17,23/"
                + "394,237,-6,-12,-17,12,3,17/74,237,9,-6,-12,3,12,12;forearm_r_gatling_barrel,17,0,0,-20,0,0,0/144,204,4,-1,-29,3,3,29/"
                + "144,204,1,3,-29,3,3,29/144,204,-4,3,-29,3,3,29/144,204,-7,-1,-29,3,3,29/144,204,-4,-6,-29,3,3,29/144,204,1,-6,-29,3,3,29/"
                + "236,261,-7,-7,-5,14,14,4/458,261,-7,-7,-25,14,14,3;forearm_r_gatling_flash,18,0,0,-29,0,0,0/264,204,-4,-4,-17,9,9,17/"
                + "100,279,-10,-1,-5,20,3,4/104,237,-1,-10,-5,3,20,4;shoulder_l,7,41,-42,0,0,0,0/!208,204,-7,-7,-7,14,14,14/"
                + "!0,128,-6,3,-6,12,29,12;shoulder_l_pod,20,3,-9,0,0,0,0/250,0,-14,-23,-17,29,23,35/308,128,-14,-25,-17,29,1,35/"
                + "210,237,-13,-22,-19,26,20,1;forearm_l,20,0,30,0,-0.25,0,0/!406,76,-7,0,-8,14,26,16/!264,237,-8,25,-9,16,3,17;"
                + "forearm_l_cannon,22,0,35,-3,0,0,0/378,0,-10,-10,-29,20,20,35/0,237,-7,-12,-23,14,1,23/112,169,10,-6,-23,1,12,23;"
                + "forearm_l_cannon_barrel,23,0,0,-29,0,0,0/316,76,-5,-5,-35,10,10,35/410,204,-8,-8,-41,16,16,9;forearm_l_cannon_flash,24,0,0,-41,0,0,0/"
                + "264,204,-4,-4,-17,9,9,17/100,279,-10,-1,-5,20,3,4/104,237,-1,-10,-5,3,20,4;torso_pod,7,0,-49,32,0,0,0/"
                + "250,0,-14,-23,-17,29,23,35/308,128,-14,-25,-17,29,1,35/210,237,-13,-22,-19,26,20,1;exhaust,7,16,-52,26,0,0,0/"
                + "198,0,-7,-44,-7,13,46,13/402,261,-7,-10,-7,14,3,14/402,261,-7,-33,-7,14,3,14/330,237,-8,-47,-8,16,4,16;"
                + "flame_exh,27,0,-46,0,3.1416,0,0/316,204,-4,0,-4,9,17,9;beacon,7,-19,-58,17,0,0,0/30,279,-3,-1,-3,6,9,6/"
                + "272,261,-4,-9,-4,9,9,9;beacon_spin,29,0,-4,0,0,0,0/148,279,-3,-3,-5,6,6,1/148,279,-3,-3,4,6,6,1");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2276F)
                .legLengths(13.775F, 14.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", 2, 1.2F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .flame("hips/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r/shoulder_r_pod", null, null, null);
    }
}
