package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for TYRANT · Autonomous Command AI (tirano). */
@SuppressWarnings("unused")
public final class M_tirano {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("tirano"), "main");

    private M_tirano() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(128, 128).addBox(-22F, -7F, -12F, 44F, 14F, 23F)
                .texOffs(0, 204).addBox(-23F, -7F, -13F, 46F, 7F, 26F)
                .texOffs(80, 279).addBox(-4F, -3F, -14F, 9F, 9F, 1F),
                PartPose.offsetAndRotation(0F, -46F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(236, 76).addBox(-10F, 0F, -10F, 20F, 28F, 20F)
                .texOffs(352, 204).addBox(-12F, 3F, -14F, 23F, 19F, 6F)
                .texOffs(262, 128).addBox(-12F, 3F, -10F, 3F, 17F, 20F),
                PartPose.offsetAndRotation(-19F, -46F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(0, 76).addBox(-12F, 0F, -12F, 23F, 29F, 23F)
                .texOffs(58, 261).addBox(-10F, -7F, -16F, 20F, 12F, 6F)
                .texOffs(234, 279).addBox(-2F, -4F, -17F, 4F, 4F, 1F)
                .texOffs(158, 261).addBox(-9F, 9F, 12F, 17F, 14F, 4F),
                PartPose.offsetAndRotation(0F, 28F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(452, 237).addBox(-7F, -1F, -7F, 14F, 6F, 14F)
                .texOffs(92, 76).addBox(-16F, 4F, -24F, 32F, 9F, 40F)
                .texOffs(174, 279).addBox(-14F, 7F, -25F, 29F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(236, 76).mirror().addBox(-10F, 0F, -10F, 20F, 28F, 20F).mirror(false)
                .texOffs(352, 204).mirror().addBox(-12F, 3F, -14F, 23F, 19F, 6F).mirror(false)
                .texOffs(262, 128).mirror().addBox(9F, 3F, -10F, 3F, 17F, 20F).mirror(false),
                PartPose.offsetAndRotation(19F, -46F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(0, 76).mirror().addBox(-12F, 0F, -12F, 23F, 29F, 23F).mirror(false)
                .texOffs(58, 261).mirror().addBox(-10F, -7F, -16F, 20F, 12F, 6F).mirror(false)
                .texOffs(234, 279).mirror().addBox(-2F, -4F, -17F, 4F, 4F, 1F).mirror(false)
                .texOffs(158, 261).mirror().addBox(-9F, 9F, 12F, 17F, 14F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 28F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(452, 237).mirror().addBox(-7F, -1F, -7F, 14F, 6F, 14F).mirror(false)
                .texOffs(92, 76).mirror().addBox(-16F, 4F, -24F, 32F, 9F, 40F).mirror(false)
                .texOffs(174, 279).mirror().addBox(-14F, 7F, -25F, 29F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 29F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 169).addBox(-18F, -14F, -10F, 35F, 14F, 21F)
                .texOffs(0, 0).addBox(-32F, -52F, -17F, 64F, 41F, 35F)
                .texOffs(118, 237).addBox(-22F, -43F, -19F, 45F, 22F, 1F)
                .texOffs(160, 169).addBox(-24F, -51F, -14F, 48F, 6F, 28F)
                .texOffs(324, 261).addBox(-19F, -34F, 17F, 38F, 16F, 1F)
                .texOffs(0, 279).addBox(-6F, -41F, -20F, 12F, 12F, 3F)
                .texOffs(200, 261).addBox(-9F, -44F, -18F, 17F, 17F, 1F),
                PartPose.offsetAndRotation(0F, -7F, 0F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(308, 261).addBox(-2F, -14F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(-29F, -49F, 6F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(308, 261).addBox(-2F, -14F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(-29F, -49F, 14F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(308, 261).addBox(-2F, -14F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(29F, -49F, 6F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(308, 261).addBox(-2F, -14F, -2F, 4F, 14F, 4F),
                PartPose.offsetAndRotation(29F, -49F, 14F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(110, 261).addBox(-6F, -6F, -6F, 12F, 6F, 12F)
                .texOffs(312, 169).addBox(-9F, -20F, -9F, 17F, 14F, 20F)
                .texOffs(54, 279).addBox(-6F, -19F, -10F, 12F, 12F, 1F)
                .texOffs(148, 279).addBox(-3F, -16F, -11F, 6F, 6F, 1F)
                .texOffs(0, 261).addBox(-6F, -22F, -7F, 12F, 1F, 17F),
                PartPose.offsetAndRotation(0F, -52F, -3F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(436, 128).addBox(-1F, -35F, -1F, 1F, 35F, 1F)
                .texOffs(162, 279).addBox(-1F, -36F, -1F, 3F, 3F, 3F),
                PartPose.offsetAndRotation(7F, -17F, 6F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(208, 204).addBox(-7F, -7F, -7F, 14F, 14F, 14F)
                .texOffs(0, 128).addBox(-6F, 3F, -6F, 12F, 29F, 12F),
                PartPose.offsetAndRotation(-41F, -42F, 0F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r_pod = p_shoulder_r.addOrReplaceChild("shoulder_r_pod", CubeListBuilder.create()
                .texOffs(250, 0).addBox(-14F, -23F, -17F, 29F, 23F, 35F)
                .texOffs(308, 128).addBox(-14F, -25F, -17F, 29F, 1F, 35F)
                .texOffs(210, 237).addBox(-13F, -22F, -19F, 26F, 20F, 1F),
                PartPose.offsetAndRotation(-3F, -9F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(406, 76).addBox(-7F, 0F, -8F, 14F, 26F, 16F)
                .texOffs(264, 237).addBox(-8F, 25F, -9F, 16F, 3F, 17F),
                PartPose.offsetAndRotation(0F, 30F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_gatling = p_forearm_r.addOrReplaceChild("forearm_r_gatling", CubeListBuilder.create()
                .texOffs(48, 128).addBox(-9F, -9F, -20F, 17F, 17F, 23F)
                .texOffs(394, 237).addBox(-6F, -12F, -17F, 12F, 3F, 17F)
                .texOffs(74, 237).addBox(9F, -6F, -12F, 3F, 12F, 12F),
                PartPose.offsetAndRotation(0F, 33F, -3F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gatling_barrel = p_forearm_r_gatling.addOrReplaceChild("forearm_r_gatling_barrel", CubeListBuilder.create()
                .texOffs(144, 204).addBox(4F, -1F, -29F, 3F, 3F, 29F)
                .texOffs(144, 204).addBox(1F, 3F, -29F, 3F, 3F, 29F)
                .texOffs(144, 204).addBox(-4F, 3F, -29F, 3F, 3F, 29F)
                .texOffs(144, 204).addBox(-7F, -1F, -29F, 3F, 3F, 29F)
                .texOffs(144, 204).addBox(-4F, -6F, -29F, 3F, 3F, 29F)
                .texOffs(144, 204).addBox(1F, -6F, -29F, 3F, 3F, 29F)
                .texOffs(236, 261).addBox(-7F, -7F, -5F, 14F, 14F, 4F)
                .texOffs(458, 261).addBox(-7F, -7F, -25F, 14F, 14F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gatling_flash = p_forearm_r_gatling_barrel.addOrReplaceChild("forearm_r_gatling_flash", CubeListBuilder.create()
                .texOffs(264, 204).addBox(-4F, -4F, -17F, 9F, 9F, 17F)
                .texOffs(100, 279).addBox(-10F, -1F, -5F, 20F, 3F, 4F)
                .texOffs(104, 237).addBox(-1F, -10F, -5F, 3F, 20F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -29F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(208, 204).mirror().addBox(-7F, -7F, -7F, 14F, 14F, 14F).mirror(false)
                .texOffs(0, 128).mirror().addBox(-6F, 3F, -6F, 12F, 29F, 12F).mirror(false),
                PartPose.offsetAndRotation(41F, -42F, 0F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l_pod = p_shoulder_l.addOrReplaceChild("shoulder_l_pod", CubeListBuilder.create()
                .texOffs(250, 0).addBox(-14F, -23F, -17F, 29F, 23F, 35F)
                .texOffs(308, 128).addBox(-14F, -25F, -17F, 29F, 1F, 35F)
                .texOffs(210, 237).addBox(-13F, -22F, -19F, 26F, 20F, 1F),
                PartPose.offsetAndRotation(3F, -9F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(406, 76).mirror().addBox(-7F, 0F, -8F, 14F, 26F, 16F).mirror(false)
                .texOffs(264, 237).mirror().addBox(-8F, 25F, -9F, 16F, 3F, 17F).mirror(false),
                PartPose.offsetAndRotation(0F, 30F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_cannon = p_forearm_l.addOrReplaceChild("forearm_l_cannon", CubeListBuilder.create()
                .texOffs(378, 0).addBox(-10F, -10F, -29F, 20F, 20F, 35F)
                .texOffs(0, 237).addBox(-7F, -12F, -23F, 14F, 1F, 23F)
                .texOffs(112, 169).addBox(10F, -6F, -23F, 1F, 12F, 23F),
                PartPose.offsetAndRotation(0F, 35F, -3F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_cannon_barrel = p_forearm_l_cannon.addOrReplaceChild("forearm_l_cannon_barrel", CubeListBuilder.create()
                .texOffs(316, 76).addBox(-5F, -5F, -35F, 10F, 10F, 35F)
                .texOffs(410, 204).addBox(-8F, -8F, -41F, 16F, 16F, 9F),
                PartPose.offsetAndRotation(0F, 0F, -29F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_cannon_flash = p_forearm_l_cannon_barrel.addOrReplaceChild("forearm_l_cannon_flash", CubeListBuilder.create()
                .texOffs(264, 204).addBox(-4F, -4F, -17F, 9F, 9F, 17F)
                .texOffs(100, 279).addBox(-10F, -1F, -5F, 20F, 3F, 4F)
                .texOffs(104, 237).addBox(-1F, -10F, -5F, 3F, 20F, 4F),
                PartPose.offsetAndRotation(0F, 0F, -41F, 0F, 0F, 0F));
        PartDefinition p_torso_pod = p_torso.addOrReplaceChild("torso_pod", CubeListBuilder.create()
                .texOffs(250, 0).addBox(-14F, -23F, -17F, 29F, 23F, 35F)
                .texOffs(308, 128).addBox(-14F, -25F, -17F, 29F, 1F, 35F)
                .texOffs(210, 237).addBox(-13F, -22F, -19F, 26F, 20F, 1F),
                PartPose.offsetAndRotation(0F, -49F, 32F, 0F, 0F, 0F));
        PartDefinition p_exhaust = p_torso.addOrReplaceChild("exhaust", CubeListBuilder.create()
                .texOffs(198, 0).addBox(-7F, -44F, -7F, 13F, 46F, 13F)
                .texOffs(402, 261).addBox(-7F, -10F, -7F, 14F, 3F, 14F)
                .texOffs(402, 261).addBox(-7F, -33F, -7F, 14F, 3F, 14F)
                .texOffs(330, 237).addBox(-8F, -47F, -8F, 16F, 4F, 16F),
                PartPose.offsetAndRotation(16F, -52F, 26F, 0F, 0F, 0F));
        PartDefinition p_flame_exh = p_exhaust.addOrReplaceChild("flame_exh", CubeListBuilder.create()
                .texOffs(316, 204).addBox(-4F, 0F, -4F, 9F, 17F, 9F),
                PartPose.offsetAndRotation(0F, -46F, 0F, 3.1416F, 0F, 0F));
        PartDefinition p_beacon = p_torso.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(30, 279).addBox(-3F, -1F, -3F, 6F, 9F, 6F)
                .texOffs(272, 261).addBox(-4F, -9F, -4F, 9F, 9F, 9F),
                PartPose.offsetAndRotation(-19F, -58F, 17F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(148, 279).addBox(-3F, -3F, -5F, 6F, 6F, 1F)
                .texOffs(148, 279).addBox(-3F, -3F, 4F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -4F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.2276F)
                .legLengths(13.775F, 14.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", 2, 1.2F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .flame("hips/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r/shoulder_r_pod", null, null, null);
    }
}
