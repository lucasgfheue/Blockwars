package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Anvil (yunque). */
@SuppressWarnings("unused")
public final class M_yunque {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("yunque"), "main");

    private M_yunque() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-29,0,0,0,0/286,57,-16,-6,-9,33,11,18/106,90,-18,-5,-10,35,6,20/258,136,-3,-2,-11,7,7,1;skirt0,0,0,0,-10,-0.15,0,0/"
                + "190,117,-14,0,-1,29,15,2;skirt1,0,0,0,10,0.15,0,0/190,117,-14,0,-1,29,15,2;thigh_r,-1,-14,-29,0,0,0,0/"
                + "344,0,-8,0,-8,15,21,15/66,117,-9,2,-11,18,15,4/388,57,-9,2,-8,2,13,15;shin_r,3,0,21,0,0,0,0/148,0,-9,0,-9,18,22,18/"
                + "60,136,-8,-6,-12,15,9,4/414,117,-7,7,9,13,11,3;foot_r,4,0,22,0,0,0,0/336,117,-5,-1,-5,11,4,11/236,0,-12,3,-18,24,7,30/"
                + "326,136,-11,6,-19,22,3,1;thigh_l,-1,14,-29,0,0,0,0/!344,0,-8,0,-8,15,21,15/!66,117,-9,2,-11,18,15,4/!388,57,7,2,-8,2,13,15;"
                + "shin_l,6,0,21,0,0,0,0/!148,0,-9,0,-9,18,22,18/!60,136,-8,-6,-12,15,9,4/!414,117,-7,7,9,13,11,3;foot_l,7,0,22,0,0,0,0/"
                + "!336,117,-5,-1,-5,11,4,11/!236,0,-12,3,-18,24,7,30/!326,136,-11,6,-19,22,3,1;torso,0,0,-6,0,0,0,0/422,57,-13,-11,-8,27,11,16/"
                + "0,0,-24,-40,-13,48,31,26/110,117,-17,-33,-14,34,17,1/216,90,-18,-38,-11,36,4,21/0,136,-15,-26,13,29,12,1/"
                + "162,136,-4,-31,-15,9,9,2/446,117,-7,-33,-14,13,13,1;head,9,0,-40,-2,0,0,0/98,136,-4,-4,-4,9,4,9/0,57,-8,-20,-9,15,15,18/"
                + "252,117,-8,-20,-10,16,15,1/372,136,-6,-13,-10,11,2,1/396,136,-4,-13,-10,9,1,1/380,117,-2,-21,-4,4,1,13;"
                + "shoulder_r,9,-31,-32,0,0,0,0/330,90,-6,-6,-6,11,11,11/174,57,-11,-11,-10,18,11,20/0,117,-10,-12,-9,15,1,18/"
                + "250,57,-4,2,-4,9,22,9;forearm_r,11,0,23,0,-0.25,0,0/128,57,-6,0,-6,11,20,12/286,117,-6,19,-7,12,2,13;"
                + "forearm_r_hammer,12,0,23,-2,-1.2,0,0/220,0,-2,-4,-2,4,35,4/404,0,-8,26,-11,15,13,22/0,90,-8,31,-12,16,4,23/"
                + "134,136,-7,28,-12,13,11,1;shoulder_l,9,31,-32,0,0,0,0/!330,90,-6,-6,-6,11,11,11/!174,57,-7,-11,-10,18,11,20/"
                + "!0,117,-6,-12,-9,15,1,18/!250,57,-4,2,-4,9,22,9;forearm_l,14,0,23,0,-0.25,0,0/!128,57,-6,0,-6,11,20,12/"
                + "!286,117,-6,19,-7,12,2,13;forearm_l_gun,15,0,25,-2,0,0,0/66,57,-4,-5,-20,9,10,22/418,90,-3,-7,-18,7,2,18/"
                + "184,136,-2,4,-3,4,4,7;forearm_l_gun_barrel,16,0,-1,-20,0,0,0/374,90,-2,-2,-18,4,4,18/238,136,-3,-3,-19,7,7,3;"
                + "forearm_l_gun_flash,17,0,0,-20,0,0,0/468,90,-3,-3,-13,7,7,13/274,136,-8,-1,-4,15,2,3/180,117,-1,-8,-4,2,15,3;"
                + "stack_r,9,-15,-35,18,-0.15,0,0.1/78,90,-3,-19,-3,7,20,7/206,136,-4,-20,-4,8,2,8/310,136,-2,-21,-2,4,1,4;"
                + "stack_l,9,15,-35,18,-0.15,0,-0.1/78,90,-3,-19,-3,7,20,7/206,136,-4,-20,-4,8,2,8/310,136,-2,-21,-2,4,1,4");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(10.45F, 11F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
