package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Anvil (yunque). */
@SuppressWarnings("unused")
public final class M_yunque {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("yunque"), "main");

    private M_yunque() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(286, 57).addBox(-16F, -6F, -9F, 33F, 11F, 18F)
                .texOffs(106, 90).addBox(-18F, -5F, -10F, 35F, 6F, 20F)
                .texOffs(258, 136).addBox(-3F, -2F, -11F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt0 = p_hips.addOrReplaceChild("skirt0", CubeListBuilder.create()
                .texOffs(190, 117).addBox(-14F, 0F, -1F, 29F, 15F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -10F, -0.15F, 0F, 0F));
        PartDefinition p_skirt1 = p_hips.addOrReplaceChild("skirt1", CubeListBuilder.create()
                .texOffs(190, 117).addBox(-14F, 0F, -1F, 29F, 15F, 2F),
                PartPose.offsetAndRotation(0F, 0F, 10F, 0.15F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(344, 0).addBox(-8F, 0F, -8F, 15F, 21F, 15F)
                .texOffs(66, 117).addBox(-9F, 2F, -11F, 18F, 15F, 4F)
                .texOffs(388, 57).addBox(-9F, 2F, -8F, 2F, 13F, 15F),
                PartPose.offsetAndRotation(-14F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(148, 0).addBox(-9F, 0F, -9F, 18F, 22F, 18F)
                .texOffs(60, 136).addBox(-8F, -6F, -12F, 15F, 9F, 4F)
                .texOffs(414, 117).addBox(-7F, 7F, 9F, 13F, 11F, 3F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(336, 117).addBox(-5F, -1F, -5F, 11F, 4F, 11F)
                .texOffs(236, 0).addBox(-12F, 3F, -18F, 24F, 7F, 30F)
                .texOffs(326, 136).addBox(-11F, 6F, -19F, 22F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(344, 0).mirror().addBox(-8F, 0F, -8F, 15F, 21F, 15F).mirror(false)
                .texOffs(66, 117).mirror().addBox(-9F, 2F, -11F, 18F, 15F, 4F).mirror(false)
                .texOffs(388, 57).mirror().addBox(7F, 2F, -8F, 2F, 13F, 15F).mirror(false),
                PartPose.offsetAndRotation(14F, -29F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(148, 0).mirror().addBox(-9F, 0F, -9F, 18F, 22F, 18F).mirror(false)
                .texOffs(60, 136).mirror().addBox(-8F, -6F, -12F, 15F, 9F, 4F).mirror(false)
                .texOffs(414, 117).mirror().addBox(-7F, 7F, 9F, 13F, 11F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(336, 117).mirror().addBox(-5F, -1F, -5F, 11F, 4F, 11F).mirror(false)
                .texOffs(236, 0).mirror().addBox(-12F, 3F, -18F, 24F, 7F, 30F).mirror(false)
                .texOffs(326, 136).mirror().addBox(-11F, 6F, -19F, 22F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(422, 57).addBox(-13F, -11F, -8F, 27F, 11F, 16F)
                .texOffs(0, 0).addBox(-24F, -40F, -13F, 48F, 31F, 26F)
                .texOffs(110, 117).addBox(-17F, -33F, -14F, 34F, 17F, 1F)
                .texOffs(216, 90).addBox(-18F, -38F, -11F, 36F, 4F, 21F)
                .texOffs(0, 136).addBox(-15F, -26F, 13F, 29F, 12F, 1F)
                .texOffs(162, 136).addBox(-4F, -31F, -15F, 9F, 9F, 2F)
                .texOffs(446, 117).addBox(-7F, -33F, -14F, 13F, 13F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(98, 136).addBox(-4F, -4F, -4F, 9F, 4F, 9F)
                .texOffs(0, 57).addBox(-8F, -20F, -9F, 15F, 15F, 18F)
                .texOffs(252, 117).addBox(-8F, -20F, -10F, 16F, 15F, 1F)
                .texOffs(372, 136).addBox(-6F, -13F, -10F, 11F, 2F, 1F)
                .texOffs(396, 136).addBox(-4F, -13F, -10F, 9F, 1F, 1F)
                .texOffs(380, 117).addBox(-2F, -21F, -4F, 4F, 1F, 13F),
                PartPose.offsetAndRotation(0F, -40F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(330, 90).addBox(-6F, -6F, -6F, 11F, 11F, 11F)
                .texOffs(174, 57).addBox(-11F, -11F, -10F, 18F, 11F, 20F)
                .texOffs(0, 117).addBox(-10F, -12F, -9F, 15F, 1F, 18F)
                .texOffs(250, 57).addBox(-4F, 2F, -4F, 9F, 22F, 9F),
                PartPose.offsetAndRotation(-31F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(128, 57).addBox(-6F, 0F, -6F, 11F, 20F, 12F)
                .texOffs(286, 117).addBox(-6F, 19F, -7F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_hammer = p_forearm_r.addOrReplaceChild("forearm_r_hammer", CubeListBuilder.create()
                .texOffs(220, 0).addBox(-2F, -4F, -2F, 4F, 35F, 4F)
                .texOffs(404, 0).addBox(-8F, 26F, -11F, 15F, 13F, 22F)
                .texOffs(0, 90).addBox(-8F, 31F, -12F, 16F, 4F, 23F)
                .texOffs(134, 136).addBox(-7F, 28F, -12F, 13F, 11F, 1F),
                PartPose.offsetAndRotation(0F, 23F, -2F, -1.2F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(330, 90).mirror().addBox(-6F, -6F, -6F, 11F, 11F, 11F).mirror(false)
                .texOffs(174, 57).mirror().addBox(-7F, -11F, -10F, 18F, 11F, 20F).mirror(false)
                .texOffs(0, 117).mirror().addBox(-6F, -12F, -9F, 15F, 1F, 18F).mirror(false)
                .texOffs(250, 57).mirror().addBox(-4F, 2F, -4F, 9F, 22F, 9F).mirror(false),
                PartPose.offsetAndRotation(31F, -32F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(128, 57).mirror().addBox(-6F, 0F, -6F, 11F, 20F, 12F).mirror(false)
                .texOffs(286, 117).mirror().addBox(-6F, 19F, -7F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_gun = p_forearm_l.addOrReplaceChild("forearm_l_gun", CubeListBuilder.create()
                .texOffs(66, 57).addBox(-4F, -5F, -20F, 9F, 10F, 22F)
                .texOffs(418, 90).addBox(-3F, -7F, -18F, 7F, 2F, 18F)
                .texOffs(184, 136).addBox(-2F, 4F, -3F, 4F, 4F, 7F),
                PartPose.offsetAndRotation(0F, 25F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_barrel = p_forearm_l_gun.addOrReplaceChild("forearm_l_gun_barrel", CubeListBuilder.create()
                .texOffs(374, 90).addBox(-2F, -2F, -18F, 4F, 4F, 18F)
                .texOffs(238, 136).addBox(-3F, -3F, -19F, 7F, 7F, 3F),
                PartPose.offsetAndRotation(0F, -1F, -20F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_gun_flash = p_forearm_l_gun_barrel.addOrReplaceChild("forearm_l_gun_flash", CubeListBuilder.create()
                .texOffs(468, 90).addBox(-3F, -3F, -13F, 7F, 7F, 13F)
                .texOffs(274, 136).addBox(-8F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(180, 117).addBox(-1F, -8F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(78, 90).addBox(-3F, -19F, -3F, 7F, 20F, 7F)
                .texOffs(206, 136).addBox(-4F, -20F, -4F, 8F, 2F, 8F)
                .texOffs(310, 136).addBox(-2F, -21F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-15F, -35F, 18F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(78, 90).addBox(-3F, -19F, -3F, 7F, 20F, 7F)
                .texOffs(206, 136).addBox(-4F, -20F, -4F, 8F, 2F, 8F)
                .texOffs(310, 136).addBox(-2F, -21F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(15F, -35F, 18F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3F)
                .legLengths(10.45F, 11F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel", "hips/torso/shoulder_l/forearm_l/forearm_l_gun/forearm_l_gun_barrel/forearm_l_gun_flash", null);
    }
}
