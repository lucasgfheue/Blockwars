package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Firedamp (grisu). */
@SuppressWarnings("unused")
public final class M_grisu {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("grisu"), "main");

    private M_grisu() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(256, 256, "hips,-1,0,-28,0,0,0,0/0,135,-11,-5,-8,23,10,15/0,185,-12,-4,-9,25,5,17/32,239,-3,-2,-10,6,6,1;thigh_r,-1,-10,-28,0,0,0,0/"
                + "134,74,-5,0,-5,10,21,10/200,185,-6,2,-8,11,15,4/198,160,-6,2,-5,2,13,10;shin_r,1,0,21,0,0,0,0/118,41,-6,0,-6,11,22,11/"
                + "186,224,-5,-5,-9,10,8,4/122,224,-4,7,6,8,11,3;foot_r,2,0,22,0,0,0,0/214,224,-3,-1,-3,7,4,7/156,105,-8,3,-12,16,6,20/"
                + "174,239,-7,5,-13,14,3,1;thigh_l,-1,10,-28,0,0,0,0/!134,74,-5,0,-5,10,21,10/!200,185,-6,2,-8,11,15,4/!198,160,4,2,-5,2,13,10;"
                + "shin_l,4,0,21,0,0,0,0/!118,41,-6,0,-6,11,22,11/!186,224,-5,-5,-9,10,8,4/!122,224,-4,7,6,8,11,3;foot_l,5,0,22,0,0,0,0/"
                + "!214,224,-3,-1,-3,7,4,7/!156,105,-8,3,-12,16,6,20/!174,239,-7,5,-13,14,3,1;torso,0,0,-5,0,0,0,0/76,135,-10,-10,-7,21,10,15/"
                + "0,41,-17,-15,-12,34,8,25/174,74,-11,-27,-6,23,15,15/72,105,-19,-32,-12,3,26,3/72,105,-19,-32,9,3,26,3/"
                + "72,105,16,-32,-12,3,26,3/72,105,16,-32,9,3,26,3/60,239,-19,-34,-12,38,3,3/60,239,-19,-34,9,38,3,3/0,74,-20,-31,-13,40,4,27/"
                + "180,207,-14,-26,-11,28,14,1/30,248,-13,-34,-14,4,2,1/30,248,10,-34,-14,4,2,1;head,7,0,-34,-2,0,0,0/0,224,-6,-4,-6,11,4,11/"
                + "0,105,-10,-17,-8,19,13,17/0,239,-8,-15,-8,15,8,1/230,185,-10,-15,-5,1,8,11/230,185,9,-15,-5,1,8,11/124,185,-10,-18,-8,20,1,18/"
                + "212,239,-10,-5,-8,19,2,1/40,248,-8,-19,-7,2,1,2/40,248,6,-19,-7,2,1,2;antenna,8,5,-11,4,-0.2,0,0.15/142,160,0,-23,0,1,23,1/"
                + "204,239,-1,-24,-1,2,2,2;shoulder_r,7,-25,-28,0,0,0,0/84,185,-5,-5,-5,10,10,10/124,105,-4,2,-4,8,19,8;"
                + "shoulder_r_pod,10,-2,-6,0,0,0,0/82,0,-10,-15,-11,19,15,23/58,160,-10,-16,-11,19,1,23/58,224,-9,-14,-12,17,13,1;"
                + "forearm_r,10,0,20,0,-0.25,0,0/84,105,-5,0,-5,10,17,10/144,224,-5,16,-6,10,2,11;forearm_r_mortar,12,0,20,-2,-0.55,0,0/"
                + "146,160,-7,-5,-7,13,10,13;forearm_r_mortar_barrel,13,0,-4,-4,0,0,0/0,0,-6,-6,-30,11,11,30/94,224,-6,-6,-28,12,12,2/"
                + "0,207,-7,-7,-33,13,13,4;forearm_r_mortar_flash,14,0,0,-32,0,0,0/34,207,-3,-3,-11,6,6,11/142,239,-7,-1,-3,13,2,3/"
                + "108,207,-1,-7,-3,2,13,3;shoulder_l,7,25,-28,0,0,0,0/!84,185,-5,-5,-5,10,10,10/!124,105,-4,2,-4,8,19,8;"
                + "shoulder_l_pod,16,2,-6,0,0,0,0/82,0,-10,-15,-11,19,15,23/58,160,-10,-16,-11,19,1,23/58,224,-9,-14,-12,17,13,1;"
                + "forearm_l,16,0,20,0,-0.25,0,0/!84,105,-5,0,-5,10,17,10/!144,224,-5,16,-6,10,2,11;forearm_l_claw,18,0,20,-2,0,0,0/"
                + "68,207,-5,-1,-5,10,6,10;forearm_l_claw_f0,19,-3,5,-2,0,0,0.25/44,224,-1,0,-2,3,11,4/46,239,-1,11,-2,3,3,4;"
                + "forearm_l_claw_f1,19,3,5,-2,0,0,-0.25/44,224,-1,0,-2,3,11,4/46,239,-1,11,-2,3,3,4;forearm_l_claw_f2,19,0,5,3,0.25,0,0/"
                + "44,224,-1,0,-2,3,11,4/46,239,-1,11,-2,3,3,4;cargo0,7,-8,-25,20,0,0,0/148,135,-8,-6,-7,16,12,13/0,248,-7,-1,-7,14,2,1/"
                + "118,207,-8,-7,-7,17,1,14;cargo1,7,8,-25,20,0,0,0/148,135,-8,-6,-7,16,12,13/0,248,-7,-1,-7,14,2,1/118,207,-8,-7,-7,17,1,14;"
                + "cargo2,7,0,-38,20,0,0,0/0,160,-8,-6,-7,16,12,13/0,248,-7,-1,-7,14,2,1/118,207,-8,-7,-7,17,1,14");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3474F)
                .legLengths(10.45F, 10.925F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_mortar/forearm_r_mortar_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_mortar/forearm_r_mortar_barrel/forearm_r_mortar_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r/shoulder_r_pod", null, null, null);
    }
}
