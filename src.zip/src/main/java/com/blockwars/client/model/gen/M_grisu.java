package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Firedamp (grisu). */
@SuppressWarnings("unused")
public final class M_grisu {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("grisu"), "main");

    private M_grisu() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 135).addBox(-11F, -5F, -8F, 23F, 10F, 15F)
                .texOffs(0, 185).addBox(-12F, -4F, -9F, 25F, 5F, 17F)
                .texOffs(32, 239).addBox(-3F, -2F, -10F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(134, 74).addBox(-5F, 0F, -5F, 10F, 21F, 10F)
                .texOffs(200, 185).addBox(-6F, 2F, -8F, 11F, 15F, 4F)
                .texOffs(198, 160).addBox(-6F, 2F, -5F, 2F, 13F, 10F),
                PartPose.offsetAndRotation(-10F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(118, 41).addBox(-6F, 0F, -6F, 11F, 22F, 11F)
                .texOffs(186, 224).addBox(-5F, -5F, -9F, 10F, 8F, 4F)
                .texOffs(122, 224).addBox(-4F, 7F, 6F, 8F, 11F, 3F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(214, 224).addBox(-3F, -1F, -3F, 7F, 4F, 7F)
                .texOffs(156, 105).addBox(-8F, 3F, -12F, 16F, 6F, 20F)
                .texOffs(174, 239).addBox(-7F, 5F, -13F, 14F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(134, 74).mirror().addBox(-5F, 0F, -5F, 10F, 21F, 10F).mirror(false)
                .texOffs(200, 185).mirror().addBox(-6F, 2F, -8F, 11F, 15F, 4F).mirror(false)
                .texOffs(198, 160).mirror().addBox(4F, 2F, -5F, 2F, 13F, 10F).mirror(false),
                PartPose.offsetAndRotation(10F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(118, 41).mirror().addBox(-6F, 0F, -6F, 11F, 22F, 11F).mirror(false)
                .texOffs(186, 224).mirror().addBox(-5F, -5F, -9F, 10F, 8F, 4F).mirror(false)
                .texOffs(122, 224).mirror().addBox(-4F, 7F, 6F, 8F, 11F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(214, 224).mirror().addBox(-3F, -1F, -3F, 7F, 4F, 7F).mirror(false)
                .texOffs(156, 105).mirror().addBox(-8F, 3F, -12F, 16F, 6F, 20F).mirror(false)
                .texOffs(174, 239).mirror().addBox(-7F, 5F, -13F, 14F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(76, 135).addBox(-10F, -10F, -7F, 21F, 10F, 15F)
                .texOffs(0, 41).addBox(-17F, -15F, -12F, 34F, 8F, 25F)
                .texOffs(174, 74).addBox(-11F, -27F, -6F, 23F, 15F, 15F)
                .texOffs(72, 105).addBox(-19F, -32F, -12F, 3F, 26F, 3F)
                .texOffs(72, 105).addBox(-19F, -32F, 9F, 3F, 26F, 3F)
                .texOffs(72, 105).addBox(16F, -32F, -12F, 3F, 26F, 3F)
                .texOffs(72, 105).addBox(16F, -32F, 9F, 3F, 26F, 3F)
                .texOffs(60, 239).addBox(-19F, -34F, -12F, 38F, 3F, 3F)
                .texOffs(60, 239).addBox(-19F, -34F, 9F, 38F, 3F, 3F)
                .texOffs(0, 74).addBox(-20F, -31F, -13F, 40F, 4F, 27F)
                .texOffs(180, 207).addBox(-14F, -26F, -11F, 28F, 14F, 1F)
                .texOffs(30, 248).addBox(-13F, -34F, -14F, 4F, 2F, 1F)
                .texOffs(30, 248).addBox(10F, -34F, -14F, 4F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 224).addBox(-6F, -4F, -6F, 11F, 4F, 11F)
                .texOffs(0, 105).addBox(-10F, -17F, -8F, 19F, 13F, 17F)
                .texOffs(0, 239).addBox(-8F, -15F, -8F, 15F, 8F, 1F)
                .texOffs(230, 185).addBox(-10F, -15F, -5F, 1F, 8F, 11F)
                .texOffs(230, 185).addBox(9F, -15F, -5F, 1F, 8F, 11F)
                .texOffs(124, 185).addBox(-10F, -18F, -8F, 20F, 1F, 18F)
                .texOffs(212, 239).addBox(-10F, -5F, -8F, 19F, 2F, 1F)
                .texOffs(40, 248).addBox(-8F, -19F, -7F, 2F, 1F, 2F)
                .texOffs(40, 248).addBox(6F, -19F, -7F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -34F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(142, 160).addBox(0F, -23F, 0F, 1F, 23F, 1F)
                .texOffs(204, 239).addBox(-1F, -24F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -11F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(84, 185).addBox(-5F, -5F, -5F, 10F, 10F, 10F)
                .texOffs(124, 105).addBox(-4F, 2F, -4F, 8F, 19F, 8F),
                PartPose.offsetAndRotation(-25F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r_pod = p_shoulder_r.addOrReplaceChild("shoulder_r_pod", CubeListBuilder.create()
                .texOffs(82, 0).addBox(-10F, -15F, -11F, 19F, 15F, 23F)
                .texOffs(58, 160).addBox(-10F, -16F, -11F, 19F, 1F, 23F)
                .texOffs(58, 224).addBox(-9F, -14F, -12F, 17F, 13F, 1F),
                PartPose.offsetAndRotation(-2F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(84, 105).addBox(-5F, 0F, -5F, 10F, 17F, 10F)
                .texOffs(144, 224).addBox(-5F, 16F, -6F, 10F, 2F, 11F),
                PartPose.offsetAndRotation(0F, 20F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_mortar = p_forearm_r.addOrReplaceChild("forearm_r_mortar", CubeListBuilder.create()
                .texOffs(146, 160).addBox(-7F, -5F, -7F, 13F, 10F, 13F),
                PartPose.offsetAndRotation(0F, 20F, -2F, -0.55F, 0F, 0F));
        PartDefinition p_forearm_r_mortar_barrel = p_forearm_r_mortar.addOrReplaceChild("forearm_r_mortar_barrel", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-6F, -6F, -30F, 11F, 11F, 30F)
                .texOffs(94, 224).addBox(-6F, -6F, -28F, 12F, 12F, 2F)
                .texOffs(0, 207).addBox(-7F, -7F, -33F, 13F, 13F, 4F),
                PartPose.offsetAndRotation(0F, -4F, -4F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_mortar_flash = p_forearm_r_mortar_barrel.addOrReplaceChild("forearm_r_mortar_flash", CubeListBuilder.create()
                .texOffs(34, 207).addBox(-3F, -3F, -11F, 6F, 6F, 11F)
                .texOffs(142, 239).addBox(-7F, -1F, -3F, 13F, 2F, 3F)
                .texOffs(108, 207).addBox(-1F, -7F, -3F, 2F, 13F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -32F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(84, 185).mirror().addBox(-5F, -5F, -5F, 10F, 10F, 10F).mirror(false)
                .texOffs(124, 105).mirror().addBox(-4F, 2F, -4F, 8F, 19F, 8F).mirror(false),
                PartPose.offsetAndRotation(25F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l_pod = p_shoulder_l.addOrReplaceChild("shoulder_l_pod", CubeListBuilder.create()
                .texOffs(82, 0).addBox(-10F, -15F, -11F, 19F, 15F, 23F)
                .texOffs(58, 160).addBox(-10F, -16F, -11F, 19F, 1F, 23F)
                .texOffs(58, 224).addBox(-9F, -14F, -12F, 17F, 13F, 1F),
                PartPose.offsetAndRotation(2F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(84, 105).mirror().addBox(-5F, 0F, -5F, 10F, 17F, 10F).mirror(false)
                .texOffs(144, 224).mirror().addBox(-5F, 16F, -6F, 10F, 2F, 11F).mirror(false),
                PartPose.offsetAndRotation(0F, 20F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_claw = p_forearm_l.addOrReplaceChild("forearm_l_claw", CubeListBuilder.create()
                .texOffs(68, 207).addBox(-5F, -1F, -5F, 10F, 6F, 10F),
                PartPose.offsetAndRotation(0F, 20F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_claw_f0 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f0", CubeListBuilder.create()
                .texOffs(44, 224).addBox(-1F, 0F, -2F, 3F, 11F, 4F)
                .texOffs(46, 239).addBox(-1F, 11F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(-3F, 5F, -2F, 0F, 0F, 0.25F));
        PartDefinition p_forearm_l_claw_f1 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f1", CubeListBuilder.create()
                .texOffs(44, 224).addBox(-1F, 0F, -2F, 3F, 11F, 4F)
                .texOffs(46, 239).addBox(-1F, 11F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(3F, 5F, -2F, 0F, 0F, -0.25F));
        PartDefinition p_forearm_l_claw_f2 = p_forearm_l_claw.addOrReplaceChild("forearm_l_claw_f2", CubeListBuilder.create()
                .texOffs(44, 224).addBox(-1F, 0F, -2F, 3F, 11F, 4F)
                .texOffs(46, 239).addBox(-1F, 11F, -2F, 3F, 3F, 4F),
                PartPose.offsetAndRotation(0F, 5F, 3F, 0.25F, 0F, 0F));
        PartDefinition p_cargo0 = p_torso.addOrReplaceChild("cargo0", CubeListBuilder.create()
                .texOffs(148, 135).addBox(-8F, -6F, -7F, 16F, 12F, 13F)
                .texOffs(0, 248).addBox(-7F, -1F, -7F, 14F, 2F, 1F)
                .texOffs(118, 207).addBox(-8F, -7F, -7F, 17F, 1F, 14F),
                PartPose.offsetAndRotation(-8F, -25F, 20F, 0F, 0F, 0F));
        PartDefinition p_cargo1 = p_torso.addOrReplaceChild("cargo1", CubeListBuilder.create()
                .texOffs(148, 135).addBox(-8F, -6F, -7F, 16F, 12F, 13F)
                .texOffs(0, 248).addBox(-7F, -1F, -7F, 14F, 2F, 1F)
                .texOffs(118, 207).addBox(-8F, -7F, -7F, 17F, 1F, 14F),
                PartPose.offsetAndRotation(8F, -25F, 20F, 0F, 0F, 0F));
        PartDefinition p_cargo2 = p_torso.addOrReplaceChild("cargo2", CubeListBuilder.create()
                .texOffs(0, 160).addBox(-8F, -6F, -7F, 16F, 12F, 13F)
                .texOffs(0, 248).addBox(-7F, -1F, -7F, 14F, 2F, 1F)
                .texOffs(118, 207).addBox(-8F, -7F, -7F, 17F, 1F, 14F),
                PartPose.offsetAndRotation(0F, -38F, 20F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3474F)
                .legLengths(10.45F, 10.925F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_mortar/forearm_r_mortar_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_mortar/forearm_r_mortar_barrel/forearm_r_mortar_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r/shoulder_r_pod", null, null, null);
    }
}
