package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Tetanus (tetano). */
@SuppressWarnings("unused")
public final class M_tetano {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("tetano"), "main");

    private M_tetano() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "base,-1,0,22,-47,0,0,0/0,0,-18,-31,-13,36,31,26/168,221,-20,-3,-9,39,5,18/326,165,-16,-34,-12,31,4,23;"
                + "snout,0,0,-26,-16,-0.2,0,0/124,0,-16,-26,-29,31,26,31/166,165,-13,-29,-23,26,4,26/24,267,-13,-10,-30,26,10,1/"
                + "486,267,-10,-20,-30,5,4,1/486,267,5,-20,-30,5,4,1;tusk_r,1,-13,-5,-26,0.3,0,-0.3/478,246,-2,-1,-5,4,13,4;"
                + "tusk_l,1,13,-5,-26,0.3,0,0.3/!478,246,-2,-1,-5,4,13,4;jaw,1,0,0,-13,0,0,0/96,111,-13,0,-21,26,5,26/210,267,-12,-3,-21,23,3,3;"
                + "seg0,0,0,0,13,0,0,0/248,0,-18,-31,0,36,31,23/200,111,-14,-27,-4,29,23,8/0,196,-16,-34,1,31,4,21/282,221,-20,-3,4,39,5,16/"
                + "94,267,-14,-18,23,29,5,1/0,267,-2,-42,8,4,8,8;seg1,5,0,0,23,0,0,0/366,0,-17,-31,0,35,31,23/274,111,-13,-27,-4,27,23,8/"
                + "104,196,-15,-34,1,29,4,21/392,221,-19,-3,4,37,5,16/154,267,-13,-18,23,27,5,1;seg2,6,0,0,23,0,0,0/0,57,-16,-31,0,33,31,23/"
                + "344,111,-12,-27,-4,25,23,8/204,196,-14,-34,1,28,4,21/0,246,-18,-3,4,35,5,16/262,267,-12,-18,23,25,5,1/"
                + "0,267,-2,-42,8,4,8,8;seg3,7,0,0,23,0,0,0/112,57,-15,-31,0,31,31,23/410,111,-12,-27,-4,23,23,8/302,196,-13,-34,1,26,4,21/"
                + "102,246,-17,-3,4,34,5,16/314,267,-12,-18,23,23,5,1;seg4,8,0,0,23,0,0,0/220,57,-15,-31,0,29,31,23/0,165,-11,-27,-4,21,23,8/"
                + "396,196,-12,-34,1,24,4,21/202,246,-16,-3,4,32,5,16/362,267,-11,-18,23,21,5,1/0,267,-2,-42,8,4,8,8;seg5,9,0,0,23,0,0,0/"
                + "324,57,-14,-31,0,27,31,23/58,165,-10,-27,-4,20,23,8/0,221,-11,-34,1,22,4,21/298,246,-15,-3,4,30,5,16/"
                + "406,267,-10,-18,23,20,5,1;seg6,10,0,0,23,0,0,0/0,111,-13,-31,0,25,31,23/114,165,-9,-27,-4,18,23,8/86,221,-10,-34,1,20,4,21/"
                + "390,246,-14,-3,4,28,5,16/448,267,-9,-18,23,18,5,1/0,267,-2,-42,8,4,8,8;tailtip,11,0,-10,23,0.2,0,0/270,165,-5,-5,-1,10,10,18/"
                + "78,267,-3,-3,17,5,5,3");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.SERPENT).parts("base", "base", "base/snout").walkRate(0.3077F)
                .segment("base/seg0")
                .segment("base/seg0/seg1")
                .segment("base/seg0/seg1/seg2")
                .segment("base/seg0/seg1/seg2/seg3")
                .segment("base/seg0/seg1/seg2/seg3/seg4")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6/tailtip")
                .jaw("base/snout/jaw")
                .primary(Rig.MountKind.BODY, "base/snout", null, null, null)
                .secondary(Rig.MountKind.BODY, "base/snout", null, null, null);
    }
}
