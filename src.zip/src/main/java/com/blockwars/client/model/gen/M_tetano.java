package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Tetanus (tetano). */
@SuppressWarnings("unused")
public final class M_tetano {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("tetano"), "main");

    private M_tetano() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_base = root.addOrReplaceChild("base", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-18F, -31F, -13F, 36F, 31F, 26F)
                .texOffs(168, 221).addBox(-20F, -3F, -9F, 39F, 5F, 18F)
                .texOffs(326, 165).addBox(-16F, -34F, -12F, 31F, 4F, 23F),
                PartPose.offsetAndRotation(0F, 22F, -47F, 0F, 0F, 0F));
        PartDefinition p_snout = p_base.addOrReplaceChild("snout", CubeListBuilder.create()
                .texOffs(124, 0).addBox(-16F, -26F, -29F, 31F, 26F, 31F)
                .texOffs(166, 165).addBox(-13F, -29F, -23F, 26F, 4F, 26F)
                .texOffs(24, 267).addBox(-13F, -10F, -30F, 26F, 10F, 1F)
                .texOffs(486, 267).addBox(-10F, -20F, -30F, 5F, 4F, 1F)
                .texOffs(486, 267).addBox(5F, -20F, -30F, 5F, 4F, 1F),
                PartPose.offsetAndRotation(0F, -26F, -16F, -0.2F, 0F, 0F));
        PartDefinition p_tusk_r = p_snout.addOrReplaceChild("tusk_r", CubeListBuilder.create()
                .texOffs(478, 246).addBox(-2F, -1F, -5F, 4F, 13F, 4F),
                PartPose.offsetAndRotation(-13F, -5F, -26F, 0.3F, 0F, -0.3F));
        PartDefinition p_tusk_l = p_snout.addOrReplaceChild("tusk_l", CubeListBuilder.create()
                .texOffs(478, 246).mirror().addBox(-2F, -1F, -5F, 4F, 13F, 4F).mirror(false),
                PartPose.offsetAndRotation(13F, -5F, -26F, 0.3F, 0F, 0.3F));
        PartDefinition p_jaw = p_snout.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(96, 111).addBox(-13F, 0F, -21F, 26F, 5F, 26F)
                .texOffs(210, 267).addBox(-12F, -3F, -21F, 23F, 3F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -13F, 0F, 0F, 0F));
        PartDefinition p_seg0 = p_base.addOrReplaceChild("seg0", CubeListBuilder.create()
                .texOffs(248, 0).addBox(-18F, -31F, 0F, 36F, 31F, 23F)
                .texOffs(200, 111).addBox(-14F, -27F, -4F, 29F, 23F, 8F)
                .texOffs(0, 196).addBox(-16F, -34F, 1F, 31F, 4F, 21F)
                .texOffs(282, 221).addBox(-20F, -3F, 4F, 39F, 5F, 16F)
                .texOffs(94, 267).addBox(-14F, -18F, 23F, 29F, 5F, 1F)
                .texOffs(0, 267).addBox(-2F, -42F, 8F, 4F, 8F, 8F),
                PartPose.offsetAndRotation(0F, 0F, 13F, 0F, 0F, 0F));
        PartDefinition p_seg1 = p_seg0.addOrReplaceChild("seg1", CubeListBuilder.create()
                .texOffs(366, 0).addBox(-17F, -31F, 0F, 35F, 31F, 23F)
                .texOffs(274, 111).addBox(-13F, -27F, -4F, 27F, 23F, 8F)
                .texOffs(104, 196).addBox(-15F, -34F, 1F, 29F, 4F, 21F)
                .texOffs(392, 221).addBox(-19F, -3F, 4F, 37F, 5F, 16F)
                .texOffs(154, 267).addBox(-13F, -18F, 23F, 27F, 5F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 23F, 0F, 0F, 0F));
        PartDefinition p_seg2 = p_seg1.addOrReplaceChild("seg2", CubeListBuilder.create()
                .texOffs(0, 57).addBox(-16F, -31F, 0F, 33F, 31F, 23F)
                .texOffs(344, 111).addBox(-12F, -27F, -4F, 25F, 23F, 8F)
                .texOffs(204, 196).addBox(-14F, -34F, 1F, 28F, 4F, 21F)
                .texOffs(0, 246).addBox(-18F, -3F, 4F, 35F, 5F, 16F)
                .texOffs(262, 267).addBox(-12F, -18F, 23F, 25F, 5F, 1F)
                .texOffs(0, 267).addBox(-2F, -42F, 8F, 4F, 8F, 8F),
                PartPose.offsetAndRotation(0F, 0F, 23F, 0F, 0F, 0F));
        PartDefinition p_seg3 = p_seg2.addOrReplaceChild("seg3", CubeListBuilder.create()
                .texOffs(112, 57).addBox(-15F, -31F, 0F, 31F, 31F, 23F)
                .texOffs(410, 111).addBox(-12F, -27F, -4F, 23F, 23F, 8F)
                .texOffs(302, 196).addBox(-13F, -34F, 1F, 26F, 4F, 21F)
                .texOffs(102, 246).addBox(-17F, -3F, 4F, 34F, 5F, 16F)
                .texOffs(314, 267).addBox(-12F, -18F, 23F, 23F, 5F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 23F, 0F, 0F, 0F));
        PartDefinition p_seg4 = p_seg3.addOrReplaceChild("seg4", CubeListBuilder.create()
                .texOffs(220, 57).addBox(-15F, -31F, 0F, 29F, 31F, 23F)
                .texOffs(0, 165).addBox(-11F, -27F, -4F, 21F, 23F, 8F)
                .texOffs(396, 196).addBox(-12F, -34F, 1F, 24F, 4F, 21F)
                .texOffs(202, 246).addBox(-16F, -3F, 4F, 32F, 5F, 16F)
                .texOffs(362, 267).addBox(-11F, -18F, 23F, 21F, 5F, 1F)
                .texOffs(0, 267).addBox(-2F, -42F, 8F, 4F, 8F, 8F),
                PartPose.offsetAndRotation(0F, 0F, 23F, 0F, 0F, 0F));
        PartDefinition p_seg5 = p_seg4.addOrReplaceChild("seg5", CubeListBuilder.create()
                .texOffs(324, 57).addBox(-14F, -31F, 0F, 27F, 31F, 23F)
                .texOffs(58, 165).addBox(-10F, -27F, -4F, 20F, 23F, 8F)
                .texOffs(0, 221).addBox(-11F, -34F, 1F, 22F, 4F, 21F)
                .texOffs(298, 246).addBox(-15F, -3F, 4F, 30F, 5F, 16F)
                .texOffs(406, 267).addBox(-10F, -18F, 23F, 20F, 5F, 1F),
                PartPose.offsetAndRotation(0F, 0F, 23F, 0F, 0F, 0F));
        PartDefinition p_seg6 = p_seg5.addOrReplaceChild("seg6", CubeListBuilder.create()
                .texOffs(0, 111).addBox(-13F, -31F, 0F, 25F, 31F, 23F)
                .texOffs(114, 165).addBox(-9F, -27F, -4F, 18F, 23F, 8F)
                .texOffs(86, 221).addBox(-10F, -34F, 1F, 20F, 4F, 21F)
                .texOffs(390, 246).addBox(-14F, -3F, 4F, 28F, 5F, 16F)
                .texOffs(448, 267).addBox(-9F, -18F, 23F, 18F, 5F, 1F)
                .texOffs(0, 267).addBox(-2F, -42F, 8F, 4F, 8F, 8F),
                PartPose.offsetAndRotation(0F, 0F, 23F, 0F, 0F, 0F));
        PartDefinition p_tailtip = p_seg6.addOrReplaceChild("tailtip", CubeListBuilder.create()
                .texOffs(270, 165).addBox(-5F, -5F, -1F, 10F, 10F, 18F)
                .texOffs(78, 267).addBox(-3F, -3F, 17F, 5F, 5F, 3F),
                PartPose.offsetAndRotation(0F, -10F, 23F, 0.2F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.SERPENT).parts("base", "base", "base/snout").walkRate(0.3077F)
                .segment("base/seg0")
                .segment("base/seg0/seg1")
                .segment("base/seg0/seg1/seg2")
                .segment("base/seg0/seg1/seg2/seg3")
                .segment("base/seg0/seg1/seg2/seg3/seg4")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6")
                .segment("base/seg0/seg1/seg2/seg3/seg4/seg5/seg6/tailtip")
                .jaw("base/snout/jaw")
                .primary(Rig.MountKind.BODY, "base/snout", null, null, null)
                .secondary(Rig.MountKind.BODY, "base/snout", null, null, null);
    }
}
