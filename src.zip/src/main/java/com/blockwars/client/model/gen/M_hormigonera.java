package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Mixer (hormigonera). */
@SuppressWarnings("unused")
public final class M_hormigonera {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("hormigonera"), "main");

    private M_hormigonera() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 97).addBox(-37F, -36F, -32F, 75F, 15F, 64F)
                .texOffs(122, 176).addBox(-20F, -40F, -20F, 40F, 4F, 45F)
                .texOffs(278, 97).addBox(-20F, -22F, -30F, 40F, 18F, 60F)
                .texOffs(288, 345).addBox(-35F, -32F, -33F, 70F, 7F, 1F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_tread_r = p_hull.addOrReplaceChild("tread_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-9F, -11F, -37F, 18F, 22F, 75F)
                .texOffs(186, 0).addBox(-10F, -16F, -38F, 20F, 6F, 77F),
                PartPose.offsetAndRotation(-29F, -11F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_r0 = p_tread_r.addOrReplaceChild("wheel_r0", CubeListBuilder.create()
                .texOffs(398, 292).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(430, 345).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -26F, 0F, 0F, 0F));
        PartDefinition p_wheel_r1 = p_tread_r.addOrReplaceChild("wheel_r1", CubeListBuilder.create()
                .texOffs(398, 292).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(430, 345).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r2 = p_tread_r.addOrReplaceChild("wheel_r2", CubeListBuilder.create()
                .texOffs(398, 292).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(430, 345).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_r3 = p_tread_r.addOrReplaceChild("wheel_r3", CubeListBuilder.create()
                .texOffs(398, 292).addBox(-1F, -7F, -7F, 1F, 13F, 13F)
                .texOffs(430, 345).addBox(-1F, -2F, -2F, 2F, 4F, 4F),
                PartPose.offsetAndRotation(-9F, 2F, 26F, 0F, 0F, 0F));
        PartDefinition p_tread_l = p_hull.addOrReplaceChild("tread_l", CubeListBuilder.create()
                .texOffs(0, 0).mirror().addBox(-9F, -11F, -37F, 18F, 22F, 75F).mirror(false)
                .texOffs(186, 0).mirror().addBox(-10F, -16F, -38F, 20F, 6F, 77F).mirror(false),
                PartPose.offsetAndRotation(29F, -11F, 0F, 0F, 0F, 0F));
        PartDefinition p_wheel_l0 = p_tread_l.addOrReplaceChild("wheel_l0", CubeListBuilder.create()
                .texOffs(398, 292).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(430, 345).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -26F, 0F, 0F, 0F));
        PartDefinition p_wheel_l1 = p_tread_l.addOrReplaceChild("wheel_l1", CubeListBuilder.create()
                .texOffs(398, 292).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(430, 345).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, -9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l2 = p_tread_l.addOrReplaceChild("wheel_l2", CubeListBuilder.create()
                .texOffs(398, 292).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(430, 345).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 9F, 0F, 0F, 0F));
        PartDefinition p_wheel_l3 = p_tread_l.addOrReplaceChild("wheel_l3", CubeListBuilder.create()
                .texOffs(398, 292).mirror().addBox(-1F, -7F, -7F, 1F, 13F, 13F).mirror(false)
                .texOffs(430, 345).mirror().addBox(-1F, -2F, -2F, 2F, 4F, 4F).mirror(false),
                PartPose.offsetAndRotation(9F, 2F, 26F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hull.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(320, 292).addBox(-12F, -11F, -7F, 24F, 11F, 15F)
                .texOffs(0, 249).addBox(-20F, -33F, -10F, 40F, 24F, 19F)
                .texOffs(292, 176).addBox(-16F, -31F, -12F, 32F, 20F, 24F)
                .texOffs(158, 292).addBox(-20F, -24F, -10F, 41F, 6F, 21F)
                .texOffs(160, 323).addBox(-14F, -35F, -8F, 28F, 4F, 17F),
                PartPose.offsetAndRotation(0F, -37F, 4F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(48, 345).addBox(-7F, -4F, -7F, 13F, 4F, 13F)
                .texOffs(200, 249).addBox(-11F, -20F, -9F, 22F, 15F, 20F)
                .texOffs(250, 345).addBox(-9F, -18F, -10F, 18F, 9F, 1F)
                .texOffs(132, 323).addBox(-12F, -18F, -6F, 1F, 9F, 13F)
                .texOffs(132, 323).addBox(11F, -18F, -6F, 1F, 9F, 13F)
                .texOffs(0, 323).addBox(-12F, -21F, -9F, 23F, 1F, 21F)
                .texOffs(0, 364).addBox(-11F, -6F, -10F, 22F, 2F, 1F)
                .texOffs(46, 364).addBox(-9F, -22F, -8F, 2F, 1F, 2F)
                .texOffs(46, 364).addBox(7F, -22F, -8F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -35F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(88, 323).addBox(-6F, -6F, -6F, 11F, 11F, 11F)
                .texOffs(0, 292).addBox(-11F, -11F, -10F, 18F, 11F, 20F)
                .texOffs(374, 323).addBox(-10F, -12F, -9F, 15F, 1F, 18F)
                .texOffs(122, 292).addBox(-4F, 2F, -4F, 9F, 20F, 9F),
                PartPose.offsetAndRotation(-26F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(76, 292).addBox(-6F, 0F, -6F, 11F, 18F, 12F)
                .texOffs(156, 345).addBox(-6F, 17F, -7F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_cannon = p_forearm_r.addOrReplaceChild("forearm_r_cannon", CubeListBuilder.create()
                .texOffs(118, 249).addBox(-8F, -8F, -22F, 15F, 15F, 26F)
                .texOffs(440, 323).addBox(-6F, -9F, -18F, 11F, 1F, 18F)
                .texOffs(282, 292).addBox(8F, -4F, -18F, 1F, 9F, 18F),
                PartPose.offsetAndRotation(0F, 24F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_barrel = p_forearm_r_cannon.addOrReplaceChild("forearm_r_cannon_barrel", CubeListBuilder.create()
                .texOffs(284, 249).addBox(-4F, -4F, -26F, 8F, 8F, 26F)
                .texOffs(0, 345).addBox(-6F, -6F, -31F, 12F, 12F, 7F),
                PartPose.offsetAndRotation(0F, 0F, -22F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_flash = p_forearm_r_cannon_barrel.addOrReplaceChild("forearm_r_cannon_flash", CubeListBuilder.create()
                .texOffs(334, 323).addBox(-3F, -3F, -13F, 7F, 7F, 13F)
                .texOffs(450, 345).addBox(-8F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(38, 345).addBox(-1F, -8F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -31F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(88, 323).mirror().addBox(-6F, -6F, -6F, 11F, 11F, 11F).mirror(false)
                .texOffs(0, 292).mirror().addBox(-7F, -11F, -10F, 18F, 11F, 20F).mirror(false)
                .texOffs(374, 323).mirror().addBox(-6F, -12F, -9F, 15F, 1F, 18F).mirror(false)
                .texOffs(122, 292).mirror().addBox(-4F, 2F, -4F, 9F, 20F, 9F).mirror(false),
                PartPose.offsetAndRotation(26F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(76, 292).mirror().addBox(-6F, 0F, -6F, 11F, 18F, 12F).mirror(false)
                .texOffs(156, 345).mirror().addBox(-6F, 17F, -7F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_bucket = p_forearm_l.addOrReplaceChild("forearm_l_bucket", CubeListBuilder.create()
                .texOffs(426, 292).addBox(-3F, -2F, -3F, 7F, 18F, 7F),
                PartPose.offsetAndRotation(0F, 21F, -2F, -0.4F, 0F, 0F));
        PartDefinition p_forearm_l_bucket_bk = p_forearm_l_bucket.addOrReplaceChild("forearm_l_bucket_bk", CubeListBuilder.create()
                .texOffs(404, 249).addBox(-11F, 0F, -13F, 22F, 13F, 18F)
                .texOffs(250, 323).addBox(-12F, -1F, -14F, 23F, 2F, 19F)
                .texOffs(442, 345).addBox(-9F, 12F, -13F, 2F, 4F, 2F)
                .texOffs(442, 345).addBox(-4F, 12F, -13F, 2F, 4F, 2F)
                .texOffs(442, 345).addBox(2F, 12F, -13F, 2F, 4F, 2F)
                .texOffs(442, 345).addBox(7F, 12F, -13F, 2F, 4F, 2F),
                PartPose.offsetAndRotation(0F, 15F, -2F, 0.6F, 0F, 0F));
        PartDefinition p_drum = p_torso.addOrReplaceChild("drum", CubeListBuilder.create()
                .texOffs(352, 249).addBox(-7F, -10F, -7F, 13F, 20F, 13F)
                .texOffs(100, 345).addBox(-7F, -1F, -7F, 14F, 2F, 14F),
                PartPose.offsetAndRotation(0F, -22F, 19F, 0F, 0F, 1.5708F));
        PartDefinition p_beacon = p_torso.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(234, 345).addBox(-2F, -1F, -2F, 4F, 7F, 4F)
                .texOffs(206, 345).addBox(-3F, -7F, -3F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(-12F, -40F, 12F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(486, 345).addBox(-2F, -2F, -4F, 4F, 4F, 1F)
                .texOffs(486, 345).addBox(-2F, -2F, 3F, 4F, 4F, 1F),
                PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_r = p_hull.addOrReplaceChild("skirt_r", CubeListBuilder.create()
                .texOffs(0, 176).addBox(-1F, -7F, -30F, 1F, 13F, 60F),
                PartPose.offsetAndRotation(-39F, -20F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt_l = p_hull.addOrReplaceChild("skirt_l", CubeListBuilder.create()
                .texOffs(0, 176).mirror().addBox(-1F, -7F, -30F, 1F, 13F, 60F).mirror(false),
                PartPose.offsetAndRotation(39F, -20F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 512);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/torso", "hull/torso/head").walkRate(0F)
                .arm("hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r", -1, false)
                .arm("hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l", 1, false)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .primary(Rig.MountKind.ARM, "hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hull/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hull/torso/shoulder_l", null, null, null);
    }
}
