package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Mixer (hormigonera). */
@SuppressWarnings("unused")
public final class M_hormigonera {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("hormigonera"), "main");

    private M_hormigonera() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 512, "hull,-1,0,22,0,0,0,0/0,97,-37,-36,-32,75,15,64/122,176,-20,-40,-20,40,4,45/278,97,-20,-22,-30,40,18,60/"
                + "288,345,-35,-32,-33,70,7,1;tread_r,0,-29,-11,0,0,0,0/0,0,-9,-11,-37,18,22,75/186,0,-10,-16,-38,20,6,77;"
                + "wheel_r0,1,-9,2,-26,0,0,0/398,292,-1,-7,-7,1,13,13/430,345,-1,-2,-2,2,4,4;wheel_r1,1,-9,2,-9,0,0,0/398,292,-1,-7,-7,1,13,13/"
                + "430,345,-1,-2,-2,2,4,4;wheel_r2,1,-9,2,9,0,0,0/398,292,-1,-7,-7,1,13,13/430,345,-1,-2,-2,2,4,4;wheel_r3,1,-9,2,26,0,0,0/"
                + "398,292,-1,-7,-7,1,13,13/430,345,-1,-2,-2,2,4,4;tread_l,0,29,-11,0,0,0,0/!0,0,-9,-11,-37,18,22,75/!186,0,-10,-16,-38,20,6,77;"
                + "wheel_l0,6,9,2,-26,0,0,0/!398,292,-1,-7,-7,1,13,13/!430,345,-1,-2,-2,2,4,4;wheel_l1,6,9,2,-9,0,0,0/!398,292,-1,-7,-7,1,13,13/"
                + "!430,345,-1,-2,-2,2,4,4;wheel_l2,6,9,2,9,0,0,0/!398,292,-1,-7,-7,1,13,13/!430,345,-1,-2,-2,2,4,4;wheel_l3,6,9,2,26,0,0,0/"
                + "!398,292,-1,-7,-7,1,13,13/!430,345,-1,-2,-2,2,4,4;torso,0,0,-37,4,0,0,0/320,292,-12,-11,-7,24,11,15/0,249,-20,-33,-10,40,24,19/"
                + "292,176,-16,-31,-12,32,20,24/158,292,-20,-24,-10,41,6,21/160,323,-14,-35,-8,28,4,17;head,11,0,-35,-2,0,0,0/"
                + "48,345,-7,-4,-7,13,4,13/200,249,-11,-20,-9,22,15,20/250,345,-9,-18,-10,18,9,1/132,323,-12,-18,-6,1,9,13/"
                + "132,323,11,-18,-6,1,9,13/0,323,-12,-21,-9,23,1,21/0,364,-11,-6,-10,22,2,1/46,364,-9,-22,-8,2,1,2/46,364,7,-22,-8,2,1,2;"
                + "shoulder_r,11,-26,-28,0,0,0,0/88,323,-6,-6,-6,11,11,11/0,292,-11,-11,-10,18,11,20/374,323,-10,-12,-9,15,1,18/"
                + "122,292,-4,2,-4,9,20,9;forearm_r,13,0,21,0,-0.25,0,0/76,292,-6,0,-6,11,18,12/156,345,-6,17,-7,12,2,13;"
                + "forearm_r_cannon,14,0,24,-2,0,0,0/118,249,-8,-8,-22,15,15,26/440,323,-6,-9,-18,11,1,18/282,292,8,-4,-18,1,9,18;"
                + "forearm_r_cannon_barrel,15,0,0,-22,0,0,0/284,249,-4,-4,-26,8,8,26/0,345,-6,-6,-31,12,12,7;forearm_r_cannon_flash,16,0,0,-31,0,0,0/"
                + "334,323,-3,-3,-13,7,7,13/450,345,-8,-1,-4,15,2,3/38,345,-1,-8,-4,2,15,3;shoulder_l,11,26,-28,0,0,0,0/"
                + "!88,323,-6,-6,-6,11,11,11/!0,292,-7,-11,-10,18,11,20/!374,323,-6,-12,-9,15,1,18/!122,292,-4,2,-4,9,20,9;"
                + "forearm_l,18,0,21,0,-0.25,0,0/!76,292,-6,0,-6,11,18,12/!156,345,-6,17,-7,12,2,13;forearm_l_bucket,19,0,21,-2,-0.4,0,0/"
                + "426,292,-3,-2,-3,7,18,7;forearm_l_bucket_bk,20,0,15,-2,0.6,0,0/404,249,-11,0,-13,22,13,18/250,323,-12,-1,-14,23,2,19/"
                + "442,345,-9,12,-13,2,4,2/442,345,-4,12,-13,2,4,2/442,345,2,12,-13,2,4,2/442,345,7,12,-13,2,4,2;drum,11,0,-22,19,0,0,1.5708/"
                + "352,249,-7,-10,-7,13,20,13/100,345,-7,-1,-7,14,2,14;beacon,11,-12,-40,12,0,0,0/234,345,-2,-1,-2,4,7,4/"
                + "206,345,-3,-7,-3,7,7,7;beacon_spin,23,0,-3,0,0,0,0/486,345,-2,-2,-4,4,4,1/486,345,-2,-2,3,4,4,1;skirt_r,0,-39,-20,0,0,0,0/"
                + "0,176,-1,-7,-30,1,13,60;skirt_l,0,39,-20,0,0,0,0/!0,176,-1,-7,-30,1,13,60");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.TREAD).parts("hull", "hull/torso", "hull/torso/head").walkRate(0F)
                .arm("hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r", -1, false)
                .arm("hull/torso/shoulder_l", "hull/torso/shoulder_l/forearm_l", 1, false)
                .spin("hull/tread_r/wheel_r0", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r1", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r2", 0, 0F, 1)
                .spin("hull/tread_r/wheel_r3", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l0", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l1", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l2", 0, 0F, 1)
                .spin("hull/tread_l/wheel_l3", 0, 0F, 1)
                .spin("hull/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .primary(Rig.MountKind.ARM, "hull/torso/shoulder_r", "hull/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hull/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hull/torso/shoulder_l", null, null, null);
    }
}
