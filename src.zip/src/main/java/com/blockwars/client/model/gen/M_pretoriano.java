package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Praetorian (pretoriano). */
@SuppressWarnings("unused")
public final class M_pretoriano {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("pretoriano"), "main");

    private M_pretoriano() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(148, 131).addBox(-17F, -6F, -9F, 34F, 12F, 18F)
                .texOffs(0, 162).addBox(-18F, -5F, -10F, 37F, 6F, 21F)
                .texOffs(150, 207).addBox(-3F, -2F, -12F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt0 = p_hips.addOrReplaceChild("skirt0", CubeListBuilder.create()
                .texOffs(78, 189).addBox(-15F, 0F, -1F, 30F, 16F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -11F, -0.15F, 0F, 0F));
        PartDefinition p_skirt1 = p_hips.addOrReplaceChild("skirt1", CubeListBuilder.create()
                .texOffs(78, 189).addBox(-15F, 0F, -1F, 30F, 16F, 2F),
                PartPose.offsetAndRotation(0F, 0F, 11F, 0.15F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(114, 92).addBox(-8F, 0F, -8F, 16F, 22F, 16F)
                .texOffs(256, 162).addBox(-9F, 2F, -12F, 18F, 15F, 5F)
                .texOffs(342, 131).addBox(-9F, 2F, -8F, 2F, 13F, 16F),
                PartPose.offsetAndRotation(-15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(322, 0).addBox(-9F, 0F, -9F, 18F, 23F, 18F)
                .texOffs(432, 189).addBox(-8F, -6F, -13F, 16F, 9F, 5F)
                .texOffs(368, 189).addBox(-7F, 7F, 9F, 14F, 12F, 3F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(324, 189).addBox(-6F, -1F, -6F, 11F, 5F, 11F)
                .texOffs(0, 92).addBox(-13F, 3F, -19F, 25F, 7F, 32F)
                .texOffs(216, 207).addBox(-12F, 6F, -20F, 23F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(114, 92).mirror().addBox(-8F, 0F, -8F, 16F, 22F, 16F).mirror(false)
                .texOffs(256, 162).mirror().addBox(-9F, 2F, -12F, 18F, 15F, 5F).mirror(false)
                .texOffs(342, 131).mirror().addBox(7F, 2F, -8F, 2F, 13F, 16F).mirror(false),
                PartPose.offsetAndRotation(15F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(322, 0).mirror().addBox(-9F, 0F, -9F, 18F, 23F, 18F).mirror(false)
                .texOffs(432, 189).mirror().addBox(-8F, -6F, -13F, 16F, 9F, 5F).mirror(false)
                .texOffs(368, 189).mirror().addBox(-7F, 7F, 9F, 14F, 12F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(324, 189).mirror().addBox(-6F, -1F, -6F, 11F, 5F, 11F).mirror(false)
                .texOffs(0, 92).mirror().addBox(-13F, 3F, -19F, 25F, 7F, 32F).mirror(false)
                .texOffs(216, 207).mirror().addBox(-12F, 6F, -20F, 23F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(252, 131).addBox(-14F, -12F, -8F, 28F, 12F, 17F)
                .texOffs(164, 0).addBox(-25F, -41F, -14F, 51F, 32F, 28F)
                .texOffs(302, 162).addBox(-18F, -34F, -15F, 35F, 18F, 1F)
                .texOffs(382, 131).addBox(-19F, -40F, -11F, 38F, 5F, 22F)
                .texOffs(56, 207).addBox(-15F, -27F, 14F, 30F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(474, 189).addBox(-5F, -5F, -5F, 9F, 5F, 9F)
                .texOffs(306, 92).addBox(-8F, -18F, -9F, 16F, 14F, 18F)
                .texOffs(164, 189).addBox(-7F, -20F, -7F, 14F, 1F, 16F)
                .texOffs(264, 207).addBox(-7F, -13F, -10F, 14F, 3F, 1F)
                .texOffs(294, 207).addBox(-6F, -9F, -10F, 12F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -41F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(378, 131).addBox(-1F, -28F, -1F, 1F, 28F, 1F)
                .texOffs(320, 207).addBox(-1F, -29F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(6F, -14F, 5F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(166, 162).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(228, 92).addBox(-12F, -12F, -10F, 18F, 12F, 21F)
                .texOffs(374, 162).addBox(-10F, -13F, -9F, 16F, 1F, 18F)
                .texOffs(438, 92).addBox(-5F, 2F, -5F, 9F, 23F, 9F),
                PartPose.offsetAndRotation(-32F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(178, 92).addBox(-6F, 0F, -6F, 12F, 21F, 13F)
                .texOffs(224, 189).addBox(-6F, 20F, -7F, 13F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_gatling = p_forearm_r.addOrReplaceChild("forearm_r_gatling", CubeListBuilder.create()
                .texOffs(374, 92).addBox(-7F, -7F, -16F, 14F, 14F, 18F)
                .texOffs(278, 189).addBox(-5F, -9F, -14F, 9F, 2F, 14F)
                .texOffs(142, 189).addBox(7F, -5F, -9F, 2F, 9F, 9F),
                PartPose.offsetAndRotation(0F, 26F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gatling_barrel = p_forearm_r_gatling.addOrReplaceChild("forearm_r_gatling_barrel", CubeListBuilder.create()
                .texOffs(116, 162).addBox(3F, -1F, -23F, 2F, 2F, 23F)
                .texOffs(116, 162).addBox(1F, 2F, -23F, 2F, 2F, 23F)
                .texOffs(116, 162).addBox(-3F, 2F, -23F, 2F, 2F, 23F)
                .texOffs(116, 162).addBox(-5F, -1F, -23F, 2F, 2F, 23F)
                .texOffs(116, 162).addBox(-3F, -5F, -23F, 2F, 2F, 23F)
                .texOffs(116, 162).addBox(1F, -5F, -23F, 2F, 2F, 23F)
                .texOffs(402, 189).addBox(-6F, -6F, -4F, 12F, 12F, 3F)
                .texOffs(0, 207).addBox(-6F, -6F, -20F, 12F, 12F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -16F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_gatling_flash = p_forearm_r_gatling_barrel.addOrReplaceChild("forearm_r_gatling_flash", CubeListBuilder.create()
                .texOffs(214, 162).addBox(-3F, -3F, -14F, 7F, 7F, 14F)
                .texOffs(178, 207).addBox(-8F, -1F, -4F, 16F, 2F, 3F)
                .texOffs(442, 162).addBox(-1F, -8F, -4F, 2F, 16F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -23F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(166, 162).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(228, 92).mirror().addBox(-7F, -12F, -10F, 18F, 12F, 21F).mirror(false)
                .texOffs(374, 162).mirror().addBox(-6F, -13F, -9F, 16F, 1F, 18F).mirror(false)
                .texOffs(438, 92).mirror().addBox(-5F, 2F, -5F, 9F, 23F, 9F).mirror(false),
                PartPose.offsetAndRotation(32F, -33F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(178, 92).mirror().addBox(-6F, 0F, -6F, 12F, 21F, 13F).mirror(false)
                .texOffs(224, 189).mirror().addBox(-6F, 20F, -7F, 13F, 2F, 14F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_shield = p_forearm_l.addOrReplaceChild("forearm_l_shield", CubeListBuilder.create()
                .texOffs(80, 0).addBox(-2F, -25F, -18F, 5F, 51F, 37F)
                .texOffs(0, 0).addBox(2F, -26F, -20F, 1F, 53F, 39F)
                .texOffs(394, 0).addBox(3F, -16F, -5F, 1F, 32F, 9F)
                .texOffs(138, 207).addBox(3F, -16F, -2F, 1F, 5F, 5F),
                PartPose.offsetAndRotation(8F, 10F, -5F, 0F, 0F, 0F));
        PartDefinition p_cargo0 = p_torso.addOrReplaceChild("cargo0", CubeListBuilder.create()
                .texOffs(0, 131).addBox(-11F, -7F, -8F, 21F, 15F, 16F)
                .texOffs(328, 207).addBox(-9F, -1F, -9F, 19F, 2F, 1F)
                .texOffs(0, 189).addBox(-11F, -8F, -9F, 22F, 1F, 17F),
                PartPose.offsetAndRotation(-11F, -30F, 23F, 0F, 0F, 0F));
        PartDefinition p_cargo1 = p_torso.addOrReplaceChild("cargo1", CubeListBuilder.create()
                .texOffs(0, 131).addBox(-11F, -7F, -8F, 21F, 15F, 16F)
                .texOffs(328, 207).addBox(-9F, -1F, -9F, 19F, 2F, 1F)
                .texOffs(0, 189).addBox(-11F, -8F, -9F, 22F, 1F, 17F),
                PartPose.offsetAndRotation(11F, -30F, 23F, 0F, 0F, 0F));
        PartDefinition p_cargo2 = p_torso.addOrReplaceChild("cargo2", CubeListBuilder.create()
                .texOffs(74, 131).addBox(-11F, -7F, -8F, 21F, 15F, 16F)
                .texOffs(328, 207).addBox(-9F, -1F, -9F, 19F, 2F, 1F)
                .texOffs(0, 189).addBox(-11F, -8F, -9F, 22F, 1F, 17F),
                PartPose.offsetAndRotation(0F, -46F, 23F, 0F, 0F, 0F));
        PartDefinition p_beacon = p_torso.addOrReplaceChild("beacon", CubeListBuilder.create()
                .texOffs(118, 207).addBox(-2F, -1F, -2F, 5F, 7F, 5F)
                .texOffs(28, 207).addBox(-3F, -7F, -3F, 7F, 7F, 7F),
                PartPose.offsetAndRotation(-15F, -46F, 14F, 0F, 0F, 0F));
        PartDefinition p_beacon_spin = p_beacon.addOrReplaceChild("beacon_spin", CubeListBuilder.create()
                .texOffs(166, 207).addBox(-2F, -2F, -4F, 5F, 5F, 1F)
                .texOffs(166, 207).addBox(-2F, -2F, 3F, 5F, 5F, 1F),
                PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.287F)
                .legLengths(10.925F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", 2, 1.2F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null);
    }
}
