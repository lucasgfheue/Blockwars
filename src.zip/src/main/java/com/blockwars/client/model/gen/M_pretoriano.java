package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Praetorian (pretoriano). */
@SuppressWarnings("unused")
public final class M_pretoriano {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("pretoriano"), "main");

    private M_pretoriano() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-31,0,0,0,0/148,131,-17,-6,-9,34,12,18/0,162,-18,-5,-10,37,6,21/150,207,-3,-2,-12,7,7,1;skirt0,0,0,0,-11,-0.15,0,0/"
                + "78,189,-15,0,-1,30,16,2;skirt1,0,0,0,11,0.15,0,0/78,189,-15,0,-1,30,16,2;thigh_r,-1,-15,-31,0,0,0,0/114,92,-8,0,-8,16,22,16/"
                + "256,162,-9,2,-12,18,15,5/342,131,-9,2,-8,2,13,16;shin_r,3,0,22,0,0,0,0/322,0,-9,0,-9,18,23,18/432,189,-8,-6,-13,16,9,5/"
                + "368,189,-7,7,9,14,12,3;foot_r,4,0,23,0,0,0,0/324,189,-6,-1,-6,11,5,11/0,92,-13,3,-19,25,7,32/216,207,-12,6,-20,23,3,1;"
                + "thigh_l,-1,15,-31,0,0,0,0/!114,92,-8,0,-8,16,22,16/!256,162,-9,2,-12,18,15,5/!342,131,7,2,-8,2,13,16;"
                + "shin_l,6,0,22,0,0,0,0/!322,0,-9,0,-9,18,23,18/!432,189,-8,-6,-13,16,9,5/!368,189,-7,7,9,14,12,3;foot_l,7,0,23,0,0,0,0/"
                + "!324,189,-6,-1,-6,11,5,11/!0,92,-13,3,-19,25,7,32/!216,207,-12,6,-20,23,3,1;torso,0,0,-6,0,0,0,0/252,131,-14,-12,-8,28,12,17/"
                + "164,0,-25,-41,-14,51,32,28/302,162,-18,-34,-15,35,18,1/382,131,-19,-40,-11,38,5,22/56,207,-15,-27,14,30,12,1;"
                + "head,9,0,-41,-2,0,0,0/474,189,-5,-5,-5,9,5,9/306,92,-8,-18,-9,16,14,18/164,189,-7,-20,-7,14,1,16/264,207,-7,-13,-10,14,3,1/"
                + "294,207,-6,-9,-10,12,3,1;antenna,10,6,-14,5,-0.2,0,0.15/378,131,-1,-28,-1,1,28,1/320,207,-1,-29,-1,2,2,2;"
                + "shoulder_r,9,-32,-33,0,0,0,0/166,162,-6,-6,-6,12,12,12/228,92,-12,-12,-10,18,12,21/374,162,-10,-13,-9,16,1,18/"
                + "438,92,-5,2,-5,9,23,9;forearm_r,12,0,24,0,-0.25,0,0/178,92,-6,0,-6,12,21,13/224,189,-6,20,-7,13,2,14;"
                + "forearm_r_gatling,13,0,26,-2,0,0,0/374,92,-7,-7,-16,14,14,18/278,189,-5,-9,-14,9,2,14/142,189,7,-5,-9,2,9,9;"
                + "forearm_r_gatling_barrel,14,0,0,-16,0,0,0/116,162,3,-1,-23,2,2,23/116,162,1,2,-23,2,2,23/116,162,-3,2,-23,2,2,23/"
                + "116,162,-5,-1,-23,2,2,23/116,162,-3,-5,-23,2,2,23/116,162,1,-5,-23,2,2,23/402,189,-6,-6,-4,12,12,3/0,207,-6,-6,-20,12,12,2;"
                + "forearm_r_gatling_flash,15,0,0,-23,0,0,0/214,162,-3,-3,-14,7,7,14/178,207,-8,-1,-4,16,2,3/442,162,-1,-8,-4,2,16,3;"
                + "shoulder_l,9,32,-33,0,0,0,0/!166,162,-6,-6,-6,12,12,12/!228,92,-7,-12,-10,18,12,21/!374,162,-6,-13,-9,16,1,18/"
                + "!438,92,-5,2,-5,9,23,9;forearm_l,17,0,24,0,-0.25,0,0/!178,92,-6,0,-6,12,21,13/!224,189,-6,20,-7,13,2,14;"
                + "forearm_l_shield,18,8,10,-5,0,0,0/80,0,-2,-25,-18,5,51,37/0,0,2,-26,-20,1,53,39/394,0,3,-16,-5,1,32,9/"
                + "138,207,3,-16,-2,1,5,5;cargo0,9,-11,-30,23,0,0,0/0,131,-11,-7,-8,21,15,16/328,207,-9,-1,-9,19,2,1/0,189,-11,-8,-9,22,1,17;"
                + "cargo1,9,11,-30,23,0,0,0/0,131,-11,-7,-8,21,15,16/328,207,-9,-1,-9,19,2,1/0,189,-11,-8,-9,22,1,17;cargo2,9,0,-46,23,0,0,0/"
                + "74,131,-11,-7,-8,21,15,16/328,207,-9,-1,-9,19,2,1/0,189,-11,-8,-9,22,1,17;beacon,9,-15,-46,14,0,0,0/118,207,-2,-1,-2,5,7,5/"
                + "28,207,-3,-7,-3,7,7,7;beacon_spin,23,0,-3,0,0,0,0/166,207,-2,-2,-4,5,5,1/166,207,-2,-2,3,5,5,1");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.287F)
                .legLengths(10.925F, 11.5F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .spin("hips/torso/beacon/beacon_spin", 1, 0.35F, 0)
                .spin("hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", 2, 1.2F, 3)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_gatling/forearm_r_gatling_barrel/forearm_r_gatling_flash", null);
    }
}
