package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Thornback (lomoespino). */
@SuppressWarnings("unused")
public final class M_lomoespino {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("lomoespino"), "main");

    private M_lomoespino() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "body,-1,0,-16,0,0,0,0/376,0,-11,-17,-21,22,17,42/184,0,-18,-26,-30,36,14,60/16,150,-10,-25,-32,20,11,2/"
                + "0,82,-11,-29,-16,22,6,36/0,0,-16,-25,-30,32,22,60/122,150,-11,-20,30,22,11,1;leg_fr,-1,-21,-16,-22,0,0,0.12/"
                + "116,82,-8,-2,-9,16,20,18/376,82,-9,-5,-10,18,8,20;shin_fr,1,0,16,0,0,0,-0.12/248,82,-6,0,-6,12,18,12/"
                + "86,150,-5,2,-8,10,11,2;foot_fr,2,0,18,0,0,0,0/296,82,-9,0,-13,18,6,22/266,150,-8,2,-14,16,3,1;leg_fl,-1,21,-16,-22,0,0,-0.12/"
                + "!116,82,-8,-2,-9,16,20,18/!376,82,-9,-5,-10,18,8,20;shin_fl,4,0,16,0,0,0,0.12/!248,82,-6,0,-6,12,18,12/"
                + "!86,150,-5,2,-8,10,11,2;foot_fl,5,0,18,0,0,0,0/!296,82,-9,0,-13,18,6,22/!266,150,-8,2,-14,16,3,1;leg_br,-1,-21,-16,22,0,0,0.12/"
                + "116,82,-8,-2,-9,16,20,18/376,82,-9,-5,-10,18,8,20;shin_br,7,0,16,0,0,0,-0.12/248,82,-6,0,-6,12,18,12/"
                + "86,150,-5,2,-8,10,11,2;foot_br,8,0,18,0,0,0,0/296,82,-9,0,-13,18,6,22/266,150,-8,2,-14,16,3,1;leg_bl,-1,21,-16,22,0,0,-0.12/"
                + "!116,82,-8,-2,-9,16,20,18/!376,82,-9,-5,-10,18,8,20;shin_bl,10,0,16,0,0,0,0.12/!248,82,-6,0,-6,12,18,12/"
                + "!86,150,-5,2,-8,10,11,2;foot_bl,11,0,18,0,0,0,0/!296,82,-9,0,-13,18,6,22/!266,150,-8,2,-14,16,3,1;head,0,0,-17,-32,0,0,0/"
                + "184,82,-8,-13,-12,16,14,16/340,124,-6,-8,-19,12,8,8/320,150,-6,-10,-13,3,2,1/320,150,3,-10,-13,3,2,1;"
                + "jaw,13,0,1,-8,0,0,0/416,124,-5,0,-12,10,3,12/300,150,-4,-1,-12,8,1,2;turret,0,0,-30,-4,0,0,0/0,124,-9,-6,-10,18,6,20/"
                + "270,124,-7,-7,-8,14,1,16;turret_gatling,15,0,-8,-4,0,0,0/452,82,-6,-6,-14,12,12,16/460,124,-4,-8,-12,8,2,12/"
                + "380,124,6,-4,-8,2,8,8;turret_gatling_barrel,16,0,0,-14,0,0,0/76,124,3,-1,-20,2,2,20/76,124,1,2,-20,2,2,20/"
                + "76,124,-3,2,-20,2,2,20/76,124,-5,-1,-20,2,2,20/76,124,-3,-4,-20,2,2,20/76,124,1,-4,-20,2,2,20/60,150,-5,-5,-4,10,10,3/"
                + "168,150,-5,-5,-17,10,10,2;turret_gatling_flash,17,0,0,-20,0,0,0/198,124,-3,-3,-12,6,6,12/224,150,-7,-1,-4,14,2,3/"
                + "330,124,-1,-7,-4,2,14,3;spine0,0,0,-28,32,0.6,0,0/400,124,-2,-12,0,4,12,4/258,150,-1,-14,1,2,3,2;spine1,0,0,-20,32,0.7,0,0/"
                + "0,150,-2,-10,0,4,10,4/258,150,-1,-12,1,2,3,2;spine2,0,0,-12,32,0.8,0,0/192,150,-2,-9,0,4,8,4/258,150,-1,-11,1,2,3,2;"
                + "spine3,0,0,-4,32,0.9,0,0/208,150,-2,-7,0,4,6,4/258,150,-1,-10,1,2,3,2;tail0,0,0,-17,30,0.5,0,0/120,124,-3,-3,-1,6,6,14;"
                + "tail1,23,0,0,13,0.2,0,0/160,124,-2,-2,-1,5,5,14;tail2,24,0,0,13,0.2,0,0/234,124,-2,-2,-1,4,4,14;bspike0,0,0,-30,-16,0.5,0,0/"
                + "110,150,-2,-10,-2,3,10,3;bspike1,0,0,-30,0,0.5,0,0/110,150,-2,-10,-2,3,10,3;bspike2,0,0,-30,16,0.5,0,0/"
                + "110,150,-2,-10,-2,3,10,3");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.4F)
                .legLengths(8F, 9F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .spin("body/turret/turret_gatling/turret_gatling_barrel", 2, 1.2F, 3)
                .sway("body/spine0", 0, 0.05F, 0F)
                .sway("body/spine1", 0, 0.05F, 0.7F)
                .sway("body/spine2", 0, 0.05F, 1.4F)
                .sway("body/spine3", 0, 0.05F, 2.1F)
                .sway("body/tail0", 1, 0.12F, 0F)
                .sway("body/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("body/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .jaw("body/head/jaw")
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_gatling/turret_gatling_barrel", "body/turret/turret_gatling/turret_gatling_barrel/turret_gatling_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_gatling/turret_gatling_barrel", "body/turret/turret_gatling/turret_gatling_barrel/turret_gatling_flash", null);
    }
}
