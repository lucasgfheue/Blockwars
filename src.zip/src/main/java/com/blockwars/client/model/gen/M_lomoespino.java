package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Thornback (lomoespino). */
@SuppressWarnings("unused")
public final class M_lomoespino {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("lomoespino"), "main");

    private M_lomoespino() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(376, 0).addBox(-11F, -17F, -21F, 22F, 17F, 42F)
                .texOffs(184, 0).addBox(-18F, -26F, -30F, 36F, 14F, 60F)
                .texOffs(16, 150).addBox(-10F, -25F, -32F, 20F, 11F, 2F)
                .texOffs(0, 82).addBox(-11F, -29F, -16F, 22F, 6F, 36F)
                .texOffs(0, 0).addBox(-16F, -25F, -30F, 32F, 22F, 60F)
                .texOffs(122, 150).addBox(-11F, -20F, 30F, 22F, 11F, 1F),
                PartPose.offsetAndRotation(0F, -16F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create()
                .texOffs(116, 82).addBox(-8F, -2F, -9F, 16F, 20F, 18F)
                .texOffs(376, 82).addBox(-9F, -5F, -10F, 18F, 8F, 20F),
                PartPose.offsetAndRotation(-21F, -16F, -22F, 0F, 0F, 0.12F));
        PartDefinition p_shin_fr = p_leg_fr.addOrReplaceChild("shin_fr", CubeListBuilder.create()
                .texOffs(248, 82).addBox(-6F, 0F, -6F, 12F, 18F, 12F)
                .texOffs(86, 150).addBox(-5F, 2F, -8F, 10F, 11F, 2F),
                PartPose.offsetAndRotation(0F, 16F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_fr = p_shin_fr.addOrReplaceChild("foot_fr", CubeListBuilder.create()
                .texOffs(296, 82).addBox(-9F, 0F, -13F, 18F, 6F, 22F)
                .texOffs(266, 150).addBox(-8F, 2F, -14F, 16F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create()
                .texOffs(116, 82).mirror().addBox(-8F, -2F, -9F, 16F, 20F, 18F).mirror(false)
                .texOffs(376, 82).mirror().addBox(-9F, -5F, -10F, 18F, 8F, 20F).mirror(false),
                PartPose.offsetAndRotation(21F, -16F, -22F, 0F, 0F, -0.12F));
        PartDefinition p_shin_fl = p_leg_fl.addOrReplaceChild("shin_fl", CubeListBuilder.create()
                .texOffs(248, 82).mirror().addBox(-6F, 0F, -6F, 12F, 18F, 12F).mirror(false)
                .texOffs(86, 150).mirror().addBox(-5F, 2F, -8F, 10F, 11F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 16F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_fl = p_shin_fl.addOrReplaceChild("foot_fl", CubeListBuilder.create()
                .texOffs(296, 82).mirror().addBox(-9F, 0F, -13F, 18F, 6F, 22F).mirror(false)
                .texOffs(266, 150).mirror().addBox(-8F, 2F, -14F, 16F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create()
                .texOffs(116, 82).addBox(-8F, -2F, -9F, 16F, 20F, 18F)
                .texOffs(376, 82).addBox(-9F, -5F, -10F, 18F, 8F, 20F),
                PartPose.offsetAndRotation(-21F, -16F, 22F, 0F, 0F, 0.12F));
        PartDefinition p_shin_br = p_leg_br.addOrReplaceChild("shin_br", CubeListBuilder.create()
                .texOffs(248, 82).addBox(-6F, 0F, -6F, 12F, 18F, 12F)
                .texOffs(86, 150).addBox(-5F, 2F, -8F, 10F, 11F, 2F),
                PartPose.offsetAndRotation(0F, 16F, 0F, 0F, 0F, -0.12F));
        PartDefinition p_foot_br = p_shin_br.addOrReplaceChild("foot_br", CubeListBuilder.create()
                .texOffs(296, 82).addBox(-9F, 0F, -13F, 18F, 6F, 22F)
                .texOffs(266, 150).addBox(-8F, 2F, -14F, 16F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0F));
        PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create()
                .texOffs(116, 82).mirror().addBox(-8F, -2F, -9F, 16F, 20F, 18F).mirror(false)
                .texOffs(376, 82).mirror().addBox(-9F, -5F, -10F, 18F, 8F, 20F).mirror(false),
                PartPose.offsetAndRotation(21F, -16F, 22F, 0F, 0F, -0.12F));
        PartDefinition p_shin_bl = p_leg_bl.addOrReplaceChild("shin_bl", CubeListBuilder.create()
                .texOffs(248, 82).mirror().addBox(-6F, 0F, -6F, 12F, 18F, 12F).mirror(false)
                .texOffs(86, 150).mirror().addBox(-5F, 2F, -8F, 10F, 11F, 2F).mirror(false),
                PartPose.offsetAndRotation(0F, 16F, 0F, 0F, 0F, 0.12F));
        PartDefinition p_foot_bl = p_shin_bl.addOrReplaceChild("foot_bl", CubeListBuilder.create()
                .texOffs(296, 82).mirror().addBox(-9F, 0F, -13F, 18F, 6F, 22F).mirror(false)
                .texOffs(266, 150).mirror().addBox(-8F, 2F, -14F, 16F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 18F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_body.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(184, 82).addBox(-8F, -13F, -12F, 16F, 14F, 16F)
                .texOffs(340, 124).addBox(-6F, -8F, -19F, 12F, 8F, 8F)
                .texOffs(320, 150).addBox(-6F, -10F, -13F, 3F, 2F, 1F)
                .texOffs(320, 150).addBox(3F, -10F, -13F, 3F, 2F, 1F),
                PartPose.offsetAndRotation(0F, -17F, -32F, 0F, 0F, 0F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(416, 124).addBox(-5F, 0F, -12F, 10F, 3F, 12F)
                .texOffs(300, 150).addBox(-4F, -1F, -12F, 8F, 1F, 2F),
                PartPose.offsetAndRotation(0F, 1F, -8F, 0F, 0F, 0F));
        PartDefinition p_turret = p_body.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(0, 124).addBox(-9F, -6F, -10F, 18F, 6F, 20F)
                .texOffs(270, 124).addBox(-7F, -7F, -8F, 14F, 1F, 16F),
                PartPose.offsetAndRotation(0F, -30F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_gatling = p_turret.addOrReplaceChild("turret_gatling", CubeListBuilder.create()
                .texOffs(452, 82).addBox(-6F, -6F, -14F, 12F, 12F, 16F)
                .texOffs(460, 124).addBox(-4F, -8F, -12F, 8F, 2F, 12F)
                .texOffs(380, 124).addBox(6F, -4F, -8F, 2F, 8F, 8F),
                PartPose.offsetAndRotation(0F, -8F, -4F, 0F, 0F, 0F));
        PartDefinition p_turret_gatling_barrel = p_turret_gatling.addOrReplaceChild("turret_gatling_barrel", CubeListBuilder.create()
                .texOffs(76, 124).addBox(3F, -1F, -20F, 2F, 2F, 20F)
                .texOffs(76, 124).addBox(1F, 2F, -20F, 2F, 2F, 20F)
                .texOffs(76, 124).addBox(-3F, 2F, -20F, 2F, 2F, 20F)
                .texOffs(76, 124).addBox(-5F, -1F, -20F, 2F, 2F, 20F)
                .texOffs(76, 124).addBox(-3F, -4F, -20F, 2F, 2F, 20F)
                .texOffs(76, 124).addBox(1F, -4F, -20F, 2F, 2F, 20F)
                .texOffs(60, 150).addBox(-5F, -5F, -4F, 10F, 10F, 3F)
                .texOffs(168, 150).addBox(-5F, -5F, -17F, 10F, 10F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -14F, 0F, 0F, 0F));
        PartDefinition p_turret_gatling_flash = p_turret_gatling_barrel.addOrReplaceChild("turret_gatling_flash", CubeListBuilder.create()
                .texOffs(198, 124).addBox(-3F, -3F, -12F, 6F, 6F, 12F)
                .texOffs(224, 150).addBox(-7F, -1F, -4F, 14F, 2F, 3F)
                .texOffs(330, 124).addBox(-1F, -7F, -4F, 2F, 14F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -20F, 0F, 0F, 0F));
        PartDefinition p_spine0 = p_body.addOrReplaceChild("spine0", CubeListBuilder.create()
                .texOffs(400, 124).addBox(-2F, -12F, 0F, 4F, 12F, 4F)
                .texOffs(258, 150).addBox(-1F, -14F, 1F, 2F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -28F, 32F, 0.6F, 0F, 0F));
        PartDefinition p_spine1 = p_body.addOrReplaceChild("spine1", CubeListBuilder.create()
                .texOffs(0, 150).addBox(-2F, -10F, 0F, 4F, 10F, 4F)
                .texOffs(258, 150).addBox(-1F, -12F, 1F, 2F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -20F, 32F, 0.7F, 0F, 0F));
        PartDefinition p_spine2 = p_body.addOrReplaceChild("spine2", CubeListBuilder.create()
                .texOffs(192, 150).addBox(-2F, -9F, 0F, 4F, 8F, 4F)
                .texOffs(258, 150).addBox(-1F, -11F, 1F, 2F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -12F, 32F, 0.8F, 0F, 0F));
        PartDefinition p_spine3 = p_body.addOrReplaceChild("spine3", CubeListBuilder.create()
                .texOffs(208, 150).addBox(-2F, -7F, 0F, 4F, 6F, 4F)
                .texOffs(258, 150).addBox(-1F, -10F, 1F, 2F, 3F, 2F),
                PartPose.offsetAndRotation(0F, -4F, 32F, 0.9F, 0F, 0F));
        PartDefinition p_tail0 = p_body.addOrReplaceChild("tail0", CubeListBuilder.create()
                .texOffs(120, 124).addBox(-3F, -3F, -1F, 6F, 6F, 14F),
                PartPose.offsetAndRotation(0F, -17F, 30F, 0.5F, 0F, 0F));
        PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create()
                .texOffs(160, 124).addBox(-2F, -2F, -1F, 5F, 5F, 14F),
                PartPose.offsetAndRotation(0F, 0F, 13F, 0.2F, 0F, 0F));
        PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create()
                .texOffs(234, 124).addBox(-2F, -2F, -1F, 4F, 4F, 14F),
                PartPose.offsetAndRotation(0F, 0F, 13F, 0.2F, 0F, 0F));
        PartDefinition p_bspike0 = p_body.addOrReplaceChild("bspike0", CubeListBuilder.create()
                .texOffs(110, 150).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -30F, -16F, 0.5F, 0F, 0F));
        PartDefinition p_bspike1 = p_body.addOrReplaceChild("bspike1", CubeListBuilder.create()
                .texOffs(110, 150).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -30F, 0F, 0.5F, 0F, 0F));
        PartDefinition p_bspike2 = p_body.addOrReplaceChild("bspike2", CubeListBuilder.create()
                .texOffs(110, 150).addBox(-2F, -10F, -2F, 3F, 10F, 3F),
                PartPose.offsetAndRotation(0F, -30F, 16F, 0.5F, 0F, 0F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.QUAD).parts("body", "body", "body/head").walkRate(0.4F)
                .legLengths(8F, 9F)
                .leg("leg_fr", "leg_fr/shin_fr", "leg_fr/shin_fr/foot_fr", -1, 0F, 0)
                .leg("leg_fl", "leg_fl/shin_fl", "leg_fl/shin_fl/foot_fl", 1, 3.1416F, 0)
                .leg("leg_br", "leg_br/shin_br", "leg_br/shin_br/foot_br", -1, 3.1416F, 0)
                .leg("leg_bl", "leg_bl/shin_bl", "leg_bl/shin_bl/foot_bl", 1, 0F, 0)
                .spin("body/turret/turret_gatling/turret_gatling_barrel", 2, 1.2F, 3)
                .sway("body/spine0", 0, 0.05F, 0F)
                .sway("body/spine1", 0, 0.05F, 0.7F)
                .sway("body/spine2", 0, 0.05F, 1.4F)
                .sway("body/spine3", 0, 0.05F, 2.1F)
                .sway("body/tail0", 1, 0.12F, 0F)
                .sway("body/tail0/tail1", 1, 0.12F, 0.9F)
                .sway("body/tail0/tail1/tail2", 1, 0.12F, 1.8F)
                .jaw("body/head/jaw")
                .primary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_gatling/turret_gatling_barrel", "body/turret/turret_gatling/turret_gatling_barrel/turret_gatling_flash", null)
                .secondary(Rig.MountKind.TURRET, "body/turret", "body/turret/turret_gatling/turret_gatling_barrel", "body/turret/turret_gatling/turret_gatling_barrel/turret_gatling_flash", null);
    }
}
