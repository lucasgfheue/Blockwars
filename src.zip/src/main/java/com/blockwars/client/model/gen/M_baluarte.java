package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Bulwark (baluarte). */
@SuppressWarnings("unused")
public final class M_baluarte {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("baluarte"), "main");

    private M_baluarte() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(0, 123).addBox(-16F, -5F, -9F, 32F, 11F, 17F)
                .texOffs(394, 123).addBox(-17F, -5F, -10F, 35F, 5F, 19F)
                .texOffs(302, 173).addBox(-3F, -2F, -11F, 6F, 6F, 1F),
                PartPose.offsetAndRotation(0F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_skirt0 = p_hips.addOrReplaceChild("skirt0", CubeListBuilder.create()
                .texOffs(358, 151).addBox(-14F, 0F, -1F, 28F, 15F, 2F),
                PartPose.offsetAndRotation(0F, 0F, -10F, -0.15F, 0F, 0F));
        PartDefinition p_skirt1 = p_hips.addOrReplaceChild("skirt1", CubeListBuilder.create()
                .texOffs(358, 151).addBox(-14F, 0F, -1F, 28F, 15F, 2F),
                PartPose.offsetAndRotation(0F, 0F, 10F, 0.15F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(108, 87).addBox(-8F, 0F, -8F, 15F, 21F, 15F)
                .texOffs(270, 151).addBox(-9F, 2F, -11F, 17F, 14F, 4F)
                .texOffs(182, 123).addBox(-9F, 2F, -8F, 2F, 12F, 15F),
                PartPose.offsetAndRotation(-14F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(384, 0).addBox(-9F, 0F, -9F, 17F, 22F, 17F)
                .texOffs(186, 173).addBox(-8F, -5F, -12F, 15F, 9F, 4F)
                .texOffs(94, 173).addBox(-6F, 6F, 9F, 13F, 11F, 3F),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(50, 173).addBox(-5F, -1F, -5F, 11F, 4F, 11F)
                .texOffs(0, 87).addBox(-12F, 3F, -18F, 24F, 6F, 30F)
                .texOffs(368, 173).addBox(-11F, 5F, -19F, 22F, 3F, 1F),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(108, 87).mirror().addBox(-8F, 0F, -8F, 15F, 21F, 15F).mirror(false)
                .texOffs(270, 151).mirror().addBox(-9F, 2F, -11F, 17F, 14F, 4F).mirror(false)
                .texOffs(182, 123).mirror().addBox(6F, 2F, -8F, 2F, 12F, 15F).mirror(false),
                PartPose.offsetAndRotation(14F, -28F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(384, 0).mirror().addBox(-9F, 0F, -9F, 17F, 22F, 17F).mirror(false)
                .texOffs(186, 173).mirror().addBox(-8F, -5F, -12F, 15F, 9F, 4F).mirror(false)
                .texOffs(94, 173).mirror().addBox(-6F, 6F, 9F, 13F, 11F, 3F).mirror(false),
                PartPose.offsetAndRotation(0F, 21F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(50, 173).mirror().addBox(-5F, -1F, -5F, 11F, 4F, 11F).mirror(false)
                .texOffs(0, 87).mirror().addBox(-12F, 3F, -18F, 24F, 6F, 30F).mirror(false)
                .texOffs(368, 173).mirror().addBox(-11F, 5F, -19F, 22F, 3F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 22F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(98, 123).addBox(-13F, -11F, -8F, 26F, 11F, 16F)
                .texOffs(154, 0).addBox(-24F, -39F, -13F, 48F, 30F, 26F)
                .texOffs(82, 151).addBox(-17F, -32F, -14F, 33F, 17F, 1F)
                .texOffs(256, 123).addBox(-18F, -38F, -10F, 36F, 4F, 21F)
                .texOffs(126, 173).addBox(-14F, -25F, 13F, 29F, 12F, 1F),
                PartPose.offsetAndRotation(0F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(224, 173).addBox(-4F, -4F, -4F, 9F, 4F, 9F)
                .texOffs(390, 87).addBox(-8F, -17F, -9F, 15F, 13F, 17F)
                .texOffs(418, 151).addBox(-6F, -18F, -6F, 13F, 1F, 15F)
                .texOffs(414, 173).addBox(-6F, -12F, -9F, 13F, 3F, 1F)
                .texOffs(442, 173).addBox(-5F, -8F, -9F, 11F, 3F, 1F),
                PartPose.offsetAndRotation(0F, -39F, -2F, 0F, 0F, 0F));
        PartDefinition p_antenna = p_head.addOrReplaceChild("antenna", CubeListBuilder.create()
                .texOffs(216, 123).addBox(-1F, -26F, -1F, 1F, 26F, 1F)
                .texOffs(466, 173).addBox(-1F, -27F, -1F, 2F, 2F, 2F),
                PartPose.offsetAndRotation(5F, -13F, 4F, -0.2F, 0F, 0.15F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(0, 151).addBox(-5F, -5F, -5F, 11F, 11F, 11F)
                .texOffs(318, 87).addBox(-11F, -11F, -10F, 17F, 11F, 19F)
                .texOffs(150, 151).addBox(-10F, -12F, -9F, 15F, 1F, 17F)
                .texOffs(282, 87).addBox(-4F, 2F, -4F, 9F, 22F, 9F),
                PartPose.offsetAndRotation(-30F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(236, 87).addBox(-5F, 0F, -6F, 11F, 19F, 12F)
                .texOffs(0, 173).addBox(-6F, 18F, -6F, 12F, 2F, 13F),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_cannon = p_forearm_r.addOrReplaceChild("forearm_r_cannon", CubeListBuilder.create()
                .texOffs(302, 0).addBox(-8F, -8F, -22F, 15F, 15F, 26F)
                .texOffs(214, 151).addBox(-5F, -9F, -17F, 11F, 1F, 17F)
                .texOffs(220, 123).addBox(8F, -4F, -17F, 1F, 9F, 17F),
                PartPose.offsetAndRotation(0F, 26F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_barrel = p_forearm_r_cannon.addOrReplaceChild("forearm_r_cannon_barrel", CubeListBuilder.create()
                .texOffs(168, 87).addBox(-4F, -4F, -26F, 8F, 8F, 26F)
                .texOffs(312, 151).addBox(-6F, -6F, -30F, 12F, 12F, 6F),
                PartPose.offsetAndRotation(0F, 0F, -22F, 0F, 0F, 0F));
        PartDefinition p_forearm_r_cannon_flash = p_forearm_r_cannon_barrel.addOrReplaceChild("forearm_r_cannon_flash", CubeListBuilder.create()
                .texOffs(44, 151).addBox(-3F, -3F, -13F, 6F, 6F, 13F)
                .texOffs(316, 173).addBox(-8F, -1F, -4F, 15F, 2F, 3F)
                .texOffs(348, 151).addBox(-1F, -8F, -4F, 2F, 15F, 3F),
                PartPose.offsetAndRotation(0F, 0F, -30F, 0F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(0, 151).mirror().addBox(-5F, -5F, -5F, 11F, 11F, 11F).mirror(false)
                .texOffs(318, 87).mirror().addBox(-6F, -11F, -10F, 17F, 11F, 19F).mirror(false)
                .texOffs(150, 151).mirror().addBox(-5F, -12F, -9F, 15F, 1F, 17F).mirror(false)
                .texOffs(282, 87).mirror().addBox(-4F, 2F, -4F, 9F, 22F, 9F).mirror(false),
                PartPose.offsetAndRotation(30F, -31F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(236, 87).mirror().addBox(-5F, 0F, -6F, 11F, 19F, 12F).mirror(false)
                .texOffs(0, 173).mirror().addBox(-6F, 18F, -6F, 12F, 2F, 13F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_shield = p_forearm_l.addOrReplaceChild("forearm_l_shield", CubeListBuilder.create()
                .texOffs(76, 0).addBox(-2F, -24F, -17F, 4F, 48F, 35F)
                .texOffs(0, 0).addBox(2F, -25F, -18F, 1F, 50F, 37F)
                .texOffs(452, 0).addBox(3F, -15F, -4F, 1F, 30F, 9F)
                .texOffs(292, 173).addBox(3F, -15F, -2F, 1F, 4F, 4F),
                PartPose.offsetAndRotation(8F, 10F, -4F, 0F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(370, 123).addBox(-3F, -18F, -3F, 6F, 19F, 6F)
                .texOffs(260, 173).addBox(-4F, -20F, -4F, 8F, 2F, 8F)
                .texOffs(352, 173).addBox(-2F, -21F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(-14F, -35F, 17F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(370, 123).addBox(-3F, -18F, -3F, 6F, 19F, 6F)
                .texOffs(260, 173).addBox(-4F, -20F, -4F, 8F, 2F, 8F)
                .texOffs(352, 173).addBox(-2F, -21F, -2F, 4F, 1F, 4F),
                PartPose.offsetAndRotation(14F, -35F, 17F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3056F)
                .legLengths(10.26F, 10.8F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null);
    }
}
