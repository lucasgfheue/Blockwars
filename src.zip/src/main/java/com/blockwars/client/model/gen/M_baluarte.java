package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.LayerDefinition;

/** Generated model for Bulwark (baluarte). */
@SuppressWarnings("unused")
public final class M_baluarte {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("baluarte"), "main");

    private M_baluarte() {}

    /** Parts as data (see {@link ModelData}): name, parent, pivot and rotation, then the boxes. */
    public static LayerDefinition createBodyLayer() {
        return ModelData.build(512, 256, "hips,-1,0,-28,0,0,0,0/0,123,-16,-5,-9,32,11,17/394,123,-17,-5,-10,35,5,19/302,173,-3,-2,-11,6,6,1;skirt0,0,0,0,-10,-0.15,0,0/"
                + "358,151,-14,0,-1,28,15,2;skirt1,0,0,0,10,0.15,0,0/358,151,-14,0,-1,28,15,2;thigh_r,-1,-14,-28,0,0,0,0/"
                + "108,87,-8,0,-8,15,21,15/270,151,-9,2,-11,17,14,4/182,123,-9,2,-8,2,12,15;shin_r,3,0,21,0,0,0,0/384,0,-9,0,-9,17,22,17/"
                + "186,173,-8,-5,-12,15,9,4/94,173,-6,6,9,13,11,3;foot_r,4,0,22,0,0,0,0/50,173,-5,-1,-5,11,4,11/0,87,-12,3,-18,24,6,30/"
                + "368,173,-11,5,-19,22,3,1;thigh_l,-1,14,-28,0,0,0,0/!108,87,-8,0,-8,15,21,15/!270,151,-9,2,-11,17,14,4/"
                + "!182,123,6,2,-8,2,12,15;shin_l,6,0,21,0,0,0,0/!384,0,-9,0,-9,17,22,17/!186,173,-8,-5,-12,15,9,4/!94,173,-6,6,9,13,11,3;"
                + "foot_l,7,0,22,0,0,0,0/!50,173,-5,-1,-5,11,4,11/!0,87,-12,3,-18,24,6,30/!368,173,-11,5,-19,22,3,1;torso,0,0,-5,0,0,0,0/"
                + "98,123,-13,-11,-8,26,11,16/154,0,-24,-39,-13,48,30,26/82,151,-17,-32,-14,33,17,1/256,123,-18,-38,-10,36,4,21/"
                + "126,173,-14,-25,13,29,12,1;head,9,0,-39,-2,0,0,0/224,173,-4,-4,-4,9,4,9/390,87,-8,-17,-9,15,13,17/418,151,-6,-18,-6,13,1,15/"
                + "414,173,-6,-12,-9,13,3,1/442,173,-5,-8,-9,11,3,1;antenna,10,5,-13,4,-0.2,0,0.15/216,123,-1,-26,-1,1,26,1/"
                + "466,173,-1,-27,-1,2,2,2;shoulder_r,9,-30,-31,0,0,0,0/0,151,-5,-5,-5,11,11,11/318,87,-11,-11,-10,17,11,19/"
                + "150,151,-10,-12,-9,15,1,17/282,87,-4,2,-4,9,22,9;forearm_r,12,0,23,0,-0.25,0,0/236,87,-5,0,-6,11,19,12/"
                + "0,173,-6,18,-6,12,2,13;forearm_r_cannon,13,0,26,-2,0,0,0/302,0,-8,-8,-22,15,15,26/214,151,-5,-9,-17,11,1,17/"
                + "220,123,8,-4,-17,1,9,17;forearm_r_cannon_barrel,14,0,0,-22,0,0,0/168,87,-4,-4,-26,8,8,26/312,151,-6,-6,-30,12,12,6;"
                + "forearm_r_cannon_flash,15,0,0,-30,0,0,0/44,151,-3,-3,-13,6,6,13/316,173,-8,-1,-4,15,2,3/348,151,-1,-8,-4,2,15,3;"
                + "shoulder_l,9,30,-31,0,0,0,0/!0,151,-5,-5,-5,11,11,11/!318,87,-6,-11,-10,17,11,19/!150,151,-5,-12,-9,15,1,17/"
                + "!282,87,-4,2,-4,9,22,9;forearm_l,17,0,23,0,-0.25,0,0/!236,87,-5,0,-6,11,19,12/!0,173,-6,18,-6,12,2,13;"
                + "forearm_l_shield,18,8,10,-4,0,0,0/76,0,-2,-24,-17,4,48,35/0,0,2,-25,-18,1,50,37/452,0,3,-15,-4,1,30,9/"
                + "292,173,3,-15,-2,1,4,4;stack_r,9,-14,-35,17,-0.15,0,0.1/370,123,-3,-18,-3,6,19,6/260,173,-4,-20,-4,8,2,8/"
                + "352,173,-2,-21,-2,4,1,4;stack_l,9,14,-35,17,-0.15,0,-0.1/370,123,-3,-18,-3,6,19,6/260,173,-4,-20,-4,8,2,8/"
                + "352,173,-2,-21,-2,4,1,4");
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.3056F)
                .legLengths(10.26F, 10.8F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .sway("hips/torso/head/antenna", 2, 0.08F, 0F)
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel", "hips/torso/shoulder_r/forearm_r/forearm_r_cannon/forearm_r_cannon_barrel/forearm_r_cannon_flash", null);
    }
}
