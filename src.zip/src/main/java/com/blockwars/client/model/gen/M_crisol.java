package com.blockwars.client.model.gen;

import com.blockwars.BlockWars;
import com.blockwars.client.Rig;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generated model for Crucible (crisol). */
@SuppressWarnings("unused")
public final class M_crisol {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(BlockWars.id("crisol"), "main");

    private M_crisol() {}

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_hips = root.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(328, 110).addBox(-18F, -6F, -10F, 36F, 12F, 19F)
                .texOffs(140, 142).addBox(-19F, -5F, -11F, 38F, 6F, 22F)
                .texOffs(388, 192).addBox(-4F, -2F, -12F, 7F, 7F, 1F),
                PartPose.offsetAndRotation(0F, -34F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_r = root.addOrReplaceChild("thigh_r", CubeListBuilder.create()
                .texOffs(118, 70).addBox(-8F, 0F, -8F, 17F, 23F, 17F)
                .texOffs(0, 171).addBox(-10F, 2F, -12F, 19F, 16F, 5F)
                .texOffs(438, 110).addBox(-10F, 2F, -8F, 2F, 14F, 17F),
                PartPose.offsetAndRotation(-16F, -34F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_r = p_thigh_r.addOrReplaceChild("shin_r", CubeListBuilder.create()
                .texOffs(356, 0).addBox(-10F, 0F, -10F, 19F, 24F, 19F)
                .texOffs(118, 192).addBox(-8F, -6F, -13F, 17F, 10F, 5F)
                .texOffs(0, 192).addBox(-7F, 7F, 10F, 14F, 12F, 4F),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_r = p_shin_r.addOrReplaceChild("foot_r", CubeListBuilder.create()
                .texOffs(348, 171).addBox(-6F, -1F, -6F, 12F, 5F, 12F)
                .texOffs(0, 70).addBox(-13F, 4F, -20F, 26F, 7F, 33F)
                .texOffs(0, 208).addBox(-12F, 6F, -21F, 24F, 4F, 1F),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_thigh_l = root.addOrReplaceChild("thigh_l", CubeListBuilder.create()
                .texOffs(118, 70).mirror().addBox(-8F, 0F, -8F, 17F, 23F, 17F).mirror(false)
                .texOffs(0, 171).mirror().addBox(-10F, 2F, -12F, 19F, 16F, 5F).mirror(false)
                .texOffs(438, 110).mirror().addBox(7F, 2F, -8F, 2F, 14F, 17F).mirror(false),
                PartPose.offsetAndRotation(16F, -34F, 0F, 0F, 0F, 0F));
        PartDefinition p_shin_l = p_thigh_l.addOrReplaceChild("shin_l", CubeListBuilder.create()
                .texOffs(356, 0).mirror().addBox(-10F, 0F, -10F, 19F, 24F, 19F).mirror(false)
                .texOffs(118, 192).mirror().addBox(-8F, -6F, -13F, 17F, 10F, 5F).mirror(false)
                .texOffs(0, 192).mirror().addBox(-7F, 7F, 10F, 14F, 12F, 4F).mirror(false),
                PartPose.offsetAndRotation(0F, 23F, 0F, 0F, 0F, 0F));
        PartDefinition p_foot_l = p_shin_l.addOrReplaceChild("foot_l", CubeListBuilder.create()
                .texOffs(348, 171).mirror().addBox(-6F, -1F, -6F, 12F, 5F, 12F).mirror(false)
                .texOffs(0, 70).mirror().addBox(-13F, 4F, -20F, 26F, 7F, 33F).mirror(false)
                .texOffs(0, 208).mirror().addBox(-12F, 6F, -21F, 24F, 4F, 1F).mirror(false),
                PartPose.offsetAndRotation(0F, 24F, 0F, 0F, 0F, 0F));
        PartDefinition p_torso = p_hips.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(166, 110).addBox(-15F, -12F, -10F, 29F, 12F, 20F)
                .texOffs(0, 0).addBox(-21F, -46F, -17F, 42F, 36F, 34F)
                .texOffs(152, 0).addBox(-26F, -42F, -13F, 53F, 29F, 27F)
                .texOffs(0, 110).addBox(-27F, -18F, -14F, 54F, 3F, 29F)
                .texOffs(0, 110).addBox(-27F, -32F, -14F, 54F, 3F, 29F)
                .texOffs(404, 192).addBox(-15F, -26F, -18F, 7F, 7F, 1F)
                .texOffs(428, 192).addBox(6F, -23F, -18F, 10F, 5F, 1F)
                .texOffs(0, 142).addBox(-16F, -44F, -12F, 32F, 5F, 24F)
                .texOffs(52, 192).addBox(-16F, -30F, 17F, 32F, 14F, 1F)
                .texOffs(280, 192).addBox(-5F, -36F, -19F, 10F, 10F, 2F)
                .texOffs(162, 192).addBox(-7F, -38F, -18F, 14F, 14F, 1F),
                PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition p_tspike_r0 = p_torso.addOrReplaceChild("tspike_r0", CubeListBuilder.create()
                .texOffs(36, 192).addBox(-2F, -12F, -2F, 4F, 12F, 4F),
                PartPose.offsetAndRotation(-24F, -43F, 5F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_r1 = p_torso.addOrReplaceChild("tspike_r1", CubeListBuilder.create()
                .texOffs(36, 192).addBox(-2F, -12F, -2F, 4F, 12F, 4F),
                PartPose.offsetAndRotation(-24F, -43F, 12F, 0.5F, 0F, -0.5F));
        PartDefinition p_tspike_l0 = p_torso.addOrReplaceChild("tspike_l0", CubeListBuilder.create()
                .texOffs(36, 192).addBox(-2F, -12F, -2F, 4F, 12F, 4F),
                PartPose.offsetAndRotation(24F, -43F, 5F, 0.5F, 0F, 0.5F));
        PartDefinition p_tspike_l1 = p_torso.addOrReplaceChild("tspike_l1", CubeListBuilder.create()
                .texOffs(36, 192).addBox(-2F, -12F, -2F, 4F, 12F, 4F),
                PartPose.offsetAndRotation(24F, -43F, 12F, 0.5F, 0F, 0.5F));
        PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(240, 192).addBox(-5F, -2F, -5F, 10F, 2F, 10F)
                .texOffs(288, 142).addBox(-8F, -12F, -7F, 17F, 10F, 14F)
                .texOffs(358, 192).addBox(-7F, -11F, -8F, 14F, 7F, 1F)
                .texOffs(50, 208).addBox(-7F, -9F, -9F, 4F, 4F, 1F)
                .texOffs(50, 208).addBox(-2F, -9F, -9F, 4F, 4F, 1F)
                .texOffs(50, 208).addBox(3F, -9F, -9F, 4F, 4F, 1F)
                .texOffs(228, 171).addBox(-9F, -13F, -8F, 18F, 1F, 16F),
                PartPose.offsetAndRotation(0F, -46F, -2F, 0F, 0F, 0F));
        PartDefinition p_shoulder_r = p_torso.addOrReplaceChild("shoulder_r", CubeListBuilder.create()
                .texOffs(350, 142).addBox(-6F, -6F, -6F, 12F, 12F, 12F)
                .texOffs(236, 70).addBox(-12F, -12F, -11F, 19F, 12F, 22F)
                .texOffs(118, 171).addBox(-11F, -13F, -10F, 17F, 1F, 19F)
                .texOffs(318, 70).addBox(-5F, 2F, -5F, 10F, 24F, 10F),
                PartPose.offsetAndRotation(-34F, -37F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_r = p_shoulder_r.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(186, 70).addBox(-6F, 0F, -7F, 12F, 22F, 13F)
                .texOffs(442, 171).addBox(-7F, 20F, -7F, 13F, 2F, 14F),
                PartPose.offsetAndRotation(0F, 25F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_r_bucket = p_forearm_r.addOrReplaceChild("forearm_r_bucket", CubeListBuilder.create()
                .texOffs(260, 142).addBox(-4F, -2F, -4F, 7F, 19F, 7F),
                PartPose.offsetAndRotation(0F, 25F, -2F, -0.4F, 0F, 0F));
        PartDefinition p_forearm_r_bucket_bk = p_forearm_r_bucket.addOrReplaceChild("forearm_r_bucket_bk", CubeListBuilder.create()
                .texOffs(358, 70).addBox(-12F, 0F, -14F, 24F, 14F, 19F)
                .texOffs(398, 142).addBox(-13F, -1F, -15F, 25F, 2F, 20F)
                .texOffs(420, 192).addBox(-10F, 13F, -14F, 2F, 5F, 2F)
                .texOffs(420, 192).addBox(-4F, 13F, -14F, 2F, 5F, 2F)
                .texOffs(420, 192).addBox(2F, 13F, -14F, 2F, 5F, 2F)
                .texOffs(420, 192).addBox(8F, 13F, -14F, 2F, 5F, 2F),
                PartPose.offsetAndRotation(0F, 17F, -2F, 0.6F, 0F, 0F));
        PartDefinition p_shoulder_l = p_torso.addOrReplaceChild("shoulder_l", CubeListBuilder.create()
                .texOffs(350, 142).mirror().addBox(-6F, -6F, -6F, 12F, 12F, 12F).mirror(false)
                .texOffs(236, 70).mirror().addBox(-7F, -12F, -11F, 19F, 12F, 22F).mirror(false)
                .texOffs(118, 171).mirror().addBox(-6F, -13F, -10F, 17F, 1F, 19F).mirror(false)
                .texOffs(318, 70).mirror().addBox(-5F, 2F, -5F, 10F, 24F, 10F).mirror(false),
                PartPose.offsetAndRotation(34F, -37F, 0F, 0F, 0F, 0F));
        PartDefinition p_forearm_l = p_shoulder_l.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(186, 70).mirror().addBox(-6F, 0F, -7F, 12F, 22F, 13F).mirror(false)
                .texOffs(442, 171).mirror().addBox(-7F, 20F, -7F, 13F, 2F, 14F).mirror(false),
                PartPose.offsetAndRotation(0F, 25F, 0F, -0.25F, 0F, 0F));
        PartDefinition p_forearm_l_flamer = p_forearm_l.addOrReplaceChild("forearm_l_flamer", CubeListBuilder.create()
                .texOffs(264, 110).addBox(-5F, -5F, -18F, 10F, 10F, 22F)
                .texOffs(48, 171).addBox(-4F, 5F, -7F, 7F, 7F, 14F)
                .texOffs(396, 171).addBox(-4F, 7F, -8F, 8F, 2F, 15F),
                PartPose.offsetAndRotation(0F, 28F, -2F, 0F, 0F, 0F));
        PartDefinition p_forearm_l_flamer_barrel = p_forearm_l_flamer.addOrReplaceChild("forearm_l_flamer_barrel", CubeListBuilder.create()
                .texOffs(190, 171).addBox(-2F, -2F, -14F, 5F, 5F, 14F)
                .texOffs(304, 192).addBox(-4F, -4F, -17F, 7F, 7F, 4F)
                .texOffs(60, 208).addBox(-1F, 3F, -17F, 2F, 1F, 2F),
                PartPose.offsetAndRotation(0F, -1F, -19F, 0F, 0F, 0F));
        PartDefinition p_exhaust = p_torso.addOrReplaceChild("exhaust", CubeListBuilder.create()
                .texOffs(312, 0).addBox(-5F, -36F, -5F, 11F, 38F, 11F)
                .texOffs(192, 192).addBox(-6F, -8F, -6F, 12F, 2F, 12F)
                .texOffs(192, 192).addBox(-6F, -28F, -6F, 12F, 2F, 12F)
                .texOffs(296, 171).addBox(-7F, -39F, -7F, 13F, 4F, 13F),
                PartPose.offsetAndRotation(13F, -46F, 24F, 0F, 0F, 0F));
        PartDefinition p_flame_exh = p_exhaust.addOrReplaceChild("flame_exh", CubeListBuilder.create()
                .texOffs(90, 171).addBox(-4F, 0F, -4F, 7F, 14F, 7F),
                PartPose.offsetAndRotation(0F, -38F, 0F, 3.1416F, 0F, 0F));
        PartDefinition p_stack_r = p_torso.addOrReplaceChild("stack_r", CubeListBuilder.create()
                .texOffs(112, 142).addBox(-4F, -20F, -4F, 7F, 22F, 7F)
                .texOffs(326, 192).addBox(-4F, -22F, -4F, 8F, 2F, 8F)
                .texOffs(450, 192).addBox(-2F, -23F, -2F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(-16F, -41F, 22F, -0.15F, 0F, 0.1F));
        PartDefinition p_stack_l = p_torso.addOrReplaceChild("stack_l", CubeListBuilder.create()
                .texOffs(112, 142).addBox(-4F, -20F, -4F, 7F, 22F, 7F)
                .texOffs(326, 192).addBox(-4F, -22F, -4F, 8F, 2F, 8F)
                .texOffs(450, 192).addBox(-2F, -23F, -2F, 5F, 1F, 5F),
                PartPose.offsetAndRotation(16F, -41F, 22F, -0.15F, 0F, -0.1F));
        return LayerDefinition.create(mesh, 512, 256);
    }

    public static Rig rig() {
        return new Rig(Rig.Arch.BIPED).parts("hips", "hips/torso", "hips/torso/head").walkRate(0.275F)
                .legLengths(11.4F, 12F)
                .leg("thigh_r", "thigh_r/shin_r", "thigh_r/shin_r/foot_r", -1, 0F, 0)
                .leg("thigh_l", "thigh_l/shin_l", "thigh_l/shin_l/foot_l", 1, 3.1416F, 0)
                .arm("hips/torso/shoulder_r", "hips/torso/shoulder_r/forearm_r", -1, false)
                .arm("hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l", 1, false)
                .flame("hips/torso/exhaust/flame_exh")
                .primary(Rig.MountKind.ARM, "hips/torso/shoulder_r", null, null, null)
                .secondary(Rig.MountKind.ARM, "hips/torso/shoulder_l", "hips/torso/shoulder_l/forearm_l/forearm_l_flamer/forearm_l_flamer_barrel", null, null);
    }
}
