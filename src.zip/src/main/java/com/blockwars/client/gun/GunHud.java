package com.blockwars.client.gun;

import com.blockwars.gun.AmmoType;
import com.blockwars.gun.Attachment;
import com.blockwars.gun.GunData;
import com.blockwars.gun.GunItem;
import com.blockwars.gun.GunSpec;
import com.blockwars.gun.AmmoItem;
import com.blockwars.network.GunFeedbackPayload;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;

/** Weapon HUD: ammo counter, reserve, ammo type, attachment, heat / charge / reload bars, dynamic crosshair, hit markers, scope. */
public final class GunHud {
    private GunHud() {}

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui) return;
        GunItem gun = GunClient.heldGun(p);
        if (gun == null) return;
        GunSpec spec = gun.spec;
        ItemStack s = p.getMainHandItem();
        Font font = mc.font;
        int w = g.guiWidth(), h = g.guiHeight();
        float pt = delta.getGameTimeDeltaPartialTick(true);
        long now = p.level().getGameTime();
        int cx = w / 2, cy = h / 2;

        // ---------------------------------------------------------- scope
        boolean scoped = GunClient.isScoped();
        if (scoped) {
            int r = Math.min(w, h) / 2 - 10;
            int dark = 0xF0000000;
            g.fill(0, 0, w, cy - r, dark);
            g.fill(0, cy + r, w, h, dark);
            g.fill(0, cy - r, cx - r, cy + r, dark);
            g.fill(cx + r, cy - r, w, cy + r, dark);
            // soften the corners of the lens with a stepped ring
            for (int y = -r; y < r; y += 2) {
                int half = (int) Math.sqrt(Math.max(0, r * r - y * y));
                g.fill(cx - r, cy + y, cx - half, cy + y + 2, dark);
                g.fill(cx + half, cy + y, cx + r, cy + y + 2, dark);
            }
            int col = 0xE0101010;
            g.fill(cx - r, cy, cx - 6, cy + 1, col);
            g.fill(cx + 6, cy, cx + r, cy + 1, col);
            g.fill(cx, cy - r, cx + 1, cy - 6, col);
            g.fill(cx, cy + 6, cx + 1, cy + r, col);
            for (int i = 1; i <= 4; i++) g.fill(cx - 3, cy + i * 14, cx + 4, cy + i * 14 + 1, col);
            g.fill(cx, cy, cx + 1, cy + 1, 0xFFFF3030);
        }

        // ---------------------------------------------------------- crosshair
        if (!scoped && mc.options.getCameraType().isFirstPerson()) {
            float ads = Mth.lerp(pt, GunClient.adsO, GunClient.ads);
            float bloom = Mth.lerp(pt, GunClient.spreadBloomO, GunClient.spreadBloom);
            float base = spec.kind == GunSpec.Kind.FLAME || spec.kind == GunSpec.Kind.FUSION ? 6 : 3 + spec.spread * 1.6F;
            int gap = Math.round(Mth.lerp(ads, base, 2 + spec.adsSpread * 2) + bloom * 10);
            int col = 0xDDFFFFFF;
            int len = 5;
            if (spec.pellets > 1) {
                // shotgun: a ring
                for (int i = 0; i < 16; i++) {
                    double a = i * Math.PI / 8;
                    int x = cx + (int) Math.round(Math.cos(a) * (gap + 3)), y = cy + (int) Math.round(Math.sin(a) * (gap + 3));
                    g.fill(x, y, x + 1, y + 1, col);
                }
            } else {
                g.fill(cx - gap - len, cy, cx - gap, cy + 1, col);
                g.fill(cx + gap + 1, cy, cx + gap + 1 + len, cy + 1, col);
                g.fill(cx, cy - gap - len, cx + 1, cy - gap, col);
                g.fill(cx, cy + gap + 1, cx + 1, cy + gap + 1 + len, col);
            }
            g.fill(cx, cy, cx + 1, cy + 1, 0xFFFFFFFF);
            // charge arc
            if (GunClient.holdingCharge()) {
                float c = GunClient.charge;
                int n = 24;
                for (int i = 0; i < n; i++) {
                    if (i / (float) n > Math.min(1.0F, c)) break;
                    double a = -Math.PI / 2 + i * Math.PI * 2 / n;
                    int x = cx + (int) Math.round(Math.cos(a) * 14), y = cy + (int) Math.round(Math.sin(a) * 14);
                    int cc = c > 1.0F ? ((now / 2) % 2 == 0 ? 0xFFFF2020 : 0xFFFFFFFF) : c >= 0.99F ? 0xFFFFFFFF : 0xFF000000 | spec.color;
                    g.fill(x, y, x + 2, y + 2, cc);
                }
            }
        }

        // ---------------------------------------------------------- hit marker
        if (GunClient.hitMarker > 0) {
            int k = GunClient.hitKind;
            int col = k == GunFeedbackPayload.KILL ? 0xFFFF3030 : k == GunFeedbackPayload.HEADSHOT ? 0xFFFFD040 : 0xFFFFFFFF;
            int r0 = 4, r1 = k == GunFeedbackPayload.KILL ? 11 : 8;
            for (int i = r0; i <= r1; i++) {
                g.fill(cx - i, cy - i, cx - i + 1, cy - i + 1, col);
                g.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, col);
                g.fill(cx - i, cy + i, cx - i + 1, cy + i + 1, col);
                g.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, col);
            }
        }

        // ---------------------------------------------------------- ammo panel (bottom right)
        int pw = 132;
        int x = w - pw - 10, y = h - 64;
        g.fill(x - 4, y - 4, x + pw + 4, y + 52, 0x99101418);
        g.fill(x - 4, y - 4, x + pw + 4, y - 3, spec.dangerous ? 0xFFFF3030 : 0xFFFFB040);
        g.drawString(font, s.getHoverName(), x, y, spec.dangerous ? 0xFFFF6060 : 0xFFF2E6D0, true);
        Attachment att = GunData.attachment(s);
        if (spec.usesAmmo()) {
            int ammo = GunData.ammo(s);
            int mag = spec.effectiveMag(att);
            AmmoType type = GunClient.loaded(s, spec);
            int reserve = countReserve(p, type) * (type.perMag ? spec.mag : 1);
            String big = String.valueOf(ammo);
            int ammoCol = ammo == 0 ? 0xFFFF4040 : ammo <= mag / 4 ? 0xFFFFC040 : 0xFFFFFFFF;
            g.pose().pushPose();
            g.pose().translate(x, y + 12, 0);
            g.pose().scale(2.0F, 2.0F, 1.0F);
            g.drawString(font, big, 0, 0, ammoCol, true);
            g.pose().popPose();
            g.drawString(font, "/ " + reserve, x + font.width(big) * 2 + 4, y + 19, 0xFFB0B8C0, true);
            // round pips
            int pips = Math.min(mag, 40);
            for (int i = 0; i < pips; i++) {
                boolean full = i < Math.round(ammo * pips / (float) mag);
                int px = x + 72 + (i % 20) * 3, py = y + 14 + (i / 20) * 6;
                g.fill(px, py, px + 2, py + 4, full ? 0xFF000000 | type.color : 0x55FFFFFF);
            }
            g.drawString(font, Component.translatable("item.blockwars." + type.itemId), x, y + 32, 0xFF000000 | type.color, true);
        } else {
            g.drawString(font, Component.translatable("hud.blockwars.no_ammo_needed"), x, y + 16, 0xFFB0D8FF, true);
        }
        // mode / attachment line
        Component modeLine = spec.modeToggle
                ? Component.translatable(GunData.mode(s) == 1 ? "hud.blockwars.mode_auto" : "hud.blockwars.mode_burst")
                : Component.translatable("hud.blockwars.fire." + spec.effectiveFire(GunData.mode(s), att).name().toLowerCase());
        if (att != null) modeLine = modeLine.copy().append(" · ").append(Component.translatable("item.blockwars." + att.itemId));
        g.drawString(font, modeLine, x, y + 42, 0xFF8FD18F, true);

        // ---------------------------------------------------------- bars above the panel
        int by = y - 12;
        float reload = GunData.reloadProgress(s, now);
        if (reload >= 0) {
            bar(g, font, x, by, pw, reload, 0xFF5AC8FA, Component.translatable("hud.blockwars.reloading"));
            by -= 14;
        }
        if (spec.usesHeat()) {
            float heat = GunData.heat(s, spec, now);
            boolean lock = GunData.locked(s);
            int hc = lock ? ((now / 3) % 2 == 0 ? 0xFFFF2020 : 0xFF801010) : heat < 0.6F ? 0xFFFFCC00 : heat < 0.85F ? 0xFFFF6B00 : 0xFFFF1A1A;
            bar(g, font, x, by, pw, heat, hc, Component.translatable(lock ? "hud.blockwars.overheated" : "hud.blockwars.gun_heat", Math.round(heat * 100)));
            by -= 14;
        }
        long melt = GunData.meltdown(s);
        if (melt > 0) {
            boolean blink = (now / 4) % 2 == 0;
            Component msg = Component.translatable("hud.blockwars.solaris_meltdown", String.format("%.1f", Math.max(0, melt - now) / 20.0F));
            int tw = font.width(msg);
            g.fill(cx - tw / 2 - 8, cy - 52, cx + tw / 2 + 8, cy - 36, blink ? 0xCCB00000 : 0xCC400000);
            g.drawString(font, msg, cx - tw / 2, cy - 48, 0xFFFFFFFF, true);
        }
        if (GunClient.holdingCharge() && spec.overcharge > 0 && GunClient.charge > 1.0F) {
            boolean blink = (now / 3) % 2 == 0;
            Component msg = Component.translatable("hud.blockwars.umbral_release");
            int tw = font.width(msg);
            g.fill(cx - tw / 2 - 8, cy + 30, cx + tw / 2 + 8, cy + 46, blink ? 0xCC6010B0 : 0xCC200040);
            g.drawString(font, msg, cx - tw / 2, cy + 34, 0xFFFFFFFF, true);
        }
    }

    private static int countReserve(LocalPlayer p, AmmoType type) {
        int n = 0;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack st = p.getInventory().getItem(i);
            if (st.getItem() instanceof AmmoItem ai && ai.type == type) n += st.getCount();
        }
        return n;
    }

    private static void bar(GuiGraphics g, Font font, int x, int y, int w, float frac, int color, Component label) {
        g.fill(x - 4, y - 2, x + w + 4, y + 12, 0x99101418);
        g.fill(x, y + 9, x + w, y + 11, 0xFF1C2228);
        g.fill(x, y + 9, x + Math.round(w * Mth.clamp(frac, 0, 1)), y + 11, color);
        g.drawString(font, label, x, y, 0xFFCFE3EE, true);
    }
}
