package com.blockwars.client.gun;

import com.blockwars.entity.GunBulletEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Bullets are drawn as glowing streaks stretched along their velocity, facing the camera. */
public class TracerRenderer extends EntityRenderer<GunBulletEntity> {
    public TracerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public void render(GunBulletEntity e, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        if (e.isHidden() || e.tickCount < 1) return;
        Vec3 v = e.getDeltaMovement();
        double speed = v.length();
        if (speed < 1e-3) return;
        Vec3 d = v.normalize();
        double len = Math.min(3.5, speed * 0.9);
        Vec3 cam = this.entityRenderDispatcher.camera.getPosition();
        Vec3 here = new Vec3(e.xo + (e.getX() - e.xo) * partialTick, e.yo + (e.getY() - e.yo) * partialTick, e.zo + (e.getZ() - e.zo) * partialTick);
        Vec3 toCam = cam.subtract(here);
        Vec3 side = d.cross(toCam);
        if (side.lengthSqr() < 1e-6) return;
        int c = e.getColor();
        float r = ((c >> 16) & 0xFF) / 255.0F, g = ((c >> 8) & 0xFF) / 255.0F, b = (c & 0xFF) / 255.0F;
        VertexConsumer vc = buffers.getBuffer(RenderType.lightning());
        Matrix4f m = pose.last().pose();
        // outer glow, then a hot white core
        float size = e.getSize();
        quad(vc, m, d, side.normalize().scale(0.045 * size), len * Math.min(1.5, 0.7 + size * 0.3), r, g, b, 0.55F);
        quad(vc, m, d, side.normalize().scale(0.016 * size), len * 0.8, 1.0F, 1.0F, 1.0F, 0.9F);
        if (size >= 2.0F) {
            // plasma bolts get a fat glowing head
            quad(vc, m, d, side.normalize().scale(0.09 * size), 0.35 * size, r, g, b, 0.8F);
        }
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Vec3 d, Vec3 side, double len, float r, float g, float b, float a) {
        Vec3 tail = d.scale(-len);
        float[][] pts = {
                {(float) side.x, (float) side.y, (float) side.z, a},
                {(float) -side.x, (float) -side.y, (float) -side.z, a},
                {(float) (tail.x - side.x * 0.2), (float) (tail.y - side.y * 0.2), (float) (tail.z - side.z * 0.2), 0.0F},
                {(float) (tail.x + side.x * 0.2), (float) (tail.y + side.y * 0.2), (float) (tail.z + side.z * 0.2), 0.0F}};
        // both windings so the streak is visible from either side
        for (int i = 0; i < 4; i++) vc.addVertex(m, pts[i][0], pts[i][1], pts[i][2]).setColor(r, g, b, pts[i][3]);
        for (int i = 3; i >= 0; i--) vc.addVertex(m, pts[i][0], pts[i][1], pts[i][2]).setColor(r, g, b, pts[i][3]);
    }

    @Override
    public boolean shouldRender(GunBulletEntity e, net.minecraft.client.renderer.culling.Frustum frustum, double x, double y, double z) {
        return true;
    }

    @Override
    public ResourceLocation getTextureLocation(GunBulletEntity e) {
        return InventoryMenu.BLOCK_ATLAS;
    }
}
