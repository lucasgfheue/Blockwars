package com.blockwars.client.gun;

import com.blockwars.ModParticles;
import com.blockwars.ModSounds;
import com.blockwars.entity.BaseMechaEntity;
import com.blockwars.gun.AmmoType;
import com.blockwars.gun.Attachment;
import com.blockwars.gun.GunData;
import com.blockwars.gun.GunItem;
import com.blockwars.gun.GunSpec;
import com.blockwars.mecha.WeaponSpec;
import com.blockwars.network.GunActionPayload;
import com.blockwars.network.GunFeedbackPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Everything that makes shooting feel right on the shooter's screen: input, predicted muzzle flash, brass, recoil
 * that climbs and partially recovers, camera shake, FOV punch, aim-down-sights, scope zoom and hit markers.
 */
public final class GunClient {
    private GunClient() {}

    // trigger / prediction
    private static boolean triggerSent;
    private static int hold;
    private static int localCooldown;
    private static int localBurst;
    private static int beamSoundTick;
    private static ItemStack lastStack = ItemStack.EMPTY;

    // feel
    public static float kick, kickO;            // weapon model kick (0..~2)
    public static float shake;                  // camera shake intensity
    private static float fovPunch, fovPunchO;
    private static float recover;               // pitch to give back after recoil
    public static float ads, adsO;              // aim-down-sights blend
    public static float charge;                 // 0..1 charge for HUD / model glow
    public static int hitMarker;                // ticks left
    public static int hitKind;
    public static float spreadBloom, spreadBloomO;
    private static long shakeTime;

    @org.jetbrains.annotations.Nullable
    public static GunItem heldGun(LocalPlayer p) {
        if (p == null || p.getVehicle() instanceof BaseMechaEntity || p.isSpectator()) return null;
        return p.getMainHandItem().getItem() instanceof GunItem g ? g : null;
    }

    private static void send(byte a) {
        PacketDistributor.sendToServer(new GunActionPayload(a));
    }

    // ================================================================= input

    /** Left click with a gun shoots instead of punching / mining. */
    public static void onClickInput(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        if (event.isAttack() && heldGun(mc.player) != null) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    /** R / G when not piloting a mecha. */
    public static void reloadKey() {
        if (heldGun(Minecraft.getInstance().player) != null) send(GunActionPayload.RELOAD);
    }

    public static void altKey() {
        if (heldGun(Minecraft.getInstance().player) != null) send(GunActionPayload.ALT);
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        kickO = kick;
        fovPunchO = fovPunch;
        adsO = ads;
        spreadBloomO = spreadBloom;
        kick *= 0.62F;
        fovPunch *= 0.7F;
        shake *= 0.78F;
        spreadBloom *= 0.85F;
        if (hitMarker > 0) hitMarker--;
        if (p == null) return;
        // recoil recovery: give back part of the climb
        if (recover > 0.01F) {
            float r = recover * 0.22F;
            p.setXRot(p.getXRot() + r);
            recover -= r;
        }
        GunItem gun = heldGun(p);
        boolean aiming = gun != null && p.isUsingItem() && p.getUseItem().getItem() == gun;
        ads += ((aiming ? 1.0F : 0.0F) - ads) * 0.32F;
        if (gun == null || mc.screen != null) {
            if (triggerSent) {
                send(GunActionPayload.TRIGGER_UP);
                triggerSent = false;
            }
            hold = 0;
            charge = 0;
            localBurst = 0;
            return;
        }
        ItemStack stack = p.getMainHandItem();
        if (stack != lastStack && lastStack.getItem() != stack.getItem()) {
            localCooldown = 0;
            localBurst = 0;
        }
        lastStack = stack;
        GunSpec spec = gun.spec;
        Attachment att = GunData.attachment(stack);
        GunSpec.Fire fire = spec.effectiveFire(GunData.mode(stack), att);
        boolean down = mc.options.keyAttack.isDown();
        if (localCooldown > 0) localCooldown--;

        if (down && !triggerSent) {
            triggerSent = true;
            hold = 0;
            send(GunActionPayload.TRIGGER_DOWN);
            if (fire == GunSpec.Fire.SEMI) predictShot(p, stack, spec, att, 1.0F);
            if (fire == GunSpec.Fire.BURST && localBurst <= 0) localBurst = spec.burst;
            if (fire == GunSpec.Fire.CHARGE && canPredict(p, stack, spec)) {
                p.level().playLocalSound(p.getX(), p.getEyeY(), p.getZ(), ModSounds.get("gun." + spec.id + ".special"), SoundSource.PLAYERS, 0.8F, 1.0F, false);
            }
        } else if (!down && triggerSent) {
            triggerSent = false;
            send(GunActionPayload.TRIGGER_UP);
            if (fire == GunSpec.Fire.CHARGE && hold >= spec.chargeMin && (spec.overcharge == 0 || hold < spec.overcharge)) {
                predictShot(p, stack, spec, att, Mth.clamp(hold / (float) spec.chargeFull, 0.0F, 1.0F));
            }
            hold = 0;
        }
        if (triggerSent) hold++;
        charge = fire == GunSpec.Fire.CHARGE && triggerSent ? Math.min(1.25F, hold / (float) spec.chargeFull) : 0.0F;
        if (fire == GunSpec.Fire.CHARGE && triggerSent && spec.overcharge > 0 && hold > spec.chargeFull) {
            // UMBRAL shakes harder and harder as the core destabilises
            shake = Math.max(shake, 0.4F + 2.0F * (hold - spec.chargeFull) / (float) (spec.overcharge - spec.chargeFull));
        }
        switch (fire) {
            case AUTO, BEAM -> {
                if (triggerSent && localCooldown <= 0) predictShot(p, stack, spec, att, 1.0F);
            }
            case BURST -> {
                if (localBurst > 0 && localCooldown <= 0) {
                    if (predictShot(p, stack, spec, att, 1.0F)) {
                        localBurst--;
                        if (localBurst == 0) localCooldown = spec.rate * 3;
                    } else {
                        localBurst = 0;
                    }
                }
            }
            default -> { }
        }
    }

    private static boolean canPredict(LocalPlayer p, ItemStack stack, GunSpec spec) {
        if (GunData.reloading(stack)) return false;
        if (spec.usesHeat() && GunData.locked(stack)) return false;
        return !spec.usesAmmo() || GunData.ammo(stack) > 0;
    }

    /** The shooter's own instant copy of the shot: sound, flash, brass, recoil. The server does the real work. */
    private static boolean predictShot(LocalPlayer p, ItemStack stack, GunSpec spec, Attachment att, float chargeFrac) {
        if (localCooldown > 0) return false;
        if (!canPredict(p, stack, spec)) {
            if (spec.usesAmmo() && GunData.ammo(stack) <= 0 && spec.fire != GunSpec.Fire.BEAM) {
                p.level().playLocalSound(p.getX(), p.getEyeY(), p.getZ(), ModSounds.get("gun.empty"), SoundSource.PLAYERS, 0.8F, 1.0F, false);
                localCooldown = 8;
            }
            return false;
        }
        localCooldown = spec.effectiveRate(att);
        RandomSource rnd = p.getRandom();
        boolean suppressed = att == Attachment.SUPPRESSOR;
        boolean beam = spec.fire == GunSpec.Fire.BEAM;
        float scale = spec.fire == GunSpec.Fire.CHARGE ? 0.35F + 0.65F * chargeFrac : 1.0F;
        float adsMul = 1.0F - 0.4F * ads;
        if (p.isCrouching()) adsMul *= 0.8F;

        // sound (beams retrigger their loop every few ticks)
        if (!beam || beamSoundTick-- <= 0) {
            float vol = suppressed ? 0.35F : 1.0F;
            float pitch = suppressed ? 1.5F : 0.95F + rnd.nextFloat() * 0.1F;
            p.level().playLocalSound(p.getX(), p.getEyeY(), p.getZ(), ModSounds.get("gun." + spec.id + ".fire"), SoundSource.PLAYERS, vol, pitch, false);
            beamSoundTick = 3;
        }

        // recoil: climb + random yaw, part of it recovers
        float climb = spec.recoil * scale * adsMul;
        p.setXRot(Mth.clamp(p.getXRot() - climb, -90.0F, 90.0F));
        p.setYRot(p.getYRot() + (rnd.nextFloat() - 0.5F) * 2.0F * spec.recoilYaw * scale * adsMul);
        recover += climb * (beam ? 0.0F : 0.45F);
        kick = Math.min(2.5F, kick + spec.kick * scale);
        shake = Math.min(4.0F, shake + spec.shake * scale * (beam ? 0.4F : 1.0F));
        fovPunch = Math.min(0.08F, fovPunch + 0.012F * spec.shake * scale);
        spreadBloom = Math.min(1.0F, spreadBloom + 0.12F + spec.recoil * 0.03F);
        shakeTime = p.level().getGameTime();

        // muzzle flash + smoke + brass, positioned on the first-person weapon
        Vec3 fwd = p.getLookAngle();
        Vec3 right = fwd.cross(new Vec3(0, 1, 0)).normalize();
        Vec3 up = right.cross(fwd).normalize();
        Vec3 eye = p.getEyePosition();
        float side = 0.24F * (1.0F - ads);
        Vec3 muzzle = eye.add(fwd.scale(0.95)).add(right.scale(side)).add(up.scale(-0.2F * (1.0F - ads) - 0.05F));
        if (!suppressed) {
            switch (spec.kind) {
                case BULLET, ROCKET -> {
                    p.level().addParticle(ModParticles.muzzle(spec.color), muzzle.x, muzzle.y, muzzle.z, 0, 0, 0);
                    for (int i = 0; i < 4; i++) {
                        Vec3 v = fwd.scale(0.15 + rnd.nextDouble() * 0.2).add(rnd.nextGaussian() * 0.04, rnd.nextGaussian() * 0.04, rnd.nextGaussian() * 0.04);
                        p.level().addParticle(ModParticles.of(WeaponSpec.PType.SPARK, spec.color), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                    }
                }
                case RAIL, TESLA, SINGULARITY -> {
                    p.level().addParticle(ModParticles.muzzle(spec.color), muzzle.x, muzzle.y, muzzle.z, 0, 0, 0);
                    for (int i = 0; i < 6; i++) {
                        double a = i * Math.PI / 3;
                        Vec3 v = right.scale(Math.cos(a) * 0.08).add(up.scale(Math.sin(a) * 0.08)).add(fwd.scale(0.05));
                        p.level().addParticle(ModParticles.of(WeaponSpec.PType.ORB, spec.color), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                    }
                }
                case FLAME -> {
                    for (int i = 0; i < 2; i++) {
                        Vec3 v = fwd.scale(0.5).add(rnd.nextGaussian() * 0.05, rnd.nextGaussian() * 0.05, rnd.nextGaussian() * 0.05);
                        p.level().addParticle(ParticleTypes.FLAME, muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                    }
                }
                case FUSION -> {
                    p.level().addParticle(ModParticles.muzzle(0xFFE080), muzzle.x, muzzle.y, muzzle.z, 0, 0, 0);
                    p.level().addParticle(ModParticles.of(WeaponSpec.PType.EMBER, spec.color), muzzle.x, muzzle.y, muzzle.z,
                            rnd.nextGaussian() * 0.03, 0.04, rnd.nextGaussian() * 0.03);
                }
            }
        }
        if (spec.kind == GunSpec.Kind.BULLET || spec.kind == GunSpec.Kind.ROCKET) {
            Vec3 v = fwd.scale(0.2);
            p.level().addParticle(ModParticles.of(WeaponSpec.PType.SMOKE, 0x9A9A9A), muzzle.x, muzzle.y, muzzle.z, v.x * 0.2, 0.02, v.z * 0.2);
        }
        if (spec.casings) {
            Vec3 port = eye.add(fwd.scale(0.55)).add(right.scale(0.22F * (1.0F - ads) + 0.05F)).add(up.scale(-0.12));
            Vec3 v = right.scale(0.11 + rnd.nextDouble() * 0.05).add(up.scale(0.12 + rnd.nextDouble() * 0.05)).add(fwd.scale(-0.03));
            p.level().addParticle(ModParticles.casing(spec.casingColor), port.x, port.y, port.z, v.x, v.y, v.z);
        }
        return true;
    }

    // ================================================================= server feedback

    public static void onFeedback(byte kind, float value) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (kind == GunFeedbackPayload.SHAKE) {
            shake = Math.min(5.0F, shake + value);
            fovPunch = Math.min(0.1F, fovPunch + value * 0.01F);
            return;
        }
        hitMarker = kind == GunFeedbackPayload.KILL ? 14 : 7;
        hitKind = kind;
        String sound = kind == GunFeedbackPayload.KILL ? "gun.kill" : kind == GunFeedbackPayload.HEADSHOT ? "gun.headshot" : "gun.hit";
        p.level().playLocalSound(p.getX(), p.getEyeY(), p.getZ(), ModSounds.get(sound), SoundSource.PLAYERS,
                kind == GunFeedbackPayload.HIT ? 0.45F : 0.8F, 1.0F, false);
    }

    // ================================================================= camera

    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (shake < 0.01F) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !mc.options.getCameraType().isFirstPerson() && shake < 0.5F) return;
        double t = (mc.player.tickCount + event.getPartialTick()) * 1.0;
        float s = shake;
        event.setPitch(event.getPitch() + (float) (Math.sin(t * 2.7) * 0.6 + Math.sin(t * 6.1) * 0.35) * s);
        event.setYaw(event.getYaw() + (float) (Math.cos(t * 3.3) * 0.45) * s);
        event.setRoll(event.getRoll() + (float) (Math.sin(t * 4.3) * 0.9) * s);
    }

    public static void onFov(ViewportEvent.ComputeFov event) {
        if (!event.usedConfiguredFov()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        float pt = (float) event.getPartialTick();
        double fov = event.getFOV();
        float a = Mth.lerp(pt, adsO, ads);
        GunItem gun = heldGun(p);
        if (gun != null && a > 0.01F) {
            boolean scope = GunData.attachment(p.getMainHandItem()) == Attachment.SCOPE;
            double zoom = scope ? 0.25 : 0.82;
            fov *= Mth.lerp(a, 1.0, zoom);
        }
        fov *= 1.0 + Mth.lerp(pt, fovPunchO, fovPunch);
        event.setFOV(fov);
    }

    /** Aiming down sights slows you less than drawing a bow. */
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (!(event.getEntity() instanceof LocalPlayer p)) return;
        GunItem gun = heldGun(p);
        if (gun != null && p.isUsingItem() && p.getUseItem().getItem() == gun && !p.isPassenger()) {
            event.getInput().leftImpulse = Mth.clamp(event.getInput().leftImpulse * 2.6F, -1.0F, 1.0F);
            event.getInput().forwardImpulse = Mth.clamp(event.getInput().forwardImpulse * 2.6F, -1.0F, 1.0F);
        }
    }

    /** Guns draw their own crosshair. */
    public static void onGuiLayer(RenderGuiLayerEvent.Pre event) {
        if (event.getName().equals(VanillaGuiLayers.CROSSHAIR) && heldGun(Minecraft.getInstance().player) != null) {
            event.setCanceled(true);
        }
    }

    public static boolean isScoped() {
        Minecraft mc = Minecraft.getInstance();
        GunItem gun = heldGun(mc.player);
        return gun != null && ads > 0.85F && GunData.attachment(mc.player.getMainHandItem()) == Attachment.SCOPE
                && mc.options.getCameraType().isFirstPerson();
    }

    public static boolean holdingCharge() {
        return triggerSent && charge > 0;
    }

    public static AmmoType loaded(ItemStack s, GunSpec spec) {
        AmmoType t = GunData.ammoType(s);
        return t != null ? t : AmmoType.defaultFor(spec.caliber);
    }

    public static boolean isLeftHand(InteractionHand hand) {
        return hand == InteractionHand.OFF_HAND;
    }
}
