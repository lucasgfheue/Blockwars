package com.blockwars.client.gun;

import com.blockwars.gun.GunData;
import com.blockwars.gun.GunItem;
import com.blockwars.gun.GunSpec;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

/**
 * First-person weapon placement: hip-fire position, aim-down-sights, recoil kick, reload dip, charge tremble.
 * Third person: both arms raised like a crossbow, so every gun is aimed where the player looks.
 */
public class GunItemExtensions implements IClientItemExtensions {
    @Override
    public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
        return hand == InteractionHand.MAIN_HAND ? HumanoidModel.ArmPose.CROSSBOW_HOLD : null;
    }

    @Override
    public boolean applyForgeHandTransform(PoseStack pose, LocalPlayer player, HumanoidArm arm, ItemStack stack, float partialTick,
                                           float equipProcess, float swingProcess) {
        if (!(stack.getItem() instanceof GunItem gun) || player.getMainHandItem() != stack) return false;
        GunSpec spec = gun.spec;
        int side = arm == HumanoidArm.RIGHT ? 1 : -1;
        float ads = Mth.lerp(partialTick, GunClient.adsO, GunClient.ads);
        float kick = Mth.lerp(partialTick, GunClient.kickO, GunClient.kick);
        float t = player.tickCount + partialTick;

        // hip -> sights
        float x = Mth.lerp(ads, 0.24F, 0.0F) * side;
        float y = Mth.lerp(ads, -0.24F, -0.05F);
        float z = Mth.lerp(ads, -0.62F, -0.55F);
        y -= equipProcess * 0.6F;
        // idle breathing (less when aiming)
        float breathe = 1.0F - 0.75F * ads;
        y += Mth.sin(t * 0.08F) * 0.006F * breathe;
        x += Mth.cos(t * 0.05F) * 0.004F * breathe;
        // recoil: back and up
        z += kick * 0.06F;
        y += kick * 0.012F;
        pose.translate(x, y, z);
        pose.mulPose(Axis.XP.rotationDegrees(kick * (5.0F - 2.5F * ads)));
        pose.mulPose(Axis.ZP.rotationDegrees(kick * 1.5F * side * (1.0F - ads)));

        // reload: tilt the weapon and dip it, then bring it back
        float reload = GunData.reloadProgress(stack, player.level().getGameTime());
        if (reload >= 0.0F && reload < 1.0F) {
            float r = Mth.sin(reload * Mth.PI);
            pose.translate(0.0F, -0.18F * r, 0.05F * r);
            pose.mulPose(Axis.ZP.rotationDegrees(-38.0F * r * side));
            pose.mulPose(Axis.XP.rotationDegrees(-16.0F * r));
            // magazine slap near the end
            if (reload > 0.7F) pose.translate(0.0F, Mth.sin((reload - 0.7F) * 30.0F) * 0.01F, 0.0F);
        }
        // charging weapons tremble, more so past full charge
        float c = GunClient.charge;
        if (c > 0.0F) {
            float amp = c > 1.0F ? 0.012F * (1.0F + (c - 1.0F) * 8.0F) : 0.003F * c;
            pose.translate(Mth.sin(t * 2.3F) * amp, Mth.cos(t * 2.9F) * amp, 0.0F);
        }
        // SOLARIS shakes when it is close to melting
        if (spec.usesHeat()) {
            float heat = GunData.heat(stack, spec, player.level().getGameTime());
            if (heat > 0.7F) {
                float amp = (heat - 0.7F) * 0.02F;
                pose.translate(Mth.sin(t * 3.1F) * amp, Mth.cos(t * 2.7F) * amp, 0.0F);
            }
        }
        return true;
    }
}
