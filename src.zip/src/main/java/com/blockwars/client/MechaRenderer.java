package com.blockwars.client;

import com.blockwars.BlockWars;
import com.blockwars.entity.MechaEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.resources.ResourceLocation;

public class MechaRenderer extends MobRenderer<MechaEntity, MechaModel> {
    private static final ResourceLocation TEXTURE = BlockWars.id("textures/entity/mecha.png");

    public MechaRenderer(EntityRendererProvider.Context context) {
        super(context, new MechaModel(context.bakeLayer(MechaModel.LAYER)), 1.3F);
    }

    @Override
    public ResourceLocation getTextureLocation(MechaEntity entity) {
        return TEXTURE;
    }

    /** The pilot doesn't see their own mecha in first person, so the cockpit view is clear. */
    @Override
    public boolean shouldRender(MechaEntity entity, Frustum frustum, double camX, double camY, double camZ) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && entity.hasPassenger(mc.player) && mc.options.getCameraType().isFirstPerson()) {
            return false;
        }
        return super.shouldRender(entity, frustum, camX, camY, camZ);
    }
}
