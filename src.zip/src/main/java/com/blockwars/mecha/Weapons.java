package com.blockwars.mecha;

import com.blockwars.ModParticles;
import com.blockwars.entity.BaseMechaEntity;
import com.blockwars.entity.GenericMechaEntity;
import com.blockwars.entity.MechaShotEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/** Executes every weapon kind for the generated mechas. All visuals are sent from the server so everyone sees them. */
public final class Weapons {
    private Weapons() {}

    public static ItemStack itemStack(String id) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null) return new ItemStack(Items.IRON_NUGGET);
        ItemStack s = new ItemStack(BuiltInRegistries.ITEM.get(rl));
        return s.isEmpty() ? new ItemStack(Items.IRON_NUGGET) : s;
    }

    // ================================================================= server

    public static void serverTick(GenericMechaEntity m, Player pilot, WeaponSpec w, int t, boolean primary) {
        if (!(m.level() instanceof ServerLevel level)) return;
        if (t == 0 && w.charge) {
            m.playShared("charge", 1.2F, 1.0F);
        }
        if (w.kind == WeaponSpec.Kind.MOVE && t > w.windup) {
            moveTick(level, m, pilot, w, t);
        }
        if (w.charge && t < w.windup) {
            Vec3 mz = muzzle(m, w, 0);
            level.sendParticles(ModParticles.of(w.particle, w.color), mz.x, mz.y, mz.z, 3, 0.15, 0.15, 0.15, 0.02);
        }
        int k = w.eventIndex(t);
        if (k < 0) return;
        boolean continuous = w.interval == 1 && w.count > 3;
        if (!continuous || k % 8 == 0) {
            m.playSlot(primary ? "primary" : "secondary", continuous ? 1.0F : 1.2F, 1.0F);
        }
        Vec3 aim = pilot.getLookAngle();
        Vec3 mz = muzzle(m, w, k);
        switch (w.kind) {
            case PROJECTILE -> projectile(level, m, pilot, w, mz, aim);
            case BEAM -> beam(level, m, pilot, w, mz, aim, k);
            case CONE -> cone(level, m, pilot, w, mz, aim);
            case AREA -> area(level, m, pilot, w, k);
            case MELEE -> melee(level, m, pilot, w);
            case MOVE -> moveStart(level, m, pilot, w);
            case LIGHTNING -> lightning(level, m, pilot, w);
            case CHAIN -> chain(level, m, pilot, w, mz, aim);
            case DRILL -> drill(level, m, pilot, w, k);
            case REWIND -> rewind(level, m, w);
            case SINGULARITY -> m.startSingularity(aimPoint(level, pilot, w.range), w.radius, w.power, 140, pilot);
            case VENT -> vent(level, m, pilot, w);
        }
        if (w.heat > 0) m.addHeat(w.heat);
        m.markAttack();
    }

    /** Muzzle position for event k (twin weapons alternate barrels). */
    public static Vec3 muzzle(BaseMechaEntity m, WeaponSpec w, int k) {
        if (w.hasMuzzle2 && k % 2 == 1) return m.localPoint(w.mr2, w.mu2, w.mf2);
        return m.localPoint(w.mr, w.mu, w.mf);
    }

    public static Vec3 aimPoint(Level level, Player pilot, float range) {
        Vec3 from = pilot.getEyePosition();
        Vec3 to = from.add(pilot.getLookAngle().scale(Math.max(4.0F, range)));
        BlockHitResult hit = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, pilot));
        return hit.getType() == HitResult.Type.MISS ? to : hit.getLocation();
    }

    private static boolean griefing(Level level) {
        return level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
    }

    private static boolean valid(GenericMechaEntity m, Player pilot, Entity e) {
        return e != m && e != pilot && e.isAlive() && e.getVehicle() != m && !(e instanceof Player p && (p.isCreative() || p.isSpectator()) && p == pilot);
    }

    @Nullable
    public static Entity findTarget(Entity from, @Nullable Entity owner, @Nullable Entity mecha, double range, double minDot) {
        Vec3 dir = from.getDeltaMovement().lengthSqr() > 1e-4 ? from.getDeltaMovement().normalize() : new Vec3(0, 0, 1);
        Entity best = null;
        double bestScore = -1;
        for (LivingEntity e : from.level().getEntitiesOfClass(LivingEntity.class, from.getBoundingBox().inflate(range),
                e -> e != owner && e != mecha && e.isAlive() && (mecha == null || e.getVehicle() != mecha) && !(e instanceof Player p && p.isSpectator()))) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(from.position());
            double d = to.length();
            if (d > range || d < 0.5) continue;
            double dot = to.normalize().dot(dir);
            if (dot < minDot) continue;
            double score = dot * 2 - d / range;
            if (score > bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    /** Apply damage + effects of a weapon to one target. */
    public static void hit(GenericMechaEntity m, Player pilot, WeaponSpec w, LivingEntity e, float damage, Vec3 from, @Nullable Entity direct) {
        if (damage > 0) {
            boolean hurt = e.hurt(direct != null ? m.damageSources().thrown(direct, pilot) : m.damageSources().playerAttack(pilot), damage);
            if (hurt && m.spec.has(Passive.LIFESTEAL)) {
                m.heal(damage * 0.3F);
            }
        }
        if (w.fire > 0) e.igniteForSeconds(w.fire);
        if (w.extinguish) e.clearFire();
        applyFx(e, w.fx, w.fxTime, w.fxAmp);
        applyFx(e, w.fx2, w.fxTime, 0);
        if (w.knockback > 0) {
            Vec3 d = e.position().subtract(from).multiply(1, 0, 1);
            if (d.lengthSqr() < 1e-4) d = m.forward();
            d = d.normalize();
            e.knockback(w.knockback, -d.x, -d.z);
            e.hurtMarked = true;
        }
        if (w.pull > 0) {
            Vec3 d = m.position().add(0, 1, 0).subtract(e.position()).normalize().scale(w.pull);
            e.setDeltaMovement(e.getDeltaMovement().add(d));
            e.hurtMarked = true;
        }
    }

    public static void applyFx(LivingEntity e, WeaponSpec.Fx fx, int time, int amp) {
        switch (fx) {
            case POISON -> e.addEffect(new MobEffectInstance(MobEffects.POISON, time, amp));
            case WITHER -> e.addEffect(new MobEffectInstance(MobEffects.WITHER, time, amp));
            case SLOW -> e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, time, amp));
            case FREEZE -> {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, time, amp + 1));
                e.setTicksFrozen(Math.min(e.getTicksRequiredToFreeze() + 60, e.getTicksFrozen() + 12));
            }
            case WEAKNESS -> e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, time, amp));
            case BLIND -> e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, time, amp));
            case NAUSEA -> e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, Math.max(time, 100), 0));
            case GLOW -> e.addEffect(new MobEffectInstance(MobEffects.GLOWING, time, 0));
            case ROOT -> {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, time, 9));
                e.addEffect(new MobEffectInstance(MobEffects.JUMP, time, 128));
            }
            case TIME_SLOW -> {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, time, amp));
                e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, time, amp));
            }
            default -> { }
        }
    }

    private static void burst(ServerLevel level, ParticleOptions p, Vec3 at, int n, double spread, double speed) {
        level.sendParticles(p, at.x, at.y, at.z, n, spread, spread, spread, speed);
    }

    // ----------------------------------------------------------------- PROJECTILE
    private static void projectile(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w, Vec3 mz, Vec3 aim) {
        Entity target = w.homing ? findTarget(pilot, pilot, m, 40.0, 0.5) : null;
        for (int i = 0; i < w.pellets; i++) {
            MechaShotEntity shot = new MechaShotEntity(level, pilot, m, w);
            shot.setPos(mz.x, mz.y, mz.z);
            Vec3 d = aim.add(0, w.lob, 0);
            shot.shoot(d.x, d.y, d.z, w.speed, w.spread);
            shot.setTarget(target);
            level.addFreshEntity(shot);
        }
        burst(level, ModParticles.of(w.particle, w.color), mz, 6, 0.12, 0.08);
        level.sendParticles(ParticleTypes.SMOKE, mz.x, mz.y, mz.z, 3, 0.1, 0.1, 0.1, 0.02);
    }

    /** Called by MechaShotEntity when it lands. */
    public static void impact(@Nullable GenericMechaEntity m, @Nullable Player pilot, WeaponSpec w, Vec3 at, Entity shot) {
        if (!(shot.level() instanceof ServerLevel level)) return;
        burst(level, ModParticles.of(w.particle, w.color), at, 10, 0.25, 0.15);
        if (w.power > 0) {
            level.explode(shot, at.x, at.y, at.z, w.power, w.setsFire, Level.ExplosionInteraction.MOB);
        }
        if (w.setsFire && griefing(level)) {
            BlockPos p = BlockPos.containing(at);
            if (level.getBlockState(p).isAir() && level.getBlockState(p.below()).isFaceSturdy(level, p.below(), Direction.UP)) {
                level.setBlockAndUpdate(p, Blocks.FIRE.defaultBlockState());
            }
        }
    }

    // ----------------------------------------------------------------- BEAM
    private static void beam(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w, Vec3 from, Vec3 aim, int k) {
        Vec3 to = from.add(aim.scale(w.range));
        BlockHitResult bh = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, pilot));
        Vec3 end = bh.getType() == HitResult.Type.MISS ? to : bh.getLocation();
        List<LivingEntity> hits = new ArrayList<>();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(from, end).inflate(1.0), e -> valid(m, pilot, e))) {
            Optional<Vec3> c = e.getBoundingBox().inflate(0.35).clip(from, end);
            if (c.isPresent()) hits.add(e);
        }
        hits.sort(Comparator.comparingDouble(e -> e.distanceToSqr(from)));
        if (!w.pierce && !hits.isEmpty()) {
            LivingEntity first = hits.get(0);
            hits = List.of(first);
            end = first.getBoundingBox().getCenter();
        }
        for (LivingEntity e : hits) hit(m, pilot, w, e, w.damage, from, null);
        // visuals: a dense line of particles from muzzle to end
        Vec3 d = end.subtract(from);
        double len = d.length();
        Vec3 step = d.normalize().scale(0.4);
        ParticleOptions core = ModParticles.of(w.particle, w.color2);
        ParticleOptions glow = ModParticles.of(w.particle, w.color);
        Vec3 p = from;
        for (double s = 0; s < len; s += 0.4) {
            level.sendParticles(glow, p.x, p.y, p.z, 1, 0.04, 0.04, 0.04, 0.0);
            if (((int) (s / 0.4)) % 2 == 0) level.sendParticles(core, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
            p = p.add(step);
        }
        burst(level, glow, end, 8, 0.2, 0.12);
        if (w.setsFire && griefing(level) && bh.getType() != HitResult.Type.MISS && k % 4 == 0) {
            BlockPos fp = bh.getBlockPos().relative(bh.getDirection());
            if (level.getBlockState(fp).isAir()) level.setBlockAndUpdate(fp, Blocks.FIRE.defaultBlockState());
        }
    }

    // ----------------------------------------------------------------- CONE
    private static void cone(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w, Vec3 from, Vec3 aim) {
        double cos = Math.cos(Math.toRadians(w.angle));
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(w.range), e -> valid(m, pilot, e))) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(from);
            if (to.length() > w.range || to.normalize().dot(aim) < cos) continue;
            hit(m, pilot, w, e, w.damage, from, null);
        }
        ParticleOptions po = ModParticles.of(w.particle, w.color);
        for (int i = 0; i < 10; i++) {
            Vec3 v = aim.add(level.random.nextGaussian() * w.angle / 140.0, level.random.nextGaussian() * w.angle / 140.0, level.random.nextGaussian() * w.angle / 140.0)
                    .normalize().scale(w.range / 14.0 + level.random.nextDouble() * 0.3);
            level.sendParticles(po, from.x, from.y, from.z, 0, v.x, v.y, v.z, 1.0);
        }
        if (w.particle == WeaponSpec.PType.EMBER) {
            level.sendParticles(ParticleTypes.FLAME, from.x, from.y, from.z, 0, aim.x * 0.6, aim.y * 0.6, aim.z * 0.6, 1.0);
        }
        if (w.extinguish) {
            BlockHitResult bh = level.clip(new ClipContext(from, from.add(aim.scale(w.range)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, pilot));
            BlockPos bp = bh.getBlockPos().relative(bh.getDirection());
            if (level.getBlockState(bp).is(Blocks.FIRE)) level.removeBlock(bp, false);
        }
        if (w.fire > 0 && griefing(level) && level.random.nextInt(4) == 0) {
            BlockHitResult bh = level.clip(new ClipContext(from, from.add(aim.scale(w.range)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, pilot));
            if (bh.getType() != HitResult.Type.MISS) {
                BlockPos fp = bh.getBlockPos().relative(bh.getDirection());
                if (level.getBlockState(fp).isAir()) level.setBlockAndUpdate(fp, Blocks.FIRE.defaultBlockState());
            }
        }
    }

    // ----------------------------------------------------------------- AREA
    private static Vec3 areaCenter(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w) {
        return switch (w.center) {
            case SELF -> m.position().add(0, 0.5, 0);
            case FRONT -> m.localPoint(0, 0.5, 2.6);
            case AIM -> aimPoint(level, pilot, w.range);
        };
    }

    private static void area(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w, int k) {
        Vec3 c = areaCenter(level, m, pilot, w);
        float r = w.ring ? w.radius * (0.45F + 0.55F * (k + 1) / Math.max(1, w.count)) : w.radius;
        ParticleOptions po = ModParticles.of(w.particle, w.color);
        // ring visuals
        int n = (int) (r * 10);
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            double x = c.x + Math.cos(a) * r, z = c.z + Math.sin(a) * r;
            if (w.upward) {
                level.sendParticles(po, x, c.y, z, 0, 0, 0.5 + level.random.nextDouble() * 0.4, 0, 1.0);
            } else {
                level.sendParticles(po, x, c.y + 0.1, z, 0, Math.cos(a) * 0.15, 0.05, Math.sin(a) * 0.15, 1.0);
            }
        }
        level.sendParticles(po, c.x, c.y + 0.5, c.z, (int) (r * 6), r * 0.4, 0.6, r * 0.4, 0.02);
        if (w.shake) {
            BlockState below = level.getBlockState(BlockPos.containing(c).below());
            if (!below.isAir()) level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, below), c.x, c.y, c.z, 40, r * 0.5, 0.1, r * 0.5, 0.2);
        }
        switch (w.fx) {
            case HEAL -> {
                m.heal(w.heal);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(w.radius),
                        e -> e != m && (e instanceof Player || e instanceof BaseMechaEntity))) {
                    e.heal(w.heal * 0.5F);
                    level.sendParticles(ParticleTypes.HEART, e.getX(), e.getY() + e.getBbHeight(), e.getZ(), 2, 0.3, 0.2, 0.3, 0);
                }
                return;
            }
            case SHIELD -> {
                m.shieldTicks = w.fxTime;
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(w.radius),
                        e -> e != m && (e instanceof Player || e instanceof BaseMechaEntity))) {
                    if (e instanceof GenericMechaEntity g) g.shieldTicks = Math.max(g.shieldTicks, w.fxTime / 2);
                    else e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, w.fxTime, 2));
                }
                return;
            }
            case SMOKE_STEALTH -> {
                m.invisTicks = w.fxTime;
                level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, c.x, c.y + 1, c.z, 40, r * 0.5, 1.0, r * 0.5, 0.01);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(w.radius), e -> valid(m, pilot, e))) {
                    applyFx(e, WeaponSpec.Fx.BLIND, 100, 0);
                }
                return;
            }
            case TIME_SLOW -> {
                for (Entity e : level.getEntities(m, new AABB(c, c).inflate(w.radius), e -> e instanceof Projectile && ((Projectile) e).getOwner() != pilot)) {
                    e.setDeltaMovement(e.getDeltaMovement().scale(0.35));
                    e.hurtMarked = true;
                }
            }
            default -> { }
        }
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r + 0.5), e -> valid(m, pilot, e))) {
            if (e.position().distanceTo(c) > r + 0.8) continue;
            hit(m, pilot, w, e, w.damage, c, null);
            if (w.upward) {
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.55, 0));
                e.hurtMarked = true;
            }
        }
        if (w.setsFire && griefing(level)) {
            for (int i = 0; i < 6; i++) {
                double a = level.random.nextDouble() * Math.PI * 2;
                int x = (int) Math.floor(c.x + Math.cos(a) * r), z = (int) Math.floor(c.z + Math.sin(a) * r);
                BlockPos p = new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z), z);
                if (level.getBlockState(p).isAir() && level.getBlockState(p.below()).isFaceSturdy(level, p.below(), Direction.UP)) {
                    level.setBlockAndUpdate(p, Blocks.FIRE.defaultBlockState());
                }
            }
        }
    }

    // ----------------------------------------------------------------- MELEE
    private static void melee(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w) {
        Vec3 fwd = m.forward();
        double cos = Math.cos(Math.toRadians(Math.min(180, w.angle / 2)));
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(w.range, 1.5, w.range), e -> valid(m, pilot, e))) {
            Vec3 to = e.position().subtract(m.position()).multiply(1, 0, 1);
            double d = to.length();
            if (d > w.range + m.getBbWidth() / 2) continue;
            if (w.angle < 360 && d > 0.5 && to.normalize().dot(fwd) < cos) continue;
            hit(m, pilot, w, e, w.damage, m.position(), null);
        }
        ParticleOptions po = ModParticles.of(w.particle, w.color);
        int arcs = w.angle >= 360 ? 16 : 8;
        for (int i = 0; i < arcs; i++) {
            double a = Math.toRadians(-w.angle / 2 + w.angle * i / (arcs - 1.0)) + Math.atan2(fwd.z, fwd.x);
            double rr = w.range * 0.8;
            Vec3 p = m.position().add(Math.cos(a) * rr, 1.6, Math.sin(a) * rr);
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            level.sendParticles(po, p.x, p.y, p.z, 2, 0.2, 0.2, 0.2, 0.05);
        }
    }

    // ----------------------------------------------------------------- MOVE (dash / blink / pounce)
    private static void moveStart(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w) {
        Vec3 dir = w.blink ? pilot.getLookAngle().multiply(1, 0.3, 1).normalize() : m.forward();
        m.setDeltaMovement(dir.scale(w.speed).add(0, w.up, 0));
        m.hurtMarked = true;
        m.moveHits.clear();
        m.moveLanded = !w.land;
        if (w.blink) {
            m.invisTicks = Math.max(m.invisTicks, 6);
            burst(level, ModParticles.of(w.particle, w.color), m.position().add(0, 1.5, 0), 40, 0.6, 0.2);
        }
    }

    private static void moveTick(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w, int t) {
        ParticleOptions po = ModParticles.of(w.particle, w.color);
        level.sendParticles(po, m.getX(), m.getY() + m.getBbHeight() * 0.5, m.getZ(), w.blink ? 12 : 4, m.getBbWidth() * 0.4, m.getBbHeight() * 0.3, m.getBbWidth() * 0.4, 0.02);
        if (!w.contact || w.damage <= 0) return;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(1.0), e -> valid(m, pilot, e))) {
            if (m.moveHits.add(e.getId())) {
                hit(m, pilot, w, e, w.damage, m.position(), null);
                Vec3 f = m.forward();
                e.knockback(Math.max(1.0, w.knockback), -f.x, -f.z);
                e.hurtMarked = true;
            }
        }
    }

    public static void landing(GenericMechaEntity m, Player pilot, WeaponSpec w) {
        if (!(m.level() instanceof ServerLevel level) || w.radius <= 0) return;
        m.playSlot("step", 2.0F, 0.6F);
        Vec3 c = m.position();
        BlockState below = level.getBlockState(m.blockPosition().below());
        if (!below.isAir()) level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, below), c.x, c.y + 0.1, c.z, 50, w.radius * 0.4, 0.1, w.radius * 0.4, 0.2);
        burst(level, ModParticles.of(w.particle, w.color), c.add(0, 0.3, 0), 30, w.radius * 0.4, 0.1);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(w.radius, 1, w.radius), e -> valid(m, pilot, e))) {
            if (e.position().distanceTo(c) > w.radius + 0.5) continue;
            hit(m, pilot, w, e, w.damage, c, null);
        }
    }

    // ----------------------------------------------------------------- LIGHTNING
    private static void lightning(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w) {
        Vec3 c;
        if (w.around) {
            double a = level.random.nextDouble() * Math.PI * 2, d = 4 + level.random.nextDouble() * (w.radius - 4);
            c = m.position().add(Math.cos(a) * d, 0, Math.sin(a) * d);
        } else {
            c = aimPoint(level, pilot, w.range);
        }
        int x = (int) Math.floor(c.x), z = (int) Math.floor(c.z);
        int y = w.around ? level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) : (int) Math.floor(c.y);
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(x + 0.5, y, z + 0.5);
            if (pilot instanceof ServerPlayer sp) bolt.setCause(sp);
            level.addFreshEntity(bolt);
        }
        burst(level, ModParticles.of(w.particle, w.color), new Vec3(x + 0.5, y + 0.5, z + 0.5), 30, 0.8, 0.3);
    }

    // ----------------------------------------------------------------- CHAIN
    private static void chain(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w, Vec3 from, Vec3 aim) {
        Set<Integer> seen = new HashSet<>();
        Vec3 last = from;
        LivingEntity cur = null;
        double best = -1;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(w.range), e -> valid(m, pilot, e))) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(from);
            double d = to.length();
            if (d > w.range) continue;
            double dot = to.normalize().dot(aim);
            if (dot < 0.8) continue;
            double score = dot - d / (w.range * 4);
            if (score > best) { best = score; cur = e; }
        }
        if (cur == null) {
            arc(level, w, from, from.add(aim.scale(Math.min(8, w.range))));
            return;
        }
        for (int j = 0; j <= w.jumps && cur != null; j++) {
            seen.add(cur.getId());
            Vec3 at = cur.getBoundingBox().getCenter();
            arc(level, w, last, at);
            hit(m, pilot, w, cur, w.damage * (j == 0 ? 1.0F : 0.75F), last, null);
            last = at;
            LivingEntity next = null;
            double nd = 8.0;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, cur.getBoundingBox().inflate(8.0), e -> valid(m, pilot, e) && !seen.contains(e.getId()))) {
                double d = e.distanceTo(cur);
                if (d < nd) { nd = d; next = e; }
            }
            cur = next;
        }
    }

    /** jagged electric arc between two points */
    private static void arc(ServerLevel level, WeaponSpec w, Vec3 a, Vec3 b) {
        ParticleOptions po = ModParticles.of(w.particle, w.color);
        ParticleOptions white = ModParticles.of(WeaponSpec.PType.SPARK, 0xFFFFFF);
        Vec3 d = b.subtract(a);
        int n = Math.max(4, (int) (d.length() * 3));
        Vec3 prev = a;
        for (int i = 1; i <= n; i++) {
            Vec3 p = a.add(d.scale(i / (double) n));
            if (i < n) p = p.add(level.random.nextGaussian() * 0.25, level.random.nextGaussian() * 0.25, level.random.nextGaussian() * 0.25);
            Vec3 seg = p.subtract(prev);
            for (int s = 0; s < 3; s++) {
                Vec3 q = prev.add(seg.scale(s / 3.0));
                level.sendParticles(s == 0 ? white : po, q.x, q.y, q.z, 1, 0, 0, 0, 0);
            }
            prev = p;
        }
    }

    // ----------------------------------------------------------------- DRILL
    private static void drill(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w, int k) {
        Vec3 fwd = m.forward();
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
        double dist = m.getBbWidth() / 2 + 0.8 + k * 0.9;
        Vec3 c = m.position().add(fwd.scale(dist));
        int rad = Math.max(1, (int) w.radius);
        for (int dx = -rad; dx <= rad; dx++) {
            for (int dy = 0; dy <= 2 * rad; dy++) {
                Vec3 p = c.add(right.scale(dx)).add(0, dy + 0.5, 0);
                BlockPos bp = BlockPos.containing(p);
                BlockState st = level.getBlockState(bp);
                if (st.isAir() || st.getDestroySpeed(level, bp) < 0 || st.getDestroySpeed(level, bp) > 50) continue;
                if (!level.mayInteract(pilot, bp)) continue;
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5, 8, 0.3, 0.3, 0.3, 0.1);
                level.destroyBlock(bp, true, pilot);
            }
        }
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(1.5, 2, 1.5), e -> valid(m, pilot, e))) {
            hit(m, pilot, w, e, w.damage, m.position(), null);
        }
        burst(level, ModParticles.of(w.particle, w.color), c.add(0, 1, 0), 10, 0.5, 0.1);
        level.sendParticles(ParticleTypes.CRIT, c.x, c.y + 1, c.z, 8, 0.4, 0.4, 0.4, 0.3);
    }

    // ----------------------------------------------------------------- REWIND
    private static void rewind(ServerLevel level, GenericMechaEntity m, WeaponSpec w) {
        float past = m.pastHealth(100);
        if (past > m.getHealth()) m.setHealth(past);
        m.clearFire();
        m.removeAllEffects();
        for (int i = 0; i < 60; i++) {
            double a = i * 0.35, h = i * 0.06;
            double r = 2.0 - i * 0.02;
            level.sendParticles(ModParticles.of(WeaponSpec.PType.SHARD, i % 2 == 0 ? w.color : 0xFFFFFF),
                    m.getX() + Math.cos(a) * r, m.getY() + 3.5 - h, m.getZ() + Math.sin(a) * r, 0, -Math.cos(a) * 0.05, -0.05, -Math.sin(a) * 0.05, 1.0);
        }
        if (m.getControllingPassenger() instanceof Player p) {
            p.displayClientMessage(Component.translatable("message.blockwars.rewind"), true);
        }
    }

    // ----------------------------------------------------------------- VENT (HELIOS)
    private static void vent(ServerLevel level, GenericMechaEntity m, Player pilot, WeaponSpec w) {
        float heat = Math.max(0.0F, m.getHeatFraction());
        m.ventHeat();
        Vec3 c = m.position().add(0, 1.5, 0);
        float r = w.radius * (0.6F + heat * 0.8F);
        for (int i = 0; i < 80; i++) {
            double a = level.random.nextDouble() * Math.PI * 2, b = (level.random.nextDouble() - 0.5) * 1.2;
            level.sendParticles(ModParticles.of(WeaponSpec.PType.EMBER, i % 3 == 0 ? 0xFFFFFF : w.color), c.x, c.y, c.z, 0,
                    Math.cos(a) * r * 0.08, b * 0.4, Math.sin(a) * r * 0.08, 1.0);
        }
        level.sendParticles(ParticleTypes.LARGE_SMOKE, c.x, c.y + 1, c.z, 30, 1.0, 1.0, 1.0, 0.1);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r), e -> valid(m, pilot, e))) {
            if (e.position().distanceTo(c) > r) continue;
            hit(m, pilot, w, e, w.damage * (0.5F + heat), c, null);
        }
    }

    // ================================================================= client-side extras

    public static void clientTick(GenericMechaEntity m, WeaponSpec w, int t, boolean primary) {
        Level level = m.level();
        // charge glow at the muzzle before the shot
        if (t < w.windup && (w.charge || w.kind == WeaponSpec.Kind.BEAM || w.anim == WeaponSpec.Anim.CAST)) {
            Vec3 mz = muzzle(m, w, 0);
            for (int i = 0; i < 2; i++) {
                double a = m.getRandom().nextDouble() * Math.PI * 2;
                level.addParticle(ModParticles.of(w.particle, w.color), mz.x + Math.cos(a) * 0.6, mz.y + (m.getRandom().nextDouble() - 0.5) * 0.6,
                        mz.z + Math.sin(a) * 0.6, -Math.cos(a) * 0.06, 0, -Math.sin(a) * 0.06);
            }
        }
        int k = w.eventIndex(t);
        if (k >= 0 && w.kind == WeaponSpec.Kind.PROJECTILE) {
            Vec3 mz = muzzle(m, w, k);
            level.addParticle(ParticleTypes.FLASH, mz.x, mz.y, mz.z, 0, 0, 0);
        }
    }
}
