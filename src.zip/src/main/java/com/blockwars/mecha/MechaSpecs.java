package com.blockwars.mecha;

import java.util.List;

/** Generated: the 80 BlockWars mechas (stats, weapons, passives, muzzle positions). */
public final class MechaSpecs {
    private MechaSpecs() {}

    private static MechaSpec baluarte() {
        return new MechaSpec("baluarte")
                .stats(230F, 20F, 6F, 0.21F, 0.6F)
                .size(2.05F, 3.56F, 2.19F, 1.23F)
                .glow(0xFFAA3C)
                .lore(3)
                .passives(Passive.FRONT_SHIELD, Passive.BRACED)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.baluarte.primary").anim(WeaponSpec.Anim.AIM).timing(26, 12, 4, 1, 1).pellets(7).dmg(3.5F).speed(2.6F).spread(9F).colors(0xFFB04A, 0xFFB04A).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(0.938F, 1.646F, 1.775F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.baluarte.secondary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.SELF).timing(90, 24, 12, 1, 1).dmg(10F).radius(6F).knock(1.6F).colors(0xC8A060, 0xC8A060).particle(WeaponSpec.PType.SMOKE).muzzle(0.938F, 1.646F, 1.775F));
    }

    private static MechaSpec avispon() {
        return new MechaSpec("avispon")
                .stats(110F, 10F, 2F, 0.36F, 1.5F)
                .size(1.62F, 2.72F, 1.5F, 0.98F)
                .glow(0xFF5028)
                .lore(3)
                .passives(Passive.AGILE)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.avispon.primary").anim(WeaponSpec.Anim.AIM).timing(24, 22, 2, 10, 2).dmg(2.5F).speed(3.4F).spread(3F).colors(0xFFD040, 0xFFD040).particle(WeaponSpec.PType.SPARK).item("minecraft:gold_nugget").flags("twin").muzzle(0.688F, 1.258F, 1.207F).muzzle2(-0.688F, 1.258F, 1.207F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.avispon.secondary").anim(WeaponSpec.Anim.POD).timing(80, 26, 4, 6, 3).dmg(5F).speed(1.1F).spread(12F).power(1F).colors(0xFF7030, 0xFF7030).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:firework_rocket").flags("homing").muzzle(0.75F, 2.531F, 0.438F));
    }

    private static MechaSpec obus() {
        return new MechaSpec("obus")
                .stats(190F, 16F, 4F, 0.18F, 0.4F)
                .size(2.31F, 3.79F, 1.16F, 1.39F)
                .glow(0xFF5A28)
                .lore(3)
                .passives(Passive.BRACED)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.obus.primary").anim(WeaponSpec.Anim.AIM).timing(60, 20, 8, 1, 1).dmg(14F).speed(1.6F).spread(1F).gravity(0.045F).power(3.2F).lob(0.55F).colors(0xFF9030, 0xFF9030).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:fire_charge").muzzle(0F, 3.509F, 1.197F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.obus.secondary").anim(WeaponSpec.Anim.POD).center(WeaponSpec.Center.SELF).timing(160, 30, 4, 1, 1).radius(7F).fx(WeaponSpec.Fx.SMOKE_STEALTH, 120, 0).colors(0x8A8A8A, 0x8A8A8A).particle(WeaponSpec.PType.SMOKE).muzzle(0F, 3.509F, 1.197F));
    }

    private static MechaSpec centinela() {
        return new MechaSpec("centinela")
                .stats(240F, 22F, 7F, 0.2F, 0F)
                .size(1.88F, 2.84F, 1.41F, 1.12F)
                .glow(0xFFBE50)
                .lore(3)
                .passives(Passive.TREADS)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.centinela.primary").anim(WeaponSpec.Anim.AIM).timing(50, 16, 4, 1, 1).dmg(16F).speed(3F).spread(0.5F).power(2.4F).colors(0xFFA040, 0xFFA040).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:fire_charge").muzzle(0.781F, 1.042F, 1.597F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.centinela.secondary").anim(WeaponSpec.Anim.SPIN).timing(30, 24, 2, 11, 2).dmg(3F).speed(3.5F).spread(2.5F).colors(0xFFD070, 0xFFD070).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(-0.781F, 0.964F, 1.165F));
    }

    private static MechaSpec coloso() {
        return new MechaSpec("coloso")
                .stats(320F, 22F, 8F, 0.17F, 0.45F)
                .size(2.75F, 4.59F, 3.06F, 1.65F)
                .glow(0xFF7828)
                .lore(3)
                .passives(Passive.TITAN)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.coloso.primary").anim(WeaponSpec.Anim.SWING).timing(36, 24, 11, 1, 1).dmg(22F).range(5.5F).angle(80F).knock(2.4F).colors(0xFFB080, 0xFFB080).particle(WeaponSpec.PType.SMOKE).flags("shake").muzzle(1.188F, 1.607F, 0.695F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.coloso.secondary").anim(WeaponSpec.Anim.POD).timing(110, 40, 8, 8, 3).dmg(6F).speed(1F).spread(6F).power(1.8F).lob(0.35F).colors(0xFF8040, 0xFF8040).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:firework_rocket").muzzle(1.281F, 4.094F, 0.438F));
    }

    private static MechaSpec lancero() {
        return new MechaSpec("lancero")
                .stats(150F, 14F, 3F, 0.26F, 0.9F)
                .size(1.72F, 3.38F, 2.09F, 1.03F)
                .glow(0x50C8FF)
                .lore(3)
                .passives()
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.lancero.primary").anim(WeaponSpec.Anim.AIM).timing(70, 24, 16, 1, 1).dmg(34F).range(64F).colors(0x60D0FF, 0xFFFFFF).particle(WeaponSpec.PType.SPARK).flags("pierce,charge").muzzle(0.812F, 1.814F, 2.055F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.lancero.secondary").anim(WeaponSpec.Anim.AIM).timing(16, 10, 1, 3, 3).dmg(4F).speed(3.6F).spread(1.5F).colors(0x9FE8FF, 0x9FE8FF).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(-0.812F, 1.659F, 1.321F));
    }

    private static MechaSpec serafin() {
        return new MechaSpec("serafin")
                .stats(150F, 13F, 4F, 0.3F, 1F)
                .size(1.8F, 3.59F, 2.22F, 1.08F)
                .glow(0x5ADCFF)
                .lore(3)
                .passives(Passive.FLIGHT)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.serafin.primary").anim(WeaponSpec.Anim.BEAM).timing(40, 30, 6, 24, 1).dmg(1.6F).range(40F).colors(0x70E0FF, 0xFFFFFF).particle(WeaponSpec.PType.SPARK).flags("twin").muzzle(0.844F, 1.506F, 0.731F).muzzle2(-0.844F, 1.506F, 0.731F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.serafin.secondary").anim(WeaponSpec.Anim.CAST).timing(70, 24, 4, 6, 3).dmg(6F).speed(1.6F).spread(18F).colors(0xFFF0A0, 0xFFF0A0).particle(WeaponSpec.PType.ORB).trail(WeaponSpec.PType.ORB).item("minecraft:prismarine_crystals").flags("homing").muzzle(-0.844F, 1.506F, 0.731F));
    }

    private static MechaSpec valquiria() {
        return new MechaSpec("valquiria")
                .stats(140F, 12F, 3F, 0.32F, 1.8F)
                .size(1.72F, 3.5F, 2.09F, 1.03F)
                .glow(0xFFC878)
                .lore(3)
                .passives(Passive.LEAP)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.valquiria.primary").anim(WeaponSpec.Anim.SWING).timing(50, 16, 5, 1, 1).dmg(14F).speed(1.9F).up(0.15F).colors(0xFFD890, 0xFFD890).particle(WeaponSpec.PType.SPARK).flags("contact").muzzle(0.812F, 1.845F, 2.176F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.valquiria.secondary").anim(WeaponSpec.Anim.AIM).timing(10, 8, 2, 1, 1).dmg(6F).speed(3.2F).spread(0.5F).colors(0xFFE080, 0xFFE080).particle(WeaponSpec.PType.ORB).item("minecraft:glowstone_dust").muzzle(-1.031F, 1.913F, 0.675F));
    }

    private static MechaSpec prisma() {
        return new MechaSpec("prisma")
                .stats(130F, 12F, 4F, 0.27F, 0F)
                .size(1.76F, 2.53F, 1.02F, 1.05F)
                .glow(0xC88CFF)
                .lore(3)
                .passives(Passive.HOVER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.prisma.primary").anim(WeaponSpec.Anim.CAST).timing(46, 30, 8, 22, 1).dmg(1.8F).range(44F).colors(0xC890FF, 0x80F0FF).particle(WeaponSpec.PType.SHARD).flags("pierce").muzzle(0.938F, 1.406F, 0.75F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.prisma.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(220, 20, 4, 1, 1).radius(5F).fx(WeaponSpec.Fx.SHIELD, 120, 0).colors(0xB0A0FF, 0xB0A0FF).particle(WeaponSpec.PType.SHARD).muzzle(-0.938F, 1.406F, 0.75F));
    }

    private static MechaSpec espectro() {
        return new MechaSpec("espectro")
                .stats(120F, 11F, 2F, 0.31F, 1.1F)
                .size(1.5F, 3.72F, 2.47F, 0.9F)
                .glow(0x78FFAA)
                .lore(3)
                .passives(Passive.STEALTH, Passive.NIGHT_VISION)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.espectro.primary").anim(WeaponSpec.Anim.AIM).timing(44, 14, 8, 1, 1).dmg(24F).range(72F).colors(0x70FFB0, 0xE0FFF0).particle(WeaponSpec.PType.SPARK).flags("charge").muzzle(0.781F, 2.397F, 2.002F),
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.espectro.secondary").anim(WeaponSpec.Anim.NONE).timing(70, 8, 0, 1, 1).dmg(0F).speed(3F).up(0.05F).colors(0x70FFB0, 0x70FFB0).particle(WeaponSpec.PType.SHARD).flags("blink").muzzle(-0.781F, 1.853F, 1.062F));
    }

    private static MechaSpec nova() {
        return new MechaSpec("nova")
                .stats(150F, 13F, 3F, 0.28F, 1F)
                .size(1.68F, 3.53F, 2.16F, 1F)
                .glow(0xFF9632)
                .lore(3)
                .passives(Passive.GLOW_AURA)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.nova.primary").anim(WeaponSpec.Anim.AIM).timing(18, 12, 3, 3, 3).dmg(6F).speed(1.8F).spread(1.5F).power(1.2F).colors(0xFFA040, 0xFFA040).particle(WeaponSpec.PType.ORB).trail(WeaponSpec.PType.ORB).item("minecraft:magma_cream").muzzle(0.781F, 1.537F, 0.723F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.nova.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(120, 26, 14, 1, 1).dmg(14F).radius(7F).knock(1.8F).fire(4).colors(0xFFB050, 0xFFB050).particle(WeaponSpec.PType.ORB).muzzle(-0.781F, 1.721F, 1.321F));
    }

    private static MechaSpec egida() {
        return new MechaSpec("egida")
                .stats(170F, 16F, 5F, 0.25F, 0F)
                .size(2.3F, 2.81F, 1.25F, 1.38F)
                .glow(0x6EFFA0)
                .lore(3)
                .passives(Passive.HOVER, Passive.SELF_REPAIR)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.egida.primary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(80, 24, 10, 1, 1).radius(8F).heal(16F).fx(WeaponSpec.Fx.HEAL, 60, 0).colors(0x70FFA0, 0x70FFA0).particle(WeaponSpec.PType.ORB).muzzle(1.188F, 1.656F, 0.75F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.egida.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(240, 20, 6, 1, 1).radius(8F).fx(WeaponSpec.Fx.SHIELD, 140, 0).colors(0xD0FFE0, 0xD0FFE0).particle(WeaponSpec.PType.SHARD).muzzle(1.188F, 1.656F, 0.75F));
    }

    private static MechaSpec mandibula() {
        return new MechaSpec("mandibula")
                .stats(170F, 14F, 3F, 0.27F, 0.9F)
                .size(1.9F, 3.31F, 1.97F, 1.14F)
                .glow(0xFF6E1E)
                .lore(3)
                .passives(Passive.SCRAP_ARMOR)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.mandibula.primary").anim(WeaponSpec.Anim.SPIN).timing(20, 20, 3, 8, 2).dmg(3.5F).range(4.2F).angle(70F).knock(0.1F).colors(0xFFC060, 0xFFC060).particle(WeaponSpec.PType.SPARK).muzzle(0.875F, 1.457F, 1.147F),
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.mandibula.secondary").anim(WeaponSpec.Anim.AIM).timing(40, 30, 3, 27, 1).dmg(1.4F).range(7F).angle(26F).fire(5).colors(0xFF8020, 0xFF8020).particle(WeaponSpec.PType.EMBER).muzzle(-0.875F, 1.495F, 1.169F));
    }

    private static MechaSpec cascabel() {
        return new MechaSpec("cascabel")
                .stats(150F, 13F, 2F, 0.3F, 0.8F)
                .size(2.97F, 1.25F, 0.6F, 1.78F)
                .glow(0xAAFF3C)
                .lore(3)
                .passives(Passive.CLIMBER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.cascabel.primary").anim(WeaponSpec.Anim.AIM).timing(40, 26, 3, 23, 1).dmg(1F).range(8F).angle(24F).fx(WeaponSpec.Fx.POISON, 80, 1).colors(0xB0FF40, 0xB0FF40).particle(WeaponSpec.PType.TOXIC).muzzle(0F, 1.344F, 1.156F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.cascabel.secondary").anim(WeaponSpec.Anim.POD).timing(90, 20, 4, 5, 2).dmg(4F).speed(0.9F).spread(14F).gravity(0.05F).power(1.6F).lob(0.6F).colors(0xFF9040, 0xFF9040).particle(WeaponSpec.PType.EMBER).item("minecraft:tnt").muzzle(0F, 1.344F, 1.156F));
    }

    private static MechaSpec trituradora() {
        return new MechaSpec("trituradora")
                .stats(210F, 18F, 5F, 0.19F, 0F)
                .size(3F, 1.84F, 0.69F, 1.8F)
                .glow(0xFF8C28)
                .lore(3)
                .passives(Passive.TREADS)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.DRILL).name("weapon.blockwars.trituradora.primary").anim(WeaponSpec.Anim.SPIN).timing(24, 40, 4, 9, 4).dmg(6F).range(9F).radius(1F).colors(0xD0B080, 0xD0B080).particle(WeaponSpec.PType.SMOKE).muzzle(0F, 0.375F, 2.688F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.trituradora.secondary").anim(WeaponSpec.Anim.AIM).timing(30, 10, 2, 1, 1).pellets(10).dmg(2.5F).speed(2.4F).spread(14F).colors(0xFFC080, 0xFFC080).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(0.312F, 1.281F, 1.562F));
    }

    private static MechaSpec tetano() {
        return new MechaSpec("tetano")
                .stats(200F, 15F, 3F, 0.26F, 0F)
                .size(3.6F, 1.91F, 0.6F, 2.16F)
                .glow(0xFF5A28)
                .lore(3)
                .passives(Passive.AMPHIBIOUS, Passive.TREADS)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.tetano.primary").anim(WeaponSpec.Anim.AIM).timing(46, 24, 4, 20, 1).dmg(0.8F).range(7F).angle(30F).fx(WeaponSpec.Fx.WEAKNESS, 120, 1).fx2(WeaponSpec.Fx.WITHER).colors(0xC06030, 0xC06030).particle(WeaponSpec.PType.SMOKE).muzzle(0F, 1.269F, 2.654F),
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.tetano.secondary").anim(WeaponSpec.Anim.SWING).timing(40, 18, 8, 1, 1).dmg(12F).range(5F).angle(360F).knock(1.6F).colors(0xD08050, 0xD08050).particle(WeaponSpec.PType.SMOKE).muzzle(0F, 1.269F, 2.654F));
    }

    private static MechaSpec topadora() {
        return new MechaSpec("topadora")
                .stats(220F, 19F, 5F, 0.22F, 0F)
                .size(2.04F, 2.78F, 1.41F, 1.23F)
                .glow(0xFF781E)
                .lore(3)
                .passives(Passive.TREADS, Passive.RAM)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.topadora.primary").anim(WeaponSpec.Anim.POUNCE).timing(60, 18, 4, 1, 1).dmg(12F).speed(1.5F).knock(2F).up(0.05F).colors(0xC09060, 0xC09060).particle(WeaponSpec.PType.SMOKE).flags("contact").muzzle(0.781F, 0.971F, 1.067F),
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.topadora.secondary").anim(WeaponSpec.Anim.AIM).timing(40, 30, 3, 27, 1).dmg(1.4F).range(7F).angle(26F).fire(5).colors(0xFF8020, 0xFF8020).particle(WeaponSpec.PType.EMBER).muzzle(-0.781F, 0.421F, 0.304F));
    }

    private static MechaSpec forjamagma() {
        return new MechaSpec("forjamagma")
                .stats(260F, 19F, 6F, 0.2F, 0.5F)
                .size(2.4F, 4.28F, 2.81F, 1.44F)
                .glow(0xFF6E14)
                .lore(3)
                .passives(Passive.LAVA_WALKER, Passive.TITAN)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.forjamagma.primary").anim(WeaponSpec.Anim.AIM).timing(34, 16, 5, 2, 5).dmg(8F).speed(1.3F).spread(2F).gravity(0.03F).power(1.6F).lob(0.25F).fire(6).colors(0xFF6A20, 0xFF6A20).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.EMBER).item("minecraft:magma_cream").flags("setsFire").muzzle(1.094F, 2.002F, 1.966F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.forjamagma.secondary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.SELF).timing(130, 40, 14, 4, 6).dmg(7F).radius(7F).knock(0.6F).fire(6).colors(0xFF5010, 0xFF5010).particle(WeaponSpec.PType.EMBER).flags("setsFire,ring").muzzle(-1.094F, 1.48F, 0.68F));
    }

    private static MechaSpec yunque() {
        return new MechaSpec("yunque")
                .stats(210F, 19F, 6F, 0.23F, 0.7F)
                .size(2.1F, 3.75F, 2.28F, 1.26F)
                .glow(0xFF8C28)
                .lore(3)
                .passives(Passive.FIRE_IMMUNE)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.yunque.primary").anim(WeaponSpec.Anim.SWING).center(WeaponSpec.Center.FRONT).timing(44, 26, 13, 1, 1).dmg(18F).radius(4.5F).knock(1.4F).colors(0xFFB060, 0xFFB060).particle(WeaponSpec.PType.SPARK).flags("shake").muzzle(0.969F, 1.331F, 1.169F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.yunque.secondary").anim(WeaponSpec.Anim.AIM).timing(30, 10, 2, 1, 1).pellets(8).dmg(2.5F).speed(2.2F).spread(12F).fire(3).colors(0xFF8030, 0xFF8030).particle(WeaponSpec.PType.EMBER).item("minecraft:blaze_powder").muzzle(-0.969F, 1.708F, 1.397F));
    }

    private static MechaSpec ceniza() {
        return new MechaSpec("ceniza")
                .stats(140F, 12F, 3F, 0.35F, 1.4F)
                .size(1.9F, 2.12F, 0.75F, 1.14F)
                .glow(0xFF6414)
                .lore(3)
                .passives(Passive.FIRE_IMMUNE, Passive.AGILE)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.ceniza.primary").anim(WeaponSpec.Anim.AIM).timing(40, 30, 3, 27, 1).dmg(1.6F).range(7.5F).angle(24F).fire(6).colors(0xFF7020, 0xFF7020).particle(WeaponSpec.PType.EMBER).muzzle(0F, 2.188F, 1.156F),
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.ceniza.secondary").anim(WeaponSpec.Anim.POUNCE).timing(50, 20, 6, 1, 1).dmg(10F).radius(3.5F).speed(1.3F).knock(1F).up(0.6F).colors(0xFF9050, 0xFF9050).particle(WeaponSpec.PType.EMBER).flags("land").muzzle(0F, 2.188F, 1.156F));
    }

    private static MechaSpec glaciar() {
        return new MechaSpec("glaciar")
                .stats(230F, 19F, 6F, 0.21F, 0.6F)
                .size(2.12F, 3.81F, 2.38F, 1.27F)
                .glow(0x78DCFF)
                .lore(3)
                .passives(Passive.FROST_WALKER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.glaciar.primary").anim(WeaponSpec.Anim.BEAM).timing(50, 34, 6, 28, 1).dmg(1F).range(30F).fx(WeaponSpec.Fx.FREEZE, 60, 2).colors(0x90E8FF, 0xFFFFFF).particle(WeaponSpec.PType.FROST).muzzle(0.969F, 1.539F, 0.746F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.glaciar.secondary").anim(WeaponSpec.Anim.AIM).timing(30, 10, 2, 1, 1).pellets(9).dmg(3F).speed(2.6F).spread(10F).fx(WeaponSpec.Fx.SLOW, 60, 1).colors(0xB0F0FF, 0xB0F0FF).particle(WeaponSpec.PType.FROST).item("minecraft:ice").muzzle(-0.969F, 1.749F, 1.821F));
    }

    private static MechaSpec ventisca() {
        return new MechaSpec("ventisca")
                .stats(150F, 13F, 4F, 0.27F, 0F)
                .size(1.76F, 2.16F, 0.73F, 1.05F)
                .glow(0x96E6FF)
                .lore(3)
                .passives(Passive.HOVER, Passive.FROST_WALKER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.ventisca.primary").anim(WeaponSpec.Anim.CAST).timing(46, 30, 4, 26, 1).dmg(0.8F).range(9F).angle(34F).knock(0.25F).fx(WeaponSpec.Fx.FREEZE, 80, 2).colors(0xE0F8FF, 0xE0F8FF).particle(WeaponSpec.PType.FROST).muzzle(0.938F, 1.406F, 0.75F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.ventisca.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(110, 30, 8, 3, 6).dmg(9F).radius(6F).knock(0.4F).fx(WeaponSpec.Fx.SLOW, 80, 2).colors(0xA0E8FF, 0xA0E8FF).particle(WeaponSpec.PType.FROST).flags("ring,upward").muzzle(-0.938F, 1.406F, 0.75F));
    }

    private static MechaSpec yeti() {
        return new MechaSpec("yeti")
                .stats(250F, 18F, 6F, 0.24F, 1F)
                .size(2.53F, 3.03F, 1.22F, 1.52F)
                .glow(0x78DCFF)
                .lore(3)
                .passives(Passive.FROST_WALKER, Passive.TITAN)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.yeti.primary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.FRONT).timing(40, 24, 12, 1, 1).dmg(16F).radius(5F).knock(1.5F).fx(WeaponSpec.Fx.SLOW, 60, 2).colors(0xC0F0FF, 0xC0F0FF).particle(WeaponSpec.PType.FROST).flags("shake").muzzle(0F, 2.75F, 1.906F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.yeti.secondary").anim(WeaponSpec.Anim.AIM).timing(20, 14, 2, 4, 3).dmg(4F).speed(2F).spread(3F).fx(WeaponSpec.Fx.SLOW, 60, 1).colors(0xFFFFFF, 0xFFFFFF).particle(WeaponSpec.PType.FROST).item("minecraft:snowball").muzzle(0F, 2.75F, 1.906F));
    }

    private static MechaSpec lomoespino() {
        return new MechaSpec("lomoespino")
                .stats(180F, 12F, 3F, 0.27F, 1F)
                .size(2.1F, 2.69F, 0.97F, 1.26F)
                .glow(0xBEFF5A)
                .lore(3)
                .passives(Passive.SELF_REPAIR)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.lomoespino.primary").anim(WeaponSpec.Anim.SPIN).timing(26, 22, 2, 10, 2).dmg(2.5F).speed(3F).spread(4F).fx(WeaponSpec.Fx.POISON, 60, 0).colors(0xA0FF60, 0xA0FF60).particle(WeaponSpec.PType.TOXIC).item("minecraft:sweet_berries").muzzle(0F, 2.438F, 1.312F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.lomoespino.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.AIM).timing(100, 20, 6, 1, 1).dmg(4F).range(20F).radius(6F).fx(WeaponSpec.Fx.ROOT, 80, 0).colors(0x60D040, 0x60D040).particle(WeaponSpec.PType.TOXIC).muzzle(0F, 2.438F, 1.312F));
    }

    private static MechaSpec madreespora() {
        return new MechaSpec("madreespora")
                .stats(190F, 13F, 3F, 0.24F, 0.6F)
                .size(3F, 1.56F, 0.6F, 1.8F)
                .glow(0xFF78E6)
                .lore(3)
                .passives(Passive.SELF_REPAIR)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.madreespora.primary").anim(WeaponSpec.Anim.POD).center(WeaponSpec.Center.AIM).timing(60, 60, 6, 12, 4).dmg(1F).range(22F).radius(4.5F).fx(WeaponSpec.Fx.POISON, 60, 1).fx2(WeaponSpec.Fx.NAUSEA).colors(0xE080FF, 0xE080FF).particle(WeaponSpec.PType.TOXIC).muzzle(0F, 1.406F, 0.688F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.madreespora.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(100, 20, 6, 1, 1).radius(7F).heal(14F).fx(WeaponSpec.Fx.HEAL, 60, 0).colors(0xB0FF80, 0xB0FF80).particle(WeaponSpec.PType.ORB).muzzle(0F, 1.406F, 0.688F));
    }

    private static MechaSpec mantis() {
        return new MechaSpec("mantis")
                .stats(130F, 11F, 2F, 0.34F, 1.9F)
                .size(1.45F, 3.12F, 1.84F, 0.87F)
                .glow(0xD2FF50)
                .lore(3)
                .passives(Passive.AGILE, Passive.LEAP)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.mantis.primary").anim(WeaponSpec.Anim.SWING).timing(26, 18, 7, 2, 4).dmg(10F).range(4.8F).angle(110F).knock(0.6F).colors(0xD0FF80, 0xD0FF80).particle(WeaponSpec.PType.SPARK).flags("twin").muzzle(0.75F, 0.984F, 1.167F).muzzle2(-0.75F, 0.984F, 1.167F),
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.mantis.secondary").anim(WeaponSpec.Anim.POUNCE).timing(60, 24, 6, 1, 1).dmg(12F).radius(3.5F).speed(1.2F).knock(0.8F).up(1F).colors(0xD0FF80, 0xD0FF80).particle(WeaponSpec.PType.SPARK).flags("land").muzzle(-0.75F, 0.984F, 1.167F));
    }

    private static MechaSpec revenant() {
        return new MechaSpec("revenant")
                .stats(160F, 14F, 4F, 0.27F, 1F)
                .size(1.78F, 3.66F, 2.28F, 1.06F)
                .glow(0x9650FF)
                .lore(3)
                .passives(Passive.LIFESTEAL, Passive.NIGHT_VISION)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.revenant.primary").anim(WeaponSpec.Anim.CAST).timing(24, 14, 4, 3, 3).dmg(6F).speed(1.5F).spread(4F).fx(WeaponSpec.Fx.WITHER, 80, 0).colors(0x9050FF, 0x9050FF).particle(WeaponSpec.PType.VOID).trail(WeaponSpec.PType.VOID).item("minecraft:wither_skeleton_skull").flags("homing").muzzle(0.781F, 1.569F, 0.731F),
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.revenant.secondary").anim(WeaponSpec.Anim.BEAM).timing(60, 30, 6, 24, 1).dmg(1.4F).range(24F).fx(WeaponSpec.Fx.WITHER, 60, 0).colors(0x60FFD0, 0xB080FF).particle(WeaponSpec.PType.VOID).muzzle(-0.781F, 1.173F, 0.445F));
    }

    private static MechaSpec oraculo() {
        return new MechaSpec("oraculo")
                .stats(130F, 11F, 3F, 0.28F, 0F)
                .size(1F, 2.34F, 0.88F, 0.6F)
                .glow(0xC85AFF)
                .lore(3)
                .passives(Passive.HOVER, Passive.NIGHT_VISION)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CHAIN).name("weapon.blockwars.oraculo.primary").anim(WeaponSpec.Anim.CAST).timing(40, 12, 6, 1, 1).dmg(9F).range(26F).colors(0xC070FF, 0xC070FF).particle(WeaponSpec.PType.VOID).jumps(4).muzzle(0F, 1.719F, 0.625F),
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.oraculo.secondary").anim(WeaponSpec.Anim.NONE).timing(60, 8, 0, 1, 1).speed(3.2F).up(0.1F).colors(0xC070FF, 0xC070FF).particle(WeaponSpec.PType.VOID).flags("blink").muzzle(0F, 1.719F, 0.625F));
    }

    private static MechaSpec penitente() {
        return new MechaSpec("penitente")
                .stats(200F, 18F, 6F, 0.25F, 0.9F)
                .size(2.18F, 3.88F, 2.38F, 1.31F)
                .glow(0xB45AFF)
                .lore(3)
                .passives(Passive.LIFESTEAL)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.penitente.primary").anim(WeaponSpec.Anim.SWING).timing(34, 30, 14, 1, 1).dmg(20F).range(5.5F).angle(140F).knock(1.2F).fx(WeaponSpec.Fx.WITHER, 40, 0).colors(0xB070FF, 0xB070FF).particle(WeaponSpec.PType.VOID).muzzle(1F, 1.328F, 1.108F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.penitente.secondary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.SELF).timing(100, 26, 12, 1, 1).dmg(10F).radius(7F).knock(1.4F).fx(WeaponSpec.Fx.WEAKNESS, 100, 0).colors(0x9060FF, 0x9060FF).particle(WeaponSpec.PType.VOID).flags("ring").muzzle(1F, 1.328F, 1.108F));
    }

    private static MechaSpec llamatormentas() {
        return new MechaSpec("llamatormentas")
                .stats(170F, 15F, 4F, 0.26F, 1F)
                .size(1.9F, 3.75F, 2.38F, 1.14F)
                .glow(0xFFE650)
                .lore(3)
                .passives(Passive.STORM)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.LIGHTNING).name("weapon.blockwars.llamatormentas.primary").anim(WeaponSpec.Anim.CAST).timing(50, 20, 10, 1, 1).dmg(0F).range(48F).colors(0xFFF080, 0xFFF080).particle(WeaponSpec.PType.SPARK).muzzle(0.906F, 1.756F, 1.223F),
                        new WeaponSpec(WeaponSpec.Kind.CHAIN).name("weapon.blockwars.llamatormentas.secondary").anim(WeaponSpec.Anim.AIM).timing(30, 10, 4, 1, 1).dmg(7F).range(22F).colors(0xFFF080, 0xFFF080).particle(WeaponSpec.PType.SPARK).jumps(5).muzzle(-0.906F, 1.756F, 1.223F));
    }

    private static MechaSpec cumulonimbo() {
        return new MechaSpec("cumulonimbo")
                .stats(160F, 13F, 4F, 0.27F, 0F)
                .size(2.42F, 2.62F, 1.1F, 1.45F)
                .glow(0xFFF06E)
                .lore(3)
                .passives(Passive.HOVER, Passive.STORM)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CHAIN).name("weapon.blockwars.cumulonimbo.primary").anim(WeaponSpec.Anim.SPIN).timing(24, 24, 4, 4, 5).dmg(5F).range(14F).colors(0xBFE6FF, 0xBFE6FF).particle(WeaponSpec.PType.SPARK).jumps(3).muzzle(1.312F, 1.812F, 1.25F),
                        new WeaponSpec(WeaponSpec.Kind.LIGHTNING).name("weapon.blockwars.cumulonimbo.secondary").anim(WeaponSpec.Anim.CAST).timing(180, 60, 10, 8, 6).range(0F).radius(9F).colors(0xFFF080, 0xFFF080).particle(WeaponSpec.PType.SPARK).flags("around").muzzle(-1.312F, 1.812F, 1.25F));
    }

    private static MechaSpec vendaval() {
        return new MechaSpec("vendaval")
                .stats(130F, 11F, 3F, 0.33F, 1.2F)
                .size(1.65F, 3.78F, 2.47F, 0.99F)
                .glow(0xA0E6FF)
                .lore(2)
                .passives(Passive.FLIGHT)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.vendaval.primary").anim(WeaponSpec.Anim.CAST).timing(30, 14, 4, 8, 1).dmg(2F).range(10F).angle(32F).knock(1.8F).colors(0xE8F8FF, 0xE8F8FF).particle(WeaponSpec.PType.SMOKE).muzzle(0.781F, 2.065F, 0.7F),
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.vendaval.secondary").anim(WeaponSpec.Anim.NONE).timing(40, 12, 2, 1, 1).dmg(0F).speed(2.4F).up(0.2F).colors(0xD0F0FF, 0xD0F0FF).particle(WeaponSpec.PType.SMOKE).muzzle(-0.781F, 2.242F, 1.267F));
    }

    private static MechaSpec rompeolas() {
        return new MechaSpec("rompeolas")
                .stats(190F, 17F, 5F, 0.25F, 0.6F)
                .size(3.4F, 1.62F, 0.6F, 2.04F)
                .glow(0x50DCFF)
                .lore(3)
                .passives(Passive.AMPHIBIOUS)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.rompeolas.primary").anim(WeaponSpec.Anim.AIM).timing(40, 18, 4, 2, 6).dmg(10F).speed(1.4F).spread(2F).power(2F).colors(0x60E0FF, 0x60E0FF).particle(WeaponSpec.PType.ORB).trail(WeaponSpec.PType.ORB).item("minecraft:prismarine_shard").flags("homing").muzzle(0F, 1.375F, 1.719F),
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.rompeolas.secondary").anim(WeaponSpec.Anim.AIM).timing(34, 20, 3, 17, 1).dmg(0.6F).range(10F).angle(18F).knock(1.2F).colors(0x80C8FF, 0x80C8FF).particle(WeaponSpec.PType.ORB).flags("extinguish").muzzle(0F, 1.375F, 1.719F));
    }

    private static MechaSpec cronos() {
        return new MechaSpec("cronos")
                .stats(150F, 13F, 4F, 0.26F, 0F)
                .size(1.96F, 2.53F, 1.02F, 1.17F)
                .glow(0xFFD26E)
                .lore(3)
                .passives(Passive.HOVER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.cronos.primary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(160, 100, 6, 24, 4).radius(10F).fx(WeaponSpec.Fx.TIME_SLOW, 40, 3).colors(0xFFD890, 0xFFD890).particle(WeaponSpec.PType.SHARD).muzzle(1.062F, 1.531F, 0.75F),
                        new WeaponSpec(WeaponSpec.Kind.REWIND).name("weapon.blockwars.cronos.secondary").anim(WeaponSpec.Anim.CAST).timing(300, 20, 10, 1, 1).colors(0x90F0FF, 0x90F0FF).particle(WeaponSpec.PType.SHARD).muzzle(-1.062F, 1.531F, 0.75F));
    }

    private static MechaSpec espejismo() {
        return new MechaSpec("espejismo")
                .stats(130F, 12F, 3F, 0.3F, 1.1F)
                .size(1.3F, 3.88F, 2.53F, 0.78F)
                .glow(0xFF96F0)
                .lore(2)
                .passives(Passive.STEALTH)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.espejismo.primary").anim(WeaponSpec.Anim.BEAM).timing(40, 24, 4, 20, 1).dmg(1.1F).range(28F).fx(WeaponSpec.Fx.BLIND, 80, 0).colors(0xFF90F0, 0xFFFFFF).particle(WeaponSpec.PType.SHARD).muzzle(0.656F, 2.127F, 0.7F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.espejismo.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(140, 20, 2, 1, 1).radius(8F).fx(WeaponSpec.Fx.SMOKE_STEALTH, 140, 0).colors(0xE0C0FF, 0xE0C0FF).particle(WeaponSpec.PType.SHARD).muzzle(-0.656F, 1.915F, 1.062F));
    }

    private static MechaSpec titan() {
        return new MechaSpec("titan")
                .stats(340F, 24F, 10F, 0.15F, 0F)
                .size(3.22F, 2.47F, 1.19F, 1.94F)
                .glow(0xFF7828)
                .lore(3)
                .passives(Passive.TREADS, Passive.TITAN)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.titan.primary").anim(WeaponSpec.Anim.AIM).timing(100, 24, 10, 1, 1).dmg(24F).speed(1.8F).spread(0.5F).gravity(0.03F).power(4.5F).lob(0.2F).colors(0xFF8030, 0xFF8030).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:fire_charge").muzzle(0F, 1.625F, 2.25F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.titan.secondary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.SELF).timing(160, 50, 8, 5, 8).dmg(6F).radius(9F).knock(0.9F).fx(WeaponSpec.Fx.SLOW, 40, 0).colors(0xA08060, 0xA08060).particle(WeaponSpec.PType.SMOKE).flags("ring,shake").muzzle(-0.5F, 1.688F, 1.844F));
    }

    private static MechaSpec colmena() {
        return new MechaSpec("colmena")
                .stats(180F, 15F, 4F, 0.26F, 0.6F)
                .size(3.19F, 2.09F, 0.6F, 1.92F)
                .glow(0xFFC828)
                .lore(3)
                .passives(Passive.CLIMBER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.colmena.primary").anim(WeaponSpec.Anim.POD).timing(70, 40, 4, 16, 2).dmg(3.5F).speed(1F).spread(30F).power(0.8F).lob(0.6F).colors(0xFFD040, 0xFFD040).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:honeycomb").flags("homing").muzzle(0F, 1.344F, -0.469F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.colmena.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(120, 20, 6, 1, 1).radius(6F).heal(20F).fx(WeaponSpec.Fx.HEAL, 60, 0).colors(0xFFE080, 0xFFE080).particle(WeaponSpec.PType.ORB).muzzle(0F, 1.344F, -0.469F));
    }

    private static MechaSpec peregrino() {
        return new MechaSpec("peregrino")
                .stats(140F, 12F, 3F, 0.29F, 0.8F)
                .size(1.9F, 4.94F, 3.53F, 1.14F)
                .glow(0xFFE678)
                .lore(3)
                .passives(Passive.STRIDER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.peregrino.primary").anim(WeaponSpec.Anim.AIM).timing(50, 20, 10, 1, 1).dmg(26F).range(80F).colors(0xFFE890, 0xFFFFFF).particle(WeaponSpec.PType.SPARK).flags("pierce,charge").muzzle(1F, 3.067F, 2.199F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.peregrino.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(200, 20, 4, 1, 1).radius(28F).fx(WeaponSpec.Fx.GLOW, 300, 0).colors(0xFFF0A0, 0xFFF0A0).particle(WeaponSpec.PType.SPARK).muzzle(1F, 3.067F, 2.199F));
    }

    private static MechaSpec helios() {
        return new MechaSpec("helios")
                .stats(260F, 18F, 8F, 0.2F, 0.5F)
                .size(2.35F, 4.53F, 2.97F, 1.41F)
                .glow(0xFFC83C)
                .dangerous()
                .lore(5)
                .passives(Passive.REACTOR, Passive.FIRE_IMMUNE, Passive.TITAN)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.helios.primary").anim(WeaponSpec.Anim.BEAM).timing(40, 40, 8, 32, 1).dmg(3F).range(40F).heat(24F).fire(8).colors(0xFFD040, 0xFFFFFF).particle(WeaponSpec.PType.EMBER).flags("pierce,setsFire").muzzle(1.125F, 1.802F, 0.815F),
                        new WeaponSpec(WeaponSpec.Kind.VENT).name("weapon.blockwars.helios.secondary").anim(WeaponSpec.Anim.CAST).timing(200, 30, 6, 1, 1).dmg(12F).radius(7F).knock(1.2F).fire(8).colors(0xFF7020, 0xFF7020).particle(WeaponSpec.PType.EMBER).muzzle(-1.125F, 1.802F, 0.815F));
    }

    private static MechaSpec eclipse() {
        return new MechaSpec("eclipse")
                .stats(220F, 16F, 8F, 0.24F, 0F)
                .size(2.37F, 2.88F, 1.3F, 1.42F)
                .glow(0xAA5AFF)
                .dangerous()
                .lore(5)
                .passives(Passive.HOVER, Passive.UNSTABLE)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.eclipse.primary").anim(WeaponSpec.Anim.CAST).timing(40, 30, 6, 24, 1).dmg(1.6F).range(32F).pull(0.35F).colors(0xA060FF, 0x101018).particle(WeaponSpec.PType.VOID).muzzle(1.281F, 1.812F, 0.812F),
                        new WeaponSpec(WeaponSpec.Kind.SINGULARITY).name("weapon.blockwars.eclipse.secondary").anim(WeaponSpec.Anim.CAST).timing(600, 14, 10, 1, 1).range(24F).radius(16F).power(7F).colors(0x8040FF, 0x8040FF).particle(WeaponSpec.PType.VOID).muzzle(-1.281F, 1.812F, 0.812F));
    }

    private static MechaSpec barrena() {
        return new MechaSpec("barrena")
                .stats(230F, 19F, 6F, 0.19F, 0F)
                .size(3.3F, 2.31F, 0.81F, 1.98F)
                .glow(0xFFA028)
                .lore(3)
                .passives(Passive.TREADS)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.DRILL).name("weapon.blockwars.barrena.primary").anim(WeaponSpec.Anim.SPIN).timing(40, 40, 4, 8, 4).dmg(7F).radius(1F).colors(0xFFB040, 0xFFB040).particle(WeaponSpec.PType.SPARK).muzzle(0F, 0.406F, 2.812F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.barrena.secondary").anim(WeaponSpec.Anim.AIM).timing(18, 14, 2, 5, 2).dmg(3.5F).speed(3F).spread(2F).colors(0xFFD070, 0xFFD070).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(0.344F, 1.406F, 1.688F));
    }

    private static MechaSpec topo() {
        return new MechaSpec("topo")
                .stats(210F, 17F, 5F, 0.22F, 0.6F)
                .size(3.6F, 1.47F, 0.6F, 2.16F)
                .glow(0xFFBE50)
                .lore(3)
                .passives(Passive.TREADS, Passive.NIGHT_VISION)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.DRILL).name("weapon.blockwars.topo.primary").anim(WeaponSpec.Anim.NONE).timing(36, 36, 2, 8, 4).dmg(8F).radius(1F).colors(0xD0A060, 0xD0A060).particle(WeaponSpec.PType.SMOKE).muzzle(0F, 1.082F, 2.185F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.topo.secondary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.SELF).timing(110, 30, 10, 3, 6).dmg(9F).radius(6F).knock(0.6F).fx(WeaponSpec.Fx.SLOW, 60, 1).colors(0xA08060, 0xA08060).particle(WeaponSpec.PType.SMOKE).flags("ring,shake").muzzle(0F, 1.082F, 2.185F));
    }

    private static MechaSpec pala() {
        return new MechaSpec("pala")
                .stats(260F, 20F, 7F, 0.17F, 0F)
                .size(2.48F, 2.56F, 1F, 1.48F)
                .glow(0xFFAA3C)
                .lore(3)
                .passives(Passive.TREADS, Passive.BRACED)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.pala.primary").anim(WeaponSpec.Anim.SWING).timing(34, 26, 11, 1, 1).dmg(18F).range(6F).angle(90F).knock(1.2F).up(0F).colors(0xC8A060, 0xC8A060).particle(WeaponSpec.PType.SMOKE).flags("shake").muzzle(0.219F, 0.754F, 1.948F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.pala.secondary").anim(WeaponSpec.Anim.SWING).center(WeaponSpec.Center.AIM).timing(80, 20, 8, 1, 1).dmg(10F).range(18F).radius(4F).knock(0.5F).fx(WeaponSpec.Fx.SLOW, 80, 2).colors(0x9A8060, 0x9A8060).particle(WeaponSpec.PType.SMOKE).flags("shake").muzzle(-0.438F, 1.531F, 1.688F));
    }

    private static MechaSpec grisu() {
        return new MechaSpec("grisu")
                .stats(150F, 13F, 3F, 0.26F, 0.9F)
                .size(1.83F, 3.44F, 2.03F, 1.1F)
                .glow(0xFF7828)
                .lore(3)
                .passives(Passive.FIRE_IMMUNE)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.grisu.primary").anim(WeaponSpec.Anim.AIM).timing(50, 16, 6, 1, 1).dmg(10F).speed(1.2F).spread(1F).gravity(0.05F).power(2.8F).lob(0.5F).colors(0xFF6030, 0xFF6030).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:tnt").muzzle(0.781F, 2.38F, 0.953F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.grisu.secondary").anim(WeaponSpec.Anim.POD).timing(90, 24, 4, 5, 3).dmg(5F).speed(0.9F).spread(16F).power(1.4F).lob(0.45F).colors(0xFF9040, 0xFF9040).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:firework_rocket").muzzle(0.844F, 3.094F, 0.438F));
    }

    private static MechaSpec iman() {
        return new MechaSpec("iman")
                .stats(180F, 16F, 4F, 0.24F, 0.6F)
                .size(1.98F, 3.34F, 2.16F, 1.18F)
                .glow(0x78C8FF)
                .lore(3)
                .passives(Passive.MAGNETIC)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MAGNET).name("weapon.blockwars.iman.primary").anim(WeaponSpec.Anim.BEAM).timing(40, 40, 4, 18, 2).dmg(1.5F).angle(40F).radius(14F).pull(0.45F).fx(WeaponSpec.Fx.SLOW, 30, 1).colors(0x80C8FF, 0xFF6060).particle(WeaponSpec.PType.SPARK).muzzle(0.906F, 1.506F, 0.852F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.iman.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(90, 20, 8, 1, 1).dmg(6F).radius(7F).knock(2.6F).colors(0xFF7070, 0xFF7070).particle(WeaponSpec.PType.SPARK).flags("ring").muzzle(-0.906F, 1.506F, 0.852F));
    }

    private static MechaSpec capataz() {
        return new MechaSpec("capataz")
                .stats(200F, 17F, 5F, 0.23F, 0.7F)
                .size(2.1F, 3.78F, 2.28F, 1.26F)
                .glow(0xFFE68C)
                .lore(3)
                .passives(Passive.NIGHT_VISION, Passive.GLOW_AURA)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.capataz.primary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.FRONT).timing(30, 30, 4, 6, 4).dmg(6F).radius(3.5F).knock(0.3F).fx(WeaponSpec.Fx.SLOW, 30, 1).colors(0xC0B090, 0xC0B090).particle(WeaponSpec.PType.SMOKE).flags("shake").muzzle(0.969F, 1.331F, 1.169F),
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.capataz.secondary").anim(WeaponSpec.Anim.AIM).timing(36, 26, 3, 22, 1).dmg(1.6F).range(6F).angle(14F).fire(3).colors(0x70D0FF, 0x70D0FF).particle(WeaponSpec.PType.EMBER).muzzle(-0.969F, 1.6F, 1.102F));
    }

    private static MechaSpec crisol() {
        return new MechaSpec("crisol")
                .stats(240F, 19F, 6F, 0.19F, 0.5F)
                .size(2.3F, 3.84F, 2.62F, 1.38F)
                .glow(0xFF8214)
                .lore(3)
                .passives(Passive.FIRE_IMMUNE, Passive.LAVA_WALKER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.crisol.primary").anim(WeaponSpec.Anim.SWING).center(WeaponSpec.Center.AIM).timing(70, 34, 10, 6, 4).dmg(5F).range(12F).radius(3F).fire(6).colors(0xFF8020, 0xFF8020).particle(WeaponSpec.PType.EMBER).flags("setsFire").muzzle(1.062F, 0.889F, 0.956F),
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.crisol.secondary").anim(WeaponSpec.Anim.AIM).timing(40, 26, 3, 22, 1).dmg(1.5F).range(7F).angle(26F).fire(5).colors(0xFF6010, 0xFF6010).particle(WeaponSpec.PType.EMBER).muzzle(-1.062F, 1.836F, 1.299F));
    }

    private static MechaSpec prensa() {
        return new MechaSpec("prensa")
                .stats(280F, 21F, 8F, 0.16F, 0.4F)
                .size(2.6F, 4.5F, 2.97F, 1.56F)
                .glow(0xFF6E28)
                .lore(3)
                .passives(Passive.TITAN, Passive.BRACED)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.prensa.primary").anim(WeaponSpec.Anim.SWING).timing(40, 28, 13, 1, 1).dmg(26F).range(5F).angle(70F).knock(1.6F).fx(WeaponSpec.Fx.SLOW, 40, 2).colors(0xFFB080, 0xFFB080).particle(WeaponSpec.PType.SMOKE).flags("shake").muzzle(1.188F, 1.544F, 0.687F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.prensa.secondary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.SELF).timing(110, 24, 12, 1, 1).dmg(12F).radius(6F).knock(2F).colors(0xD0D0D0, 0xD0D0D0).particle(WeaponSpec.PType.SMOKE).flags("upward,shake").muzzle(-1.188F, 1.544F, 0.687F));
    }

    private static MechaSpec caldera() {
        return new MechaSpec("caldera")
                .stats(250F, 18F, 7F, 0.22F, 0.5F)
                .size(2.38F, 4.41F, 2.88F, 1.42F)
                .glow(0xFF8C28)
                .dangerous()
                .lore(4)
                .passives(Passive.REACTOR, Passive.FIRE_IMMUNE, Passive.RAM)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.caldera.primary").anim(WeaponSpec.Anim.AIM).timing(30, 28, 4, 24, 1).dmg(2.2F).range(9F).angle(22F).knock(0.5F).heat(26F).fx(WeaponSpec.Fx.WEAKNESS, 40, 0).colors(0xF0F0F0, 0xF0F0F0).particle(WeaponSpec.PType.SMOKE).muzzle(1.125F, 2.065F, 1.966F),
                        new WeaponSpec(WeaponSpec.Kind.VENT).name("weapon.blockwars.caldera.secondary").anim(WeaponSpec.Anim.CAST).timing(180, 30, 6, 1, 1).dmg(10F).radius(7F).knock(1.6F).fire(4).colors(0xFFFFFF, 0xFFFFFF).particle(WeaponSpec.PType.SMOKE).muzzle(-1.125F, 1.986F, 1.405F));
    }

    private static MechaSpec laminador() {
        return new MechaSpec("laminador")
                .stats(250F, 20F, 7F, 0.2F, 0F)
                .size(2.22F, 3.12F, 1.62F, 1.33F)
                .glow(0xFF781E)
                .lore(3)
                .passives(Passive.TREADS, Passive.RAM)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.laminador.primary").anim(WeaponSpec.Anim.NONE).timing(60, 24, 6, 1, 1).dmg(16F).speed(1.6F).knock(1.4F).up(0F).colors(0xFFB060, 0xFFB060).particle(WeaponSpec.PType.SMOKE).flags("contact").muzzle(0.875F, 1.044F, 1.089F),
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.laminador.secondary").anim(WeaponSpec.Anim.SPIN).timing(20, 20, 3, 8, 2).dmg(3.5F).range(4.4F).angle(70F).fire(2).colors(0xFFA040, 0xFFA040).particle(WeaponSpec.PType.EMBER).muzzle(-0.875F, 1.074F, 1.081F));
    }

    private static MechaSpec fundidor() {
        return new MechaSpec("fundidor")
                .stats(170F, 15F, 4F, 0.27F, 0.9F)
                .size(1.68F, 3.5F, 2.16F, 1F)
                .glow(0xFF9628)
                .lore(3)
                .passives(Passive.FIRE_IMMUNE)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.fundidor.primary").anim(WeaponSpec.Anim.SPIN).timing(28, 24, 4, 10, 2).dmg(3F).speed(3F).spread(3F).fire(2).colors(0xFF8030, 0xFF8030).particle(WeaponSpec.PType.EMBER).item("minecraft:iron_ingot").muzzle(0.781F, 1.676F, 1.268F),
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.fundidor.secondary").anim(WeaponSpec.Anim.SWING).timing(30, 22, 9, 1, 1).dmg(14F).range(4.5F).angle(80F).knock(1F).fire(3).colors(0xFF9050, 0xFF9050).particle(WeaponSpec.PType.EMBER).muzzle(-0.781F, 1.36F, 1.154F));
    }

    private static MechaSpec escorpion() {
        return new MechaSpec("escorpion")
                .stats(170F, 15F, 4F, 0.27F, 0.7F)
                .size(3.4F, 1.59F, 0.6F, 2.04F)
                .glow(0xFFB43C)
                .lore(3)
                .passives(Passive.BRACED, Passive.CLIMBER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.escorpion.primary").anim(WeaponSpec.Anim.AIM).timing(60, 20, 12, 1, 1).dmg(30F).range(60F).colors(0xFFC060, 0xFFFFFF).particle(WeaponSpec.PType.SPARK).flags("pierce,charge").muzzle(0F, 1.406F, 2.094F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.escorpion.secondary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.SELF).timing(120, 20, 4, 1, 1).radius(6F).fx(WeaponSpec.Fx.SMOKE_STEALTH, 100, 0).colors(0xD8C090, 0xD8C090).particle(WeaponSpec.PType.SMOKE).muzzle(0F, 1.406F, 2.094F));
    }

    private static MechaSpec espejo() {
        return new MechaSpec("espejo")
                .stats(150F, 13F, 3F, 0.26F, 0F)
                .size(2.16F, 2.41F, 0.92F, 1.29F)
                .glow(0xFFE678)
                .lore(3)
                .passives(Passive.HOVER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.espejo.primary").anim(WeaponSpec.Anim.BEAM).timing(50, 36, 10, 26, 1).dmg(1.9F).range(48F).fire(4).colors(0xFFE070, 0xFFFFFF).particle(WeaponSpec.PType.SPARK).flags("setsFire").muzzle(1.188F, 1.656F, 0.75F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.espejo.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(120, 14, 8, 1, 1).radius(10F).fx(WeaponSpec.Fx.BLIND, 100, 0).fx2(WeaponSpec.Fx.GLOW).colors(0xFFFFE0, 0xFFFFE0).particle(WeaponSpec.PType.SPARK).muzzle(-1.188F, 1.656F, 0.75F));
    }

    private static MechaSpec duna() {
        return new MechaSpec("duna")
                .stats(220F, 19F, 6F, 0.23F, 0F)
                .size(2.18F, 2F, 0.81F, 1.31F)
                .glow(0xFFBE50)
                .lore(3)
                .passives(Passive.TREADS)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.duna.primary").anim(WeaponSpec.Anim.SPIN).timing(30, 30, 4, 9, 3).dmg(5F).speed(3.2F).spread(2F).power(0.8F).colors(0xFFC070, 0xFFC070).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:fire_charge").muzzle(0F, 1.344F, 1.5F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.duna.secondary").anim(WeaponSpec.Anim.AIM).timing(20, 20, 2, 9, 2).dmg(2.5F).speed(3.5F).spread(2.5F).colors(0xFFE090, 0xFFE090).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(-0.406F, 1.375F, 1.562F));
    }

    private static MechaSpec camello() {
        return new MechaSpec("camello")
                .stats(200F, 15F, 4F, 0.25F, 0.7F)
                .size(3F, 3.5F, 1.22F, 1.8F)
                .glow(0xFFC85A)
                .lore(3)
                .passives(Passive.SELF_REPAIR)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.camello.primary").anim(WeaponSpec.Anim.POD).timing(70, 34, 4, 8, 3).dmg(5F).speed(1.2F).spread(8F).power(1.2F).lob(0.3F).colors(0xFF9040, 0xFF9040).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:firework_rocket").flags("homing").muzzle(0F, 2.625F, -1F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.camello.secondary").anim(WeaponSpec.Anim.CAST).center(WeaponSpec.Center.SELF).timing(200, 20, 6, 1, 1).radius(7F).heal(18F).fx(WeaponSpec.Fx.HEAL, 60, 0).colors(0xA0FF90, 0xA0FF90).particle(WeaponSpec.PType.ORB).muzzle(0F, 2.625F, -1F));
    }

    private static MechaSpec simun() {
        return new MechaSpec("simun")
                .stats(130F, 11F, 3F, 0.35F, 1.5F)
                .size(1.38F, 2.88F, 1.62F, 0.82F)
                .glow(0xFF963C)
                .lore(3)
                .passives(Passive.AGILE)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.simun.primary").anim(WeaponSpec.Anim.AIM).timing(34, 24, 3, 20, 1).dmg(1.4F).range(8F).angle(24F).knock(0.3F).fx(WeaponSpec.Fx.BLIND, 30, 0).colors(0xE0C890, 0xE0C890).particle(WeaponSpec.PType.SMOKE).muzzle(0.719F, 1.259F, 1.093F),
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.simun.secondary").anim(WeaponSpec.Anim.NONE).timing(50, 14, 2, 1, 1).dmg(8F).speed(2.2F).knock(1F).up(0.15F).colors(0xE0C890, 0xE0C890).particle(WeaponSpec.PType.SMOKE).flags("contact").muzzle(-0.719F, 1.298F, 1.245F));
    }

    private static MechaSpec tormentadearena() {
        return new MechaSpec("tormentadearena")
                .stats(210F, 17F, 5F, 0.18F, 0F)
                .size(2.35F, 2.55F, 0.88F, 1.41F)
                .glow(0xFF8C32)
                .lore(3)
                .passives(Passive.TREADS, Passive.BRACED)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.tormentadearena.primary").anim(WeaponSpec.Anim.AIM).timing(140, 40, 10, 6, 4).dmg(10F).speed(1.4F).spread(7F).gravity(0.04F).power(2.4F).lob(0.6F).colors(0xFF7030, 0xFF7030).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:fire_charge").flags("setsFire").muzzle(0F, 2.239F, 1.364F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.tormentadearena.secondary").anim(WeaponSpec.Anim.POD).center(WeaponSpec.Center.SELF).timing(200, 20, 4, 1, 1).radius(30F).fx(WeaponSpec.Fx.GLOW, 300, 0).colors(0xFFF0A0, 0xFFF0A0).particle(WeaponSpec.PType.SPARK).muzzle(-0.438F, 1.719F, 0.844F));
    }

    private static MechaSpec acorazado() {
        return new MechaSpec("acorazado")
                .stats(300F, 22F, 8F, 0.17F, 0.4F)
                .size(2.95F, 3.56F, 1.59F, 1.77F)
                .glow(0xFFC878)
                .lore(3)
                .passives(Passive.AMPHIBIOUS, Passive.TITAN)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.acorazado.primary").anim(WeaponSpec.Anim.AIM).timing(90, 30, 8, 4, 5).dmg(14F).speed(2.4F).spread(2F).gravity(0.02F).power(2.6F).lob(0.15F).colors(0xFFA050, 0xFFA050).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:fire_charge").muzzle(0F, 3.219F, 2.031F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.acorazado.secondary").anim(WeaponSpec.Anim.AIM).timing(30, 20, 2, 6, 3).dmg(4F).speed(3.2F).spread(6F).power(0.6F).colors(0xFFD080, 0xFFD080).particle(WeaponSpec.PType.SMOKE).item("minecraft:iron_nugget").muzzle(0F, 3.219F, 2.031F));
    }

    private static MechaSpec ancla() {
        return new MechaSpec("ancla")
                .stats(210F, 18F, 6F, 0.22F, 0.6F)
                .size(2.18F, 3.88F, 2.38F, 1.31F)
                .glow(0x78D2FF)
                .lore(3)
                .passives(Passive.AMPHIBIOUS, Passive.BRACED)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MAGNET).name("weapon.blockwars.ancla.primary").anim(WeaponSpec.Anim.AIM).timing(50, 26, 6, 10, 2).dmg(2.5F).angle(18F).radius(16F).pull(0.6F).colors(0xC0D8FF, 0xFFFFFF).particle(WeaponSpec.PType.SPARK).muzzle(1F, 0.529F, 1.524F),
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.ancla.secondary").anim(WeaponSpec.Anim.SWING).timing(26, 20, 8, 1, 1).dmg(13F).range(4.5F).angle(90F).knock(1.6F).up(0.5F).colors(0xA0C0FF, 0xA0C0FF).particle(WeaponSpec.PType.SPARK).muzzle(-1F, 1.144F, 0.46F));
    }

    private static MechaSpec tiburon() {
        return new MechaSpec("tiburon")
                .stats(170F, 14F, 4F, 0.3F, 0.9F)
                .size(3.6F, 1.4F, 0.6F, 2.16F)
                .glow(0x78DCFF)
                .lore(3)
                .passives(Passive.AMPHIBIOUS, Passive.LIFESTEAL)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.tiburon.primary").anim(WeaponSpec.Anim.NONE).timing(36, 16, 3, 2, 5).dmg(11F).speed(1.4F).spread(2F).power(1.8F).colors(0x70E0FF, 0x70E0FF).particle(WeaponSpec.PType.ORB).trail(WeaponSpec.PType.ORB).item("minecraft:prismarine_shard").flags("homing").muzzle(0F, 1.05F, 2.092F),
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.tiburon.secondary").anim(WeaponSpec.Anim.NONE).timing(40, 14, 3, 1, 1).dmg(14F).speed(2F).knock(1F).up(0.2F).colors(0xFF6060, 0xFF6060).particle(WeaponSpec.PType.ORB).flags("contact").muzzle(0F, 1.05F, 2.092F));
    }

    private static MechaSpec faro() {
        return new MechaSpec("faro")
                .stats(180F, 15F, 4F, 0.24F, 0.7F)
                .size(2.18F, 4.69F, 3.78F, 1.31F)
                .glow(0xFFF0A0)
                .lore(3)
                .passives(Passive.STRIDER, Passive.NIGHT_VISION)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.faro.primary").anim(WeaponSpec.Anim.AIM).timing(55, 18, 6, 1, 1).dmg(18F).speed(2.8F).spread(0.5F).power(2.2F).colors(0xFFB060, 0xFFB060).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:fire_charge").muzzle(1F, 3.094F, 1.95F),
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.faro.secondary").anim(WeaponSpec.Anim.BEAM).timing(60, 40, 4, 34, 1).dmg(0.3F).range(48F).fx(WeaponSpec.Fx.GLOW, 200, 0).fx2(WeaponSpec.Fx.BLIND).colors(0xFFF6C0, 0xFFFFFF).particle(WeaponSpec.PType.ORB).flags("pierce").muzzle(-1F, 2.861F, 0.784F));
    }

    private static MechaSpec marea() {
        return new MechaSpec("marea")
                .stats(190F, 16F, 5F, 0.25F, 0.6F)
                .size(3.29F, 2.51F, 0.6F, 1.98F)
                .glow(0xFF7828)
                .lore(3)
                .passives(Passive.AMPHIBIOUS)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.marea.primary").anim(WeaponSpec.Anim.AIM).timing(60, 24, 4, 4, 4).dmg(12F).speed(0.8F).spread(12F).gravity(0.06F).power(2F).lob(0.6F).colors(0xFF5030, 0xFF5030).particle(WeaponSpec.PType.EMBER).item("minecraft:heavy_core").muzzle(0F, 2.227F, 1.135F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.marea.secondary").anim(WeaponSpec.Anim.POD).center(WeaponSpec.Center.AIM).timing(120, 40, 6, 5, 6).dmg(3F).range(16F).radius(5F).fire(6).fx(WeaponSpec.Fx.SLOW, 40, 0).colors(0x302020, 0x302020).particle(WeaponSpec.PType.SMOKE).flags("setsFire").muzzle(0F, 2.227F, 1.135F));
    }

    private static MechaSpec sombra() {
        return new MechaSpec("sombra")
                .stats(130F, 12F, 3F, 0.32F, 1.2F)
                .size(1.5F, 3.72F, 2.47F, 0.9F)
                .glow(0xFF3C32)
                .lore(3)
                .passives(Passive.STEALTH, Passive.NIGHT_VISION)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.sombra.primary").anim(WeaponSpec.Anim.AIM).timing(46, 14, 8, 1, 1).dmg(26F).range(80F).colors(0xFF5040, 0xFFFFFF).particle(WeaponSpec.PType.SPARK).flags("charge").muzzle(0.781F, 2.397F, 2.002F),
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.sombra.secondary").anim(WeaponSpec.Anim.SWING).timing(16, 14, 4, 1, 1).dmg(12F).range(3.8F).angle(80F).fire(2).colors(0xFF6040, 0xFF6040).particle(WeaponSpec.PType.EMBER).muzzle(-0.781F, 1.853F, 1.062F));
    }

    private static MechaSpec verdugo() {
        return new MechaSpec("verdugo")
                .stats(190F, 16F, 5F, 0.27F, 0.9F)
                .size(2.1F, 3.69F, 2.28F, 1.26F)
                .glow(0xFF281E)
                .lore(3)
                .passives(Passive.LIFESTEAL, Passive.SCRAP_ARMOR)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.verdugo.primary").anim(WeaponSpec.Anim.SPIN).timing(24, 24, 3, 10, 2).dmg(3.2F).range(4.4F).angle(90F).knock(0.1F).colors(0xFF5040, 0xFF5040).particle(WeaponSpec.PType.SPARK).flags("twin").muzzle(0.969F, 1.631F, 1.223F).muzzle2(-0.969F, 1.631F, 1.223F),
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.verdugo.secondary").anim(WeaponSpec.Anim.NONE).timing(60, 18, 5, 1, 1).dmg(15F).speed(1.8F).knock(1.6F).up(0.1F).colors(0xFF3030, 0xFF3030).particle(WeaponSpec.PType.SPARK).flags("contact").muzzle(-0.969F, 1.631F, 1.223F));
    }

    private static MechaSpec humo() {
        return new MechaSpec("humo")
                .stats(160F, 14F, 4F, 0.26F, 0.8F)
                .size(1.68F, 3.53F, 2.16F, 1F)
                .glow(0xBEFF3C)
                .lore(3)
                .passives(Passive.AMPHIBIOUS)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CONE).name("weapon.blockwars.humo.primary").anim(WeaponSpec.Anim.AIM).timing(50, 30, 4, 26, 1).dmg(0.6F).range(9F).angle(30F).fx(WeaponSpec.Fx.POISON, 80, 1).fx2(WeaponSpec.Fx.NAUSEA).colors(0xD0E040, 0xD0E040).particle(WeaponSpec.PType.TOXIC).muzzle(0.781F, 1.683F, 1.169F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.humo.secondary").anim(WeaponSpec.Anim.AIM).center(WeaponSpec.Center.AIM).timing(100, 60, 6, 10, 5).dmg(1F).range(20F).radius(4F).fx(WeaponSpec.Fx.WITHER, 40, 0).colors(0x90A030, 0x90A030).particle(WeaponSpec.PType.TOXIC).muzzle(-0.781F, 2.412F, 0.961F));
    }

    private static MechaSpec langosta() {
        return new MechaSpec("langosta")
                .stats(160F, 13F, 3F, 0.27F, 0.6F)
                .size(2.87F, 1.91F, 0.6F, 1.72F)
                .glow(0xFF4632)
                .lore(3)
                .passives(Passive.CLIMBER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.langosta.primary").anim(WeaponSpec.Anim.POD).timing(80, 40, 4, 14, 2).dmg(4F).speed(0.9F).spread(30F).power(0.7F).lob(0.6F).colors(0xFF5040, 0xFF5040).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:phantom_membrane").flags("homing").muzzle(0F, 1.25F, -0.375F),
                        new WeaponSpec(WeaponSpec.Kind.CHAIN).name("weapon.blockwars.langosta.secondary").anim(WeaponSpec.Anim.CAST).timing(40, 12, 5, 1, 1).dmg(6F).range(18F).fx(WeaponSpec.Fx.SLOW, 40, 1).colors(0xFF6060, 0xFF6060).particle(WeaponSpec.PType.SPARK).jumps(4).muzzle(0F, 1.25F, -0.375F));
    }

    private static MechaSpec pretoriano() {
        return new MechaSpec("pretoriano")
                .stats(230F, 21F, 7F, 0.22F, 0.5F)
                .size(2.18F, 3.81F, 2.38F, 1.31F)
                .glow(0xFFC878)
                .lore(3)
                .passives(Passive.FRONT_SHIELD, Passive.BRACED)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.pretoriano.primary").anim(WeaponSpec.Anim.SPIN).timing(30, 34, 6, 14, 2).dmg(2.5F).speed(3.6F).spread(3F).colors(0xFFD070, 0xFFD070).particle(WeaponSpec.PType.SPARK).item("minecraft:gold_nugget").muzzle(1F, 1.694F, 1.352F),
                        new WeaponSpec(WeaponSpec.Kind.WALL).name("weapon.blockwars.pretoriano.secondary").anim(WeaponSpec.Anim.STOMP).timing(160, 12, 2, 3, 3).range(2.5F).radius(2F).colors(0xFFC060, 0xFFC060).particle(WeaponSpec.PType.SHARD).item("minecraft:polished_blackstone_bricks").muzzle(1F, 1.694F, 1.352F));
    }

    private static MechaSpec urraca() {
        return new MechaSpec("urraca")
                .stats(160F, 14F, 4F, 0.27F, 0.8F)
                .size(1.8F, 3.41F, 1.97F, 1.08F)
                .glow(0x78DCFF)
                .lore(3)
                .passives(Passive.MAGNETIC, Passive.SCRAP_ARMOR)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MAGNET).name("weapon.blockwars.urraca.primary").anim(WeaponSpec.Anim.BEAM).timing(30, 30, 3, 13, 2).dmg(1F).angle(45F).radius(12F).pull(0.35F).colors(0x90D8FF, 0xFFE080).particle(WeaponSpec.PType.SPARK).muzzle(0.812F, 1.38F, 0.844F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.urraca.secondary").anim(WeaponSpec.Anim.AIM).timing(22, 14, 2, 1, 1).pellets(6).dmg(3F).speed(2.6F).spread(10F).colors(0xD0C090, 0xD0C090).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(-0.812F, 0.953F, 0.437F));
    }

    private static MechaSpec buitre() {
        return new MechaSpec("buitre")
                .stats(130F, 11F, 3F, 0.31F, 1F)
                .size(1.65F, 3.66F, 2.47F, 0.99F)
                .glow(0xFFA03C)
                .lore(3)
                .passives(Passive.FLIGHT, Passive.MAGNETIC)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.buitre.primary").anim(WeaponSpec.Anim.POUNCE).timing(50, 20, 4, 1, 1).dmg(14F).radius(3F).speed(1.7F).knock(1.2F).up(-0.4F).colors(0xFFA060, 0xFFA060).particle(WeaponSpec.PType.SPARK).flags("contact,land").muzzle(0.781F, 1.669F, 0.414F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.buitre.secondary").anim(WeaponSpec.Anim.AIM).timing(12, 10, 1, 3, 3).dmg(4F).speed(3.2F).spread(1.5F).colors(0xFFD090, 0xFFD090).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(-0.781F, 2.242F, 1.267F));
    }

    private static MechaSpec frankenstein() {
        return new MechaSpec("frankenstein")
                .stats(220F, 15F, 4F, 0.23F, 0.7F)
                .size(2.08F, 3.72F, 2.38F, 1.25F)
                .glow(0xA0FF78)
                .lore(3)
                .passives(Passive.SELF_REPAIR, Passive.SCRAP_ARMOR)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.frankenstein.primary").anim(WeaponSpec.Anim.SWING).timing(34, 26, 12, 1, 1).dmg(20F).range(6F).angle(140F).knock(2.2F).colors(0xC0C0C0, 0xC0C0C0).particle(WeaponSpec.PType.SMOKE).flags("shake").muzzle(0.938F, 0.529F, 1.524F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.frankenstein.secondary").anim(WeaponSpec.Anim.SPIN).timing(24, 24, 2, 10, 2).dmg(2.5F).speed(3.3F).spread(4F).colors(0xFFE090, 0xFFE090).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(-0.938F, 1.694F, 1.352F));
    }

    private static MechaSpec desguace() {
        return new MechaSpec("desguace")
                .stats(190F, 16F, 4F, 0.24F, 0.6F)
                .size(3.4F, 1.53F, 0.6F, 2.04F)
                .glow(0x78D2FF)
                .lore(3)
                .passives(Passive.SCRAP_ARMOR, Passive.CLIMBER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.desguace.primary").anim(WeaponSpec.Anim.BEAM).timing(40, 30, 4, 24, 1).dmg(2F).range(8F).fx(WeaponSpec.Fx.WEAKNESS, 60, 0).colors(0x80D8FF, 0xFFFFFF).particle(WeaponSpec.PType.SPARK).muzzle(0F, 1.406F, 1.031F),
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.desguace.secondary").anim(WeaponSpec.Anim.SWING).timing(28, 20, 8, 1, 1).dmg(15F).range(4.2F).angle(70F).knock(0.6F).fx(WeaponSpec.Fx.WEAKNESS, 80, 1).colors(0xFFC080, 0xFFC080).particle(WeaponSpec.PType.SPARK).muzzle(0F, 1.406F, 1.031F));
    }

    private static MechaSpec carronero() {
        return new MechaSpec("carronero")
                .stats(230F, 17F, 5F, 0.21F, 0F)
                .size(1.98F, 2.94F, 1.44F, 1.18F)
                .glow(0xFFAA3C)
                .lore(3)
                .passives(Passive.TREADS, Passive.RAM, Passive.MAGNETIC)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.carronero.primary").anim(WeaponSpec.Anim.AIM).timing(40, 16, 6, 1, 1).pellets(5).dmg(5F).speed(1.4F).spread(8F).gravity(0.04F).power(1F).lob(0.4F).colors(0xC0A080, 0xC0A080).particle(WeaponSpec.PType.SMOKE).item("minecraft:anvil").muzzle(-0.812F, 1.694F, 0.836F),
                        new WeaponSpec(WeaponSpec.Kind.MELEE).name("weapon.blockwars.carronero.secondary").anim(WeaponSpec.Anim.SWING).timing(26, 20, 8, 1, 1).dmg(14F).range(4.5F).angle(80F).knock(0.8F).colors(0xD0A070, 0xD0A070).particle(WeaponSpec.PType.SMOKE).muzzle(-0.812F, 1.694F, 0.836F));
    }

    private static MechaSpec grua() {
        return new MechaSpec("grua")
                .stats(190F, 16F, 5F, 0.22F, 0.6F)
                .size(2.2F, 5.22F, 3.62F, 1.32F)
                .glow(0xFFC850)
                .lore(3)
                .passives(Passive.STRIDER)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.grua.primary").anim(WeaponSpec.Anim.SWING).center(WeaponSpec.Center.AIM).timing(60, 24, 14, 1, 1).dmg(18F).range(24F).radius(3F).knock(0.8F).fx(WeaponSpec.Fx.SLOW, 60, 2).colors(0xE0B040, 0xE0B040).particle(WeaponSpec.PType.SMOKE).flags("shake").muzzle(1F, 1.697F, 1.638F),
                        new WeaponSpec(WeaponSpec.Kind.MAGNET).name("weapon.blockwars.grua.secondary").anim(WeaponSpec.Anim.AIM).timing(40, 24, 4, 10, 2).dmg(1F).angle(20F).radius(14F).pull(0.55F).colors(0xFFE080, 0xFFFFFF).particle(WeaponSpec.PType.SPARK).muzzle(-1F, 2.363F, 0.46F));
    }

    private static MechaSpec hormigonera() {
        return new MechaSpec("hormigonera")
                .stats(230F, 18F, 6F, 0.2F, 0F)
                .size(1.98F, 3F, 1.5F, 1.18F)
                .glow(0xFFC85A)
                .lore(3)
                .passives(Passive.TREADS, Passive.BRACED)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.hormigonera.primary").anim(WeaponSpec.Anim.AIM).center(WeaponSpec.Center.AIM).timing(50, 30, 4, 5, 5).dmg(3F).range(18F).radius(3.5F).fx(WeaponSpec.Fx.ROOT, 80, 0).colors(0xB8B8B0, 0xB8B8B0).particle(WeaponSpec.PType.SMOKE).muzzle(0.812F, 1.113F, 1.635F),
                        new WeaponSpec(WeaponSpec.Kind.WALL).name("weapon.blockwars.hormigonera.secondary").anim(WeaponSpec.Anim.STOMP).timing(140, 12, 2, 3, 3).range(3F).radius(3F).colors(0xC0C0C0, 0xC0C0C0).particle(WeaponSpec.PType.SMOKE).item("minecraft:gray_concrete").muzzle(-0.812F, 0.123F, 0.762F));
    }

    private static MechaSpec fortin() {
        return new MechaSpec("fortin")
                .stats(240F, 20F, 7F, 0.2F, 0.5F)
                .size(2.3F, 4.06F, 2.53F, 1.38F)
                .glow(0xFFBE50)
                .lore(3)
                .passives(Passive.BRACED, Passive.TITAN)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.fortin.primary").anim(WeaponSpec.Anim.SPIN).timing(26, 30, 4, 12, 2).dmg(3F).speed(3.5F).spread(2.5F).colors(0xFFD070, 0xFFD070).particle(WeaponSpec.PType.SPARK).item("minecraft:iron_nugget").muzzle(1.062F, 1.766F, 1.397F),
                        new WeaponSpec(WeaponSpec.Kind.WALL).name("weapon.blockwars.fortin.secondary").anim(WeaponSpec.Anim.STOMP).timing(300, 16, 2, 3, 4).radius(4F).colors(0xD0C0A0, 0xD0C0A0).particle(WeaponSpec.PType.SMOKE).item("minecraft:stone_bricks").flags("ring").muzzle(1.062F, 1.766F, 1.397F));
    }

    private static MechaSpec apisonadora() {
        return new MechaSpec("apisonadora")
                .stats(260F, 20F, 8F, 0.19F, 0F)
                .size(2.35F, 3.31F, 1.75F, 1.41F)
                .glow(0xFFB43C)
                .lore(3)
                .passives(Passive.TREADS, Passive.RAM, Passive.TITAN)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.MOVE).name("weapon.blockwars.apisonadora.primary").anim(WeaponSpec.Anim.NONE).timing(60, 26, 6, 1, 1).dmg(18F).speed(1.4F).knock(0.4F).up(0F).fx(WeaponSpec.Fx.SLOW, 60, 3).colors(0xC0A060, 0xC0A060).particle(WeaponSpec.PType.SMOKE).flags("contact").muzzle(0.906F, 0.8F, 1.013F),
                        new WeaponSpec(WeaponSpec.Kind.AREA).name("weapon.blockwars.apisonadora.secondary").anim(WeaponSpec.Anim.STOMP).center(WeaponSpec.Center.SELF).timing(50, 30, 4, 5, 5).dmg(5F).radius(4.5F).knock(0.2F).fx(WeaponSpec.Fx.SLOW, 40, 1).colors(0xA09070, 0xA09070).particle(WeaponSpec.PType.SMOKE).flags("shake").muzzle(0.906F, 0.8F, 1.013F));
    }

    private static MechaSpec demoledor() {
        return new MechaSpec("demoledor")
                .stats(200F, 17F, 5F, 0.23F, 0.6F)
                .size(2.24F, 2.99F, 1.22F, 1.34F)
                .glow(0xFFAA3C)
                .lore(3)
                .passives(Passive.BRACED)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.DRILL).name("weapon.blockwars.demoledor.primary").anim(WeaponSpec.Anim.STOMP).timing(40, 32, 4, 7, 4).dmg(9F).radius(1F).colors(0xFFB060, 0xFFB060).particle(WeaponSpec.PType.SMOKE).muzzle(0F, 2.535F, 1.186F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.demoledor.secondary").anim(WeaponSpec.Anim.AIM).timing(90, 20, 6, 3, 4).dmg(12F).speed(1.3F).spread(5F).gravity(0.04F).power(2.6F).lob(0.45F).colors(0xFF7030, 0xFF7030).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:tnt").muzzle(0F, 2.535F, 1.186F));
    }

    private static MechaSpec heraldo() {
        return new MechaSpec("heraldo")
                .stats(180F, 16F, 5F, 0.25F, 0F)
                .size(2.26F, 2.53F, 1.02F, 1.35F)
                .glow(0xFF323C)
                .lore(4)
                .passives(Passive.HOVER, Passive.NIGHT_VISION)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.CHAIN).name("weapon.blockwars.heraldo.primary").anim(WeaponSpec.Anim.AIM).timing(30, 12, 4, 1, 1).dmg(8F).range(24F).fx(WeaponSpec.Fx.GLOW, 200, 0).colors(0xFF4050, 0xFF4050).particle(WeaponSpec.PType.SPARK).jumps(5).muzzle(1.25F, 1.75F, 1.25F),
                        new WeaponSpec(WeaponSpec.Kind.LIGHTNING).name("weapon.blockwars.heraldo.secondary").anim(WeaponSpec.Anim.CAST).timing(200, 50, 10, 5, 8).range(64F).colors(0xFF6060, 0xFF6060).particle(WeaponSpec.PType.SPARK).muzzle(-1.25F, 1.75F, 0.75F));
    }

    private static MechaSpec angelus() {
        return new MechaSpec("angelus")
                .stats(200F, 16F, 6F, 0.2F, 0.4F)
                .size(2.18F, 3.25F, 1.41F, 1.31F)
                .glow(0xFF3C3C)
                .dangerous()
                .lore(5)
                .passives(Passive.BRACED, Passive.NIGHT_VISION)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.ORBITAL).name("weapon.blockwars.angelus.primary").anim(WeaponSpec.Anim.CAST).timing(900, 120, 80, 9, 4).range(128F).radius(9F).power(6F).colors(0xFF3040, 0xFFFFFF).particle(WeaponSpec.PType.VOID).flags("setsFire,charge,terrain").muzzle(0F, 3.062F, 0.812F),
                        new WeaponSpec(WeaponSpec.Kind.BEAM).name("weapon.blockwars.angelus.secondary").anim(WeaponSpec.Anim.BEAM).timing(30, 24, 4, 20, 1).dmg(1.2F).range(64F).fx(WeaponSpec.Fx.GLOW, 200, 0).colors(0xFF3040, 0xFFC0C0).particle(WeaponSpec.PType.SPARK).muzzle(0F, 3.062F, 0.812F));
    }

    private static MechaSpec tirano() {
        return new MechaSpec("tirano")
                .stats(300F, 22F, 9F, 0.24F, 0.6F)
                .size(2.92F, 4.78F, 3.22F, 1.76F)
                .glow(0xFF1E1E)
                .dangerous()
                .lore(5)
                .passives(Passive.ROGUE_AI, Passive.TITAN, Passive.NIGHT_VISION)
                .weapons(
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.tirano.primary").anim(WeaponSpec.Anim.SPIN).timing(34, 36, 6, 15, 2).dmg(4F).speed(3.6F).spread(3F).power(0.5F).colors(0xFF6040, 0xFF6040).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:fire_charge").muzzle(1.281F, 2.115F, 1.557F),
                        new WeaponSpec(WeaponSpec.Kind.PROJECTILE).name("weapon.blockwars.tirano.secondary").anim(WeaponSpec.Anim.POD).timing(100, 40, 6, 10, 3).dmg(7F).speed(1.1F).spread(10F).power(1.8F).lob(0.35F).colors(0xFF4030, 0xFF4030).particle(WeaponSpec.PType.EMBER).trail(WeaponSpec.PType.SMOKE).item("minecraft:firework_rocket").flags("homing").muzzle(1.375F, 4.25F, 0.438F));
    }

    public static final List<MechaSpec> ALL = List.of(
            baluarte(),
            avispon(),
            obus(),
            centinela(),
            coloso(),
            lancero(),
            serafin(),
            valquiria(),
            prisma(),
            espectro(),
            nova(),
            egida(),
            mandibula(),
            cascabel(),
            trituradora(),
            tetano(),
            topadora(),
            forjamagma(),
            yunque(),
            ceniza(),
            glaciar(),
            ventisca(),
            yeti(),
            lomoespino(),
            madreespora(),
            mantis(),
            revenant(),
            oraculo(),
            penitente(),
            llamatormentas(),
            cumulonimbo(),
            vendaval(),
            rompeolas(),
            cronos(),
            espejismo(),
            titan(),
            colmena(),
            peregrino(),
            helios(),
            eclipse(),
            barrena(),
            topo(),
            pala(),
            grisu(),
            iman(),
            capataz(),
            crisol(),
            prensa(),
            caldera(),
            laminador(),
            fundidor(),
            escorpion(),
            espejo(),
            duna(),
            camello(),
            simun(),
            tormentadearena(),
            acorazado(),
            ancla(),
            tiburon(),
            faro(),
            marea(),
            sombra(),
            verdugo(),
            humo(),
            langosta(),
            pretoriano(),
            urraca(),
            buitre(),
            frankenstein(),
            desguace(),
            carronero(),
            grua(),
            hormigonera(),
            fortin(),
            apisonadora(),
            demoledor(),
            heraldo(),
            angelus(),
            tirano());
}
