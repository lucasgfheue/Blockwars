package com.blockwars.mecha;

/** Data describing one weapon slot. Built fluently by the generated MechaSpecs class. */
public final class WeaponSpec {
    public enum Kind { PROJECTILE, BEAM, CONE, AREA, MELEE, MOVE, LIGHTNING, CHAIN, DRILL, REWIND, SINGULARITY, VENT, ORBITAL, WALL, MAGNET }
    public enum Anim { AIM, BEAM, SWING, STOMP, CAST, SPIN, POUNCE, POD, NONE }
    public enum Center { SELF, AIM, FRONT }
    public enum Fx { NONE, POISON, WITHER, SLOW, FREEZE, WEAKNESS, BLIND, NAUSEA, GLOW, ROOT, HEAL, SHIELD, TIME_SLOW, SMOKE_STEALTH }
    public enum PType { SPARK, ORB, EMBER, SHARD, SMOKE, FROST, TOXIC, VOID }

    public final Kind kind;
    public String nameKey = "";
    public Anim anim = Anim.AIM;
    public Center center = Center.SELF;
    public int cooldown = 20, duration = 10, windup = 0, count = 1, interval = 1, pellets = 1, fire = 0, fxTime = 60, fxAmp = 0, jumps = 3;
    public float damage = 4, range = 24, angle = 40, radius = 4, speed = 2.5F, spread = 1, gravity = 0, power = 0, knockback = 0,
            pull = 0, up = 0, lob = 0, heal = 0, heat = 0;
    public Fx fx = Fx.NONE, fx2 = Fx.NONE;
    public int color = 0xFFFFFF, color2 = 0xFFFFFF;
    public PType particle = PType.SPARK;
    public PType trail = null;
    public String item = "minecraft:iron_nugget";
    public boolean homing, pierce, setsFire, ring, upward, around, blink, contact, land, charge, extinguish, twin, shake, terrain;
    public float mr, mu = 1.5F, mf = 1.0F;        // muzzle (right, up, forward) in blocks
    public float mr2, mu2 = 1.5F, mf2 = 1.0F;     // second muzzle for twin weapons
    public boolean hasMuzzle2;

    public WeaponSpec(Kind kind) {
        this.kind = kind;
    }

    public WeaponSpec name(String key) { this.nameKey = key; return this; }
    public WeaponSpec anim(Anim a) { this.anim = a; return this; }
    public WeaponSpec center(Center c) { this.center = c; return this; }
    public WeaponSpec timing(int cooldown, int duration, int windup, int count, int interval) {
        this.cooldown = cooldown; this.duration = duration; this.windup = windup; this.count = count; this.interval = Math.max(1, interval); return this;
    }
    public WeaponSpec pellets(int n) { this.pellets = n; return this; }
    public WeaponSpec dmg(float d) { this.damage = d; return this; }
    public WeaponSpec range(float r) { this.range = r; return this; }
    public WeaponSpec angle(float a) { this.angle = a; return this; }
    public WeaponSpec radius(float r) { this.radius = r; return this; }
    public WeaponSpec speed(float s) { this.speed = s; return this; }
    public WeaponSpec spread(float s) { this.spread = s; return this; }
    public WeaponSpec gravity(float g) { this.gravity = g; return this; }
    public WeaponSpec power(float p) { this.power = p; return this; }
    public WeaponSpec knock(float k) { this.knockback = k; return this; }
    public WeaponSpec pull(float p) { this.pull = p; return this; }
    public WeaponSpec up(float u) { this.up = u; return this; }
    public WeaponSpec lob(float l) { this.lob = l; return this; }
    public WeaponSpec heal(float h) { this.heal = h; return this; }
    public WeaponSpec heat(float h) { this.heat = h; return this; }
    public WeaponSpec fire(int seconds) { this.fire = seconds; return this; }
    public WeaponSpec fx(Fx fx, int time, int amp) { this.fx = fx; this.fxTime = time; this.fxAmp = amp; return this; }
    public WeaponSpec fx2(Fx fx) { this.fx2 = fx; return this; }
    public WeaponSpec colors(int c1, int c2) { this.color = c1; this.color2 = c2; return this; }
    public WeaponSpec particle(PType p) { this.particle = p; return this; }
    public WeaponSpec trail(PType p) { this.trail = p; return this; }
    public WeaponSpec item(String id) { this.item = id; return this; }
    public WeaponSpec jumps(int j) { this.jumps = j; return this; }
    public WeaponSpec flags(String flags) {
        for (String f : flags.split(",")) {
            switch (f.trim()) {
                case "homing" -> homing = true;
                case "pierce" -> pierce = true;
                case "setsFire" -> setsFire = true;
                case "ring" -> ring = true;
                case "upward" -> upward = true;
                case "around" -> around = true;
                case "blink" -> blink = true;
                case "contact" -> contact = true;
                case "land" -> land = true;
                case "charge" -> charge = true;
                case "extinguish" -> extinguish = true;
                case "twin" -> twin = true;
                case "shake" -> shake = true;
                case "terrain" -> terrain = true;
                default -> { }
            }
        }
        return this;
    }
    public WeaponSpec muzzle(float r, float u, float f) { this.mr = r; this.mu = u; this.mf = f; return this; }
    public WeaponSpec muzzle2(float r, float u, float f) { this.mr2 = r; this.mu2 = u; this.mf2 = f; this.hasMuzzle2 = true; return this; }

    /** Index of the event fired at tick t (0-based), or -1 if no event happens at this tick. */
    public int eventIndex(int t) {
        if (t < this.windup) return -1;
        int d = t - this.windup;
        if (d % this.interval != 0) return -1;
        int i = d / this.interval;
        return i < this.count ? i : -1;
    }

    /** Seconds (from the start of the action) at which event i fires. */
    public float eventTime(int i) {
        return (this.windup + i * this.interval) / 20.0F;
    }
}
