package com.blockwars.mecha;

import java.util.EnumSet;
import java.util.Set;

/** Everything that defines one of the generated BlockWars mechas. */
public final class MechaSpec {
    public final String id;
    public float health = 150, armor = 12, toughness = 3, speed = 0.25F, jump = 1.0F, step = 1.6F;
    public float width = 2.0F, height = 3.4F, seat = 2.2F, shadow = 1.2F;
    public int glow = 0xFFFFFF;
    public boolean dangerous;
    public final Set<Passive> passives = EnumSet.noneOf(Passive.class);
    public WeaponSpec primary = new WeaponSpec(WeaponSpec.Kind.PROJECTILE);
    public WeaponSpec secondary = new WeaponSpec(WeaponSpec.Kind.PROJECTILE);
    public int loreLines;

    public MechaSpec(String id) {
        this.id = id;
    }

    public MechaSpec stats(float health, float armor, float toughness, float speed, float jump) {
        this.health = health; this.armor = armor; this.toughness = toughness; this.speed = speed; this.jump = jump; return this;
    }
    public MechaSpec size(float width, float height, float seat, float shadow) {
        this.width = width; this.height = height; this.seat = seat; this.shadow = shadow; return this;
    }
    public MechaSpec glow(int color) { this.glow = color; return this; }
    public MechaSpec dangerous() { this.dangerous = true; return this; }
    public MechaSpec lore(int lines) { this.loreLines = lines; return this; }
    public MechaSpec passives(Passive... ps) {
        for (Passive p : ps) this.passives.add(p);
        if (this.passives.contains(Passive.STRIDER)) this.step = 3.0F;
        if (this.passives.contains(Passive.TREADS)) this.step = 1.3F;
        return this;
    }
    public MechaSpec weapons(WeaponSpec primary, WeaponSpec secondary) {
        this.primary = primary; this.secondary = secondary; return this;
    }

    public boolean has(Passive p) {
        return this.passives.contains(p);
    }

    public boolean flies() {
        return has(Passive.FLIGHT) || has(Passive.HOVER);
    }
}
