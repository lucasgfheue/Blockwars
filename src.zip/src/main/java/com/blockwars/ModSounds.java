package com.blockwars;

import com.blockwars.mecha.MechaSpec;
import com.blockwars.mecha.MechaSpecs;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.HashMap;
import java.util.Map;

/** Every mecha has its own synthesized sounds: primary, secondary, step and ambient. */
public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, BlockWars.MODID);
    private static final Map<String, DeferredHolder<SoundEvent, SoundEvent>> BY_KEY = new HashMap<>();

    public static final String[] SLOTS = {"primary", "secondary", "step", "ambient"};
    public static final String[] GUN_SLOTS = {"fire", "reload", "special"};
    public static final String[] GUN_SHARED = {"hit", "kill", "headshot", "empty", "attach", "impact", "casing", "swarm", "jam", "spin", "grenade"};
    public static final String[] SHARED = {"alarm", "singularity", "meltdown", "charge", "hud", "rogue", "orbital", "klaxon"};

    static {
        for (MechaSpec spec : MechaSpecs.ALL) {
            for (String slot : SLOTS) {
                register(spec.id + "." + slot);
            }
        }
        for (String s : SHARED) {
            register("shared." + s);
        }
        for (com.blockwars.gun.GunSpec g : com.blockwars.gun.Guns.ALL) {
            for (String slot : GUN_SLOTS) register("gun." + g.id + "." + slot);
        }
        for (String s : GUN_SHARED) register("gun." + s);
    }

    private static void register(String key) {
        BY_KEY.put(key, SOUNDS.register(key, () -> SoundEvent.createVariableRangeEvent(BlockWars.id(key))));
    }

    /** Sound for a key like "baluarte.primary"; falls back to a vanilla sound if missing. */
    public static SoundEvent get(String key) {
        DeferredHolder<SoundEvent, SoundEvent> h = BY_KEY.get(key);
        return h != null ? h.get() : SoundEvents.IRON_GOLEM_STEP;
    }
}
