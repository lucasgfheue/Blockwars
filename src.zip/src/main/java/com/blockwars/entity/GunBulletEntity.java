package com.blockwars.entity;

import com.blockwars.ModEntities;
import com.blockwars.ModParticles;
import com.blockwars.gun.GunLogic;
import com.blockwars.mecha.WeaponSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;

/** A fast bullet / pellet. Rendered as a glowing tracer streak. */
public class GunBulletEntity extends ThrowableItemProjectile {
    private static final EntityDataAccessor<Integer> DATA_COLOR = SynchedEntityData.defineId(GunBulletEntity.class, EntityDataSerializers.INT);
    /** bit 0: hidden tracer (suppressor), bit 1: incendiary, bit 2: dragon's breath, bit 3: piercing */
    private static final EntityDataAccessor<Integer> DATA_FLAGS = SynchedEntityData.defineId(GunBulletEntity.class, EntityDataSerializers.INT);

    public float damage = 4;
    public int fireSeconds;
    public int pierce;
    public int bounces;
    public int maxAge = 40;
    public boolean breaksGlass;
    public boolean placesFire;
    @Nullable public Entity homingTarget;
    private final Set<Integer> hitIds = new HashSet<>();
    private boolean keepFlying;

    public GunBulletEntity(EntityType<? extends GunBulletEntity> type, Level level) {
        super(type, level);
    }

    public GunBulletEntity(Level level, LivingEntity shooter) {
        super(ModEntities.GUN_BULLET.get(), shooter, level);
        this.setNoGravity(true);
    }

    public void setLook(int color, boolean hidden, boolean incendiary, boolean dragon, boolean piercing) {
        this.entityData.set(DATA_COLOR, color);
        this.entityData.set(DATA_FLAGS, (hidden ? 1 : 0) | (incendiary ? 2 : 0) | (dragon ? 4 : 0) | (piercing ? 8 : 0));
    }

    public int getColor() {
        return this.entityData.get(DATA_COLOR);
    }

    public boolean isHidden() {
        return (this.entityData.get(DATA_FLAGS) & 1) != 0;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_COLOR, 0xFFE0A0);
        builder.define(DATA_FLAGS, 0);
    }

    @Override
    protected Item getDefaultItem() {
        return Items.IRON_NUGGET;
    }

    @Override
    protected double getDefaultGravity() {
        return 0.0;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            int flags = this.entityData.get(DATA_FLAGS);
            if ((flags & 4) != 0) {
                this.level().addParticle(ParticleTypes.FLAME, this.getX(), this.getY(), this.getZ(), 0, 0, 0);
                this.level().addParticle(ModParticles.of(WeaponSpec.PType.EMBER, 0xFF6020), this.getX(), this.getY(), this.getZ(), 0, 0.02, 0);
            } else if ((flags & 2) != 0 && this.random.nextInt(2) == 0) {
                this.level().addParticle(ModParticles.of(WeaponSpec.PType.EMBER, 0xFF8030), this.getX(), this.getY(), this.getZ(), 0, 0, 0);
            }
            if (this.isInWater()) {
                this.level().addParticle(ParticleTypes.BUBBLE, this.getX(), this.getY(), this.getZ(), 0, 0, 0);
            }
            return;
        }
        if (this.tickCount > this.maxAge) {
            this.discard();
            return;
        }
        if (this.isInWater()) {
            this.setDeltaMovement(this.getDeltaMovement().scale(0.6));
            if (this.getDeltaMovement().lengthSqr() < 0.05) this.discard();
        }
        if (this.homingTarget != null && this.homingTarget.isAlive() && this.tickCount > 1) {
            Vec3 v = this.getDeltaMovement();
            double sp = v.length();
            Vec3 want = this.homingTarget.getBoundingBox().getCenter().subtract(this.position()).normalize().scale(sp);
            this.setDeltaMovement(v.add(want.subtract(v).scale(0.35)).normalize().scale(sp));
            this.hasImpulse = true;
        }
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        if (this.hitIds.contains(entity.getId())) return false;
        if (entity instanceof GunBulletEntity) return false;
        return super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity e = result.getEntity();
        this.hitIds.add(e.getId());
        if (this.level().isClientSide) return;
        boolean head = false;
        float dmg = this.damage;
        if (e instanceof LivingEntity le && le.getBbHeight() > 0.9F && result.getLocation().y >= le.getEyeY() - 0.22) {
            head = true;
            dmg *= 1.6F;
        }
        GunLogic.damage(this.getOwner(), this, e, dmg, this.fireSeconds, head, this.getDeltaMovement(), 0.25F);
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!(this.level() instanceof ServerLevel level)) return;
        BlockPos pos = result.getBlockPos();
        BlockState st = level.getBlockState(pos);
        Vec3 at = result.getLocation();
        Player owner = this.getOwner() instanceof Player p ? p : null;
        // impact: chips of the block, sparks, a puff of dust
        if (!st.isAir()) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), at.x, at.y, at.z, 6, 0.08, 0.08, 0.08, 0.12);
        }
        level.sendParticles(ModParticles.of(WeaponSpec.PType.SPARK, this.getColor()), at.x, at.y, at.z, 4, 0.05, 0.05, 0.05, 0.15);
        level.sendParticles(ParticleTypes.SMOKE, at.x, at.y, at.z, 1, 0.02, 0.02, 0.02, 0.01);
        GunLogic.impactSound(level, at, st);
        // glass shatters
        boolean pane = st.is(Tags.Blocks.GLASS_PANES);
        if ((pane || (this.breaksGlass && st.is(Tags.Blocks.GLASS_BLOCKS))) && owner != null && level.mayInteract(owner, pos)) {
            level.destroyBlock(pos, false, owner);
            this.setDeltaMovement(this.getDeltaMovement().scale(0.7));
            this.keepFlying = true;
            return; // keeps flying through the window
        }
        // incendiary rounds and dragon's breath set things alight
        if (this.placesFire && owner != null) {
            BlockPos fp = pos.relative(result.getDirection());
            if (level.getBlockState(fp).isAir() && level.mayInteract(owner, fp) && this.random.nextFloat() < 0.45F) {
                level.setBlockAndUpdate(fp, Blocks.FIRE.defaultBlockState());
            }
        }
        // ricochet
        if (this.bounces > 0) {
            this.bounces--;
            Vec3 v = this.getDeltaMovement();
            Direction d = result.getDirection();
            v = switch (d.getAxis()) {
                case X -> new Vec3(-v.x, v.y, v.z);
                case Y -> new Vec3(v.x, -v.y, v.z);
                case Z -> new Vec3(v.x, v.y, -v.z);
            };
            this.setDeltaMovement(v.scale(0.85));
            this.setPos(at.x + d.getStepX() * 0.05, at.y + d.getStepY() * 0.05, at.z + d.getStepZ() * 0.05);
            this.damage *= 0.85F;
            this.hitIds.clear();
            this.hasImpulse = true;
            level.sendParticles(ModParticles.of(WeaponSpec.PType.SPARK, 0xFFFFFF), at.x, at.y, at.z, 8, 0.05, 0.05, 0.05, 0.25);
            this.keepFlying = true;
        }
    }

    @Override
    protected void onHit(HitResult result) {
        this.keepFlying = false;
        super.onHit(result);
        if (this.level().isClientSide) return;
        if (result.getType() == HitResult.Type.ENTITY) {
            if (this.pierce-- <= 0) this.discard();
            else this.damage *= 0.75F;
        } else if (result.getType() == HitResult.Type.BLOCK && !this.keepFlying) {
            this.discard();
        }
    }
}
