package com.blockwars.entity;

import com.blockwars.ModEntities;
import com.blockwars.ModParticles;
import com.blockwars.mecha.WeaponSpec;
import com.blockwars.mecha.Weapons;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/** Configurable projectile used by all generated mechas: bullets, shells, plasma, homing rockets, torpedoes... */
public class MechaShotEntity extends ThrowableItemProjectile {
    private static final EntityDataAccessor<Integer> DATA_COLOR = SynchedEntityData.defineId(MechaShotEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TRAIL = SynchedEntityData.defineId(MechaShotEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_GRAVITY = SynchedEntityData.defineId(MechaShotEntity.class, EntityDataSerializers.FLOAT);

    @Nullable private WeaponSpec spec;
    @Nullable private GenericMechaEntity mecha;
    @Nullable private Entity target;

    public MechaShotEntity(EntityType<? extends MechaShotEntity> type, Level level) {
        super(type, level);
    }

    public MechaShotEntity(Level level, Player pilot, GenericMechaEntity mecha, WeaponSpec spec) {
        super(ModEntities.SHOT.get(), pilot, level);
        this.spec = spec;
        this.mecha = mecha;
        this.entityData.set(DATA_COLOR, spec.color);
        this.entityData.set(DATA_TRAIL, spec.trail != null ? spec.trail.ordinal() : spec.particle.ordinal());
        this.entityData.set(DATA_GRAVITY, spec.gravity);
        this.setNoGravity(spec.gravity <= 0.0F);
        this.setItem(Weapons.itemStack(spec.item));
    }

    public void setTarget(@Nullable Entity target) {
        this.target = target;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_COLOR, 0xFFFFFF);
        builder.define(DATA_TRAIL, 0);
        builder.define(DATA_GRAVITY, 0.0F);
    }

    @Override
    protected Item getDefaultItem() {
        return Items.IRON_NUGGET;
    }

    @Override
    protected double getDefaultGravity() {
        return this.entityData.get(DATA_GRAVITY);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            WeaponSpec.PType[] types = WeaponSpec.PType.values();
            int t = this.entityData.get(DATA_TRAIL);
            WeaponSpec.PType p = types[Math.max(0, Math.min(types.length - 1, t))];
            this.level().addParticle(ModParticles.of(p, this.entityData.get(DATA_COLOR)), this.getX(), this.getY(), this.getZ(), 0, 0, 0);
            if (this.isInWater()) {
                this.level().addParticle(ParticleTypes.BUBBLE, this.getX(), this.getY(), this.getZ(), 0, 0, 0);
            }
            return;
        }
        if (this.spec == null || this.tickCount > 140) {
            this.discard();
            return;
        }
        // homing: steer toward the target
        if (this.spec.homing && this.tickCount > 4) {
            if (this.target == null || !this.target.isAlive()) {
                this.target = Weapons.findTarget(this, this.getOwner(), this.mecha, 28.0, 0.2);
            }
            if (this.target != null) {
                Vec3 v = this.getDeltaMovement();
                double sp = Math.max(0.6, v.length());
                Vec3 want = this.target.getBoundingBox().getCenter().subtract(this.position()).normalize().scale(sp);
                this.setDeltaMovement(v.add(want.subtract(v).scale(0.18)).normalize().scale(sp * 1.02));
                this.hasImpulse = true;
            }
        }
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        if (entity == this.mecha) return false;
        return super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (this.spec != null && result.getEntity() instanceof LivingEntity living && this.mecha != null && this.getOwner() instanceof Player pilot) {
            Weapons.hit(this.mecha, pilot, this.spec, living, this.spec.damage, this.position(), this);
        } else if (this.spec != null) {
            result.getEntity().hurt(this.damageSources().thrown(this, this.getOwner()), this.spec.damage);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide) {
            if (this.spec != null) {
                Weapons.impact(this.mecha, this.getOwner() instanceof Player p ? p : null, this.spec, this.position(), this);
            }
            this.discard();
        }
    }
}
