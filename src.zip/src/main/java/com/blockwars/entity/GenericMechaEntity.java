package com.blockwars.entity;

import com.blockwars.ModItems;
import com.blockwars.ModParticles;
import com.blockwars.ModSounds;
import com.blockwars.mecha.MechaSpec;
import com.blockwars.mecha.Passive;
import com.blockwars.mecha.WeaponSpec;
import com.blockwars.mecha.Weapons;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

/** One class drives all 40 generated mechas; behaviour comes from their {@link MechaSpec}. */
public class GenericMechaEntity extends BaseMechaEntity {
    private static final EntityDataAccessor<Integer> DATA_HEAT = SynchedEntityData.defineId(GenericMechaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ALERT = SynchedEntityData.defineId(GenericMechaEntity.class, EntityDataSerializers.INT);
    /** ROGUE_AI phase: 0 dormant, 1 waking up, 2 in control. */
    private static final EntityDataAccessor<Integer> DATA_ROGUE = SynchedEntityData.defineId(GenericMechaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_ROGUE_YAW = SynchedEntityData.defineId(GenericMechaEntity.class, EntityDataSerializers.FLOAT);
    public static final int MAX_HEAT = 1000;

    public final MechaSpec spec;

    // weapon / passive state (server side)
    public int shieldTicks;
    public int invisTicks;
    public final Set<Integer> moveHits = new HashSet<>();
    public boolean moveLanded = true;
    private int stillTicks;
    private int lastHurtTick = -1000;
    private int lastAttackTick = -1000;
    private final float[] healthHistory = new float[120];
    private int meltdownTicks = -1;
    private int unstableTicks = -1;
    private boolean unstableUsed;
    // singularity
    private Vec3 singularity;
    private int singularityTicks;
    private int singularityMax;
    private float singularityRadius;
    private float singularityPower;
    private Player singularityOwner;
    // orbital uplink
    public Vec3 orbitalTarget;
    public boolean orbitalDrift;
    // rogue AI: when set, weapons aim here instead of where the pilot looks
    public Vec3 aiAim;
    public Vec3 aiTargetPos;
    private int rogueTimer = 900;
    private int roguePhaseTicks;
    private LivingEntity rogueTarget;

    public GenericMechaEntity(EntityType<? extends GenericMechaEntity> type, Level level, MechaSpec spec) {
        super(type, level);
        this.spec = spec;
    }

    public static AttributeSupplier.Builder createAttributes(MechaSpec spec) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, spec.health)
                .add(Attributes.ARMOR, spec.armor)
                .add(Attributes.ARMOR_TOUGHNESS, spec.toughness)
                .add(Attributes.MOVEMENT_SPEED, spec.speed)
                .add(Attributes.KNOCKBACK_RESISTANCE, spec.has(Passive.RAM) || spec.has(Passive.TITAN) || spec.has(Passive.BRACED) ? 1.0 : 0.85)
                .add(Attributes.STEP_HEIGHT, spec.step)
                .add(Attributes.SAFE_FALL_DISTANCE, spec.flies() ? 40.0 : 12.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_HEAT, 0);
        builder.define(DATA_ALERT, 0);
        builder.define(DATA_ROGUE, 0);
        builder.define(DATA_ROGUE_YAW, 0.0F);
    }

    // ================================================================= configuration

    @Override
    public Item getCoreItem() {
        return ModItems.GENERATED_CORES.get(this.spec.id).get();
    }

    @Override
    protected double seatHeight() {
        return this.spec.seat;
    }

    @Override
    protected float jumpStrength() {
        return this.spec.has(Passive.TREADS) || this.spec.has(Passive.HOVER) ? 0.0F : this.spec.jump;
    }

    @Override
    public boolean canFly() {
        return this.spec.flies();
    }

    @Override
    protected double flightLift() {
        return this.spec.has(Passive.HOVER) ? 0.08 : 0.13;
    }

    @Override
    protected double flightMaxRise() {
        return this.spec.has(Passive.HOVER) ? 0.32 : 0.55;
    }

    @Override
    protected double glideSpeed() {
        return this.spec.has(Passive.HOVER) ? -0.1 : -0.22;
    }

    @Override protected int primaryCooldownTicks() { return this.spec.primary.cooldown; }
    @Override protected int secondaryCooldownTicks() { return this.spec.secondary.cooldown; }
    @Override protected int primaryDuration() { return this.spec.primary.duration; }
    @Override protected int secondaryDuration() { return this.spec.secondary.duration; }

    @Override
    public String primaryNameKey() {
        return "weapon.blockwars." + this.spec.id + ".primary";
    }

    @Override
    public String secondaryNameKey() {
        return "weapon.blockwars." + this.spec.id + ".secondary";
    }

    @Override
    public float getHeatFraction() {
        return this.spec.has(Passive.REACTOR) ? this.entityData.get(DATA_HEAT) / (float) MAX_HEAT : -1.0F;
    }

    @Override
    public int getAlertTicks() {
        return this.entityData.get(DATA_ALERT);
    }

    @Override
    public String getAlertKey() {
        if (this.spec.has(Passive.ROGUE_AI)) {
            return this.entityData.get(DATA_ROGUE) == 2 ? "hud.blockwars.rogue" : "hud.blockwars.rogue_warn";
        }
        return this.spec.has(Passive.REACTOR) ? "hud.blockwars.meltdown" : "hud.blockwars.singularity";
    }

    // ================================================================= weapons

    @Override
    protected void primaryTick(Player pilot, int t) {
        this.lastAttackTick = this.tickCount;
        Weapons.serverTick(this, pilot, this.spec.primary, t, true);
    }

    @Override
    protected void secondaryTick(Player pilot, int t) {
        this.lastAttackTick = this.tickCount;
        Weapons.serverTick(this, pilot, this.spec.secondary, t, false);
    }

    @Override
    protected void primaryClientTick(int t) {
        Weapons.clientTick(this, this.spec.primary, t, true);
    }

    @Override
    protected void secondaryClientTick(int t) {
        Weapons.clientTick(this, this.spec.secondary, t, false);
    }

    public void playSlot(String slot, float volume, float pitch) {
        SoundEvent s = ModSounds.get(this.spec.id + "." + slot);
        this.level().playSound(null, this.getX(), this.getY() + 1.5, this.getZ(), s, SoundSource.NEUTRAL, volume,
                pitch * (0.95F + this.random.nextFloat() * 0.1F));
    }

    public void playShared(String name, float volume, float pitch) {
        this.level().playSound(null, this.getX(), this.getY() + 1.5, this.getZ(), ModSounds.get("shared." + name), SoundSource.NEUTRAL, volume, pitch);
    }

    // ================================================================= heat (HELIOS)

    public void addHeat(float amount) {
        if (!this.spec.has(Passive.REACTOR)) return;
        this.entityData.set(DATA_HEAT, Mth.clamp(this.entityData.get(DATA_HEAT) + Math.round(amount), 0, MAX_HEAT));
    }

    public void ventHeat() {
        this.entityData.set(DATA_HEAT, 0);
        if (this.meltdownTicks >= 0) {
            this.meltdownTicks = -1;
            this.entityData.set(DATA_ALERT, 0);
            if (this.getControllingPassenger() instanceof Player p) {
                p.displayClientMessage(Component.translatable("message.blockwars.meltdown_averted"), true);
            }
        }
    }

    private void tickReactor(Player pilot) {
        int heat = this.entityData.get(DATA_HEAT);
        if (this.tickCount - this.lastAttackTick > 30 && heat > 0) {
            this.entityData.set(DATA_HEAT, Math.max(0, heat - 3));
        }
        if (heat >= MAX_HEAT && this.meltdownTicks < 0) {
            this.meltdownTicks = 140;
            if (pilot != null) pilot.displayClientMessage(Component.translatable("message.blockwars.meltdown_start"), false);
        }
        if (this.meltdownTicks >= 0) {
            this.entityData.set(DATA_ALERT, this.meltdownTicks);
            if (this.meltdownTicks % 10 == 0) this.playShared("alarm", 2.0F, 1.0F + (140 - this.meltdownTicks) / 140.0F);
            if (this.level() instanceof ServerLevel sl) {
                sl.sendParticles(ModParticles.of(WeaponSpec.PType.EMBER, 0xFF3010), this.getX(), this.getY() + 2.2, this.getZ(),
                        6, 0.8, 1.2, 0.8, 0.05);
            }
            if (this.meltdownTicks-- == 0) {
                this.meltdown(9.0F, true);
            }
        }
    }

    /** The reactor lets go. The pilot is thrown out first — which does not save them. */
    private void meltdown(float power, boolean terrain) {
        this.playShared("meltdown", 4.0F, 0.8F);
        Vec3 c = this.position().add(0, 1.5, 0);
        for (Entity p : this.getPassengers()) {
            p.stopRiding();
            p.setDeltaMovement(this.random.nextGaussian() * 0.6, 1.2, this.random.nextGaussian() * 0.6);
            p.hurtMarked = true;
        }
        this.ejectPassengers();
        this.level().explode(this, c.x, c.y, c.z, power, true,
                terrain ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.MOB);
        this.discard();
    }

    // ================================================================= singularity (ECLIPSE)

    public void startSingularity(Vec3 center, float radius, float power, int ticks, Player owner) {
        this.singularity = center;
        this.singularityRadius = radius;
        this.singularityPower = power;
        this.singularityTicks = ticks;
        this.singularityMax = ticks;
        this.singularityOwner = owner;
        if (owner != null) {
            owner.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0));
            owner.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 160, 0));
        }
        this.playShared("singularity", 4.0F, 0.7F);
    }

    private void tickSingularity() {
        if (this.singularity == null || !(this.level() instanceof ServerLevel sl)) return;
        int age = this.singularityMax - this.singularityTicks;
        Vec3 c = this.singularity;
        float R = this.singularityRadius;
        float eat = Math.min(5.5F, 1.0F + age * 0.045F);
        if (this.singularityTicks % 20 == 0) {
            sl.playSound(null, c.x, c.y, c.z, ModSounds.get("shared.singularity"), SoundSource.HOSTILE, 3.0F, 0.6F + age * 0.004F);
        }
        // visuals: accretion disc + dark core
        for (int i = 0; i < 24; i++) {
            double a = (age * 0.35 + i * (Math.PI * 2 / 24));
            double rr = eat + 1.5 + (i % 3) * 0.8;
            sl.sendParticles(ModParticles.of(WeaponSpec.PType.VOID, i % 2 == 0 ? 0xA060FF : 0xFFFFFF),
                    c.x + Math.cos(a) * rr, c.y + Math.sin(a * 2) * 0.3, c.z + Math.sin(a) * rr, 0,
                    -Math.sin(a) * 0.4 - Math.cos(a) * 0.15, 0, Math.cos(a) * 0.4 - Math.sin(a) * 0.15, 1.0);
        }
        sl.sendParticles(ModParticles.of(WeaponSpec.PType.SMOKE, 0x050508), c.x, c.y, c.z, 8, eat * 0.3, eat * 0.3, eat * 0.3, 0.0);
        // pull everything — including this mecha and its pilot
        for (Entity e : sl.getEntities((Entity) null, new AABB(c, c).inflate(R), e -> e.isAlive() && !e.isSpectator()
                && !(e instanceof Player pl && pl.getAbilities().flying))) {
            if (e.isPassenger() && !(e.getVehicle() == null)) continue;
            Vec3 d = c.subtract(e.position().add(0, e.getBbHeight() / 2, 0));
            double dist = d.length();
            if (dist > R) continue;
            double strength = (0.06 + 0.22 * (1.0 - dist / R)) * (e == this ? 0.6 : 1.0);
            e.setDeltaMovement(e.getDeltaMovement().scale(0.85).add(d.normalize().scale(strength)));
            e.hurtMarked = true;
            e.fallDistance = 0;
            if (dist < eat * 0.6 + 1.0) {
                if (e instanceof ItemEntity) {
                    e.discard();
                } else if (e == this) {
                    if (this.isVehicle()) {
                        for (Entity p : this.getPassengers()) {
                            if (p instanceof Player pl) pl.displayClientMessage(Component.translatable("message.blockwars.event_horizon"), false);
                        }
                        this.ejectPassengers();
                    }
                    super.hurt(this.damageSources().magic(), 6.0F);
                } else if (e instanceof LivingEntity le) {
                    le.hurt(this.damageSources().magic(), 6.0F);
                }
            }
        }
        // devour terrain (respects the mobGriefing gamerule)
        if (sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            BlockPos center = BlockPos.containing(c);
            int r = (int) Math.ceil(eat);
            for (int i = 0; i < 70; i++) {
                BlockPos p = center.offset(this.random.nextInt(2 * r + 1) - r, this.random.nextInt(2 * r + 1) - r, this.random.nextInt(2 * r + 1) - r);
                if (p.distSqr(center) > eat * eat) continue;
                BlockState st = sl.getBlockState(p);
                if (st.isAir() || st.getDestroySpeed(sl, p) < 0) continue;
                if (this.random.nextInt(4) == 0) {
                    sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 4, 0.3, 0.3, 0.3, 0.1);
                }
                sl.removeBlock(p, false);
            }
        }
        if (--this.singularityTicks <= 0) {
            Vec3 at = this.singularity;
            this.singularity = null;
            sl.explode(this, at.x, at.y, at.z, this.singularityPower, false, Level.ExplosionInteraction.MOB);
            sl.sendParticles(ModParticles.of(WeaponSpec.PType.VOID, 0xFFFFFF), at.x, at.y, at.z, 120, 2.0, 2.0, 2.0, 0.6);
        }
    }

    private void tickUnstable(Player pilot) {
        if (this.unstableUsed || this.singularity != null) return;
        if (this.unstableTicks < 0 && this.getHealth() < this.getMaxHealth() * 0.25F && this.getHealth() > 0) {
            this.unstableTicks = 100;
            if (pilot != null) pilot.displayClientMessage(Component.translatable("message.blockwars.unstable"), false);
        }
        if (this.unstableTicks >= 0) {
            this.entityData.set(DATA_ALERT, this.unstableTicks);
            if (this.unstableTicks % 10 == 0) this.playShared("alarm", 2.0F, 0.7F);
            if (this.unstableTicks-- == 0) {
                this.unstableUsed = true;
                this.entityData.set(DATA_ALERT, 0);
                this.startSingularity(this.position().add(0, 1.5, 0), 12.0F, 6.0F, 120, pilot);
            }
        }
    }

    // ================================================================= rogue AI (the one that wakes up)

    public boolean isRogueActive() {
        return this.spec.has(Passive.ROGUE_AI) && this.entityData.get(DATA_ROGUE) == 2 && this.isAlive();
    }

    private void tickRogue(Player pilot) {
        int phase = this.entityData.get(DATA_ROGUE);
        if (pilot == null) {
            if (phase != 0) this.endRogue(null);
            this.rogueTimer = Math.max(this.rogueTimer, 200);
            return;
        }
        if (phase == 0) {
            // damage makes it wake up sooner
            int rate = this.getHealth() < this.getMaxHealth() * 0.5F ? 3 : 1;
            this.rogueTimer -= rate;
            if (this.rogueTimer <= 0) {
                this.entityData.set(DATA_ROGUE, 1);
                this.roguePhaseTicks = 60;
                pilot.displayClientMessage(Component.translatable("message.blockwars.rogue_warn"), false);
                this.playShared("rogue", 2.0F, 0.6F);
            }
            return;
        }
        this.entityData.set(DATA_ALERT, this.roguePhaseTicks);
        if (phase == 1) {
            if (this.roguePhaseTicks % 10 == 0) this.playShared("alarm", 1.5F, 0.5F);
            if (--this.roguePhaseTicks <= 0) {
                this.entityData.set(DATA_ROGUE, 2);
                this.roguePhaseTicks = 200;
                pilot.displayClientMessage(Component.translatable("message.blockwars.rogue_start"), false);
                this.playShared("rogue", 3.0F, 1.0F);
                pilot.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 220, 0));
            }
            return;
        }
        // phase 2: it drives. It hunts the nearest living thing that isn't its pilot.
        if (this.rogueTarget == null || !this.rogueTarget.isAlive() || this.rogueTarget.distanceTo(this) > 32 || this.tickCount % 40 == 0) {
            this.rogueTarget = null;
            double best = 28 * 28;
            for (LivingEntity e : this.level().getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(28),
                    e -> e != this && e != pilot && e.isAlive() && e.getVehicle() != this && !(e instanceof Player p && (p.isCreative() || p.isSpectator())))) {
                double d = e.distanceToSqr(this);
                if (d < best) { best = d; this.rogueTarget = e; }
            }
        }
        if (this.rogueTarget != null) {
            Vec3 tc = this.rogueTarget.getBoundingBox().getCenter();
            Vec3 eye = this.position().add(0, this.getBbHeight() * 0.7, 0);
            this.aiAim = tc.subtract(eye).normalize();
            this.aiTargetPos = tc;
            Vec3 flat = tc.subtract(this.position());
            this.entityData.set(DATA_ROGUE_YAW, (float) Math.toDegrees(Math.atan2(flat.z, flat.x)) - 90.0F);
            double dist = flat.length();
            if (dist < this.spec.primary.range + 4 || this.spec.primary.kind == WeaponSpec.Kind.PROJECTILE) this.tryPrimary(pilot);
            if (this.random.nextInt(30) == 0) this.trySecondary(pilot);
        } else {
            // nothing to kill: it wanders, scanning
            this.aiAim = null;
            this.aiTargetPos = null;
            this.entityData.set(DATA_ROGUE_YAW, this.getYRot() + 6.0F);
        }
        if (this.level() instanceof ServerLevel sl && this.tickCount % 3 == 0) {
            sl.sendParticles(ModParticles.of(WeaponSpec.PType.SPARK, 0xFF2020), this.getRandomX(0.8), this.getRandomY(), this.getRandomZ(0.8), 1, 0, 0, 0, 0.02);
        }
        if (this.roguePhaseTicks % 40 == 0) this.playShared("rogue", 1.2F, 0.8F + this.random.nextFloat() * 0.4F);
        if (--this.roguePhaseTicks <= 0) this.endRogue(pilot);
    }

    private void endRogue(Player pilot) {
        this.entityData.set(DATA_ROGUE, 0);
        this.entityData.set(DATA_ALERT, 0);
        this.aiAim = null;
        this.aiTargetPos = null;
        this.rogueTarget = null;
        this.rogueTimer = 600 + this.random.nextInt(600);
        if (pilot != null) pilot.displayClientMessage(Component.translatable("message.blockwars.rogue_end"), false);
    }

    @Override
    public void tickRidden(Player player, Vec3 travelVector) {
        super.tickRidden(player, travelVector);
        if (this.isRogueActive()) {
            float target = this.entityData.get(DATA_ROGUE_YAW);
            float diff = Mth.clamp(Mth.wrapDegrees(target - this.getYRot()), -9.0F, 9.0F);
            float yaw = this.getYRot() + diff;
            this.setRot(yaw, 0.0F);
            this.yRotO = yaw;
            this.yBodyRot = yaw;
            this.yHeadRot = yaw;
        }
    }

    @Override
    public Vec3 getRiddenInput(Player player, Vec3 travelVector) {
        if (this.isRogueActive()) {
            return new Vec3(0.0, 0.0, 0.75); // it walks wherever it wants
        }
        return super.getRiddenInput(player, travelVector);
    }

    // ================================================================= ticking

    @Override
    public void tick() {
        super.tick();
        Player pilot = this.getControllingPassenger() instanceof Player p ? p : null;
        if (this.level().isClientSide) {
            this.clientEffects();
            return;
        }
        this.healthHistory[this.tickCount % this.healthHistory.length] = this.getHealth();
        if (this.shieldTicks > 0) {
            this.shieldTicks--;
            if (this.shieldTicks % 4 == 0 && this.level() instanceof ServerLevel sl) {
                for (int i = 0; i < 10; i++) {
                    double a = this.random.nextDouble() * Math.PI * 2, b = this.random.nextDouble() * Math.PI;
                    double r = Math.max(this.getBbWidth(), this.getBbHeight()) * 0.7;
                    sl.sendParticles(ModParticles.of(WeaponSpec.PType.SHARD, this.spec.glow), this.getX() + Math.cos(a) * Math.sin(b) * r,
                            this.getY() + this.getBbHeight() / 2 + Math.cos(b) * r, this.getZ() + Math.sin(a) * Math.sin(b) * r, 1, 0, 0, 0, 0);
                }
            }
        }
        // stealth
        boolean moving = this.getDeltaMovement().horizontalDistanceSqr() > 0.0004;
        this.stillTicks = moving ? 0 : this.stillTicks + 1;
        if (this.invisTicks > 0) this.invisTicks--;
        boolean stealth = this.invisTicks > 0 || (this.spec.has(Passive.STEALTH) && this.stillTicks > 40 && this.tickCount - this.lastAttackTick > 40);
        if (stealth != this.isInvisible()) {
            this.setInvisible(stealth);
            if (pilot != null) pilot.setInvisible(stealth);
        }
        if (this.spec.has(Passive.SELF_REPAIR) && this.tickCount % 40 == 0 && this.tickCount - this.lastHurtTick > 100 && this.getHealth() < this.getMaxHealth()) {
            this.heal(2.0F);
        }
        if (this.spec.has(Passive.STORM) && this.level().isThundering()) {
            if (this.primaryCooldown > 0) this.primaryCooldown--;
            if (this.secondaryCooldown > 0) this.secondaryCooldown--;
        }
        if (pilot != null) {
            if (this.spec.has(Passive.NIGHT_VISION) && this.tickCount % 80 == 0) {
                pilot.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, true, false));
            }
            if (this.spec.has(Passive.AMPHIBIOUS) && this.isInWater() && this.tickCount % 40 == 0) {
                pilot.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 200, 0, true, false));
            }
            if (pilot.isOnFire() && (this.spec.has(Passive.FIRE_IMMUNE) || this.spec.has(Passive.LAVA_WALKER))) {
                pilot.clearFire();
            }
        }
        if (this.spec.has(Passive.FROST_WALKER) && this.tickCount % 2 == 0) {
            this.freezeWater();
        }
        if (this.spec.has(Passive.RAM) && moving && this.tickCount % 5 == 0) {
            Vec3 fwd = this.forward();
            for (LivingEntity e : this.level().getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().move(fwd.scale(1.0)).inflate(0.3),
                    e -> e != this && e != pilot && e.getVehicle() != this)) {
                e.knockback(0.9, -fwd.x, -fwd.z);
                e.hurtMarked = true;
            }
        }
        if (this.spec.has(Passive.REACTOR)) this.tickReactor(pilot);
        if (this.spec.has(Passive.UNSTABLE)) this.tickUnstable(pilot);
        if (this.spec.has(Passive.ROGUE_AI)) this.tickRogue(pilot);
        if (this.spec.has(Passive.MAGNETIC) && pilot != null && this.tickCount % 4 == 0 && this.level() instanceof ServerLevel sl) {
            Weapons.vacuum(sl, this, pilot, this.position().add(0, this.getBbHeight() * 0.5, 0), 7.0, 0.3);
        }
        if (this.singularity != null) this.tickSingularity();
        // landing shockwave for leap attacks
        if (!this.moveLanded && this.onGround() && pilot != null) {
            this.moveLanded = true;
            WeaponSpec w = this.spec.primary.kind == WeaponSpec.Kind.MOVE && this.spec.primary.land ? this.spec.primary : this.spec.secondary;
            Weapons.landing(this, pilot, w);
        }
        // ambient engine sound
        if (pilot != null && this.tickCount % 100 == 0) {
            this.playSlot("ambient", 0.45F, 1.0F);
        }
    }

    private void clientEffects() {
        if (this.spec.has(Passive.GLOW_AURA) && this.random.nextInt(3) == 0) {
            this.level().addParticle(ModParticles.of(WeaponSpec.PType.EMBER, this.spec.glow),
                    this.getRandomX(0.8), this.getRandomY(), this.getRandomZ(0.8), 0, 0.03, 0);
        }
        if (this.spec.has(Passive.UNSTABLE) && this.random.nextInt(4) == 0) {
            this.level().addParticle(ModParticles.of(WeaponSpec.PType.VOID, 0x8040FF),
                    this.getRandomX(1.0), this.getRandomY(), this.getRandomZ(1.0), 0, -0.02, 0);
        }
        if (this.spec.has(Passive.REACTOR) && this.getHeatFraction() > 0.5F && this.random.nextFloat() < this.getHeatFraction()) {
            this.level().addParticle(ParticleTypes.LARGE_SMOKE, this.getRandomX(0.6), this.getY() + this.getBbHeight(), this.getRandomZ(0.6), 0, 0.08, 0);
        }
        if (this.canFly() && this.getBoostAmount(1.0F) > 0.2F) {
            Vec3 p = this.localPoint(0, this.spec.has(Passive.HOVER) ? 0.4 : 1.8, -0.5);
            this.level().addParticle(ModParticles.of(WeaponSpec.PType.EMBER, this.spec.glow), p.x, p.y, p.z, 0, -0.3, 0);
        }
        if (this.isRogueActive() && this.random.nextInt(2) == 0) {
            this.level().addParticle(ModParticles.of(WeaponSpec.PType.SPARK, 0xFF3030), this.getRandomX(0.9), this.getRandomY(), this.getRandomZ(0.9), 0, 0.02, 0);
        }
        if (this.spec.has(Passive.MAGNETIC) && this.random.nextInt(5) == 0) {
            double a = this.random.nextDouble() * Math.PI * 2;
            this.level().addParticle(ModParticles.of(WeaponSpec.PType.SPARK, this.spec.glow), this.getX() + Math.cos(a) * 3, this.getY() + 1, this.getZ() + Math.sin(a) * 3,
                    -Math.cos(a) * 0.15, 0, -Math.sin(a) * 0.15);
        }
        if (this.spec.has(Passive.HOVER) && this.random.nextInt(2) == 0) {
            this.level().addParticle(ModParticles.of(WeaponSpec.PType.ORB, this.spec.glow), this.getRandomX(0.3), this.getY() + 0.2, this.getRandomZ(0.3), 0, -0.05, 0);
        }
    }

    private void freezeWater() {
        BlockPos base = this.blockPosition().below();
        int r = 3;
        for (BlockPos p : BlockPos.betweenClosed(base.offset(-r, 0, -r), base.offset(r, 0, r))) {
            if (p.distSqr(base) > r * r) continue;
            BlockState st = this.level().getBlockState(p);
            if (st.is(Blocks.WATER) && st.getFluidState().isSource() && this.level().getBlockState(p.above()).isAir()) {
                this.level().setBlockAndUpdate(p, Blocks.FROSTED_ICE.defaultBlockState());
                this.level().scheduleTick(p, Blocks.FROSTED_ICE, Mth.nextInt(this.random, 60, 120));
            }
        }
    }

    // ================================================================= passives hooks

    @Override
    public boolean onClimbable() {
        if (this.spec.has(Passive.CLIMBER) && this.horizontalCollision && this.isVehicle()) return true;
        return super.onClimbable();
    }

    @Override
    public boolean canStandOnFluid(FluidState fluid) {
        if (this.spec.has(Passive.LAVA_WALKER) && fluid.is(FluidTags.LAVA)) return true;
        return super.canStandOnFluid(fluid);
    }

    @Override
    protected float getWaterSlowDown() {
        return this.spec.has(Passive.AMPHIBIOUS) ? 0.96F : super.getWaterSlowDown();
    }

    @Override
    protected float modifyIncomingDamage(DamageSource source, float amount) {
        this.lastHurtTick = this.tickCount;
        if (this.shieldTicks > 0) {
            this.playSlot("ambient", 0.6F, 1.8F);
            return 0.0F;
        }
        if (this.spec.has(Passive.STORM) && source.is(DamageTypes.LIGHTNING_BOLT)) return 0.0F;
        float a = amount;
        if (this.spec.has(Passive.FRONT_SHIELD)) {
            Vec3 src = source.getSourcePosition();
            if (src != null) {
                Vec3 to = src.subtract(this.position()).multiply(1, 0, 1);
                if (to.lengthSqr() > 0.01 && to.normalize().dot(this.forward()) > 0.3) a *= 0.55F;
            }
        }
        if (this.spec.has(Passive.BRACED) && this.stillTicks > 20) a *= 0.7F;
        if (this.spec.has(Passive.SCRAP_ARMOR) && this.random.nextFloat() < 0.25F) a *= 0.4F;
        return a;
    }

    public void markAttack() {
        this.lastAttackTick = this.tickCount;
    }

    /** Health this mecha had `ticks` ago (REWIND). */
    public float pastHealth(int ticks) {
        int i = Math.floorMod(this.tickCount - ticks, this.healthHistory.length);
        float h = this.healthHistory[i];
        return h > 0 ? h : this.getHealth();
    }

    @Override
    public void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(ModSounds.get(this.spec.id + ".step"), this.spec.has(Passive.TITAN) ? 1.4F : 0.9F, 0.9F + this.random.nextFloat() * 0.2F);
        if (this.spec.has(Passive.TITAN) && this.level() instanceof ServerLevel sl) {
            sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), this.getX(), this.getY() + 0.1, this.getZ(), 16,
                    this.getBbWidth() * 0.4, 0.05, this.getBbWidth() * 0.4, 0.15);
        }
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            if (this.spec.has(Passive.REACTOR) && this.entityData.get(DATA_HEAT) > 400) {
                super.die(source);
                this.level().explode(this, this.getX(), this.getY() + 1.5, this.getZ(), 5.0F, true, Level.ExplosionInteraction.MOB);
                return;
            }
            if (this.singularity != null) {
                Vec3 at = this.singularity;
                this.singularity = null;
                this.level().explode(this, at.x, at.y, at.z, this.singularityPower, false, Level.ExplosionInteraction.MOB);
            }
        }
        super.die(source);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Heat", this.entityData.get(DATA_HEAT));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_HEAT, tag.getInt("Heat"));
    }
}
