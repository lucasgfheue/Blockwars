package com.blockwars.entity;

import com.blockwars.ModParticles;
import com.blockwars.ModSounds;
import com.blockwars.gun.GunLogic;
import com.blockwars.mecha.WeaponSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/** A short-lived black hole opened by UMBRAL. It does not care who fired it. */
public class SingularityEntity extends Entity {
    private static final EntityDataAccessor<Integer> DATA_LIFE = SynchedEntityData.defineId(SingularityEntity.class, EntityDataSerializers.INT);
    private static final float RADIUS = 14.0F;
    @Nullable private UUID ownerId;

    public SingularityEntity(EntityType<? extends SingularityEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public void setup(@Nullable Entity owner, int life) {
        this.ownerId = owner != null ? owner.getUUID() : null;
        this.entityData.set(DATA_LIFE, life);
    }

    public int life() {
        return this.entityData.get(DATA_LIFE);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_LIFE, 120);
    }

    @Override
    public void tick() {
        super.tick();
        int life = this.life();
        float grow = Math.min(1.0F, this.tickCount / 30.0F);
        float eat = 1.0F + 3.5F * grow;
        if (this.level().isClientSide) {
            // accretion disc, jets and a black core
            for (int i = 0; i < 10; i++) {
                double a = this.tickCount * 0.35 + i * (Math.PI * 2 / 10);
                double r = eat + 1.0 + (i % 3) * 0.7;
                this.level().addParticle(ModParticles.of(WeaponSpec.PType.VOID, i % 3 == 0 ? 0xFFFFFF : 0xA060FF),
                        this.getX() + Math.cos(a) * r, this.getY() + Math.sin(a * 2) * 0.2, this.getZ() + Math.sin(a) * r,
                        -Math.sin(a) * 0.35 - Math.cos(a) * 0.12, 0, Math.cos(a) * 0.35 - Math.sin(a) * 0.12);
            }
            if (this.tickCount % 2 == 0) {
                this.level().addParticle(ModParticles.of(WeaponSpec.PType.ORB, 0xD0A0FF), this.getX(), this.getY() + 0.3, this.getZ(), 0, 0.9, 0);
                this.level().addParticle(ModParticles.of(WeaponSpec.PType.ORB, 0xD0A0FF), this.getX(), this.getY() - 0.3, this.getZ(), 0, -0.9, 0);
            }
            this.level().addParticle(ModParticles.of(WeaponSpec.PType.SMOKE, 0x050208), this.getX(), this.getY(), this.getZ(), 0, 0, 0);
            return;
        }
        ServerLevel sl = (ServerLevel) this.level();
        if (this.tickCount % 20 == 1) {
            sl.playSound(null, this.getX(), this.getY(), this.getZ(), ModSounds.get("shared.singularity"), SoundSource.HOSTILE, 3.0F, 0.6F + this.tickCount * 0.004F);
        }
        Vec3 c = this.position();
        Entity owner = this.ownerId != null ? sl.getEntity(this.ownerId) : null;
        for (Entity e : sl.getEntities(this, new AABB(c, c).inflate(RADIUS), e -> e.isAlive() && !e.isSpectator()
                && !(e instanceof Player p && p.getAbilities().flying) && !(e instanceof SingularityEntity))) {
            if (e.isPassenger()) continue;
            Vec3 d = c.subtract(e.position().add(0, e.getBbHeight() / 2, 0));
            double dist = d.length();
            if (dist > RADIUS || dist < 1e-3) continue;
            double strength = (0.05 + 0.24 * (1.0 - dist / RADIUS)) * grow;
            e.setDeltaMovement(e.getDeltaMovement().scale(0.85).add(d.normalize().scale(strength)));
            e.hurtMarked = true;
            e.fallDistance = 0;
            if (dist < eat * 0.6 + 0.8) {
                if (e instanceof ItemEntity) {
                    e.discard();
                } else if (e instanceof LivingEntity le) {
                    le.invulnerableTime = 0;
                    le.hurt(owner != null ? this.damageSources().indirectMagic(this, owner) : this.damageSources().magic(), 4.0F);
                }
            }
        }
        if (sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            BlockPos center = this.blockPosition();
            int r = (int) Math.ceil(eat);
            for (int i = 0; i < 40; i++) {
                BlockPos p = center.offset(this.random.nextInt(2 * r + 1) - r, this.random.nextInt(2 * r + 1) - r, this.random.nextInt(2 * r + 1) - r);
                if (p.distSqr(center) > eat * eat) continue;
                BlockState st = sl.getBlockState(p);
                if (st.isAir() || st.getDestroySpeed(sl, p) < 0) continue;
                if (this.random.nextInt(3) == 0) {
                    sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 4, 0.3, 0.3, 0.3, 0.1);
                }
                sl.removeBlock(p, false);
            }
        }
        if (this.tickCount % 5 == 0) GunLogic.shakeAround(sl, c, 24, 0.5F);
        if (this.tickCount >= life) {
            sl.sendParticles(ModParticles.of(WeaponSpec.PType.VOID, 0xFFFFFF), c.x, c.y, c.z, 150, 2.0, 2.0, 2.0, 0.7);
            sl.explode(this, c.x, c.y, c.z, 4.5F, false, Level.ExplosionInteraction.MOB);
            GunLogic.shakeAround(sl, c, 40, 3.0F);
            this.discard();
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(DATA_LIFE, tag.getInt("Life"));
        if (tag.hasUUID("Owner")) this.ownerId = tag.getUUID("Owner");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Life", this.life());
        if (this.ownerId != null) tag.putUUID("Owner", this.ownerId);
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 128 * 128;
    }
}
