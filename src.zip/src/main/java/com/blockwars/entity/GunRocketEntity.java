package com.blockwars.entity;

import com.blockwars.ModEntities;
import com.blockwars.ModParticles;
import com.blockwars.gun.AmmoType;
import com.blockwars.gun.GunLogic;
import com.blockwars.gun.ModGuns;
import com.blockwars.mecha.WeaponSpec;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/** Rockets (HE / thermobaric) and the UMBRAL singularity seed. */
public class GunRocketEntity extends ThrowableItemProjectile {
    /** 0 = HE rocket, 1 = thermobaric rocket, 2 = singularity seed, 3 = HE grenade, 4 = incendiary grenade, 5 = nanite canister */
    private static final EntityDataAccessor<Integer> DATA_KIND = SynchedEntityData.defineId(GunRocketEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_GRAVITY = SynchedEntityData.defineId(GunRocketEntity.class, EntityDataSerializers.FLOAT);
    public static final int GRENADE_HE = 3, GRENADE_FIRE = 4, NANITE = 5;

    public float damage = 12;
    @Nullable public Entity homingTarget;
    private boolean exploded;
    public int bouncesLeft;
    public int fuse;
    public float power = 2.5F;
    /** ticks a rocket flies before it blows up in the air (set from the launcher's range) */
    public int life = 120;
    /** keeps long shots inside the part of the world that is simulated (server) */
    private final com.blockwars.arsenal.ArsenalReach.Horizon horizon = new com.blockwars.arsenal.ArsenalReach.Horizon();
    public boolean rogueSwarm;
    public WeaponSpec.Fx fx = WeaponSpec.Fx.NONE;
    public int fxTime = 60, fxAmp;

    public GunRocketEntity(EntityType<? extends GunRocketEntity> type, Level level) {
        super(type, level);
    }

    public GunRocketEntity(Level level, LivingEntity shooter, int kind) {
        super(ModEntities.GUN_ROCKET.get(), shooter, level);
        this.entityData.set(DATA_KIND, kind);
        this.setNoGravity(true);
        AmmoType item = switch (kind) {
            case 0 -> AmmoType.ROCKET_HE;
            case 1 -> AmmoType.ROCKET_THERMO;
            case GRENADE_HE -> AmmoType.GRENADE_HE;
            case GRENADE_FIRE -> AmmoType.GRENADE_FIRE;
            case NANITE -> AmmoType.NANITES;
            default -> AmmoType.CORE;
        };
        if (kind >= GRENADE_HE) {
            this.entityData.set(DATA_GRAVITY, kind == NANITE ? 0.03F : 0.05F);
            this.setNoGravity(false);
        }
        this.setItem(new ItemStack(ModGuns.AMMO.get(item).get()));
    }

    public int kind() {
        return this.entityData.get(DATA_KIND);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_KIND, 0);
        builder.define(DATA_GRAVITY, 0.0F);
    }

    @Override
    protected Item getDefaultItem() {
        return Items.FIREWORK_ROCKET;
    }

    @Override
    protected double getDefaultGravity() {
        return this.entityData.get(DATA_GRAVITY);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double dist) {
        return dist < 256.0 * 256.0;
    }

    @Override
    public void tick() {
        if (this.level() instanceof ServerLevel sl && !this.horizon.ok(sl, this.position(), this.getDeltaMovement())) {
            // past the edge of the simulated world it would hang frozen in the air: it fizzles out instead
            this.discard();
            return;
        }
        super.tick();
        int kind = this.kind();
        if (this.level().isClientSide) {
            Vec3 v = this.getDeltaMovement();
            if (kind == GRENADE_HE || kind == GRENADE_FIRE) {
                this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY() + 0.1, this.getZ(), 0, 0.01, 0);
                if (kind == GRENADE_FIRE) this.level().addParticle(ParticleTypes.FLAME, this.getX(), this.getY(), this.getZ(), 0, 0.01, 0);
                if (this.tickCount % 4 == 0) {
                    this.level().addParticle(ModParticles.of(WeaponSpec.PType.SPARK, 0xFF3020), this.getX(), this.getY() + 0.15, this.getZ(), 0, 0.05, 0);
                }
                return;
            }
            if (kind == NANITE) {
                for (int i = 0; i < 2; i++) {
                    this.level().addParticle(ModParticles.of(WeaponSpec.PType.SHARD, i == 0 ? 0xC8D0D8 : 0x707880),
                            this.getRandomX(0.4), this.getRandomY(), this.getRandomZ(0.4), 0, 0, 0);
                }
                return;
            }
            if (kind == 2) {
                for (int i = 0; i < 3; i++) {
                    double a = (this.tickCount * 0.6 + i * 2.1);
                    this.level().addParticle(ModParticles.of(WeaponSpec.PType.VOID, i == 0 ? 0xFFFFFF : 0xA060FF),
                            this.getX() + Math.cos(a) * 0.5, this.getY() + Math.sin(a * 1.3) * 0.3, this.getZ() + Math.sin(a) * 0.5, 0, 0, 0);
                }
                this.level().addParticle(ModParticles.of(WeaponSpec.PType.SMOKE, 0x100818), this.getX(), this.getY(), this.getZ(), 0, 0, 0);
            } else {
                for (int i = 0; i < 2; i++) {
                    double f = i * 0.5;
                    this.level().addParticle(ParticleTypes.FLAME, this.getX() - v.x * f, this.getY() - v.y * f, this.getZ() - v.z * f, -v.x * 0.1, -v.y * 0.1, -v.z * 0.1);
                }
                this.level().addParticle(ModParticles.of(WeaponSpec.PType.SMOKE, 0xB0B0B0), this.getX() - v.x, this.getY() - v.y, this.getZ() - v.z, 0, 0.01, 0);
                this.level().addParticle(ParticleTypes.LARGE_SMOKE, this.getX() - v.x * 1.5, this.getY() - v.y * 1.5, this.getZ() - v.z * 1.5, 0, 0, 0);
            }
            return;
        }
        if (kind == 2) {
            this.setDeltaMovement(this.getDeltaMovement().scale(0.97));
            if (this.tickCount > 55) this.detonate(this.position());
            return;
        }
        if (kind >= GRENADE_HE) {
            if (this.fuse > 0 && this.tickCount >= this.fuse) this.detonate(this.position());
            if (this.tickCount > 200) this.detonate(this.position());
            if (this.homingTarget != null && this.homingTarget.isAlive()) {
                Vec3 want = this.homingTarget.getBoundingBox().getCenter().subtract(this.position()).normalize().scale(0.06);
                this.setDeltaMovement(this.getDeltaMovement().add(want));
                this.hasImpulse = true;
            }
            return;
        }
        // rockets accelerate after leaving the tube
        Vec3 v = this.getDeltaMovement();
        double sp = Math.min(3.2, v.length() * 1.06);
        if (this.homingTarget != null && this.homingTarget.isAlive() && this.tickCount > 3) {
            Vec3 want = this.homingTarget.getBoundingBox().getCenter().subtract(this.position()).normalize();
            v = v.normalize().add(want.subtract(v.normalize()).scale(0.22)).normalize();
        } else {
            v = v.normalize();
        }
        this.setDeltaMovement(v.scale(sp));
        this.hasImpulse = true;
        if (this.tickCount > this.life) this.detonate(this.position());
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        if (entity instanceof GunBulletEntity || entity instanceof GunRocketEntity) return false;
        return super.canHitEntity(entity);
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (this.level().isClientSide) return;
        int kind = this.kind();
        // grenades with a fuse bounce off terrain until it runs out
        if (kind >= GRENADE_HE && result.getType() == HitResult.Type.BLOCK && this.bouncesLeft > 0) {
            BlockHitResult bh = (BlockHitResult) result;
            Vec3 v = this.getDeltaMovement();
            Direction d = bh.getDirection();
            v = switch (d.getAxis()) {
                case X -> new Vec3(-v.x * 0.5, v.y * 0.7, v.z * 0.7);
                case Y -> new Vec3(v.x * 0.6, -v.y * 0.45, v.z * 0.6);
                case Z -> new Vec3(v.x * 0.7, v.y * 0.7, -v.z * 0.5);
            };
            this.setDeltaMovement(v);
            Vec3 at = bh.getLocation();
            this.setPos(at.x + d.getStepX() * 0.15, at.y + d.getStepY() * 0.15, at.z + d.getStepZ() * 0.15);
            this.bouncesLeft--;
            this.hasImpulse = true;
            this.level().playSound(null, at.x, at.y, at.z, net.minecraft.sounds.SoundEvents.CHAIN_HIT, net.minecraft.sounds.SoundSource.PLAYERS, 0.6F, 1.6F);
            return;
        }
        this.detonate(result.getLocation());
    }

    private void detonate(Vec3 at) {
        if (this.exploded || !(this.level() instanceof ServerLevel level)) return;
        this.exploded = true;
        int kind = this.kind();
        if (kind == 2) {
            GunLogic.openSingularity(level, at, this.getOwner(), 120, false);
        } else if (kind == GRENADE_HE || kind == GRENADE_FIRE) {
            GunLogic.grenadeBlast(level, at, this, this.getOwner(), kind == GRENADE_FIRE, this.damage, this.power);
        } else if (kind == NANITE) {
            GunLogic.releaseNanites(level, at, this.getOwner(), this.rogueSwarm);
        } else {
            GunLogic.rocketBlast(level, at, this, this.getOwner(), kind == 1, this.damage);
        }
        this.discard();
    }
}
