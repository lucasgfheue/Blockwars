package com.blockwars.entity;

import com.blockwars.ModParticles;
import com.blockwars.ModSounds;
import com.blockwars.mecha.WeaponSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * A grey-goo cloud released by ENJAMBRE GRIS. It drifts toward the nearest living thing, strips it,
 * and eats the blocks it passes through. Sometimes it forgets who released it.
 */
public class NaniteSwarmEntity extends Entity {
    private static final EntityDataAccessor<Boolean> DATA_ROGUE = SynchedEntityData.defineId(NaniteSwarmEntity.class, EntityDataSerializers.BOOLEAN);
    private static final int LIFE = 180;
    @Nullable private UUID ownerId;
    @Nullable private LivingEntity target;

    public NaniteSwarmEntity(EntityType<? extends NaniteSwarmEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public void setup(@Nullable Entity owner, boolean rogue) {
        this.ownerId = owner != null ? owner.getUUID() : null;
        this.entityData.set(DATA_ROGUE, rogue);
    }

    public boolean isRogue() {
        return this.entityData.get(DATA_ROGUE);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_ROGUE, false);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            int col = this.isRogue() ? 0xFF4030 : 0xC8D0D8;
            for (int i = 0; i < 8; i++) {
                double a = this.random.nextDouble() * Math.PI * 2, r = 0.4 + this.random.nextDouble() * 1.4;
                this.level().addParticle(ModParticles.of(WeaponSpec.PType.SHARD, i % 3 == 0 ? col : 0x5A6068),
                        this.getX() + Math.cos(a) * r, this.getY() + this.random.nextDouble() * 1.6, this.getZ() + Math.sin(a) * r,
                        -Math.sin(a) * 0.08, (this.random.nextDouble() - 0.5) * 0.05, Math.cos(a) * 0.08);
            }
            return;
        }
        ServerLevel sl = (ServerLevel) this.level();
        Entity owner = this.ownerId != null ? sl.getEntity(this.ownerId) : null;
        if (this.tickCount % 10 == 0 || this.target == null || !this.target.isAlive()) {
            this.target = null;
            double best = 20 * 20;
            if (this.isRogue() && owner instanceof LivingEntity lo && lo.isAlive() && lo.distanceToSqr(this) < 40 * 40) {
                this.target = lo; // it has decided its creator tastes best
            } else {
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(20),
                        e -> e.isAlive() && e != owner && !(e instanceof Player p && (p.isCreative() || p.isSpectator())))) {
                    double d = e.distanceToSqr(this);
                    if (d < best) { best = d; this.target = e; }
                }
            }
        }
        Vec3 v = Vec3.ZERO;
        if (this.target != null) {
            v = this.target.position().add(0, this.target.getBbHeight() * 0.4, 0).subtract(this.position()).normalize().scale(this.isRogue() ? 0.2 : 0.16);
        }
        this.setPos(this.getX() + v.x, this.getY() + v.y, this.getZ() + v.z);
        // strip whatever is inside the cloud
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(1.8), e -> e.isAlive() && (this.isRogue() || e != owner))) {
            e.invulnerableTime = 0;
            e.hurt(owner != null ? this.damageSources().indirectMagic(this, owner) : this.damageSources().magic(), 2.0F);
            e.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.WEAKNESS, 40, 1));
        }
        // and eat the world (respects mobGriefing)
        if (this.tickCount % 2 == 0 && sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            BlockPos c = this.blockPosition();
            for (int i = 0; i < 6; i++) {
                BlockPos p = c.offset(this.random.nextInt(5) - 2, this.random.nextInt(4) - 1, this.random.nextInt(5) - 2);
                BlockState st = sl.getBlockState(p);
                float hard = st.getDestroySpeed(sl, p);
                if (st.isAir() || hard < 0 || hard > 20) continue;
                sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 3, 0.3, 0.3, 0.3, 0.05);
                sl.removeBlock(p, false);
            }
        }
        if (this.tickCount % 16 == 0) {
            sl.playSound(null, this.getX(), this.getY(), this.getZ(), ModSounds.get("gun.swarm"), SoundSource.HOSTILE, 1.0F, 0.8F + this.random.nextFloat() * 0.4F);
        }
        if (this.tickCount >= LIFE) {
            sl.sendParticles(ModParticles.of(WeaponSpec.PType.SHARD, 0x9098A0), this.getX(), this.getY() + 0.8, this.getZ(), 60, 1.0, 1.0, 1.0, 0.2);
            this.discard();
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(DATA_ROGUE, tag.getBoolean("Rogue"));
        if (tag.hasUUID("Owner")) this.ownerId = tag.getUUID("Owner");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putBoolean("Rogue", this.isRogue());
        if (this.ownerId != null) tag.putUUID("Owner", this.ownerId);
    }

    @Override
    public boolean isPickable() {
        return false;
    }
}
