package com.blockwars;

import com.blockwars.mecha.WeaponSpec;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Colored particle types used by the mecha weapons (the color travels with each particle). */
public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(Registries.PARTICLE_TYPE, BlockWars.MODID);

    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> SPARK = register("spark", false);
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> ORB = register("orb", false);
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> EMBER = register("ember", false);
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> SHARD = register("shard", false);
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> SMOKE = register("smoke", false);
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> FROST = register("frost", false);
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> TOXIC = register("toxic", false);
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> VOID = register("void", true);

    private static DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> register(String name, boolean alwaysShow) {
        return PARTICLES.register(name, () -> new ParticleType<ColorParticleOption>(alwaysShow) {
            @Override
            public MapCodec<ColorParticleOption> codec() {
                return ColorParticleOption.codec(this);
            }

            @Override
            public StreamCodec<? super RegistryFriendlyByteBuf, ColorParticleOption> streamCodec() {
                return ColorParticleOption.streamCodec(this);
            }
        });
    }

    public static ParticleType<ColorParticleOption> type(WeaponSpec.PType p) {
        return switch (p) {
            case SPARK -> SPARK.get();
            case ORB -> ORB.get();
            case EMBER -> EMBER.get();
            case SHARD -> SHARD.get();
            case SMOKE -> SMOKE.get();
            case FROST -> FROST.get();
            case TOXIC -> TOXIC.get();
            case VOID -> VOID.get();
        };
    }

    /** A colored particle option for an RGB color (0xRRGGBB). */
    public static ColorParticleOption of(WeaponSpec.PType p, int rgb) {
        float r = ((rgb >> 16) & 0xFF) / 255.0F, g = ((rgb >> 8) & 0xFF) / 255.0F, b = (rgb & 0xFF) / 255.0F;
        return ColorParticleOption.create(type(p), r, g, b);
    }
}
