package com.blockwars.arsenal;

import com.blockwars.arsenal.ArsenalDef.Proj;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;

/**
 * Every physical Arsenal projectile: ion rings («Pulsar»), robot wasps («Colmena»), ice lances («Glaciar»), bouncing
 * candies («Dulce Venganza»), the singularity of «Abismo» and plasma bolts («Hidra»). Which one it is comes from the
 * synced weapon index; what it does from {@link ArsenalDef#proj}.
 */
public class ArsenalShot extends ThrowableItemProjectile {
    private static final EntityDataAccessor<Integer> DATA_WEAPON = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.INT);
    /** bit 0 tracer, bits 2..4 elemental core (igneous, gelid, voltaic), bit 5 alternate pellet */
    private static final EntityDataAccessor<Integer> DATA_FLAGS = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.INT);
    /** 0 flying, 1 stuck in a block (ice lance), 2 singularity */
    private static final EntityDataAccessor<Integer> DATA_STATE = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_CHARGE = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.FLOAT);

    public static final int FLYING = 0, STUCK = 1, WELL = 2;
    /** blocks a singularity may tear out of the ground before it collapses */
    private static final int MAX_RIPPED = 28;

    public float damage = 4;
    public int maxAge = 60;
    public int pierce;
    public int bounces;
    public float charge = 1.0F;
    @Nullable public Entity homingTarget;
    private final Set<Integer> hitIds = new HashSet<>();
    private boolean keepFlying;
    private int fuse = -1;
    private int stateTicks;
    private int ripped;
    private double travelled;

    public ArsenalShot(EntityType<? extends ArsenalShot> type, Level level) {
        super(type, level);
    }

    public ArsenalShot(Level level, LivingEntity shooter, ArsenalDef d) {
        super(ArsenalEntities.SHOT.get(), shooter, level);
        this.entityData.set(DATA_WEAPON, d.index);
        this.setNoGravity(d.gravity <= 0);
        if (d.proj == Proj.CANDY) this.fuse = Math.max(10, (int) d.sp2);
    }

    @Nullable
    public ArsenalDef def() {
        return Arsenal.def(this.entityData.get(DATA_WEAPON));
    }

    public int flags() {
        return this.entityData.get(DATA_FLAGS);
    }

    public void setFlag(int bit, boolean on) {
        int f = this.entityData.get(DATA_FLAGS);
        this.entityData.set(DATA_FLAGS, on ? f | (1 << bit) : f & ~(1 << bit));
    }

    public void setTracer(boolean t) {
        this.setFlag(0, t);
    }

    public boolean tracer() {
        return (this.flags() & 1) != 0;
    }

    public boolean alternate() {
        return (this.flags() & 32) != 0;
    }

    /** Elemental core the shot carries (from the weapon's upgrade), or null. */
    @Nullable
    public ArsenalModule element() {
        int f = this.flags();
        if ((f & 4) != 0) return ArsenalModule.INCENDIARY;
        if ((f & 8) != 0) return ArsenalModule.CRYO;
        if ((f & 16) != 0) return ArsenalModule.SHOCK;
        return null;
    }

    public int shotState() {
        return this.entityData.get(DATA_STATE);
    }

    public int stateTicks() {
        return this.stateTicks;
    }

    public float chargeLevel() {
        return this.entityData.get(DATA_CHARGE);
    }

    /** How charged the weapon was when this left the barrel (synced: charged shots look bigger). */
    public void setCharge(float c) {
        this.charge = c;
        this.entityData.set(DATA_CHARGE, c);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_WEAPON, 0);
        builder.define(DATA_FLAGS, 0);
        builder.define(DATA_STATE, FLYING);
        builder.define(DATA_CHARGE, 1.0F);
    }

    @Override
    protected Item getDefaultItem() {
        return Items.IRON_NUGGET;
    }

    @Override
    protected double getDefaultGravity() {
        ArsenalDef d = this.def();
        if (d == null || this.shotState() != FLYING) return 0.0;
        return d.gravity;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double dist) {
        return dist < 256.0 * 256.0;
    }

    @Override
    public boolean isOnFire() {
        return false;
    }

    // ============================================================== ticking

    @Override
    public void tick() {
        ArsenalDef d = this.def();
        int state = this.shotState();
        if (state != FLYING) {
            this.stateTicks++;
            this.setDeltaMovement(Vec3.ZERO);
            this.baseTick();
            if (d != null) {
                if (this.level().isClientSide) ArsenalShotFx.still(this, d, state);
                else this.serverStateTick(d, state);
            }
            return;
        }
        Vec3 before = this.position();
        float yRot = this.getYRot(), xRot = this.getXRot();
        super.tick();
        if (this.isRemoved() || d == null) return;
        if (this.shotState() == STUCK) {
            // keep the flight attitude: the lance stays the way it went in
            this.setYRot(yRot);
            this.setXRot(xRot);
            this.yRotO = yRot;
            this.xRotO = xRot;
        }
        if (this.shotState() == FLYING && d.drag > 0) this.setDeltaMovement(this.getDeltaMovement().scale(1.0 - d.drag));
        this.travelled += this.position().distanceTo(before);
        if (this.level().isClientSide) {
            ArsenalShotFx.trail(this, d, before);
            return;
        }
        if (this.shotState() != FLYING) return;
        ServerLevel level = (ServerLevel) this.level();
        if (this.fuse > 0 && --this.fuse == 0) {
            this.burst(level, d, this.position(), null);
            return;
        }
        if (this.tickCount > this.maxAge) {
            switch (d.proj) {
                case VOID -> this.becomeWell(d);
                case WASP, CANDY, PLASMA -> this.burst(level, d, this.position(), null);
                default -> this.discard();
            }
            return;
        }
        if (this.isInWater() && d.proj != Proj.VOID) {
            if (d.proj == Proj.PLASMA || d.proj == Proj.RING) {
                // energy dies in water with a hiss
                level.sendParticles(ParticleTypes.BUBBLE, this.getX(), this.getY(), this.getZ(), 8, 0.1, 0.1, 0.1, 0.05);
                level.playSound(null, this.getX(), this.getY(), this.getZ(), net.minecraft.sounds.SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.5F, 1.8F);
                this.discard();
                return;
            }
            this.setDeltaMovement(this.getDeltaMovement().scale(0.6));
            if (this.getDeltaMovement().lengthSqr() < 0.01) this.discard();
        }
        switch (d.proj) {
            case WASP -> this.waspFlight(level, d);
            case VOID -> {
                // the orb already bends the world on its way; it lets go of its owner only while leaving the barrel
                if (this.tickCount % 2 == 0) this.pull(d, d.sp1 * 0.35F, 0.03, this.tickCount < 10);
            }
            default -> { }
        }
    }

    /** Robot wasps keep finding prey: they re-acquire a target and weave as they fly. */
    private void waspFlight(ServerLevel level, ArsenalDef d) {
        Vec3 v = this.getDeltaMovement();
        double sp = v.length();
        if (sp < 1.0E-4) return;
        if ((this.homingTarget == null || !this.homingTarget.isAlive()) && this.tickCount % 4 == 0) this.homingTarget = this.acquire(level, v.normalize());
        if (this.homingTarget != null && this.homingTarget.isAlive() && this.tickCount > 3) {
            Vec3 want = this.homingTarget.getBoundingBox().getCenter().subtract(this.position()).normalize().scale(sp);
            float k = d.sp1 > 0 ? Math.min(0.6F, d.sp1) : 0.2F;
            v = v.add(want.subtract(v).scale(k));
        }
        // the buzzing weave
        Vec3 dir = v.normalize();
        Vec3 side = dir.cross(new Vec3(0, 1, 0));
        if (side.lengthSqr() < 1.0E-4) side = new Vec3(1, 0, 0);
        side = side.normalize();
        Vec3 up = side.cross(dir).normalize();
        float ph = this.tickCount * 1.15F + this.getId() * 1.7F;
        v = v.add(side.scale(Mth.sin(ph) * 0.07 * sp)).add(up.scale(Mth.cos(ph * 1.3F) * 0.05 * sp));
        this.setDeltaMovement(v.normalize().scale(sp));
        this.hasImpulse = true;
    }

    @Nullable
    private Entity acquire(ServerLevel level, Vec3 dir) {
        Entity owner = this.getOwner();
        Entity best = null;
        double bestScore = 0;
        Vec3 from = this.position();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(20.0), e -> e != owner && e.isAlive() && !e.isSpectator()
                && (e instanceof Enemy || e instanceof Player) && !(e instanceof OwnableEntity o && o.getOwner() == owner))) {
            if (e instanceof Player pl && pl.isCreative()) continue;
            Vec3 to = e.getBoundingBox().getCenter().subtract(from);
            double dist = to.length();
            if (dist > 20.0 || dist < 0.5) continue;
            double dot = to.scale(1.0 / dist).dot(dir);
            if (dot < 0.35) continue;
            if (level.clip(new ClipContext(from, e.getBoundingBox().getCenter(), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this)).getType() != HitResult.Type.MISS) continue;
            double score = dot * 2.0 - dist / 20.0;
            if (best == null || score > bestScore) {
                best = e;
                bestScore = score;
            }
        }
        return best;
    }

    // ============================================================== stuck lance / singularity (server)

    private void serverStateTick(ArsenalDef d, int state) {
        ServerLevel level = (ServerLevel) this.level();
        if (state == WELL) {
            this.wellTick(level, d);
            return;
        }
        // an ice lance melts out of the wall
        if (this.stateTicks > 70) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.ICE.defaultBlockState()), this.getX(), this.getY(), this.getZ(), 12, 0.1, 0.1, 0.1, 0.1);
            level.playSound(null, this.getX(), this.getY(), this.getZ(), ArsenalSounds.shared("ice_shatter"), SoundSource.PLAYERS, 0.4F, 1.5F);
            this.discard();
        }
    }

    private void wellTick(ServerLevel level, ArsenalDef d) {
        float r = Math.max(3.0F, d.sp1);
        int life = Math.max(30, (int) d.sp2);
        float t = Math.min(1.0F, this.stateTicks / (float) life);
        Vec3 c = this.position();
        this.pull(d, r * (0.6F + 0.4F * t), 0.05 + 0.13 * t, false);
        // the core grinds whatever it holds: its owner included
        if (this.stateTicks % 5 == 0) {
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(1.7), e -> e.isAlive() && !e.isSpectator())) {
                if (e instanceof Player pl && pl.isCreative()) continue;
                e.invulnerableTime = 0;
                e.hurt(level.damageSources().magic(), d.damage * 0.25F);
            }
        }
        // falling blocks that reach the core are gone for good
        for (FallingBlockEntity fb : level.getEntitiesOfClass(FallingBlockEntity.class, new AABB(c, c).inflate(1.3))) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, fb.getBlockState()), fb.getX(), fb.getY() + 0.5, fb.getZ(), 10, 0.25, 0.25, 0.25, 0.05);
            fb.discard();
        }
        if (this.stateTicks > 12 && this.stateTicks % 2 == 0) this.rip(level, r, t);
        if (this.stateTicks % 20 == 1) {
            level.playSound(null, c.x, c.y, c.z, ArsenalSounds.shared("gravity"), SoundSource.PLAYERS, 2.5F, 0.6F + t * 0.6F);
            ArsenalLogic.shakeAround(level, c, r * 2.5, 0.3F + t * 0.7F);
        }
        if (this.stateTicks % 10 == 0) ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.RING, 0x9A5CFF), c, new Vec3(0, -r * (1.0 - t * 0.5), 0));
        if (this.stateTicks >= life) this.collapse(level, d, r);
    }

    /** The singularity tears loose blocks out of the ground and swallows them. */
    private void rip(ServerLevel level, float r, float t) {
        if (this.ripped >= MAX_RIPPED || !level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return;
        if (!(this.getOwner() instanceof Player owner)) return;
        float reach = Math.min(5.5F, r * (0.35F + 0.3F * t));
        BlockPos center = this.blockPosition();
        for (int attempt = 0; attempt < 4; attempt++) {
            double a = this.random.nextDouble() * Math.PI * 2.0;
            double rr = Math.sqrt(this.random.nextDouble()) * reach;
            int x = center.getX() + (int) Math.round(Math.cos(a) * rr);
            int z = center.getZ() + (int) Math.round(Math.sin(a) * rr);
            for (int y = center.getY() + 2; y >= center.getY() - 4; y--) {
                BlockPos pos = new BlockPos(x, y, z);
                BlockState st = level.getBlockState(pos);
                if (st.isAir()) continue;
                if (!this.rippable(level, pos, st, owner)) break;
                FallingBlockEntity fb = FallingBlockEntity.fall(level, pos, st);
                Vec3 to = this.position().subtract(fb.position());
                fb.setDeltaMovement(to.normalize().scale(0.25).add(0, 0.45, 0));
                fb.hurtMarked = true;
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), x + 0.5, y + 1.0, z + 0.5, 8, 0.3, 0.1, 0.3, 0.05);
                this.ripped++;
                return;
            }
        }
    }

    private boolean rippable(ServerLevel level, BlockPos pos, BlockState st, Player owner) {
        if (st.hasBlockEntity() || !st.getFluidState().isEmpty()) return false;
        float hardness = st.getDestroySpeed(level, pos);
        if (hardness < 0 || hardness > 3.0F) return false;
        if (!level.getBlockState(pos.above()).isAir()) return false;
        return level.mayInteract(owner, pos);
    }

    /** Pull everything around toward this point. Players too: «Abismo» does not care who fired it. */
    private void pull(ArsenalDef d, float radius, double strength, boolean spareOwner) {
        if (this.level().isClientSide || radius <= 0) return;
        Vec3 c = this.position();
        Entity owner = this.getOwner();
        for (Entity e : this.level().getEntities(this, new AABB(c, c).inflate(radius), e -> !(e instanceof ArsenalShot) && !e.isSpectator())) {
            if (e instanceof Player pl && (pl.isCreative() && pl.getAbilities().flying)) continue;
            if (spareOwner && e == owner) continue;
            Vec3 to = c.subtract(e.position().add(0, e.getBbHeight() * 0.5, 0));
            double dist = to.length();
            if (dist < 0.3 || dist > radius) continue;
            double k = strength * (1.0 - dist / radius) * 2.0 + strength * 0.25;
            Vec3 add = to.scale(k / dist);
            e.setDeltaMovement(e.getDeltaMovement().scale(0.92).add(add));
            e.hurtMarked = true;
            e.fallDistance = 0;
        }
    }

    // ============================================================== hits

    @Override
    protected boolean canHitEntity(Entity entity) {
        if (this.hitIds.contains(entity.getId())) return false;
        if (entity instanceof ArsenalShot || entity instanceof FallingBlockEntity) return false;
        return super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity e = result.getEntity();
        this.hitIds.add(e.getId());
        if (this.level().isClientSide) return;
        ArsenalDef d = this.def();
        if (d == null) return;
        ServerLevel level = (ServerLevel) this.level();
        Vec3 at = result.getLocation();
        Entity owner = this.getOwner();
        switch (d.proj) {
            case VOID -> {
                this.setPos(at.x, at.y, at.z);
                this.becomeWell(d);
                return;
            }
            case WASP, CANDY, PLASMA -> {
                ArsenalLogic.damage(owner, this, e, this.damage, false, this.getDeltaMovement().normalize().scale(0.1), 0.3F);
                ArsenalLogic.applySpecial(level, owner, d, e, at);
                ArsenalLogic.applyElement(level, owner, this.element(), e);
                this.burst(level, d, at, e);
                return;
            }
            default -> { }
        }
        // ring and ice lance: piercing hits
        boolean head = false;
        float dmg = this.damage * this.falloff(d);
        if (e instanceof LivingEntity le && le.getBbHeight() > 0.9F && at.y >= le.getEyeY() - 0.22) {
            head = true;
            dmg *= d.headMul;
        }
        boolean shattered = false;
        if (d.proj == Proj.ICE && e.isFullyFrozen()) {
            // a frozen target shatters
            shattered = true;
            dmg *= Math.max(1.0F, d.sp2);
            e.setTicksFrozen(0);
            Vec3 c = e.getBoundingBox().getCenter();
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.ICE.defaultBlockState()), c.x, c.y, c.z, 40, 0.35, 0.5, 0.35, 0.25);
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.FROST, 0xD8F6FF), c.x, c.y, c.z, 16, 0.4, 0.5, 0.4, 0.12);
            level.playSound(null, c.x, c.y, c.z, ArsenalSounds.shared("ice_shatter"), SoundSource.PLAYERS, 1.6F, 0.8F);
        }
        ArsenalLogic.damage(owner, this, e, dmg, head, this.getDeltaMovement().normalize().scale(0.05), 0.25F);
        ArsenalLogic.applySpecial(level, owner, d, e, at);
        ArsenalLogic.applyElement(level, owner, this.element(), e);
        if (d.proj == Proj.ICE && !shattered && this.charge >= 0.99F && e.isAlive()) {
            // a fully charged lance freezes its target solid for a few seconds: the next hit shatters it
            e.setTicksFrozen(Math.max(e.getTicksFrozen(), e.getTicksRequiredToFreeze() + 100));
        }
        Vec3 c = e.getBoundingBox().getCenter();
        if (d.proj == Proj.ICE) {
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.FROST, 0xC8F0FF), c.x, c.y, c.z, 10, 0.25, 0.35, 0.25, 0.06);
        } else {
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), at.x, at.y, at.z, 4, 0.1, 0.1, 0.1, 0.04);
        }
    }

    /** Energy loses punch past the effective range. */
    private float falloff(ArsenalDef d) {
        double r = Math.max(4.0, d.range);
        if (this.travelled < r * 0.6) return 1.0F;
        return (float) Math.max(0.6, 1.0 - (this.travelled - r * 0.6) / r * 0.8);
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!(this.level() instanceof ServerLevel level)) return;
        ArsenalDef d = this.def();
        if (d == null) return;
        BlockPos pos = result.getBlockPos();
        BlockState st = level.getBlockState(pos);
        Vec3 at = result.getLocation();
        Direction face = result.getDirection();
        Entity owner = this.getOwner();
        Player pl = owner instanceof Player p ? p : null;
        // rings, lances and plasma go straight through glass
        if ((d.proj == Proj.RING || d.proj == Proj.ICE || d.proj == Proj.PLASMA) && (st.is(Tags.Blocks.GLASS_PANES) || st.is(Tags.Blocks.GLASS_BLOCKS))
                && pl != null && level.mayInteract(pl, pos)) {
            level.destroyBlock(pos, false, pl);
            this.setDeltaMovement(this.getDeltaMovement().scale(0.85));
            this.keepFlying = true;
            return;
        }
        switch (d.proj) {
            case VOID -> {
                this.setPos(at.x + face.getStepX() * 0.8, at.y + face.getStepY() * 0.8, at.z + face.getStepZ() * 0.8);
                this.becomeWell(d);
                this.keepFlying = true;
                return;
            }
            case WASP, PLASMA -> {
                this.burst(level, d, at.add(face.getStepX() * 0.1, face.getStepY() * 0.1, face.getStepZ() * 0.1), null);
                return;
            }
            case CANDY -> {
                if (this.bounces > 0) {
                    this.bounces--;
                    this.bounce(face, 0.62);
                    this.hitIds.clear();
                    level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("candy_bounce"), SoundSource.PLAYERS, 0.6F, 0.9F + this.random.nextFloat() * 0.5F);
                    level.sendParticles(ArsenalParticles.of(ArsenalParticles.CONFETTI, 0), at.x, at.y, at.z, 3, 0.05, 0.05, 0.05, 0.08);
                    this.keepFlying = true;
                    return;
                }
                this.burst(level, d, at.add(face.getStepX() * 0.1, face.getStepY() * 0.1, face.getStepZ() * 0.1), null);
                return;
            }
            default -> { }
        }
        ArsenalLogic.impact(level, at, face, pos, st, d, owner);
        if (this.element() == ArsenalModule.INCENDIARY) ArsenalLogic.ignite(level, owner, at, face, pos, 0.3F);
        if (d.proj == Proj.ICE) {
            this.frostBite(level, pos.relative(face), pl);
            this.setPos(at.x - this.getDeltaMovement().normalize().x * 0.3, at.y - this.getDeltaMovement().normalize().y * 0.3,
                    at.z - this.getDeltaMovement().normalize().z * 0.3);
            this.setDeltaMovement(Vec3.ZERO);
            this.setNoGravity(true);
            this.entityData.set(DATA_STATE, STUCK);
            this.stateTicks = 0;
            this.keepFlying = true;
            return;
        }
        // ion rings glance off at shallow angles
        Vec3 v = this.getDeltaMovement();
        double grazing = Math.abs(v.normalize().dot(new Vec3(face.getStepX(), face.getStepY(), face.getStepZ())));
        if (this.bounces > 0 && grazing < 0.45) {
            this.bounces--;
            this.bounce(face, 0.85);
            this.damage *= 0.8F;
            this.hitIds.clear();
            level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("energy_hit"), SoundSource.PLAYERS, 0.6F, 1.4F + this.random.nextFloat() * 0.3F);
            this.keepFlying = true;
        }
    }

    /** Ice lances freeze the water around where they land and snuff out fire. */
    private void frostBite(ServerLevel level, BlockPos at, @Nullable Player pl) {
        if (pl == null) return;
        for (BlockPos bp : BlockPos.betweenClosed(at.offset(-2, -2, -2), at.offset(2, 1, 2))) {
            if (bp.distSqr(at) > 6.5) continue;
            BlockState st = level.getBlockState(bp);
            if (!level.mayInteract(pl, bp)) continue;
            if (st.is(Blocks.WATER) && level.getFluidState(bp).isSource() && level.getBlockState(bp.above()).isAir()) {
                BlockPos imm = bp.immutable();
                level.setBlockAndUpdate(imm, Blocks.FROSTED_ICE.defaultBlockState());
                level.scheduleTick(imm, Blocks.FROSTED_ICE, Mth.nextInt(this.random, 60, 120));
            } else if (st.is(Blocks.FIRE)) {
                level.removeBlock(bp.immutable(), false);
            }
        }
    }

    private void bounce(Direction face, double keep) {
        Vec3 v = this.getDeltaMovement();
        v = switch (face.getAxis()) {
            case X -> new Vec3(-v.x, v.y, v.z);
            case Y -> new Vec3(v.x, -v.y, v.z);
            case Z -> new Vec3(v.x, v.y, -v.z);
        };
        this.setDeltaMovement(v.scale(keep));
        this.setPos(this.getX() + face.getStepX() * 0.05, this.getY() + face.getStepY() * 0.05, this.getZ() + face.getStepZ() * 0.05);
        this.hasImpulse = true;
    }

    private void becomeWell(ArsenalDef d) {
        this.setDeltaMovement(Vec3.ZERO);
        this.setNoGravity(true);
        this.entityData.set(DATA_STATE, WELL);
        this.stateTicks = 0;
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(), ArsenalSounds.shared("void_open"), SoundSource.PLAYERS, 3.0F, 1.0F);
        if (this.level() instanceof ServerLevel level) {
            ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.RING, 0x6A2CFF), this.position(), new Vec3(0, Math.max(3.0F, d.sp1), 0));
        }
    }

    /** The singularity gives up: everything it held is thrown out in a blast that takes the ground with it. */
    private void collapse(ServerLevel level, ArsenalDef d, float r) {
        Vec3 c = this.position();
        Entity owner = this.getOwner();
        float radius = Math.max(2.5F, r * 0.42F);
        ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.IMPLODE, 0x8A4CFF), c, new Vec3(radius, 0, 0));
        level.explode(this, c.x, c.y, c.z, radius, Level.ExplosionInteraction.MOB);
        ArsenalLogic.splash(level, owner, this, c, radius + 1.5F, d.damage, null);
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, 0xB080FF), c.x, c.y, c.z, 40, radius * 0.5, radius * 0.5, radius * 0.5, 0.25);
        level.playSound(null, c.x, c.y, c.z, ArsenalSounds.shared("void_collapse"), SoundSource.PLAYERS, 6.0F, 1.0F);
        ArsenalLogic.shakeAround(level, c, 24 + radius * 4, 2.6F);
        this.discard();
    }

    /** Wasps, candies and plasma bolts go off where they land (the blocks are spared). */
    private void burst(ServerLevel level, ArsenalDef d, Vec3 at, @Nullable Entity direct) {
        Entity owner = this.getOwner();
        switch (d.proj) {
            case WASP -> {
                float r = Math.max(1.0F, d.sp2);
                ArsenalLogic.splash(level, owner, this, at, r, this.damage * 0.6F, direct);
                ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, 0xFFB020), at, new Vec3(r * 0.8, 0, 0));
                level.sendParticles(ParticleTypes.FALLING_HONEY, at.x, at.y, at.z, 6, r * 0.3, r * 0.2, r * 0.3, 0.0);
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.SPARK, 0xFFD040), at.x, at.y, at.z, 10, 0.1, 0.1, 0.1, 0.3);
                level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("wasp_pop"), SoundSource.PLAYERS, 1.6F, 0.9F + this.random.nextFloat() * 0.2F);
            }
            case CANDY -> {
                float r = Math.max(0.8F, d.sp1);
                ArsenalLogic.splash(level, owner, this, at, r, this.damage * 0.5F, direct);
                ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, 0xFF7AC8), at, new Vec3(r * 0.6, 0, 0));
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.CONFETTI, 0), at.x, at.y, at.z, 22, 0.15, 0.15, 0.15, 0.25);
                level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("candy_pop"), SoundSource.PLAYERS, 1.2F, 0.9F + this.random.nextFloat() * 0.3F);
            }
            default -> {
                float r = Math.max(0.6F, d.sp1);
                ArsenalLogic.splash(level, owner, this, at, r, this.damage * 0.5F, direct);
                ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, d.tracerColor), at, new Vec3(r * 0.7, 0, 0));
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), at.x, at.y, at.z, 6, 0.15, 0.15, 0.15, 0.08);
                level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("plasma_hit"), SoundSource.PLAYERS, 1.0F, 0.9F + this.random.nextFloat() * 0.2F);
                if (owner instanceof Player && this.random.nextFloat() < d.sp2) {
                    BlockHitResult bh = level.clip(new ClipContext(at.add(0, 0.5, 0), at.add(0, -1.5, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
                    if (bh.getType() == HitResult.Type.BLOCK) ArsenalLogic.ignite(level, owner, bh.getLocation(), Direction.UP, bh.getBlockPos(), 1.0F);
                }
            }
        }
        this.discard();
    }

    @Override
    protected void onHit(HitResult result) {
        this.keepFlying = false;
        super.onHit(result);
        if (this.level().isClientSide || this.isRemoved()) return;
        if (this.shotState() != FLYING) return;
        if (result.getType() == HitResult.Type.ENTITY) {
            if (this.pierce-- <= 0) this.discard();
            else this.damage *= 0.85F;
        } else if (result.getType() == HitResult.Type.BLOCK && !this.keepFlying) {
            this.discard();
        }
    }
}
