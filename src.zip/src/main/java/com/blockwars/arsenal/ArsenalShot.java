package com.blockwars.arsenal;

import com.blockwars.arsenal.ArsenalDef.Proj;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Every physical Arsenal projectile: ion rings («Pulsar»), robot wasps («Colmena»), ice lances («Glaciar»), bouncing
 * candies («Dulce Venganza»), the singularity of «Abismo», plasma bolts («Hidra»), and the second ten: returning
 * crescents («Órbita»), chained harpoons («Kraken»), trapping bubbles («Pompa»), playing cards («Comodín»), meteors
 * called down from the sky («Meteoro»), sticky goo («Pegote»), splitting light arrows («Aurora»), cluster shells
 * («Bombarda»), deployable turrets («Vigía») and ricocheting saw blades («Tajo»). Which one it is comes from the synced
 * weapon index; what it does from {@link ArsenalDef#proj}.
 */
public class ArsenalShot extends ThrowableItemProjectile {
    private static final EntityDataAccessor<Integer> DATA_WEAPON = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.INT);
    /**
     * bit 0 tracer, bits 2..4 elemental core (igneous, gelid, voltaic), bit 5 alternate pellet, bit 6 arrow will split,
     * bit 7 bomblet, bit 8 boomerang curves left, bit 9 born mid-flight (no barrel offset)
     */
    private static final EntityDataAccessor<Integer> DATA_FLAGS = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.INT);
    /** see the state constants */
    private static final EntityDataAccessor<Integer> DATA_STATE = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.INT);
    /** charge of the shot (bigger when charged); for goo puddles, their size */
    private static final EntityDataAccessor<Float> DATA_CHARGE = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.FLOAT);
    /** entity held by the shot: harpooned or bubbled creature, a turret's target; -1 = none */
    private static final EntityDataAccessor<Integer> DATA_LINK = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.INT);
    /** block face the shot rests on (puddles, turrets, anchored harpoons) */
    private static final EntityDataAccessor<Integer> DATA_FACE = SynchedEntityData.defineId(ArsenalShot.class, EntityDataSerializers.INT);

    /** flying; stuck in a block (lance, card, arrow, saw); singularity; boomerang coming back; harpoon reeling; bubble with
     * a creature inside; goo puddle; deployed turret */
    public static final int FLYING = 0, STUCK = 1, WELL = 2, RETURN = 3, REEL = 4, TRAP = 5, PUDDLE = 6, TURRET = 7;
    public static final int F_SPLIT = 6, F_BOMBLET = 7, F_LEFT = 8, F_CHILD = 9;
    /** blocks a singularity may tear out of the ground before it collapses */
    private static final int MAX_RIPPED = 28;
    /** cards that landed on a creature lately: entity id -> {count, game time} (server) */
    private static final Map<Integer, long[]> DEALS = new HashMap<>();

    public float damage = 4;
    public int maxAge = 60;
    public int pierce;
    public int bounces;
    public float charge = 1.0F;
    @Nullable public Entity homingTarget;
    private final Set<Integer> hitIds = new HashSet<>();
    private boolean keepFlying;
    private int fuse = -1;
    private int stateTicks;
    private int ripped;
    private double travelled;
    private double liftFrom;

    public ArsenalShot(EntityType<? extends ArsenalShot> type, Level level) {
        super(type, level);
    }

    public ArsenalShot(Level level, LivingEntity shooter, ArsenalDef d) {
        super(ArsenalEntities.SHOT.get(), shooter, level);
        this.entityData.set(DATA_WEAPON, d.index);
        this.setNoGravity(d.gravity == 0);
        if (d.proj == Proj.CANDY) this.fuse = Math.max(10, (int) d.sp2);
    }

    /** A shot born from another one (split arrows, bomblets): same weapon and owner, no barrel to come out of. */
    public ArsenalShot(Level level, @Nullable Entity owner, ArsenalDef d, ArsenalShot parent) {
        super(ArsenalEntities.SHOT.get(), level);
        this.setOwner(owner);
        this.entityData.set(DATA_WEAPON, d.index);
        this.setNoGravity(d.gravity == 0);
        this.entityData.set(DATA_FLAGS, (parent.flags() & 0b11101) | (1 << F_CHILD));
        this.setPos(parent.getX(), parent.getY(), parent.getZ());
    }

    @Nullable
    public ArsenalDef def() {
        return Arsenal.def(this.entityData.get(DATA_WEAPON));
    }

    public int flags() {
        return this.entityData.get(DATA_FLAGS);
    }

    public boolean flag(int bit) {
        return (this.flags() & (1 << bit)) != 0;
    }

    public void setFlag(int bit, boolean on) {
        int f = this.entityData.get(DATA_FLAGS);
        this.entityData.set(DATA_FLAGS, on ? f | (1 << bit) : f & ~(1 << bit));
    }

    public void setTracer(boolean t) {
        this.setFlag(0, t);
    }

    public boolean tracer() {
        return (this.flags() & 1) != 0;
    }

    public boolean alternate() {
        return (this.flags() & 32) != 0;
    }

    /** Elemental core the shot carries (from the weapon's upgrade), or null. */
    @Nullable
    public ArsenalModule element() {
        int f = this.flags();
        if ((f & 4) != 0) return ArsenalModule.INCENDIARY;
        if ((f & 8) != 0) return ArsenalModule.CRYO;
        if ((f & 16) != 0) return ArsenalModule.SHOCK;
        return null;
    }

    public int shotState() {
        return this.entityData.get(DATA_STATE);
    }

    private void setState(int s) {
        this.entityData.set(DATA_STATE, s);
        this.stateTicks = 0;
    }

    public int stateTicks() {
        return this.stateTicks;
    }

    public float chargeLevel() {
        return this.entityData.get(DATA_CHARGE);
    }

    /** How charged the weapon was when this left the barrel (synced: charged shots look bigger). */
    public void setCharge(float c) {
        this.charge = c;
        this.entityData.set(DATA_CHARGE, c);
    }

    /** The creature this shot holds (harpoon, bubble) or aims at (turret), if any. */
    @Nullable
    public Entity link() {
        int id = this.entityData.get(DATA_LINK);
        return id < 0 ? null : this.level().getEntity(id);
    }

    public Direction face() {
        return Direction.from3DDataValue(this.entityData.get(DATA_FACE));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_WEAPON, 0);
        builder.define(DATA_FLAGS, 0);
        builder.define(DATA_STATE, FLYING);
        builder.define(DATA_CHARGE, 1.0F);
        builder.define(DATA_LINK, -1);
        builder.define(DATA_FACE, Direction.UP.get3DDataValue());
    }

    @Override
    protected Item getDefaultItem() {
        return Items.IRON_NUGGET;
    }

    @Override
    protected double getDefaultGravity() {
        ArsenalDef d = this.def();
        if (d == null || this.shotState() != FLYING) return 0.0;
        return d.gravity;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double dist) {
        return dist < 256.0 * 256.0;
    }

    @Override
    public boolean isOnFire() {
        return false;
    }

    // ============================================================== ticking

    @Override
    public void tick() {
        ArsenalDef d = this.def();
        int state = this.shotState();
        if (state == RETURN) {
            this.baseTick();
            if (d != null) this.returnTick(d);
            else if (!this.level().isClientSide) this.discard();
            return;
        }
        if (state != FLYING) {
            this.stateTicks++;
            this.setDeltaMovement(Vec3.ZERO);
            this.baseTick();
            if (d != null) {
                if (this.level().isClientSide) ArsenalShotFx.still(this, d, state);
                else this.serverStateTick(d, state);
            }
            return;
        }
        Vec3 before = this.position();
        float yRot = this.getYRot(), xRot = this.getXRot();
        super.tick();
        if (this.isRemoved() || d == null) return;
        if (this.shotState() == STUCK) {
            // keep the flight attitude: the lance stays the way it went in
            this.setYRot(yRot);
            this.setXRot(xRot);
            this.yRotO = yRot;
            this.xRotO = xRot;
        }
        if (this.shotState() == FLYING && d.drag > 0) this.setDeltaMovement(this.getDeltaMovement().scale(1.0 - d.drag));
        this.travelled += this.position().distanceTo(before);
        if (this.shotState() == FLYING) this.flightShape(d);
        if (this.level().isClientSide) {
            ArsenalShotFx.trail(this, d, before);
            return;
        }
        if (this.shotState() != FLYING) return;
        ServerLevel level = (ServerLevel) this.level();
        if (this.fuse > 0 && --this.fuse == 0) {
            this.burst(level, d, this.position(), null);
            return;
        }
        if (d.proj == Proj.BOOMERANG && this.tickCount >= Math.max(4, (int) d.sp1)) {
            this.startReturn();
            return;
        }
        if (d.proj == Proj.ARROW && this.flag(F_SPLIT) && this.travelled >= Math.max(2.0, d.sp2)) this.split(level, d);
        if (this.tickCount > this.maxAge) {
            switch (d.proj) {
                case VOID -> this.becomeWell(d);
                case WASP, CANDY, PLASMA, METEOR, MORTAR -> this.burst(level, d, this.position(), null);
                case BUBBLE -> this.pop(level, d, this.position(), null, false);
                default -> this.discard();
            }
            return;
        }
        if (this.isInWater() && d.proj != Proj.VOID && d.proj != Proj.HARPOON) {
            if (d.proj == Proj.PLASMA || d.proj == Proj.RING || d.proj == Proj.METEOR) {
                // energy (and a burning rock) dies in water with a hiss
                level.sendParticles(ParticleTypes.BUBBLE, this.getX(), this.getY(), this.getZ(), 8, 0.1, 0.1, 0.1, 0.05);
                level.playSound(null, this.getX(), this.getY(), this.getZ(), net.minecraft.sounds.SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.5F, 1.8F);
                this.discard();
                return;
            }
            if (d.proj == Proj.BUBBLE) {
                this.pop(level, d, this.position(), null, false);
                return;
            }
            this.setDeltaMovement(this.getDeltaMovement().scale(0.6));
            if (this.getDeltaMovement().lengthSqr() < 0.01) this.discard();
        }
        switch (d.proj) {
            case WASP -> this.waspFlight(level, d);
            case VOID -> {
                // the orb already bends the world on its way; it lets go of its owner only while leaving the barrel
                if (this.tickCount % 2 == 0) this.pull(d, d.sp1 * 0.35F, 0.03, this.tickCount < 10);
            }
            default -> { }
        }
    }

    /** Shapes of flight that are not a straight line or a parabola (both sides run it, so the client stays smooth). */
    private void flightShape(ArsenalDef d) {
        Vec3 v = this.getDeltaMovement();
        switch (d.proj) {
            case BOOMERANG -> {
                // the crescent curves out and slows down before it turns back
                double a = Math.toRadians(this.flag(F_LEFT) ? 2.4 : -2.4);
                double c = Math.cos(a), s = Math.sin(a);
                v = new Vec3(v.x * c - v.z * s, v.y * 0.96, v.x * s + v.z * c);
                if (this.tickCount > Math.max(4, (int) d.sp1) / 2) v = v.scale(0.93);
                this.setDeltaMovement(v);
            }
            case BUBBLE -> {
                // soap bubbles wobble as they drift
                float ph = this.tickCount * 0.35F + this.getId() * 0.9F;
                this.setDeltaMovement(v.add(Mth.sin(ph) * 0.012, Mth.cos(ph * 1.3F) * 0.006, Mth.cos(ph) * 0.012));
            }
            default -> { }
        }
    }

    /** Robot wasps keep finding prey: they re-acquire a target and weave as they fly. */
    private void waspFlight(ServerLevel level, ArsenalDef d) {
        Vec3 v = this.getDeltaMovement();
        double sp = v.length();
        if (sp < 1.0E-4) return;
        if ((this.homingTarget == null || !this.homingTarget.isAlive()) && this.tickCount % 4 == 0) this.homingTarget = this.acquire(level, v.normalize());
        if (this.homingTarget != null && this.homingTarget.isAlive() && this.tickCount > 3) {
            Vec3 want = this.homingTarget.getBoundingBox().getCenter().subtract(this.position()).normalize().scale(sp);
            float k = d.sp1 > 0 ? Math.min(0.6F, d.sp1) : 0.2F;
            v = v.add(want.subtract(v).scale(k));
        }
        // the buzzing weave
        Vec3 dir = v.normalize();
        Vec3 side = dir.cross(new Vec3(0, 1, 0));
        if (side.lengthSqr() < 1.0E-4) side = new Vec3(1, 0, 0);
        side = side.normalize();
        Vec3 up = side.cross(dir).normalize();
        float ph = this.tickCount * 1.15F + this.getId() * 1.7F;
        v = v.add(side.scale(Mth.sin(ph) * 0.07 * sp)).add(up.scale(Mth.cos(ph * 1.3F) * 0.05 * sp));
        this.setDeltaMovement(v.normalize().scale(sp));
        this.hasImpulse = true;
    }

    @Nullable
    private Entity acquire(ServerLevel level, Vec3 dir) {
        Entity owner = this.getOwner();
        Entity best = null;
        double bestScore = 0;
        Vec3 from = this.position();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(20.0), e -> e != owner && e.isAlive() && !e.isSpectator()
                && (e instanceof Enemy || e instanceof Player) && !(e instanceof OwnableEntity o && o.getOwner() == owner))) {
            if (e instanceof Player pl && pl.isCreative()) continue;
            Vec3 to = e.getBoundingBox().getCenter().subtract(from);
            double dist = to.length();
            if (dist > 20.0 || dist < 0.5) continue;
            double dot = to.scale(1.0 / dist).dot(dir);
            if (dot < 0.35) continue;
            if (level.clip(new ClipContext(from, e.getBoundingBox().getCenter(), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this)).getType() != HitResult.Type.MISS) continue;
            double score = dot * 2.0 - dist / 20.0;
            if (best == null || score > bestScore) {
                best = e;
                bestScore = score;
            }
        }
        return best;
    }

    // ============================================================== boomerang («Órbita»)

    private void startReturn() {
        this.setState(RETURN);
        this.hitIds.clear();
        this.setNoGravity(true);
    }

    /** The crescent flies home through anything in the way, cutting whatever it passes, and lands back in the hand. */
    private void returnTick(ArsenalDef d) {
        this.stateTicks++;
        Entity owner = this.getOwner();
        boolean server = !this.level().isClientSide;
        if (owner == null || !owner.isAlive() || owner.level() != this.level() || this.stateTicks > 160) {
            if (server) this.discard();
            return;
        }
        Vec3 from = this.position();
        Vec3 to = owner.getEyePosition().add(0, -0.35, 0).subtract(from);
        double dist = to.length();
        double speed = Math.min(Math.max(1.0, d.sp2), 0.45 + this.stateTicks * 0.14);
        Vec3 v = dist < 1.0E-4 ? Vec3.ZERO : to.scale(Math.min(speed, dist) / dist);
        this.setDeltaMovement(v);
        this.setPos(from.add(v));
        if (!server) {
            ArsenalShotFx.trail(this, d, from);
            return;
        }
        ServerLevel level = (ServerLevel) this.level();
        if (dist <= 1.6) {
            this.caught(level, d, owner);
            return;
        }
        Vec3 dir = v.lengthSqr() > 1.0E-6 ? v.normalize() : Vec3.ZERO;
        for (Entity e : level.getEntities(this, this.getBoundingBox().expandTowards(v).inflate(0.5),
                e -> e instanceof LivingEntity && e != owner && e.isAlive() && !e.isSpectator() && !this.hitIds.contains(e.getId()))) {
            this.hitIds.add(e.getId());
            ArsenalLogic.damage(owner, this, e, this.damage * 0.75F, false, dir.scale(0.12), 0.3F);
            ArsenalLogic.applySpecial(level, owner, d, e, e.position());
            ArsenalLogic.applyElement(level, owner, this.element(), e);
            Vec3 c = e.getBoundingBox().getCenter();
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), c.x, c.y, c.z, 5, 0.15, 0.2, 0.15, 0.05);
        }
    }

    /** Back in the hand: one more crescent in the launcher (or in the pocket, if the launcher is not in hand). */
    private void caught(ServerLevel level, ArsenalDef d, Entity owner) {
        if (owner instanceof Player pl) {
            ItemStack s = pl.getMainHandItem();
            if (s.getItem() instanceof ArsenalItem it && it.def == d && !ArsenalData.reloading(s) && ArsenalData.ammo(s) < ArsenalModule.mag(s, d)) {
                ArsenalData.setAmmo(s, ArsenalData.ammo(s) + 1);
            } else if (!pl.isCreative()) {
                var item = Arsenal.AMMO.get(d.ammo);
                if (item != null) {
                    ItemStack st = new ItemStack(item.get());
                    if (!pl.getInventory().add(st)) pl.drop(st, false);
                }
            }
        }
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), this.getX(), this.getY(), this.getZ(), 8, 0.2, 0.2, 0.2, 0.06);
        level.playSound(null, owner.getX(), owner.getEyeY(), owner.getZ(), ArsenalSounds.shared("boomerang_catch"), SoundSource.PLAYERS, 0.9F,
                0.95F + this.random.nextFloat() * 0.1F);
        this.discard();
    }

    // ============================================================== stuck / singularity / harpoon / bubble / puddle / turret (server)

    private void serverStateTick(ArsenalDef d, int state) {
        ServerLevel level = (ServerLevel) this.level();
        switch (state) {
            case WELL -> this.wellTick(level, d);
            case REEL -> this.reelTick(level, d);
            case TRAP -> this.trapTick(level, d);
            case PUDDLE -> this.puddleTick(level, d);
            case TURRET -> this.turretTick(level, d);
            default -> {
                if (d.proj == Proj.ICE) {
                    // an ice lance melts out of the wall
                    if (this.stateTicks > 70) {
                        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.ICE.defaultBlockState()), this.getX(), this.getY(), this.getZ(), 12, 0.1, 0.1, 0.1, 0.1);
                        level.playSound(null, this.getX(), this.getY(), this.getZ(), ArsenalSounds.shared("ice_shatter"), SoundSource.PLAYERS, 0.4F, 1.5F);
                        this.discard();
                    }
                } else if (this.stateTicks > stuckLife(d)) {
                    // cards, arrows and saw blades fade out of the wall
                    level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), this.getX(), this.getY(), this.getZ(), 3, 0.05, 0.05, 0.05, 0.02);
                    this.discard();
                }
            }
        }
    }

    /** Ticks a card, arrow or saw blade stays in the wall. */
    public static int stuckLife(ArsenalDef d) {
        return switch (d.proj) {
            case SAW -> Math.max(20, (int) d.sp2);
            case ARROW -> 60;
            default -> 80;
        };
    }

    private void wellTick(ServerLevel level, ArsenalDef d) {
        float r = Math.max(3.0F, d.sp1);
        int life = Math.max(30, (int) d.sp2);
        float t = Math.min(1.0F, this.stateTicks / (float) life);
        Vec3 c = this.position();
        this.pull(d, r * (0.6F + 0.4F * t), 0.05 + 0.13 * t, false);
        // the core grinds whatever it holds: its owner included
        if (this.stateTicks % 5 == 0) {
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(1.7), e -> e.isAlive() && !e.isSpectator())) {
                if (e instanceof Player pl && pl.isCreative()) continue;
                e.invulnerableTime = 0;
                e.hurt(level.damageSources().magic(), d.damage * 0.25F);
            }
        }
        // falling blocks that reach the core are gone for good
        for (FallingBlockEntity fb : level.getEntitiesOfClass(FallingBlockEntity.class, new AABB(c, c).inflate(1.3))) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, fb.getBlockState()), fb.getX(), fb.getY() + 0.5, fb.getZ(), 10, 0.25, 0.25, 0.25, 0.05);
            fb.discard();
        }
        if (this.stateTicks > 12 && this.stateTicks % 2 == 0) this.rip(level, r, t);
        if (this.stateTicks % 20 == 1) {
            level.playSound(null, c.x, c.y, c.z, ArsenalSounds.shared("gravity"), SoundSource.PLAYERS, 2.5F, 0.6F + t * 0.6F);
            ArsenalLogic.shakeAround(level, c, r * 2.5, 0.3F + t * 0.7F);
        }
        if (this.stateTicks % 10 == 0) ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.RING, 0x9A5CFF), c, new Vec3(0, -r * (1.0 - t * 0.5), 0));
        if (this.stateTicks >= life) this.collapse(level, d, r);
    }

    /** The singularity tears loose blocks out of the ground and swallows them. */
    private void rip(ServerLevel level, float r, float t) {
        if (this.ripped >= MAX_RIPPED || !level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return;
        if (!(this.getOwner() instanceof Player owner)) return;
        float reach = Math.min(5.5F, r * (0.35F + 0.3F * t));
        BlockPos center = this.blockPosition();
        for (int attempt = 0; attempt < 4; attempt++) {
            double a = this.random.nextDouble() * Math.PI * 2.0;
            double rr = Math.sqrt(this.random.nextDouble()) * reach;
            int x = center.getX() + (int) Math.round(Math.cos(a) * rr);
            int z = center.getZ() + (int) Math.round(Math.sin(a) * rr);
            for (int y = center.getY() + 2; y >= center.getY() - 4; y--) {
                BlockPos pos = new BlockPos(x, y, z);
                BlockState st = level.getBlockState(pos);
                if (st.isAir()) continue;
                if (!this.rippable(level, pos, st, owner)) break;
                FallingBlockEntity fb = FallingBlockEntity.fall(level, pos, st);
                Vec3 to = this.position().subtract(fb.position());
                fb.setDeltaMovement(to.normalize().scale(0.25).add(0, 0.45, 0));
                fb.hurtMarked = true;
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), x + 0.5, y + 1.0, z + 0.5, 8, 0.3, 0.1, 0.3, 0.05);
                this.ripped++;
                return;
            }
        }
    }

    private boolean rippable(ServerLevel level, BlockPos pos, BlockState st, Player owner) {
        if (st.hasBlockEntity() || !st.getFluidState().isEmpty()) return false;
        float hardness = st.getDestroySpeed(level, pos);
        if (hardness < 0 || hardness > 3.0F) return false;
        if (!level.getBlockState(pos.above()).isAir()) return false;
        return level.mayInteract(owner, pos);
    }

    /** Pull everything around toward this point. Players too: «Abismo» does not care who fired it. */
    private void pull(ArsenalDef d, float radius, double strength, boolean spareOwner) {
        if (this.level().isClientSide || radius <= 0) return;
        Vec3 c = this.position();
        Entity owner = this.getOwner();
        for (Entity e : this.level().getEntities(this, new AABB(c, c).inflate(radius), e -> !(e instanceof ArsenalShot) && !e.isSpectator())) {
            if (e instanceof Player pl && (pl.isCreative() && pl.getAbilities().flying)) continue;
            if (spareOwner && e == owner) continue;
            Vec3 to = c.subtract(e.position().add(0, e.getBbHeight() * 0.5, 0));
            double dist = to.length();
            if (dist < 0.3 || dist > radius) continue;
            double k = strength * (1.0 - dist / radius) * 2.0 + strength * 0.25;
            Vec3 add = to.scale(k / dist);
            e.setDeltaMovement(e.getDeltaMovement().scale(0.92).add(add));
            e.hurtMarked = true;
            e.fallDistance = 0;
        }
    }

    // ------------------------------------------------------------------ harpoon («Kraken»)

    /** Harpooned: the chain holds the creature. */
    private void hook(ServerLevel level, ArsenalDef d, Entity e, Vec3 at) {
        Entity owner = this.getOwner();
        ArsenalLogic.damage(owner, this, e, this.damage * this.falloff(d), false, Vec3.ZERO, 0.1F);
        ArsenalLogic.applyElement(level, owner, this.element(), e);
        level.sendParticles(ParticleTypes.SPLASH, at.x, at.y, at.z, 12, 0.2, 0.2, 0.2, 0.1);
        level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("harpoon_hit"), SoundSource.PLAYERS, 1.0F, 0.9F + this.random.nextFloat() * 0.2F);
        if (!e.isAlive() || owner == null) {
            this.discard();
            return;
        }
        this.entityData.set(DATA_LINK, e.getId());
        this.setState(REEL);
        this.setNoGravity(true);
        this.setDeltaMovement(Vec3.ZERO);
    }

    /** The harpoon bit into a wall: the chain will haul its owner over. */
    private void anchor(ServerLevel level, ArsenalDef d, BlockHitResult hit) {
        Direction face = hit.getDirection();
        Vec3 at = hit.getLocation();
        ArsenalLogic.impact(level, at, face, hit.getBlockPos(), level.getBlockState(hit.getBlockPos()), d, this.getOwner());
        level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("harpoon_hit"), SoundSource.PLAYERS, 1.0F, 0.7F);
        this.setPos(at.x + face.getStepX() * 0.05, at.y + face.getStepY() * 0.05, at.z + face.getStepZ() * 0.05);
        this.entityData.set(DATA_LINK, -1);
        this.entityData.set(DATA_FACE, face.get3DDataValue());
        this.setState(REEL);
        this.setNoGravity(true);
        this.setDeltaMovement(Vec3.ZERO);
    }

    /** Creatures too big to drag (bosses, giants) hold the chain like a wall does. */
    private static boolean tooBigToDrag(Entity e) {
        return e.getBbWidth() * e.getBbWidth() * e.getBbHeight() > 6.0F || e.getType().is(Tags.EntityTypes.BOSSES)
            || e.getType().is(Tags.EntityTypes.CAPTURING_NOT_SUPPORTED);
    }

    private void reelTick(ServerLevel level, ArsenalDef d) {
        Entity owner = this.getOwner();
        int max = Math.max(10, (int) d.sp2);
        if (owner == null || !owner.isAlive() || owner.level() != level || this.stateTicks > max) {
            this.discard();
            return;
        }
        Entity link = this.link();
        if (this.entityData.get(DATA_LINK) >= 0 && (link == null || !link.isAlive())) {
            this.discard();
            return;
        }
        Vec3 oc = owner.position().add(0, owner.getBbHeight() * 0.5, 0);
        if (link != null && !tooBigToDrag(link)) {
            // reel the catch in
            Vec3 lc = link.position().add(0, link.getBbHeight() * 0.5, 0);
            Vec3 to = oc.subtract(lc);
            double dist = to.length();
            if (dist < 2.2 || dist > d.range * 1.6) {
                this.discard();
                return;
            }
            double sp = Math.min(1.25, 0.3 + dist * 0.07) * Math.max(0.3F, d.sp1) / 0.55;
            link.setDeltaMovement(to.scale(sp / dist).add(0, 0.06, 0));
            link.hurtMarked = true;
            link.fallDistance = 0;
            this.setPos(lc.x, lc.y, lc.z);
        } else {
            // anchored (a wall, or something too big to move): haul the shooter in; sneaking lets go
            Vec3 anchor = link != null ? link.position().add(0, link.getBbHeight() * 0.5, 0) : this.position();
            if (link != null) this.setPos(anchor.x, anchor.y, anchor.z);
            Vec3 to = anchor.subtract(oc);
            double dist = to.length();
            if (dist < 1.8 || owner.isShiftKeyDown() || dist > d.range * 1.6) {
                this.discard();
                return;
            }
            double sp = Math.min(1.4, 0.35 + dist * 0.08);
            owner.setDeltaMovement(to.scale(sp / dist).add(0, 0.04, 0));
            owner.hurtMarked = true;
            owner.fallDistance = 0;
        }
    }

    // ------------------------------------------------------------------ bubble («Pompa»)

    private boolean trappable(ServerLevel level, Entity e) {
        if (!(e instanceof LivingEntity) || e == this.getOwner() || !e.isAlive()) return false;
        if (e.getBbWidth() > 1.6F || e.getBbHeight() > 2.7F || e.getType().is(Tags.EntityTypes.BOSSES)
            || e.getType().is(Tags.EntityTypes.CAPTURING_NOT_SUPPORTED)) return false;
        if (e instanceof Player pl && (pl.isCreative() || pl.isSpectator())) return false;
        // one bubble per creature: is another bubble already holding it?
        int id = e.getId();
        return level.getEntitiesOfClass(ArsenalShot.class, e.getBoundingBox().inflate(2.0),
                s -> s != this && s.shotState() == TRAP && s.entityData.get(DATA_LINK) == id).isEmpty();
    }

    /** A bubble closes around the creature and floats it up; a new hit (or time) pops it. */
    private void trap(ServerLevel level, ArsenalDef d, Entity e, Vec3 at) {
        if (!this.trappable(level, e)) {
            ArsenalLogic.damage(this.getOwner(), this, e, this.damage, false, Vec3.ZERO, 0.1F);
            this.pop(level, d, at, null, false);
            return;
        }
        this.liftFrom = e.getY();
        this.entityData.set(DATA_LINK, e.getId());
        this.setState(TRAP);
        this.setNoGravity(true);
        this.setDeltaMovement(Vec3.ZERO);
        Vec3 c = e.getBoundingBox().getCenter();
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.BUBBLE, d.tracerColor), c.x, c.y, c.z, 10, 0.3, 0.4, 0.3, 0.03);
        level.playSound(null, c.x, c.y, c.z, ArsenalSounds.shared("bubble_pop"), SoundSource.PLAYERS, 0.8F, 0.6F);
    }

    private void trapTick(ServerLevel level, ArsenalDef d) {
        Entity e = this.link();
        int life = Math.max(20, (int) d.sp1);
        if (e == null || !e.isAlive()) {
            this.pop(level, d, this.position(), null, false);
            return;
        }
        boolean hit = this.stateTicks > 4 && e instanceof LivingEntity le && le.hurtTime >= 9;
        if (this.stateTicks > life || hit) {
            this.pop(level, d, e.getBoundingBox().getCenter(), e, hit);
            return;
        }
        double vy = (this.liftFrom + Math.max(0.5, d.sp2) - e.getY()) * 0.18;
        e.setDeltaMovement(0, Mth.clamp(vy, -0.1, 0.25), 0);
        e.hurtMarked = true;
        e.fallDistance = 0;
        Vec3 c = e.getBoundingBox().getCenter();
        this.setPos(c.x, c.y, c.z);
    }

    /** Pop: a bubble that held something lets it fall; popped by a hit, it stings much harder. */
    private void pop(ServerLevel level, ArsenalDef d, Vec3 at, @Nullable Entity held, boolean byHit) {
        if (held != null) {
            ArsenalLogic.damage(this.getOwner(), this, held, byHit ? this.damage * 2.5F : this.damage, false, Vec3.ZERO, 0.1F);
            ArsenalLogic.applyElement(level, this.getOwner(), this.element(), held);
        }
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.BUBBLE, d.tracerColor), at.x, at.y, at.z, held != null ? 16 : 6, 0.25, 0.25, 0.25, 0.08);
        level.sendParticles(ParticleTypes.SPLASH, at.x, at.y, at.z, held != null ? 10 : 4, 0.2, 0.2, 0.2, 0.05);
        level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("bubble_pop"), SoundSource.PLAYERS, held != null ? 1.0F : 0.6F,
                (held != null ? 0.9F : 1.2F) + this.random.nextFloat() * 0.2F);
        this.discard();
    }

    // ------------------------------------------------------------------ cards («Comodín»)

    /** Three cards on the same creature in quick succession: the deal pays out. */
    private void deal(ServerLevel level, ArsenalDef d, Entity e, @Nullable Entity owner) {
        long now = level.getGameTime();
        if (DEALS.size() > 256) DEALS.entrySet().removeIf(en -> now - en.getValue()[1] > 60);
        long[] c = DEALS.computeIfAbsent(e.getId(), k -> new long[2]);
        if (now - c[1] > 40) c[0] = 0;
        c[0]++;
        c[1] = now;
        if (c[0] < 3 || !e.isAlive()) return;
        c[0] = 0;
        ArsenalLogic.damage(owner, this, e, Math.max(2.0F, d.sp1), false, Vec3.ZERO, 0.2F);
        Vec3 cc = e.getBoundingBox().getCenter();
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.SUIT, 0), cc.x, cc.y, cc.z, 14, 0.3, 0.4, 0.3, 0.15);
        level.playSound(null, cc.x, cc.y, cc.z, ArsenalSounds.shared("card_deal"), SoundSource.PLAYERS, 1.2F, 1.0F);
    }

    // ------------------------------------------------------------------ light arrows («Aurora»)

    /** A fully drawn arrow splits into a fan of light arrows a few blocks out. */
    private void split(ServerLevel level, ArsenalDef d) {
        this.setFlag(F_SPLIT, false);
        int n = Math.max(3, (int) d.sp1);
        Vec3 v = this.getDeltaMovement();
        for (int i = 1; i < n; i++) {
            double yaw = Math.toRadians((i % 2 == 1 ? 1 : -1) * 7.0 * ((i + 1) / 2));
            double c = Math.cos(yaw), s = Math.sin(yaw);
            ArsenalShot child = new ArsenalShot(level, this.getOwner(), d, this);
            child.setDeltaMovement(new Vec3(v.x * c - v.z * s, v.y, v.x * s + v.z * c));
            child.damage = this.damage * 0.6F;
            child.maxAge = Math.max(10, this.maxAge - this.tickCount);
            child.pierce = this.pierce;
            child.travelled = this.travelled;
            child.setCharge(this.charge);
            level.addFreshEntity(child);
        }
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), this.getX(), this.getY(), this.getZ(), 8, 0.15, 0.15, 0.15, 0.06);
        level.playSound(null, this.getX(), this.getY(), this.getZ(), ArsenalSounds.shared("arrow_split"), SoundSource.PLAYERS, 1.0F, 1.1F);
    }

    // ------------------------------------------------------------------ goo («Pegote»)

    /** Goo landing on a block spreads into a sticky puddle (or makes a puddle already there bigger). */
    private void puddle(ServerLevel level, ArsenalDef d, Vec3 at, Direction face) {
        for (ArsenalShot o : level.getEntitiesOfClass(ArsenalShot.class, new AABB(at, at).inflate(1.0), o -> o != this && o.shotState() == PUDDLE && o.def() == d)) {
            if (o.position().distanceToSqr(at) < 0.81 && o.face() == face) {
                o.stateTicks = Math.min(o.stateTicks, 10);
                o.setCharge(Math.min(1.7F, o.chargeLevel() + 0.12F));
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.DRIP, d.tracerColor), at.x, at.y, at.z, 3, 0.1, 0.05, 0.1, 0.05);
                this.discard();
                return;
            }
        }
        this.setPos(at.x + face.getStepX() * 0.03, at.y + face.getStepY() * 0.03, at.z + face.getStepZ() * 0.03);
        this.entityData.set(DATA_FACE, face.get3DDataValue());
        this.setState(PUDDLE);
        this.setDeltaMovement(Vec3.ZERO);
        this.setNoGravity(true);
        this.setCharge(1.0F);
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.DRIP, d.tracerColor), at.x, at.y, at.z, 6, 0.15, 0.05, 0.15, 0.08);
        level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("goo_splat"), SoundSource.PLAYERS, 0.7F, 0.9F + this.random.nextFloat() * 0.3F);
    }

    private void puddleTick(ServerLevel level, ArsenalDef d) {
        int life = Math.max(40, (int) d.sp2);
        if (this.stateTicks > life) {
            this.discard();
            return;
        }
        if (this.stateTicks % 4 != 0) return;
        float r = Math.max(0.8F, d.sp1) * this.chargeLevel();
        Vec3 c = this.position();
        Direction.Axis ax = this.face().getAxis();
        double ex = ax == Direction.Axis.X ? 0.4 : r, ey = ax == Direction.Axis.Y ? 0.4 : r, ez = ax == Direction.Axis.Z ? 0.4 : r;
        AABB zone = new AABB(c.x - ex, c.y - ey, c.z - ez, c.x + ex, c.y + ey, c.z + ez);
        Entity owner = this.getOwner();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, zone, e -> e.isAlive() && e != owner && !e.isSpectator())) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 14, 3, false, false));
            if (!(e instanceof Player)) {
                Vec3 v = e.getDeltaMovement();
                e.setDeltaMovement(v.x * 0.3, Math.min(v.y, 0.05), v.z * 0.3);
                e.hurtMarked = true;
            }
        }
    }

    // ------------------------------------------------------------------ turret («Vigía»)

    /** The capsule lands on its feet and unfolds into a turret (two per owner: the oldest one packs up). */
    private void deploy(ServerLevel level, Vec3 at) {
        Entity owner = this.getOwner();
        if (owner != null) {
            List<ArsenalShot> mine = level.getEntitiesOfClass(ArsenalShot.class, this.getBoundingBox().inflate(128),
                    s -> s != this && s.shotState() == TURRET && s.getOwner() == owner);
            if (mine.size() >= 2) {
                mine.sort(Comparator.comparingInt(s -> -s.stateTicks));
                mine.get(0).packUp(level);
            }
            this.setYRot(owner.getYRot());
            this.yRotO = this.getYRot();
        }
        this.setPos(at.x, at.y + 0.02, at.z);
        this.entityData.set(DATA_FACE, Direction.UP.get3DDataValue());
        this.entityData.set(DATA_LINK, -1);
        this.setState(TURRET);
        this.setDeltaMovement(Vec3.ZERO);
        this.setNoGravity(true);
        level.sendParticles(ParticleTypes.CLOUD, at.x, at.y + 0.2, at.z, 8, 0.3, 0.05, 0.3, 0.02);
        level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("turret_deploy"), SoundSource.PLAYERS, 1.0F, 1.0F);
    }

    private void turretTick(ServerLevel level, ArsenalDef d) {
        int life = Math.max(60, (int) d.sp1);
        if (this.stateTicks > life || this.stateTicks % 10 == 0 && level.getBlockState(BlockPos.containing(this.getX(), this.getY() - 0.1, this.getZ())).isAir()) {
            this.packUp(level);
            return;
        }
        Vec3 head = this.position().add(0, 0.55, 0);
        Entity target = this.link();
        float range = Math.max(4.0F, d.range);
        if (this.stateTicks % 5 == 0) {
            if (target == null || !target.isAlive() || target.distanceToSqr(head) > range * range || !this.sees(level, head, target)) {
                target = this.turretTarget(level, head, range);
            }
            this.entityData.set(DATA_LINK, target == null ? -1 : target.getId());
        }
        int every = Math.max(2, (int) d.sp2);
        if (target != null && target.isAlive() && this.stateTicks > 12 && this.stateTicks % every == 0) {
            Vec3 c = target.getBoundingBox().getCenter();
            Entity owner = this.getOwner();
            ArsenalLogic.damage(owner, this, target, this.damage, false, c.subtract(head).normalize().scale(0.05), 0.2F);
            ArsenalLogic.applyElement(level, owner, this.element(), target);
            ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BEAM, d.index), head, c.subtract(head));
            level.playSound(null, head.x, head.y, head.z, ArsenalSounds.shared("turret_shot"), SoundSource.PLAYERS, 0.8F, 0.95F + this.random.nextFloat() * 0.1F);
        }
    }

    private boolean sees(ServerLevel level, Vec3 from, Entity e) {
        return level.clip(new ClipContext(from, e.getBoundingBox().getCenter(), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this)).getType() == HitResult.Type.MISS;
    }

    /** Nearest hostile creature in sight. */
    @Nullable
    private Entity turretTarget(ServerLevel level, Vec3 head, float range) {
        Entity owner = this.getOwner();
        Entity best = null;
        double bestD = range * range;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(head, head).inflate(range), e -> e instanceof Enemy && e.isAlive()
                && !e.isSpectator() && e != owner && !(e instanceof OwnableEntity o && o.getOwner() == owner))) {
            double dd = e.getBoundingBox().getCenter().distanceToSqr(head);
            if (dd < bestD && this.sees(level, head, e)) {
                bestD = dd;
                best = e;
            }
        }
        return best;
    }

    private void packUp(ServerLevel level) {
        Vec3 c = this.position().add(0, 0.4, 0);
        ArsenalDef d = this.def();
        ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, d != null ? d.tracerColor : 0x60D0FF), c, new Vec3(0.6, 0, 0));
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.SPARK, 0x80E0FF), c.x, c.y, c.z, 10, 0.2, 0.2, 0.2, 0.2);
        level.playSound(null, c.x, c.y, c.z, ArsenalSounds.shared("boom_small"), SoundSource.PLAYERS, 0.8F, 1.4F);
        this.discard();
    }

    // ============================================================== hits

    @Override
    protected boolean canHitEntity(Entity entity) {
        if (this.hitIds.contains(entity.getId())) return false;
        if (entity instanceof ArsenalShot || entity instanceof FallingBlockEntity) return false;
        return super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity e = result.getEntity();
        this.hitIds.add(e.getId());
        if (this.level().isClientSide) return;
        ArsenalDef d = this.def();
        if (d == null) return;
        ServerLevel level = (ServerLevel) this.level();
        Vec3 at = result.getLocation();
        Entity owner = this.getOwner();
        switch (d.proj) {
            case VOID -> {
                this.setPos(at.x, at.y, at.z);
                this.becomeWell(d);
                return;
            }
            case WASP, CANDY, PLASMA, METEOR, MORTAR -> {
                ArsenalLogic.damage(owner, this, e, this.damage, false, this.getDeltaMovement().normalize().scale(0.1), 0.3F);
                ArsenalLogic.applySpecial(level, owner, d, e, at);
                ArsenalLogic.applyElement(level, owner, this.element(), e);
                this.burst(level, d, at, e);
                return;
            }
            case HARPOON -> {
                this.hook(level, d, e, at);
                return;
            }
            case BUBBLE -> {
                this.trap(level, d, e, at);
                return;
            }
            case GOO -> {
                ArsenalLogic.damage(owner, this, e, this.damage, false, Vec3.ZERO, 0.1F);
                ArsenalLogic.applySpecial(level, owner, d, e, at);
                ArsenalLogic.applyElement(level, owner, this.element(), e);
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.DRIP, d.tracerColor), at.x, at.y, at.z, 8, 0.2, 0.3, 0.2, 0.08);
                level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("goo_splat"), SoundSource.PLAYERS, 0.8F, 1.0F + this.random.nextFloat() * 0.2F);
                this.discard();
                return;
            }
            case TURRET -> {
                // the capsule only bonks whoever it hits on its way down
                ArsenalLogic.damage(owner, this, e, 1.0F, false, Vec3.ZERO, 0.2F);
                this.setDeltaMovement(this.getDeltaMovement().multiply(-0.2, 0.3, -0.2));
                return;
            }
            default -> { }
        }
        // rings, lances, crescents, cards, arrows and saw blades: piercing hits
        boolean head = false;
        float dmg = this.damage * this.falloff(d);
        if (e instanceof LivingEntity le && le.getBbHeight() > 0.9F && at.y >= le.getEyeY() - 0.22) {
            head = true;
            dmg *= d.headMul;
        }
        boolean shattered = false;
        if (d.proj == Proj.ICE && e.isFullyFrozen()) {
            // a frozen target shatters
            shattered = true;
            dmg *= Math.max(1.0F, d.sp2);
            e.setTicksFrozen(0);
            Vec3 c = e.getBoundingBox().getCenter();
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.ICE.defaultBlockState()), c.x, c.y, c.z, 40, 0.35, 0.5, 0.35, 0.25);
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.FROST, 0xD8F6FF), c.x, c.y, c.z, 16, 0.4, 0.5, 0.4, 0.12);
            level.playSound(null, c.x, c.y, c.z, ArsenalSounds.shared("ice_shatter"), SoundSource.PLAYERS, 1.6F, 0.8F);
        }
        ArsenalLogic.damage(owner, this, e, dmg, head, this.getDeltaMovement().normalize().scale(0.05), 0.25F);
        ArsenalLogic.applySpecial(level, owner, d, e, at);
        ArsenalLogic.applyElement(level, owner, this.element(), e);
        if (d.proj == Proj.ICE && !shattered && this.charge >= 0.99F && e.isAlive()) {
            // a fully charged lance freezes its target solid for a few seconds: the next hit shatters it
            e.setTicksFrozen(Math.max(e.getTicksFrozen(), e.getTicksRequiredToFreeze() + 100));
        }
        if (d.proj == Proj.CARD) this.deal(level, d, e, owner);
        Vec3 c = e.getBoundingBox().getCenter();
        if (d.proj == Proj.ICE) {
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.FROST, 0xC8F0FF), c.x, c.y, c.z, 10, 0.25, 0.35, 0.25, 0.06);
        } else if (d.proj == Proj.SAW) {
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.SPARK, 0xFFD080), at.x, at.y, at.z, 6, 0.1, 0.1, 0.1, 0.2);
        } else {
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), at.x, at.y, at.z, 4, 0.1, 0.1, 0.1, 0.04);
        }
    }

    /** Energy loses punch past the effective range. */
    private float falloff(ArsenalDef d) {
        double r = Math.max(4.0, d.range);
        if (this.travelled < r * 0.6) return 1.0F;
        return (float) Math.max(0.6, 1.0 - (this.travelled - r * 0.6) / r * 0.8);
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!(this.level() instanceof ServerLevel level)) return;
        ArsenalDef d = this.def();
        if (d == null) return;
        BlockPos pos = result.getBlockPos();
        BlockState st = level.getBlockState(pos);
        Vec3 at = result.getLocation();
        Direction face = result.getDirection();
        Entity owner = this.getOwner();
        Player pl = owner instanceof Player p ? p : null;
        // rings, lances, plasma, saw blades and arrows go straight through glass
        boolean glassBreaker = d.proj == Proj.RING || d.proj == Proj.ICE || d.proj == Proj.PLASMA || d.proj == Proj.SAW || d.proj == Proj.ARROW;
        if (glassBreaker && (st.is(Tags.Blocks.GLASS_PANES) || st.is(Tags.Blocks.GLASS_BLOCKS)) && pl != null && level.mayInteract(pl, pos)) {
            level.destroyBlock(pos, false, pl);
            this.setDeltaMovement(this.getDeltaMovement().scale(0.85));
            this.keepFlying = true;
            return;
        }
        Vec3 off = at.add(face.getStepX() * 0.1, face.getStepY() * 0.1, face.getStepZ() * 0.1);
        switch (d.proj) {
            case VOID -> {
                this.setPos(at.x + face.getStepX() * 0.8, at.y + face.getStepY() * 0.8, at.z + face.getStepZ() * 0.8);
                this.becomeWell(d);
                this.keepFlying = true;
                return;
            }
            case WASP, PLASMA, METEOR, MORTAR -> {
                this.burst(level, d, off, null);
                return;
            }
            case CANDY -> {
                if (this.bounces > 0) {
                    this.bounces--;
                    this.bounce(face, 0.62);
                    this.hitIds.clear();
                    level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("candy_bounce"), SoundSource.PLAYERS, 0.6F, 0.9F + this.random.nextFloat() * 0.5F);
                    level.sendParticles(ArsenalParticles.of(ArsenalParticles.CONFETTI, 0), at.x, at.y, at.z, 3, 0.05, 0.05, 0.05, 0.08);
                    this.keepFlying = true;
                    return;
                }
                this.burst(level, d, off, null);
                return;
            }
            case BUBBLE -> {
                this.pop(level, d, off, null, false);
                return;
            }
            case GOO -> {
                this.puddle(level, d, at, face);
                this.keepFlying = true;
                return;
            }
            case HARPOON -> {
                this.anchor(level, d, result);
                this.keepFlying = true;
                return;
            }
            case BOOMERANG -> {
                // the crescent glances off the wall and heads home early
                ArsenalLogic.impact(level, at, face, pos, st, d, owner);
                this.setPos(off.x, off.y, off.z);
                this.startReturn();
                this.keepFlying = true;
                return;
            }
            case TURRET -> {
                if (face == Direction.UP) {
                    this.deploy(level, at);
                } else {
                    // walls and ceilings: it clatters off and keeps falling
                    this.setPos(off.x, off.y, off.z);
                    this.setDeltaMovement(new Vec3(face.getStepX() * 0.12, -0.05, face.getStepZ() * 0.12));
                    level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("round"), SoundSource.PLAYERS, 0.5F, 0.6F);
                }
                this.keepFlying = true;
                return;
            }
            case SAW -> {
                if (this.bounces > 0) {
                    // saw blades ricochet off everything they cannot cut
                    this.bounces--;
                    this.bounce(face, 0.96);
                    this.hitIds.clear();
                    level.sendParticles(ArsenalParticles.of(ArsenalParticles.SPARK, 0xFFD080), at.x, at.y, at.z, 10, 0.05, 0.05, 0.05, 0.3);
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), at.x, at.y, at.z, 4, 0.05, 0.05, 0.05, 0.12);
                    level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("saw_ricochet"), SoundSource.PLAYERS, 0.8F, 0.9F + this.random.nextFloat() * 0.3F);
                    this.keepFlying = true;
                    return;
                }
                ArsenalLogic.impact(level, at, face, pos, st, d, owner);
                this.stick(at);
                this.keepFlying = true;
                return;
            }
            case CARD, ARROW -> {
                ArsenalLogic.impact(level, at, face, pos, st, d, owner);
                if (this.element() == ArsenalModule.INCENDIARY) ArsenalLogic.ignite(level, owner, at, face, pos, 0.3F);
                this.stick(at);
                this.keepFlying = true;
                return;
            }
            default -> { }
        }
        ArsenalLogic.impact(level, at, face, pos, st, d, owner);
        if (this.element() == ArsenalModule.INCENDIARY) ArsenalLogic.ignite(level, owner, at, face, pos, 0.3F);
        if (d.proj == Proj.ICE) {
            this.frostBite(level, pos.relative(face), pl);
            this.stick(at);
            this.keepFlying = true;
            return;
        }
        // ion rings glance off at shallow angles
        Vec3 v = this.getDeltaMovement();
        double grazing = Math.abs(v.normalize().dot(new Vec3(face.getStepX(), face.getStepY(), face.getStepZ())));
        if (this.bounces > 0 && grazing < 0.45) {
            this.bounces--;
            this.bounce(face, 0.85);
            this.damage *= 0.8F;
            this.hitIds.clear();
            level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("energy_hit"), SoundSource.PLAYERS, 0.6F, 1.4F + this.random.nextFloat() * 0.3F);
            this.keepFlying = true;
        }
    }

    /** Lance, card, arrow or saw blade: stays in the block the way it went in. */
    private void stick(Vec3 at) {
        Vec3 n = this.getDeltaMovement().lengthSqr() > 1.0E-8 ? this.getDeltaMovement().normalize() : Vec3.ZERO;
        this.setPos(at.x - n.x * 0.3, at.y - n.y * 0.3, at.z - n.z * 0.3);
        this.setDeltaMovement(Vec3.ZERO);
        this.setNoGravity(true);
        this.setState(STUCK);
    }

    /** Ice lances freeze the water around where they land and snuff out fire. */
    private void frostBite(ServerLevel level, BlockPos at, @Nullable Player pl) {
        if (pl == null) return;
        for (BlockPos bp : BlockPos.betweenClosed(at.offset(-2, -2, -2), at.offset(2, 1, 2))) {
            if (bp.distSqr(at) > 6.5) continue;
            BlockState st = level.getBlockState(bp);
            if (!level.mayInteract(pl, bp)) continue;
            if (st.is(Blocks.WATER) && level.getFluidState(bp).isSource() && level.getBlockState(bp.above()).isAir()) {
                BlockPos imm = bp.immutable();
                level.setBlockAndUpdate(imm, Blocks.FROSTED_ICE.defaultBlockState());
                level.scheduleTick(imm, Blocks.FROSTED_ICE, Mth.nextInt(this.random, 60, 120));
            } else if (st.is(Blocks.FIRE)) {
                level.removeBlock(bp.immutable(), false);
            }
        }
    }

    private void bounce(Direction face, double keep) {
        Vec3 v = this.getDeltaMovement();
        v = switch (face.getAxis()) {
            case X -> new Vec3(-v.x, v.y, v.z);
            case Y -> new Vec3(v.x, -v.y, v.z);
            case Z -> new Vec3(v.x, v.y, -v.z);
        };
        this.setDeltaMovement(v.scale(keep));
        this.setPos(this.getX() + face.getStepX() * 0.05, this.getY() + face.getStepY() * 0.05, this.getZ() + face.getStepZ() * 0.05);
        this.hasImpulse = true;
    }

    private void becomeWell(ArsenalDef d) {
        this.setDeltaMovement(Vec3.ZERO);
        this.setNoGravity(true);
        this.setState(WELL);
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(), ArsenalSounds.shared("void_open"), SoundSource.PLAYERS, 3.0F, 1.0F);
        if (this.level() instanceof ServerLevel level) {
            ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.RING, 0x6A2CFF), this.position(), new Vec3(0, Math.max(3.0F, d.sp1), 0));
        }
    }

    /** The singularity gives up: everything it held is thrown out in a blast that takes the ground with it. */
    private void collapse(ServerLevel level, ArsenalDef d, float r) {
        Vec3 c = this.position();
        Entity owner = this.getOwner();
        float radius = Math.max(2.5F, r * 0.42F);
        ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.IMPLODE, 0x8A4CFF), c, new Vec3(radius, 0, 0));
        level.explode(this, c.x, c.y, c.z, radius, Level.ExplosionInteraction.MOB);
        ArsenalLogic.splash(level, owner, this, c, radius + 1.5F, d.damage, null);
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, 0xB080FF), c.x, c.y, c.z, 40, radius * 0.5, radius * 0.5, radius * 0.5, 0.25);
        level.playSound(null, c.x, c.y, c.z, ArsenalSounds.shared("void_collapse"), SoundSource.PLAYERS, 6.0F, 1.0F);
        ArsenalLogic.shakeAround(level, c, 24 + radius * 4, 2.6F);
        this.discard();
    }

    /** Wasps, candies, plasma bolts, meteors and mortar shells go off where they land (the blocks are spared). */
    private void burst(ServerLevel level, ArsenalDef d, Vec3 at, @Nullable Entity direct) {
        Entity owner = this.getOwner();
        switch (d.proj) {
            case WASP -> {
                float r = Math.max(1.0F, d.sp2);
                ArsenalLogic.splash(level, owner, this, at, r, this.damage * 0.6F, direct);
                ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, 0xFFB020), at, new Vec3(r * 0.8, 0, 0));
                level.sendParticles(ParticleTypes.FALLING_HONEY, at.x, at.y, at.z, 6, r * 0.3, r * 0.2, r * 0.3, 0.0);
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.SPARK, 0xFFD040), at.x, at.y, at.z, 10, 0.1, 0.1, 0.1, 0.3);
                level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("wasp_pop"), SoundSource.PLAYERS, 1.6F, 0.9F + this.random.nextFloat() * 0.2F);
            }
            case CANDY -> {
                float r = Math.max(0.8F, d.sp1);
                ArsenalLogic.splash(level, owner, this, at, r, this.damage * 0.5F, direct);
                ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, 0xFF7AC8), at, new Vec3(r * 0.6, 0, 0));
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.CONFETTI, 0), at.x, at.y, at.z, 22, 0.15, 0.15, 0.15, 0.25);
                level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("candy_pop"), SoundSource.PLAYERS, 1.2F, 0.9F + this.random.nextFloat() * 0.3F);
            }
            case METEOR -> this.meteorImpact(level, d, at, direct);
            case MORTAR -> this.shellBurst(level, d, at, direct);
            default -> {
                float r = Math.max(0.6F, d.sp1);
                ArsenalLogic.splash(level, owner, this, at, r, this.damage * 0.5F, direct);
                ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, d.tracerColor), at, new Vec3(r * 0.7, 0, 0));
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), at.x, at.y, at.z, 6, 0.15, 0.15, 0.15, 0.08);
                level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("plasma_hit"), SoundSource.PLAYERS, 1.0F, 0.9F + this.random.nextFloat() * 0.2F);
                if (owner instanceof Player && this.random.nextFloat() < d.sp2) {
                    BlockHitResult bh = level.clip(new ClipContext(at.add(0, 0.5, 0), at.add(0, -1.5, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
                    if (bh.getType() == HitResult.Type.BLOCK) ArsenalLogic.ignite(level, owner, bh.getLocation(), Direction.UP, bh.getBlockPos(), 1.0F);
                }
            }
        }
        this.discard();
    }

    /** Blast radius of a meteor called with the given charge. */
    public static float meteorRadius(ArsenalDef d, float charge) {
        return Math.max(2.0F, d.sp1) * (0.6F + 0.4F * Mth.clamp(charge, 0.0F, 1.0F));
    }

    /** «Meteoro»: a burning rock lands — fire, a shock wave and a crater of embers (the ground itself is spared). */
    private void meteorImpact(ServerLevel level, ArsenalDef d, Vec3 at, @Nullable Entity direct) {
        Entity owner = this.getOwner();
        float r = meteorRadius(d, this.charge);
        ArsenalLogic.splash(level, owner, this, at, r, this.damage, direct);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(r), e -> e.isAlive() && e != owner)) {
            if (e.getBoundingBox().getCenter().distanceTo(at) <= r) e.igniteForSeconds(4.0F);
        }
        ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, 0xFF7A20), at, new Vec3(r * 0.9, 0, 0));
        ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.RING, 0xFFA040), at.add(0, 0.1, 0), new Vec3(0, r * 1.6, 0));
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.SMOKE, 0x3A3028), at.x, at.y + 0.5, at.z, 18, r * 0.4, 0.4, r * 0.4, 0.03);
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.FIRE, 0xFF8A30), at.x, at.y + 0.3, at.z, 16, r * 0.35, 0.2, r * 0.35, 0.06);
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.SPARK, 0xFFB050), at.x, at.y + 0.3, at.z, 20, 0.3, 0.2, 0.3, 0.45);
        BlockHitResult ground = level.clip(new ClipContext(at.add(0, 0.6, 0), at.add(0, -2.0, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        if (ground.getType() == HitResult.Type.BLOCK) {
            BlockState gs = level.getBlockState(ground.getBlockPos());
            Vec3 g = ground.getLocation();
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, gs), g.x, g.y + 0.1, g.z, 30, r * 0.3, 0.1, r * 0.3, 0.25);
            for (int i = 0; i < 5; i++) {
                double a = this.random.nextDouble() * Math.PI * 2.0, rr = this.random.nextDouble() * r * 0.6;
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.SCORCH, 0xFF6A20), g.x + Math.cos(a) * rr, g.y + 0.01, g.z + Math.sin(a) * rr,
                        0, 0, 0.5 + this.random.nextDouble() * 0.4, 0, 1.0);
            }
            if (owner instanceof Player) {
                for (int i = 0; i < 3; i++) {
                    double a = this.random.nextDouble() * Math.PI * 2.0, rr = this.random.nextDouble() * r * 0.7;
                    Vec3 p = g.add(Math.cos(a) * rr, 0.5, Math.sin(a) * rr);
                    BlockHitResult bh = level.clip(new ClipContext(p, p.add(0, -2.5, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
                    if (bh.getType() == HitResult.Type.BLOCK) ArsenalLogic.ignite(level, owner, bh.getLocation(), Direction.UP, bh.getBlockPos(), 0.6F);
                }
            }
        }
        level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared("meteor_impact"), SoundSource.PLAYERS, 4.0F, 0.9F + this.random.nextFloat() * 0.2F);
        ArsenalLogic.shakeAround(level, at, 28, 2.2F);
    }

    /** «Bombarda»: the shell bursts and throws out a cluster of bomblets that pop around it. */
    private void shellBurst(ServerLevel level, ArsenalDef d, Vec3 at, @Nullable Entity direct) {
        Entity owner = this.getOwner();
        boolean bomblet = this.flag(F_BOMBLET);
        float r = bomblet ? 1.3F : 2.4F;
        ArsenalLogic.splash(level, owner, this, at, r, this.damage, direct);
        ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, bomblet ? 0xFFC070 : 0xFFA050), at, new Vec3(r * 0.8, 0, 0));
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.SMOKE, 0x5A5448), at.x, at.y + 0.3, at.z, bomblet ? 4 : 12, r * 0.3, 0.3, r * 0.3, 0.02);
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.SPARK, 0xFFC060), at.x, at.y, at.z, bomblet ? 4 : 12, 0.1, 0.1, 0.1, 0.35);
        level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared(bomblet ? "boom_small" : "boom_big"), SoundSource.PLAYERS, bomblet ? 1.5F : 3.0F,
                (bomblet ? 1.2F : 0.9F) + this.random.nextFloat() * 0.2F);
        ArsenalLogic.shakeAround(level, at, bomblet ? 8 : 18, bomblet ? 0.4F : 1.4F);
        if (bomblet) return;
        int n = Math.max(2, (int) d.sp1);
        double a0 = this.random.nextDouble() * Math.PI * 2.0;
        for (int i = 0; i < n; i++) {
            double a = a0 + i * Math.PI * 2.0 / n + (this.random.nextDouble() - 0.5) * 0.4;
            double out = 0.22 + this.random.nextDouble() * 0.12;
            ArsenalShot b = new ArsenalShot(level, owner, d, this);
            b.setPos(at.x, at.y + 0.3, at.z);
            b.setDeltaMovement(Math.cos(a) * out, 0.38 + this.random.nextDouble() * 0.16, Math.sin(a) * out);
            b.setFlag(F_BOMBLET, true);
            b.damage = this.damage * 0.35F;
            b.maxAge = 60;
            b.fuse = 18 + this.random.nextInt(14);
            b.setCharge(0.5F);
            level.addFreshEntity(b);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        this.keepFlying = false;
        super.onHit(result);
        if (this.level().isClientSide || this.isRemoved()) return;
        if (this.shotState() != FLYING) return;
        ArsenalDef d = this.def();
        if (result.getType() == HitResult.Type.ENTITY) {
            if (this.pierce-- <= 0) this.discard();
            else if (d != null && !d.cutter() && d.proj != Proj.TURRET) this.damage *= 0.85F;
        } else if (result.getType() == HitResult.Type.BLOCK && !this.keepFlying) {
            this.discard();
        }
    }
}
