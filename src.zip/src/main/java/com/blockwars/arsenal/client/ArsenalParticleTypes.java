package com.blockwars.arsenal.client;

import com.blockwars.arsenal.Arsenal;
import com.blockwars.arsenal.ArsenalDef;
import com.blockwars.arsenal.ArsenalParticles;
import com.blockwars.arsenal.ArsenalSounds;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Client particle classes and providers for every Arsenal particle type. */
public final class ArsenalParticleTypes {
    private ArsenalParticleTypes() {}

    /** party colours for confetti sent without a colour */
    static final int[] PARTY = {0xFF5AA8, 0xFFD23C, 0x5AE0FF, 0x8CFF6A, 0xB07AFF, 0xFF8A3C, 0xFFFFFF, 0xFF4A5A};

    public static void register(RegisterParticleProvidersEvent e) {
        // light effects: drawn by ArsenalFx, no vanilla particle
        e.registerSpecial(ArsenalParticles.FLASH.get(), (o, level, x, y, z, vx, vy, vz) -> {
            ArsenalDef d = Arsenal.def(ArsenalParticles.payload(o));
            Vec3 v = new Vec3(vx, vy, vz);
            if (d != null && v.lengthSqr() > 1.0E-6) ArsenalFx.flash(new Vec3(x, y, z), v, d, (float) v.length() * 1.6F);
            return null;
        });
        e.registerSpecial(ArsenalParticles.BLAST.get(), (o, level, x, y, z, vx, vy, vz) -> {
            ArsenalFx.blast(new Vec3(x, y, z), (float) Math.max(0.6, vx), ArsenalParticles.payload(o));
            return null;
        });
        e.registerSpecial(ArsenalParticles.BEAM.get(), (o, level, x, y, z, vx, vy, vz) -> {
            ArsenalDef d = Arsenal.def(ArsenalParticles.payload(o));
            if (d != null) ArsenalFx.beam(new Vec3(x, y, z), new Vec3(x + vx, y + vy, z + vz), d, 3);
            return null;
        });
        e.registerSpecial(ArsenalParticles.ARC.get(), (o, level, x, y, z, vx, vy, vz) -> {
            ArsenalDef d = Arsenal.def(ArsenalParticles.payload(o));
            if (d != null) ArsenalFx.arc(new Vec3(x, y, z), new Vec3(x + vx, y + vy, z + vz), d, 5);
            return null;
        });
        e.registerSpecial(ArsenalParticles.RING.get(), (o, level, x, y, z, vx, vy, vz) -> {
            Vec3 n = new Vec3(vx, vy, vz);
            ArsenalFx.ring(new Vec3(x, y, z), n, (float) Math.max(0.5, n.length()), ArsenalParticles.payload(o), 10);
            return null;
        });
        e.registerSpecial(ArsenalParticles.WAVE.get(), (o, level, x, y, z, vx, vy, vz) -> {
            ArsenalDef d = Arsenal.def(ArsenalParticles.payload(o));
            Vec3 v = new Vec3(vx, vy, vz);
            if (d != null && v.lengthSqr() > 1.0E-6) ArsenalFx.wave(new Vec3(x, y, z), v.normalize(), d, false);
            return null;
        });
        e.registerSpecial(ArsenalParticles.IMPLODE.get(), (o, level, x, y, z, vx, vy, vz) -> {
            ArsenalFx.implode(new Vec3(x, y, z), (float) Math.max(1.0, vx), ArsenalParticles.payload(o));
            return null;
        });
        // world particles
        e.registerSpriteSet(ArsenalParticles.SMOKE.get(), s -> (o, level, x, y, z, vx, vy, vz) -> new Smoke(level, x, y, z, vx, vy, vz, o, s));
        e.registerSpriteSet(ArsenalParticles.SPARK.get(), s -> (o, level, x, y, z, vx, vy, vz) -> new Spark(level, x, y, z, vx, vy, vz, o, s));
        e.registerSpriteSet(ArsenalParticles.GLOW.get(), s -> (o, level, x, y, z, vx, vy, vz) -> new Glow(level, x, y, z, vx, vy, vz, o, s));
        e.registerSpriteSet(ArsenalParticles.FIRE.get(), s -> (o, level, x, y, z, vx, vy, vz) -> new Fire(level, x, y, z, vx, vy, vz, o, s));
        e.registerSpriteSet(ArsenalParticles.SCORCH.get(), s -> (o, level, x, y, z, vx, vy, vz) -> new Decal(level, x, y, z, vx, vy, vz, o, s));
        e.registerSpriteSet(ArsenalParticles.CONFETTI.get(), s -> (o, level, x, y, z, vx, vy, vz) -> new Flutter(level, x, y, z, vx, vy, vz, o, s, false));
        e.registerSpriteSet(ArsenalParticles.WRAPPER.get(), s -> (o, level, x, y, z, vx, vy, vz) -> new Flutter(level, x, y, z, vx, vy, vz, o, s, true));
        e.registerSpriteSet(ArsenalParticles.FROST.get(), s -> (o, level, x, y, z, vx, vy, vz) -> new Frost(level, x, y, z, vx, vy, vz, o, s));
    }

    // ================================================================== base helpers

    abstract static class Base extends TextureSheetParticle {
        Base(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, ColorParticleOption o) {
            super(level, x, y, z, 0, 0, 0);
            this.xd = vx;
            this.yd = vy;
            this.zd = vz;
            this.rCol = o.getRed();
            this.gCol = o.getGreen();
            this.bCol = o.getBlue();
        }

        @Override
        public ParticleRenderType getRenderType() {
            return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
        }

        /** one vertex in the particle format */
        void vtx(VertexConsumer vc, float x, float y, float z, float u, float v, float r, float g, float b, float a, int light) {
            vc.addVertex(x, y, z).setUv(u, v).setColor(r, g, b, a).setLight(light);
        }

        /** a double-sided quad from four camera-relative corners */
        void quad(VertexConsumer vc, Vector3f a, Vector3f b, Vector3f c, Vector3f d, float r, float g, float bl, float al, int light) {
            float u0 = this.sprite.getU0(), u1 = this.sprite.getU1(), v0 = this.sprite.getV0(), v1 = this.sprite.getV1();
            vtx(vc, a.x, a.y, a.z, u0, v1, r, g, bl, al, light);
            vtx(vc, b.x, b.y, b.z, u1, v1, r, g, bl, al, light);
            vtx(vc, c.x, c.y, c.z, u1, v0, r, g, bl, al, light);
            vtx(vc, d.x, d.y, d.z, u0, v0, r, g, bl, al, light);
            vtx(vc, d.x, d.y, d.z, u0, v0, r, g, bl, al, light);
            vtx(vc, c.x, c.y, c.z, u1, v0, r, g, bl, al, light);
            vtx(vc, b.x, b.y, b.z, u1, v1, r, g, bl, al, light);
            vtx(vc, a.x, a.y, a.z, u0, v1, r, g, bl, al, light);
        }
    }

    // ================================================================== smoke

    /** Soft smoke, vapour or dust: expands, rises, drifts and thins out. */
    static class Smoke extends Base {
        private final float base;
        private final float spin;

        Smoke(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, ColorParticleOption o, SpriteSet s) {
            super(level, x, y, z, vx, vy, vz, o);
            this.pickSprite(s);
            this.lifetime = 30 + this.random.nextInt(34);
            this.base = 0.1F + this.random.nextFloat() * 0.08F;
            this.quadSize = this.base;
            this.friction = 0.9F;
            this.gravity = -0.012F;
            this.hasPhysics = true;
            this.roll = this.random.nextFloat() * 6.283F;
            this.oRoll = this.roll;
            this.spin = (this.random.nextFloat() - 0.5F) * 0.05F;
            this.alpha = 0.0F;
        }

        @Override
        public void tick() {
            super.tick();
            if (this.removed) return;
            float life = this.age / (float) this.lifetime;
            this.oRoll = this.roll;
            this.roll += this.spin;
            this.xd += 0.001;
            this.quadSize = this.base * (1.0F + 4.5F * (float) Math.sqrt(life));
            float fadeIn = Math.min(1.0F, this.age / 3.0F);
            this.alpha = 0.42F * fadeIn * (1.0F - life) * (1.0F - life);
        }
    }

    // ================================================================== spark

    /** A hot streak drawn along its velocity; bounces once. */
    static class Spark extends Base {
        private boolean bounced;

        Spark(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, ColorParticleOption o, SpriteSet s) {
            super(level, x, y, z, vx, vy, vz, o);
            this.pickSprite(s);
            this.lifetime = 5 + this.random.nextInt(9);
            this.gravity = 0.9F;
            this.friction = 0.88F;
            this.hasPhysics = true;
            this.quadSize = 0.022F + this.random.nextFloat() * 0.015F;
        }

        @Override
        public void tick() {
            double before = this.yd;
            super.tick();
            if (this.onGround && !this.bounced && before < -0.05) {
                this.bounced = true;
                this.yd = -before * 0.4;
            }
            float life = this.age / (float) this.lifetime;
            this.alpha = 1.0F - life * life;
        }

        @Override
        protected int getLightColor(float pt) {
            return 0xF000F0;
        }

        @Override
        public void render(VertexConsumer vc, Camera cam, float pt) {
            Vec3 c = cam.getPosition();
            float x = (float) (Mth.lerp(pt, this.xo, this.x) - c.x);
            float y = (float) (Mth.lerp(pt, this.yo, this.y) - c.y);
            float z = (float) (Mth.lerp(pt, this.zo, this.z) - c.z);
            Vector3f vel = new Vector3f((float) this.xd, (float) this.yd, (float) this.zd);
            float sp = vel.length();
            if (sp < 1.0E-4F) vel.set(0, 0.001F, 0);
            Vector3f tail = new Vector3f(vel).mul(-Math.min(2.5F, 0.8F + sp * 3.0F));
            Vector3f mid = new Vector3f(x, y, z);
            Vector3f side = new Vector3f(vel).cross(mid);
            if (side.lengthSquared() < 1.0E-10F) return;
            side.normalize().mul(this.quadSize);
            int light = 0xF000F0;
            // the head is white-hot, the tail takes the colour
            float u0 = this.sprite.getU0(), u1 = this.sprite.getU1(), v0 = this.sprite.getV0(), v1 = this.sprite.getV1();
            float hr = Math.min(1, this.rCol + 0.4F), hg = Math.min(1, this.gCol + 0.4F), hb = Math.min(1, this.bCol + 0.4F);
            vtx(vc, x + side.x, y + side.y, z + side.z, u1, v1, hr, hg, hb, this.alpha, light);
            vtx(vc, x - side.x, y - side.y, z - side.z, u1, v0, hr, hg, hb, this.alpha, light);
            vtx(vc, x + tail.x - side.x, y + tail.y - side.y, z + tail.z - side.z, u0, v0, this.rCol, this.gCol, this.bCol, 0.0F, light);
            vtx(vc, x + tail.x + side.x, y + tail.y + side.y, z + tail.z + side.z, u0, v1, this.rCol, this.gCol, this.bCol, 0.0F, light);
            vtx(vc, x + tail.x + side.x, y + tail.y + side.y, z + tail.z + side.z, u0, v1, this.rCol, this.gCol, this.bCol, 0.0F, light);
            vtx(vc, x + tail.x - side.x, y + tail.y - side.y, z + tail.z - side.z, u0, v0, this.rCol, this.gCol, this.bCol, 0.0F, light);
            vtx(vc, x - side.x, y - side.y, z - side.z, u1, v0, hr, hg, hb, this.alpha, light);
            vtx(vc, x + side.x, y + side.y, z + side.z, u1, v1, hr, hg, hb, this.alpha, light);
        }
    }

    // ================================================================== glow

    static class Glow extends Base {
        private final float base;

        Glow(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, ColorParticleOption o, SpriteSet s) {
            super(level, x, y, z, vx, vy, vz, o);
            this.pickSprite(s);
            this.lifetime = 7 + this.random.nextInt(7);
            this.friction = 0.86F;
            this.base = 0.07F + this.random.nextFloat() * 0.05F;
            this.quadSize = this.base;
        }

        @Override
        public void tick() {
            super.tick();
            float life = this.age / (float) this.lifetime;
            this.quadSize = this.base * (1.0F - 0.6F * life);
            this.alpha = 0.9F * (1.0F - life);
        }

        @Override
        protected int getLightColor(float pt) {
            return 0xF000F0;
        }
    }

    // ================================================================== fire

    /** Flame puff: animated, rising, emissive; turns to smoke at the end. */
    static class Fire extends Base {
        private final SpriteSet sprites;
        private final float base;

        Fire(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, ColorParticleOption o, SpriteSet s) {
            super(level, x, y, z, vx, vy, vz, o);
            this.sprites = s;
            this.lifetime = 12 + this.random.nextInt(10);
            this.friction = 0.9F;
            this.gravity = -0.05F;
            this.hasPhysics = true;
            this.base = 0.12F + this.random.nextFloat() * 0.1F;
            this.quadSize = this.base;
            this.roll = this.random.nextFloat() * 6.283F;
            this.oRoll = this.roll;
            this.rCol = Math.min(1.0F, this.rCol + 0.1F);
            this.setSpriteFromAge(s);
        }

        @Override
        public void tick() {
            super.tick();
            if (this.removed) return;
            this.setSpriteFromAge(this.sprites);
            float life = this.age / (float) this.lifetime;
            this.quadSize = this.base * (1.0F + 2.2F * life);
            this.oRoll = this.roll;
            this.roll += 0.04F;
            this.alpha = life < 0.7F ? 0.95F : 0.95F * (1.0F - life) / 0.3F;
            if (life > 0.6F && this.random.nextInt(6) == 0) {
                this.level.addParticle(ArsenalParticles.of(ArsenalParticles.SMOKE, 0x3A3632), this.x, this.y + 0.1, this.z, 0, 0.03, 0);
            }
        }

        @Override
        protected int getLightColor(float pt) {
            return 0xF000F0;
        }
    }

    // ================================================================== scorch decal

    /** Scorch mark lying on a block face (velocity = face normal * size): glows hot, then cools to soot. */
    static class Decal extends Base {
        private final Vector3f n;
        private final float rot;

        Decal(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, ColorParticleOption o, SpriteSet s) {
            super(level, x, y, z, 0, 0, 0, o);
            this.xd = 0;
            this.yd = 0;
            this.zd = 0;
            this.pickSprite(s);
            Vector3f v = new Vector3f((float) vx, (float) vy, (float) vz);
            float size = v.length();
            this.n = size > 1.0E-6F ? v.div(size) : new Vector3f(0, 1, 0);
            this.quadSize = Math.max(0.03F, size);
            this.rot = this.random.nextFloat() * 6.283F;
            this.lifetime = 400;
            this.gravity = 0;
            this.hasPhysics = false;
            this.x += this.n.x * 0.012;
            this.y += this.n.y * 0.012;
            this.z += this.n.z * 0.012;
            this.xo = this.x;
            this.yo = this.y;
            this.zo = this.z;
        }

        @Override
        public void tick() {
            this.age++;
            if (this.age >= this.lifetime) this.remove();
            float left = (this.lifetime - this.age) / 80.0F;
            this.alpha = Math.min(1.0F, left) * 0.85F;
        }

        @Override
        protected int getLightColor(float pt) {
            int l = super.getLightColor(pt);
            return this.age < 30 ? 0xF000F0 : l;
        }

        @Override
        public void render(VertexConsumer vc, Camera cam, float pt) {
            Vec3 c = cam.getPosition();
            float x = (float) (this.x - c.x), y = (float) (this.y - c.y), z = (float) (this.z - c.z);
            Vector3f up = Math.abs(this.n.y) > 0.5F ? new Vector3f(1, 0, 0) : new Vector3f(0, 1, 0);
            Vector3f a = new Vector3f(up).cross(this.n).normalize();
            Vector3f b = new Vector3f(this.n).cross(a).normalize();
            Quaternionf q = new Quaternionf().rotateAxis(this.rot, this.n);
            q.transform(a);
            q.transform(b);
            a.mul(this.quadSize);
            b.mul(this.quadSize);
            int light = this.getLightColor(pt);
            float r, g, bl;
            if (this.age < 30) {
                // still glowing in the weapon's colour
                float hot = 1.0F - this.age / 30.0F;
                r = Mth.lerp(hot, 0.3F, this.rCol);
                g = Mth.lerp(hot, 0.3F, this.gCol);
                bl = Mth.lerp(hot, 0.3F, this.bCol);
            } else {
                r = 1.0F;
                g = 1.0F;
                bl = 1.0F;
            }
            Vector3f p = new Vector3f(x, y, z);
            this.quad(vc, new Vector3f(p).sub(a).sub(b), new Vector3f(p).add(a).sub(b), new Vector3f(p).add(a).add(b), new Vector3f(p).sub(a).add(b),
                    r, g, bl, this.alpha, light);
        }
    }

    // ================================================================== confetti and candy wrappers

    /** A flat scrap that tumbles, flutters down, lands and lies there for a while. */
    static class Flutter extends Base {
        private final Quaternionf rot = new Quaternionf();
        private final Quaternionf rotO = new Quaternionf();
        private final Vector3f spinAxis;
        private final boolean wrapper;
        private float spin;
        private final float w, h;
        private boolean resting;
        private final float phase;

        Flutter(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, ColorParticleOption o, SpriteSet s, boolean wrapper) {
            super(level, x, y, z, vx, vy, vz, o);
            this.pickSprite(s);
            this.wrapper = wrapper;
            int payload = ArsenalParticles.payload(o);
            if (payload == 0 || !wrapper && this.random.nextInt(3) > 0) {
                int c = PARTY[this.random.nextInt(PARTY.length)];
                this.rCol = ((c >> 16) & 0xFF) / 255.0F;
                this.gCol = ((c >> 8) & 0xFF) / 255.0F;
                this.bCol = (c & 0xFF) / 255.0F;
            }
            this.lifetime = wrapper ? 90 + this.random.nextInt(40) : 50 + this.random.nextInt(50);
            this.gravity = wrapper ? 0.45F : 0.18F;
            this.friction = wrapper ? 0.95F : 0.9F;
            this.hasPhysics = true;
            this.setSize(0.05F, 0.05F);
            this.w = wrapper ? 0.09F : 0.025F + this.random.nextFloat() * 0.015F;
            this.h = wrapper ? 0.05F : 0.012F + this.random.nextFloat() * 0.01F;
            this.rot.rotateXYZ(this.random.nextFloat() * 6.283F, this.random.nextFloat() * 6.283F, this.random.nextFloat() * 6.283F);
            this.rotO.set(this.rot);
            this.spinAxis = new Vector3f(this.random.nextFloat() - 0.5F, this.random.nextFloat() - 0.5F, this.random.nextFloat() - 0.5F).normalize();
            this.spin = 0.3F + this.random.nextFloat() * 0.4F;
            this.phase = this.random.nextFloat() * 6.283F;
        }

        @Override
        public void tick() {
            this.rotO.set(this.rot);
            double before = this.yd;
            super.tick();
            if (this.removed) return;
            if (!this.resting) {
                this.rot.rotateAxis(this.spin, this.spinAxis);
                // paper flutters: sideways sway while falling
                if (!this.onGround) {
                    this.xd += Mth.sin(this.age * 0.35F + this.phase) * 0.004;
                    this.zd += Mth.cos(this.age * 0.29F + this.phase) * 0.004;
                    if (this.yd < -0.06 && !this.wrapper) this.yd = -0.06;
                }
            }
            if (this.onGround && !this.resting) {
                if (this.wrapper && before < -0.08) {
                    this.yd = -before * 0.3;
                    this.level.playLocalSound(this.x, this.y, this.z, ArsenalSounds.shared("wrapper"), SoundSource.PLAYERS, 0.15F, 1.4F, false);
                } else {
                    this.resting = true;
                    float yaw = this.random.nextFloat() * 6.283F;
                    this.rot.identity().rotateY(yaw).rotateX(1.5708F);
                    this.rotO.set(this.rot);
                    this.xd = 0;
                    this.zd = 0;
                }
            }
            float left = (this.lifetime - this.age) / 20.0F;
            this.alpha = Math.min(1.0F, left);
        }

        @Override
        public void render(VertexConsumer vc, Camera cam, float pt) {
            Vec3 c = cam.getPosition();
            float x = (float) (Mth.lerp(pt, this.xo, this.x) - c.x);
            float y = (float) (Mth.lerp(pt, this.yo, this.y) - c.y) + (this.resting ? 0.005F : 0.0F);
            float z = (float) (Mth.lerp(pt, this.zo, this.z) - c.z);
            Quaternionf q = new Quaternionf(this.rotO).slerp(this.rot, pt);
            Vector3f a = q.transform(new Vector3f(this.w, 0, 0));
            Vector3f b = q.transform(new Vector3f(0, this.h, 0));
            Vector3f p = new Vector3f(x, y, z);
            int light = this.getLightColor(pt);
            // the face toward the light is brighter
            Vector3f n = q.transform(new Vector3f(0, 0, 1));
            float shade = 0.7F + 0.3F * Math.abs(n.y);
            this.quad(vc, new Vector3f(p).sub(a).sub(b), new Vector3f(p).add(a).sub(b), new Vector3f(p).add(a).add(b), new Vector3f(p).sub(a).add(b),
                    this.rCol * shade, this.gCol * shade, this.bCol * shade, this.alpha, light);
        }
    }

    // ================================================================== frost

    /** A glittering ice flake: drifts down, twinkles, melts away. */
    static class Frost extends Base {
        private final float base;
        private final float tw;

        Frost(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, ColorParticleOption o, SpriteSet s) {
            super(level, x, y, z, vx, vy, vz, o);
            this.pickSprite(s);
            this.lifetime = 24 + this.random.nextInt(30);
            this.friction = 0.92F;
            this.gravity = 0.04F;
            this.hasPhysics = true;
            this.base = 0.03F + this.random.nextFloat() * 0.035F;
            this.quadSize = this.base;
            this.roll = this.random.nextFloat() * 6.283F;
            this.oRoll = this.roll;
            this.tw = this.random.nextFloat() * 6.283F;
        }

        @Override
        public void tick() {
            super.tick();
            if (this.removed) return;
            float life = this.age / (float) this.lifetime;
            this.oRoll = this.roll;
            this.roll += 0.05F;
            float twinkle = 0.65F + 0.35F * Mth.sin(this.age * 0.9F + this.tw);
            this.alpha = twinkle * (1.0F - life * life);
            this.quadSize = this.base * (1.0F - 0.5F * life);
        }

        @Override
        protected int getLightColor(float pt) {
            return 0xF000F0;
        }
    }
}
