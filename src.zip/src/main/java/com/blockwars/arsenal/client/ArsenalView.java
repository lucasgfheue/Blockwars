package com.blockwars.arsenal.client;

import com.blockwars.arsenal.ArsenalDef;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * First-person weapon placement (hip, aim, sprint, recoil spring, inertia, breathing, landing, draw, reload gesture,
 * inspect) and conversion of points on the first-person weapon to world positions for smoke, wrappers and beams.
 */
public final class ArsenalView {
    private ArsenalView() {}

    /** hand matrix of the last first-person frame */
    public static final Matrix4f LAST = new Matrix4f();

    public static final float HIP_X = 0.19F, HIP_Y = -0.2F, HIP_Z = -0.5F;
    public static final float AIM_Z = -0.4F;

    static float ease(float a) {
        return a * a * (3 - 2 * a);
    }

    /** Full first-person transform for the main-hand weapon. */
    public static Matrix4f hand(LocalPlayer p, ItemStack s, ArsenalDef d, @Nullable BwmModel model, int side, float pt, float equipProcess) {
        Matrix4f m = new Matrix4f();
        float a = ease(Mth.clamp(Mth.lerp(pt, ArsenalClient.adsO, ArsenalClient.ads), 0, 1));
        float spr = Mth.lerp(pt, ArsenalClient.sprintO, ArsenalClient.sprint) * (1 - a);
        float t = p.tickCount + pt;
        float kick = Mth.lerp(pt, ArsenalClient.kickO, ArsenalClient.kick);
        float kroll = Mth.lerp(pt, ArsenalClient.kickRollO, ArsenalClient.kickRoll);
        float swx = Mth.lerp(pt, ArsenalClient.swayXO, ArsenalClient.swayX);
        float swy = Mth.lerp(pt, ArsenalClient.swayYO, ArsenalClient.swayY);
        float landv = Mth.lerp(pt, ArsenalClient.landO, ArsenalClient.land);
        float now = ArsenalClient.now(pt);

        float aimY = 0.0F;
        float hx = model != null ? model.meta("hip", 0, HIP_X) : HIP_X;
        float hy = model != null ? model.meta("hip", 1, HIP_Y) : HIP_Y;
        float hz = model != null ? model.meta("hip", 2, HIP_Z) : HIP_Z;
        float az = model != null ? model.meta("aim", 0, AIM_Z) : AIM_Z;
        float hipYaw = model != null ? model.meta("hip_rot", 0, 0.0F) : 0.0F;
        float hipPitch = model != null ? model.meta("hip_rot", 1, 0.0F) : 0.0F;
        float hipRoll = model != null ? model.meta("hip_rot", 2, 0.0F) : 0.0F;
        float x = Mth.lerp(a, hx * side, 0.0F);
        float y = Mth.lerp(a, hy, aimY);
        float z = Mth.lerp(a, hz, az);
        y -= equipProcess * 0.6F;
        // draw: the weapon swings up into place
        float e = Mth.clamp((now - ArsenalClient.equipTime) / 8.0F, 0.0F, 1.0F);
        float de = (1 - e) * (1 - e);
        y -= de * 0.22F;
        // breathing and idle drift
        float breathe = 1.0F - 0.85F * a;
        y += Mth.sin(t * 0.07F) * 0.005F * breathe;
        x += Mth.cos(t * 0.045F) * 0.004F * breathe;
        // inertia
        float inert = 1.0F - 0.65F * a;
        x += swx * 0.0035F * inert;
        y += -swy * 0.0035F * inert;
        // landing
        y -= landv * 0.035F * (1 - 0.5F * a);
        // recoil push
        z += kick * 0.06F * (1 - 0.4F * a);
        y += kick * 0.012F;
        // sprint carry
        x += -0.05F * side * spr;
        y += -0.07F * spr;
        z += 0.05F * spr;
        m.translate(x, y, z);

        // rotations about the grip, a little behind the sight anchor
        float pivot = 0.16F;
        m.translate(0, 0, pivot);
        float hipK = 1 - a;
        m.rotateY(((-swx * 0.55F) * inert + 34 * side * spr + 9 * side * de + hipYaw * side * hipK) * Mth.DEG_TO_RAD);
        m.rotateX(((-swy * 0.55F) * inert + kick * (4.6F - 2.4F * a) - 17 * spr - landv * 2.5F - 32 * de + hipPitch * hipK) * Mth.DEG_TO_RAD);
        m.rotateZ((kroll * (1 - 0.6F * a) + 14 * side * spr - 12 * side * de + hipRoll * side * hipK) * Mth.DEG_TO_RAD);
        m.translate(0, 0, -pivot);

        ArsenalAnim.State st = ArsenalAnim.local(s, d, pt);
        ArsenalAnim.gunMotion(m, st, d, side);

        // charge tremble, heat shimmer, and the hum of the dangerous ones
        float trem = 0;
        if (st.charge > 0) trem = 0.0025F * st.charge * st.charge;
        if (st.heat > 0.75F) trem = Math.max(trem, (st.heat - 0.75F) * 0.016F);
        if (d.dangerous) trem = Math.max(trem, 0.0007F);
        if (trem > 0) m.translate(Mth.sin(t * 2.3F) * trem, Mth.cos(t * 2.9F) * trem, 0);
        LAST.set(m);
        return m;
    }

    /** The first-person item model transform: item pixels -> hand space (sight anchor at the origin). */
    public static Matrix4f displayMatrix(BwmModel model) {
        float[] fp = model.meta("fp");
        float sc = fp != null ? fp[0] : 0.5F;
        float sy = fp != null ? fp[1] : 10.0F;
        float sz = fp != null ? fp[2] : 8.0F;
        return new Matrix4f().scale(sc / 16.0F).translate(-8.0F, -sy, -sz);
    }

    /** Camera-relative world offset of a first-person point given in hand space. */
    public static Vec3 toWorld(Vector3f hand) {
        Minecraft mc = Minecraft.getInstance();
        Camera cam = mc.gameRenderer.getMainCamera();
        double k = Math.tan(Math.toRadians(ArsenalClient.worldFov * 0.5)) / Math.tan(Math.toRadians(35.0));
        Vector3f v = new Vector3f((float) (hand.x * k), (float) (hand.y * k), hand.z);
        cam.rotation().transform(v);
        return new Vec3(v.x, v.y, v.z);
    }

    /** Called by the item renderer every first-person frame: where are the muzzle and the ejection port now. */
    public static void captureAnchors(Matrix4f handDisplay, @Nullable float[] muzzle, @Nullable float[] eject) {
        long now = Minecraft.getInstance().level != null ? Minecraft.getInstance().level.getGameTime() : 0;
        if (muzzle != null) {
            Vector3f v = handDisplay.transformPosition(new Vector3f(muzzle[0], muzzle[1], muzzle[2]));
            ArsenalClient.fpMuzzle = toWorld(v);
        }
        if (eject != null) {
            Vector3f v = handDisplay.transformPosition(new Vector3f(eject[0], eject[1], eject[2]));
            ArsenalClient.fpEject = toWorld(v);
        }
        ArsenalClient.fpSeen = now;
    }
}
