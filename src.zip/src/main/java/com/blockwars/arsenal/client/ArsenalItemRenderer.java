package com.blockwars.arsenal.client;

import com.blockwars.BlockWars;
import com.blockwars.arsenal.ArsenalDef;
import com.blockwars.arsenal.ArsenalItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;

/**
 * Draws Arsenal weapons: the pre-rendered icon in inventories, the animated smooth mesh everywhere else (opaque,
 * glowing and glass layers, each part lit by its own channels) and, for the local player, the muzzle flash, the
 * charge glow and the dragon's breath.
 */
public class ArsenalItemRenderer extends BlockEntityWithoutLevelRenderer {
    private static ArsenalItemRenderer instance;
    private static final Map<String, ResourceLocation> TEX = new HashMap<>();
    private static final Map<String, ResourceLocation> ICON = new HashMap<>();

    public static ArsenalItemRenderer get() {
        if (instance == null) instance = new ArsenalItemRenderer();
        return instance;
    }

    private ArsenalItemRenderer() {
        super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
    }

    @Override
    public void onResourceManagerReload(ResourceManager manager) {
    }

    public static ResourceLocation texture(String id) {
        return TEX.computeIfAbsent(id, k -> BlockWars.id("textures/arsenal/" + k + ".png"));
    }

    public static ResourceLocation icon(String id) {
        return ICON.computeIfAbsent(id, k -> BlockWars.id("textures/arsenal/icon/" + k + ".png"));
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
        if (!(stack.getItem() instanceof ArsenalItem it)) return;
        ArsenalDef d = it.def;
        if (ctx == ItemDisplayContext.GUI) {
            drawIcon(icon(d.id), pose, buffers, overlay);
            return;
        }
        BwmModel model = MeshCache.get(d.id);
        if (model == null) {
            drawIcon(icon(d.id), pose, buffers, overlay);
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        boolean fp = ctx == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND || ctx == ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
        boolean tp = ctx == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND || ctx == ItemDisplayContext.THIRD_PERSON_LEFT_HAND;
        // first person: the main arm's context is always the local player's main hand (the hand renderer may still hold the
        // previous stack object for a frame or two after the server updated it); third person: the local player's own stack
        boolean mainArmContext = p != null && (ctx == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND) == (p.getMainArm() == HumanoidArm.RIGHT);
        boolean mine = p != null && (fp ? mainArmContext : tp && !mc.options.getCameraType().isFirstPerson() && p.getMainHandItem() == stack);
        float pt = ArsenalClient.partial;
        ArsenalAnim.State st = mine ? ArsenalAnim.local(stack, d, pt) : ArsenalAnim.still(stack, d, pt);

        pose.pushPose();
        pose.scale(1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        PoseStack.Pose root = pose.last();
        Matrix4f base = new Matrix4f(root.pose());
        Matrix3f nbase = new Matrix3f(root.normal());

        // per-part transforms
        int np = model.parts.size();
        Matrix4f[] pm = new Matrix4f[np];
        Matrix3f[] nm = new Matrix3f[np];
        for (int i = 0; i < np; i++) {
            Matrix4f local = new Matrix4f();
            if (!ArsenalAnim.part(local, i, model, st, d)) continue;
            pm[i] = new Matrix4f(base).mul(local);
            nm[i] = new Matrix3f(nbase).mul(new Matrix3f(local));
        }

        ResourceLocation tex = texture(d.id);
        float defGlow = ArsenalAnim.glow(st, d);
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(tex));
        for (int i = 0; i < np; i++) {
            if (pm[i] == null) continue;
            for (BwmModel.Layer l : model.parts.get(i).layers) {
                if (l.layer == BwmModel.OPAQUE) MeshCache.draw(vc, pm[i], nm[i], l, 0xFFFFFFFF, light, overlay, false);
            }
        }
        for (int i = 0; i < np; i++) {
            if (pm[i] == null || !model.parts.get(i).hasLayer(BwmModel.EMISSIVE)) continue;
            float g = ArsenalAnim.partGlow(i, model, st);
            if (g < 0) g = defGlow;
            int a = Math.round(255 * g);
            int col = 0xFF000000 | (a << 16) | (a << 8) | a;
            for (BwmModel.Layer l : model.parts.get(i).layers) {
                if (l.layer == BwmModel.EMISSIVE) MeshCache.draw(vc, pm[i], nm[i], l, col, LightTexture.FULL_BRIGHT, overlay, true);
            }
        }
        VertexConsumer glass = null;
        for (int i = 0; i < np; i++) {
            if (pm[i] == null || !model.parts.get(i).hasLayer(BwmModel.GLASS)) continue;
            if (glass == null) glass = buffers.getBuffer(RenderType.entityTranslucent(tex));
            for (BwmModel.Layer l : model.parts.get(i).layers) {
                if (l.layer == BwmModel.GLASS) MeshCache.draw(glass, pm[i], nm[i], l, 0xFFFFFFFF, light, overlay, false);
            }
        }

        // the local shooter: anchors for world effects, muzzle flash, charge glow, dragon breath
        if (mine) {
            float[] muzzle = model.meta("muzzle");
            float[] eject = model.meta("eject");
            if (fp) ArsenalView.captureAnchors(new Matrix4f(ArsenalView.LAST).mul(ArsenalView.displayMatrix(model)), muzzle, eject);
            if (muzzle != null) {
                Matrix4f at = new Matrix4f(base).translate(muzzle[0], muzzle[1], muzzle[2]);
                double time = ArsenalClient.seconds(pt);
                float dur = ArsenalFx.flashDuration(d);
                if (d.flash == ArsenalDef.Flash.DRAGON) {
                    ArsenalFx.drawBreath(buffers, at, d, st.firing, time);
                } else if (st.sinceShot < dur) {
                    float k = 1.0F - st.sinceShot / dur;
                    ArsenalFx.drawFlash(buffers, at, d, k * k, ArsenalClient.shots, 1.0F, time);
                }
                if (st.charge > 0) ArsenalFx.drawCharge(buffers, at, d, st.charge, time);
            }
        }
        pose.popPose();
    }

    /** The inventory icon: a pre-rendered picture of the weapon on a flat quad. */
    static void drawIcon(ResourceLocation icon, PoseStack pose, MultiBufferSource buffers, int overlay) {
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(icon));
        Matrix4f m = pose.last().pose();
        int light = LightTexture.FULL_BRIGHT;
        quad(vc, m, 0, 0, 1, 1, 0.5F, overlay, light);
    }

    private static void quad(VertexConsumer vc, Matrix4f m, float x0, float y0, float x1, float y1, float z, int overlay, int light) {
        Vector3f a = m.transformPosition(new Vector3f(x0, y0, z));
        Vector3f b = m.transformPosition(new Vector3f(x1, y0, z));
        Vector3f c = m.transformPosition(new Vector3f(x1, y1, z));
        Vector3f e = m.transformPosition(new Vector3f(x0, y1, z));
        vc.addVertex(a.x, a.y, a.z, 0xFFFFFFFF, 0, 1, overlay, light, 0, 0, 1);
        vc.addVertex(b.x, b.y, b.z, 0xFFFFFFFF, 1, 1, overlay, light, 0, 0, 1);
        vc.addVertex(c.x, c.y, c.z, 0xFFFFFFFF, 1, 0, overlay, light, 0, 0, 1);
        vc.addVertex(e.x, e.y, e.z, 0xFFFFFFFF, 0, 0, overlay, light, 0, 0, 1);
    }

    public static int noOverlay() {
        return OverlayTexture.NO_OVERLAY;
    }
}
