package com.blockwars.arsenal.client;

import com.blockwars.arsenal.ArsenalData;
import com.blockwars.arsenal.ArsenalDef;
import com.blockwars.arsenal.ArsenalDef.Fire;
import com.blockwars.arsenal.ArsenalDef.Proj;
import com.blockwars.arsenal.ArsenalItem;
import com.blockwars.arsenal.ArsenalLogic;
import com.blockwars.arsenal.ArsenalModule;
import com.blockwars.arsenal.ArsenalNet;
import com.blockwars.arsenal.ArsenalParticles;
import com.blockwars.arsenal.ArsenalSounds;
import com.blockwars.entity.BaseMechaEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.CalculatePlayerTurnEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.common.NeoForge;
import org.jetbrains.annotations.Nullable;

/**
 * The shooter's side of the Arsenal: input, instant predicted shots (sound, flash, beams, arcs, flames, waves), recoil
 * that climbs and springs back, weapon inertia, sprint pose, inspect, camera shake, FOV punch, aiming and scope zoom.
 * The server does the real work in {@link ArsenalLogic}.
 */
public final class ArsenalClient {
    private ArsenalClient() {}

    // ------------------------------------------------------------------ input / prediction
    private static boolean triggerSent;
    private static int hold;
    private static int localCooldown;
    private static int localBurst;
    private static int fireSoundTick;
    private static float fireAcc;
    private static int lastSlot = -1;
    @Nullable private static ArsenalDef lastDef;
    @Nullable private static ArsenalLoop loop;
    @Nullable private static net.minecraft.client.multiplayer.ClientLevel lastLevel;

    /** shots fired since the weapon was drawn (drum turns, alternating effects) */
    public static int shots;
    /** game time of the last shot fired by the local player */
    public static long lastShot = -1000;
    /** game time when the current manual cycle (pump) started */
    public static long cycleStart = -1000;
    public static long inspectStart = -1000;
    public static long reloadEnded = -1000;
    public static long equipTime = -1000;
    private static boolean wasReloading;
    private static boolean wrapperDue;
    public static float spin, spinO, spinSpeed;
    public static float charge, chargeO;
    public static float firing, firingO;

    // ------------------------------------------------------------------ feel
    public static float kick, kickO, kickV;
    public static float kickRoll, kickRollO;
    public static float shake;
    private static float fovPunch, fovPunchO;
    private static float recover;
    public static float ads, adsO;
    public static float sprint, sprintO;
    public static float swayX, swayXO, swayY, swayYO;
    private static float lastYaw, lastPitch;
    private static boolean haveLast;
    public static float land, landO;
    private static boolean wasOnGround = true;
    private static float fallSpeed;
    public static float bloom, bloomO;
    public static int hitMarker;
    public static int hitKind;
    public static float hitDamage;

    // ------------------------------------------------------------------ render anchors
    /** last frame's world FOV, for converting first-person (fixed 70°) positions to world positions */
    public static double worldFov = 70.0;
    public static float partial;
    /** muzzle / ejection port of the first-person weapon as camera-relative world offsets (refreshed each frame) */
    @Nullable public static Vec3 fpMuzzle, fpEject;
    public static long fpSeen = -1000;

    public static void init(IEventBus modBus) {
        modBus.addListener(ArsenalClient::registerExtensions);
        modBus.addListener(ArsenalClient::registerReload);
        modBus.addListener(ArsenalClient::registerParticles);
        modBus.addListener(ArsenalClient::registerRenderers);
        modBus.addListener(ArsenalClient::registerHud);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onClientTick);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onFrame);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onClickInput);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onCameraAngles);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onFov);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onTurn);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onMovementInput);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onGuiLayer);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onRenderHand);
        NeoForge.EVENT_BUS.addListener(ArsenalClient::onRenderStage);
    }

    private static void registerExtensions(RegisterClientExtensionsEvent event) {
        var items = com.blockwars.arsenal.Arsenal.WEAPONS.values().stream().map(h -> (net.minecraft.world.item.Item) h.get())
                .toArray(net.minecraft.world.item.Item[]::new);
        event.registerItem(new ArsenalItemExt(), items);
    }

    private static void registerReload(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener(MeshCache.INSTANCE);
    }

    private static void registerParticles(RegisterParticleProvidersEvent event) {
        ArsenalParticleTypes.register(event);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(com.blockwars.arsenal.ArsenalEntities.SHOT.get(), ShotRenderer::new);
    }

    private static void registerHud(RegisterGuiLayersEvent event) {
        event.registerAboveAll(com.blockwars.BlockWars.id("arsenal_hud"), ArsenalHud::render);
    }

    // ------------------------------------------------------------------ helpers

    @Nullable
    public static ArsenalItem held(@Nullable LocalPlayer p) {
        if (p == null || p.getVehicle() instanceof BaseMechaEntity || p.isSpectator()) return null;
        return p.getMainHandItem().getItem() instanceof ArsenalItem a ? a : null;
    }

    public static boolean holding() {
        return held(Minecraft.getInstance().player) != null;
    }

    private static void play(LocalPlayer p, SoundEvent s, float vol, float pitch) {
        p.level().playLocalSound(p.getX(), p.getEyeY(), p.getZ(), s, SoundSource.PLAYERS, vol, pitch, false);
    }

    public static float now(float pt) {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? 0 : mc.level.getGameTime() + pt;
    }

    /** World time in seconds as a double (oscillators stay smooth on old worlds). */
    public static double seconds(float pt) {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? 0 : (mc.level.getGameTime() + (double) pt) / 20.0;
    }

    public static boolean aiming(LocalPlayer p) {
        return p.isUsingItem() && p.getUsedItemHand() == InteractionHand.MAIN_HAND && held(p) != null;
    }

    /** The weapon's own "special" sound is its inspect flourish unless it is needed for charging, spinning or pumping. */
    static boolean specialIsInspect(ArsenalDef d) {
        return d.chargeTicks == 0 && d.spinUp == 0 && !d.manual();
    }

    // ------------------------------------------------------------------ keys (routed from BlockWarsClient)

    public static void reloadKey() {
        LocalPlayer p = Minecraft.getInstance().player;
        ArsenalItem it = held(p);
        if (it == null) return;
        ItemStack s = p.getMainHandItem();
        ArsenalDef d = it.def;
        if (!d.usesAmmo() || ArsenalData.ammo(s) >= ArsenalModule.mag(s, d)) {
            // nothing to reload: look the weapon over instead
            if (now(0) - inspectStart > ArsenalAnim.inspectTicks(d)) {
                inspectStart = (long) now(0);
                play(p, specialIsInspect(d) ? ArsenalSounds.weapon(d, "special") : ArsenalSounds.shared("inspect"), 0.7F, 1.0F);
            }
            return;
        }
        inspectStart = -1000;
        ArsenalNet.send(ArsenalNet.RELOAD);
    }

    public static void modeKey() {
        if (holding()) ArsenalNet.send(ArsenalNet.MODE);
    }

    /** Left click shoots instead of punching or mining. */
    private static void onClickInput(InputEvent.InteractionKeyMappingTriggered event) {
        if (event.isAttack() && holding()) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    // ------------------------------------------------------------------ tick

    private static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (mc.level != lastLevel) {
            // another world or dimension: its clock has nothing to do with the stamps taken in the last one
            lastLevel = mc.level;
            resetClocks();
        }
        kickO = kick;
        kickRollO = kickRoll;
        fovPunchO = fovPunch;
        adsO = ads;
        sprintO = sprint;
        swayXO = swayX;
        swayYO = swayY;
        landO = land;
        bloomO = bloom;
        spinO = spin;
        chargeO = charge;
        firingO = firing;
        // recoil spring: fast kick back, slightly bouncy return
        kickV += -0.42F * kick - 0.5F * kickV;
        kick = Math.max(-0.4F, kick + kickV);
        kickRoll *= 0.6F;
        fovPunch *= 0.7F;
        shake *= 0.78F;
        bloom *= 0.86F;
        land *= 0.7F;
        if (hitMarker > 0) hitMarker--;
        ArsenalFx.tick();
        if (p == null) return;

        if (recover > 0.01F) {
            float r = recover * 0.2F;
            p.setXRot(p.getXRot() + r);
            recover -= r;
        }
        // weapon inertia: the gun lags behind quick turns
        float yaw = p.getYRot(), pitch = p.getXRot();
        if (haveLast) {
            float dy = Mth.clamp(Mth.wrapDegrees(yaw - lastYaw), -25, 25);
            float dp = Mth.clamp(pitch - lastPitch, -25, 25);
            swayX += (-dy * 0.22F - swayX) * 0.45F;
            swayY += (-dp * 0.22F - swayY) * 0.45F;
        }
        lastYaw = yaw;
        lastPitch = pitch;
        haveLast = true;
        // landing dip
        if (p.onGround() && !wasOnGround) land = Math.min(1.5F, land + 0.25F + fallSpeed * 1.6F);
        fallSpeed = (float) Math.max(0, -p.getDeltaMovement().y);
        wasOnGround = p.onGround();

        ArsenalItem it = held(p);
        ItemStack stack = p.getMainHandItem();
        boolean aim = it != null && aiming(p) && !ArsenalData.reloading(stack);
        float adsSpeed = it == null ? 0.3F : Mth.clamp(0.42F - it.def.weight * 0.035F, 0.14F, 0.42F)
                * (ArsenalModule.has(stack, ArsenalModule.SCOPE) ? 0.8F : 1.0F);
        ads += ((aim ? 1.0F : 0.0F) - ads) * adsSpeed;
        boolean sprinting = it != null && p.isSprinting() && !aim && !triggerSent;
        sprint += ((sprinting ? 1.0F : 0.0F) - sprint) * 0.25F;

        if (it == null || mc.screen != null) {
            if (triggerSent) {
                ArsenalNet.send(ArsenalNet.TRIGGER_UP);
                triggerSent = false;
            }
            hold = 0;
            charge = 0;
            localBurst = 0;
            firing *= 0.8F;
            spinSpeed *= 0.85F;
            spin += spinSpeed;
            if (it == null) lastDef = null;
            return;
        }
        ArsenalDef d = it.def;
        long now = p.level().getGameTime();
        int slot = p.getInventory().selected;
        if (d != lastDef || slot != lastSlot) {
            lastDef = d;
            lastSlot = slot;
            localCooldown = 0;
            localBurst = 0;
            shots = 0;
            equipTime = now;
            inspectStart = -1000;
            play(p, ArsenalSounds.weapon(d, "equip"), 0.8F, 1.0F);
        }
        boolean reloading = ArsenalData.reloading(stack);
        if (wasReloading && !reloading) reloadEnded = now;
        wasReloading = reloading;
        if (reloading || aim) inspectStart = -1000;

        Fire fire = d.mode(ArsenalData.mode(stack));
        boolean down = mc.options.keyAttack.isDown();
        if (localCooldown > 0) localCooldown--;
        if (down && !triggerSent) {
            triggerSent = true;
            hold = 0;
            inspectStart = -1000;
            ArsenalNet.send(ArsenalNet.TRIGGER_DOWN);
            if (fire == Fire.SEMI) predictShot(p, stack, d, 1.0F);
            if (fire == Fire.BURST && localBurst <= 0) localBurst = d.burst;
            if (fire == Fire.CHARGE && canPredict(stack, d)) play(p, ArsenalSounds.weapon(d, "special"), 0.9F, 1.0F);
            if (d.spinUp > 0 && spinSpeed < 30.0F) play(p, ArsenalSounds.weapon(d, "special"), 0.9F, 1.0F);
        } else if (!down && triggerSent) {
            triggerSent = false;
            ArsenalNet.send(ArsenalNet.TRIGGER_UP);
            if (fire == Fire.CHARGE) {
                int full = ArsenalLogic.chargeTicks(stack, d);
                if (hold >= Math.max(3, full / 4)) predictShot(p, stack, d, Mth.clamp(hold / (float) full, 0.0F, 1.0F));
            }
            hold = 0;
        }
        if (triggerSent) hold++;
        charge = fire == Fire.CHARGE && triggerSent && canPredict(stack, d) ? Math.min(1.0F, hold / (float) ArsenalLogic.chargeTicks(stack, d)) : 0.0F;
        if (charge > 0.0F) {
            shake = Math.max(shake, 0.04F + 0.22F * charge * charge * (d.dangerous ? 1.6F : 1.0F));
            chargeEffects(p, d, charge);
        }

        // rotary barrels
        if (d.spinUp > 0) {
            float target = triggerSent ? 60.0F : 0.0F;
            spinSpeed += (target - spinSpeed) * (triggerSent ? 1.0F / Math.max(2, d.spinUp) * 2.0F : 0.06F);
        } else {
            spinSpeed *= 0.8F;
        }
        spin += spinSpeed;

        switch (fire) {
            case AUTO, BEAM -> {
                boolean spunUp = d.spinUp == 0 || spinSpeed >= 50.0F;
                if (triggerSent && !spunUp) {
                    shake = Math.max(shake, 0.06F * spinSpeed / 60.0F);
                } else if (triggerSent && localCooldown <= 0) {
                    if (d.rpm > 1200) {
                        fireAcc += d.shotsPerTick();
                        int n = (int) fireAcc;
                        fireAcc -= n;
                        if (n > 0 && predictShot(p, stack, d, 1.0F)) {
                            localCooldown = 0;
                            shots += n - 1;
                        }
                    } else {
                        predictShot(p, stack, d, 1.0F);
                    }
                }
            }
            case BURST -> {
                if (localBurst > 0 && localCooldown <= 0) {
                    if (predictShot(p, stack, d, 1.0F)) {
                        localBurst--;
                        if (localBurst == 0) localCooldown = d.cooldown() * 3;
                    } else {
                        localBurst = 0;
                    }
                }
            }
            default -> { }
        }

        // eased "firing" level for the animation channels
        boolean active = triggerSent && now - lastShot <= Math.max(3, d.cooldown() + 1) && canPredict(stack, d);
        firing += ((active ? 1.0F : 0.0F) - firing) * (active ? 0.45F : 0.14F);

        // continuous weapons hum while they fire
        boolean beam = fire == Fire.BEAM && active;
        if (beam && (loop == null || loop.isStopped())) {
            loop = new ArsenalLoop(ArsenalSounds.shared(d.proj == Proj.FLAME ? "flame_loop" : "beam_loop"), p);
            mc.getSoundManager().play(loop);
        }
        if (loop != null) loop.keep(beam);

        // the pump throws its wrapper out halfway through the stroke
        if (wrapperDue && now - cycleStart >= Math.max(2, d.cycleTicks / 2)) {
            wrapperDue = false;
            ejectWrapper(p, d);
        }

        // spinning parts of the held weapon
        BwmModel model = MeshCache.get(d.id);
        if (model != null) ArsenalAnim.integrate(model, ArsenalAnim.local(stack, d, 0.0F));
    }

    private static void resetClocks() {
        lastShot = -1000;
        cycleStart = -1000;
        inspectStart = -1000;
        reloadEnded = -1000;
        equipTime = -1000;
        fpSeen = -1000;
        fpMuzzle = null;
        fpEject = null;
        lastDef = null;
        lastSlot = -1;
        shots = 0;
        hold = 0;
        localCooldown = 0;
        localBurst = 0;
        fireAcc = 0;
        triggerSent = false;
        wasReloading = false;
        wrapperDue = false;
        charge = chargeO = 0;
        firing = firingO = 0;
        spin = spinO = spinSpeed = 0;
        if (loop != null) {
            loop.keep(false);
            loop = null;
        }
        ArsenalFx.clear();
    }

    /** Charging glows and pulls at the air around the barrel. */
    private static void chargeEffects(LocalPlayer p, ArsenalDef d, float c) {
        Vec3 m = muzzleNow(p);
        RandomSource r = p.getRandom();
        if (d.proj == Proj.VOID) {
            for (int i = 0; i < 1 + (int) (c * 3); i++) {
                Vec3 o = new Vec3(r.nextGaussian(), r.nextGaussian(), r.nextGaussian()).normalize().scale(0.5 + r.nextFloat() * 0.6);
                p.level().addParticle(net.minecraft.core.particles.ParticleTypes.PORTAL, m.x, m.y, m.z, o.x, o.y - 1.0, o.z);
            }
        } else if (d.proj == Proj.ICE && r.nextFloat() < c) {
            Vec3 o = new Vec3(r.nextGaussian(), r.nextGaussian(), r.nextGaussian()).scale(0.25);
            p.level().addParticle(ArsenalParticles.of(ArsenalParticles.FROST, 0xD8F6FF), m.x + o.x, m.y + o.y, m.z + o.z, -o.x * 0.1, -o.y * 0.1, -o.z * 0.1);
        }
    }

    private static boolean canPredict(ItemStack s, ArsenalDef d) {
        if (ArsenalData.reloading(s)) return false;
        if (d.usesHeat() && ArsenalData.locked(s)) return false;
        return !d.usesAmmo() || ArsenalData.ammo(s) > 0;
    }

    /** Where the barrel ends right now, in the world. */
    static Vec3 muzzleNow(LocalPlayer p) {
        Vec3 eye = p.getEyePosition(partial);
        Vec3 fwd = p.getViewVector(partial);
        boolean fpFresh = fpMuzzle != null && p.level().getGameTime() - fpSeen < 3 && Minecraft.getInstance().options.getCameraType().isFirstPerson();
        return fpFresh ? eye.add(fpMuzzle) : ArsenalLogic.muzzle(p).add(fwd.scale(0.1));
    }

    /** The shooter's instant copy of a shot. */
    private static boolean predictShot(LocalPlayer p, ItemStack s, ArsenalDef d, float chargeFrac) {
        if (localCooldown > 0) return false;
        if (!canPredict(s, d)) {
            if (d.usesAmmo() && ArsenalData.ammo(s) <= 0 && d.mode(ArsenalData.mode(s)) != Fire.BEAM) {
                play(p, ArsenalSounds.shared("dry"), 0.9F, 1.0F);
                localCooldown = 8;
            }
            return false;
        }
        localCooldown = Math.max(Math.max(1, Math.round(d.cooldown() * ArsenalModule.cooldownMul(s))), d.manual() ? d.cycleTicks : 0);
        RandomSource rnd = p.getRandom();
        long now = p.level().getGameTime();
        shots++;
        lastShot = now;
        if (d.manual()) {
            cycleStart = now;
            wrapperDue = true;
        }
        inspectStart = -1000;
        boolean beam = d.mode(ArsenalData.mode(s)) == Fire.BEAM;
        float scale = d.chargeTicks > 0 ? 0.35F + 0.65F * chargeFrac : 1.0F;

        // sound: continuous weapons loop instead; very fast ones every other shot
        if (!beam && (d.rpm < 900 || fireSoundTick-- <= 0)) {
            float pitch = 0.96F + rnd.nextFloat() * 0.08F;
            if (d.chargeTicks > 0) pitch *= 1.1F - 0.15F * chargeFrac;
            play(p, ArsenalSounds.weapon(d, "fire"), 1.0F, pitch);
            if (d.manual()) play(p, ArsenalSounds.weapon(d, "special"), 0.8F, 1.0F);
            fireSoundTick = 1;
        }

        // recoil: climb + random yaw, part of it recovers; stance and upgrades change it
        float stance = 1.0F - 0.35F * ads;
        if (p.isCrouching()) stance *= 0.8F;
        stance *= ArsenalModule.recoilMul(s);
        float climb = d.recoilV * scale * stance * (beam ? 0.25F : 1.0F);
        p.setXRot(Mth.clamp(p.getXRot() - climb, -90.0F, 90.0F));
        p.setYRot(p.getYRot() + (rnd.nextFloat() - 0.5F) * 2.0F * d.recoilH * scale * stance);
        recover += climb * Mth.clamp(d.recover, 0.0F, 1.0F);
        kickV += d.kick * scale * (0.8F + 0.4F * rnd.nextFloat()) * (beam ? 0.3F : 1.0F) * ArsenalModule.recoilMul(s);
        kickRoll += (rnd.nextFloat() - 0.5F) * d.kick * 6.0F * scale;
        shake = Math.min(4.0F, shake + d.shake * scale * (beam ? 0.35F : 1.0F));
        fovPunch = Math.min(0.08F, fovPunch + 0.01F * d.shake * scale);
        bloom = Math.min(1.0F, bloom + 0.1F + d.recoilV * 0.03F);

        // effects in the world, anchored on the first-person weapon (or the eye when it is not visible)
        Vec3 fwd = p.getViewVector(partial);
        Vec3 muzzle = muzzleNow(p);
        ArsenalFx.muzzleWorld(p, d, muzzle, fwd, chargeFrac);
        if (d.hitscan()) predictHitscan(p, d, s, muzzle);
        return true;
    }

    /** Candy wrappers flutter out of the pump. */
    private static void ejectWrapper(LocalPlayer p, ArsenalDef d) {
        if (d.casing != ArsenalDef.Casing.WRAPPER) return;
        Vec3 eye = p.getEyePosition(partial);
        Vec3 fwd = p.getViewVector(partial);
        boolean fpFresh = fpEject != null && p.level().getGameTime() - fpSeen < 3 && Minecraft.getInstance().options.getCameraType().isFirstPerson();
        Vec3 port = fpFresh ? eye.add(fpEject) : eye.add(fwd.scale(0.5)).add(0, -0.3, 0);
        RandomSource rnd = p.getRandom();
        Vec3 right = fwd.cross(new Vec3(0, 1, 0)).normalize();
        Vec3 up = right.cross(fwd).normalize();
        Vec3 v = right.scale(0.1 + rnd.nextDouble() * 0.05).add(up.scale(0.12 + rnd.nextDouble() * 0.05)).add(fwd.scale(-0.03)).add(p.getDeltaMovement());
        p.level().addParticle(ArsenalParticles.of(ArsenalParticles.WRAPPER, d.tracerColor), port.x, port.y, port.z, v.x, v.y, v.z);
        play(p, ArsenalSounds.shared("wrapper"), 0.4F, 0.9F + rnd.nextFloat() * 0.3F);
    }

    /** Instant weapons: draw the beam, arc, flame or wave right away. */
    private static void predictHitscan(LocalPlayer p, ArsenalDef d, ItemStack s, Vec3 muzzle) {
        Vec3 eye = p.getEyePosition(partial);
        Vec3 look = p.getViewVector(partial);
        switch (d.proj) {
            case FLAME -> ArsenalFx.flames(p, d, muzzle, look);
            case WAVE -> ArsenalFx.wave(muzzle, look, d, true);
            case ARC -> {
                Entity target = ArsenalLogic.crosshairTarget(p, d.range);
                Vec3 end;
                if (target != null) {
                    end = target.getBoundingBox().getCenter();
                } else {
                    BlockHitResult bh = p.level().clip(new ClipContext(eye, eye.add(look.scale(d.range)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
                    end = bh.getLocation();
                    if (bh.getType() == HitResult.Type.BLOCK) ArsenalFx.impactGlow(end, d.tracerColor);
                }
                ArsenalFx.arc(muzzle, end, d, 5);
            }
            default -> ArsenalFx.liveBeam(d, p.level().getGameTime() + 2);
        }
    }

    /** The end of a straight beam from the eye: first block or living thing. */
    static Vec3 beamEnd(LocalPlayer p, double range, float pt) {
        Vec3 eye = p.getEyePosition(pt);
        Vec3 look = p.getViewVector(pt);
        Vec3 to = eye.add(look.scale(range));
        BlockHitResult bh = p.level().clip(new ClipContext(eye, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 end = bh.getType() == HitResult.Type.MISS ? to : bh.getLocation();
        double best = end.distanceToSqr(eye);
        for (Entity e : p.level().getEntities(p, new net.minecraft.world.phys.AABB(eye, end).inflate(1.0), e -> e instanceof LivingEntity && e.isAlive())) {
            var c = e.getBoundingBox().inflate(0.2).clip(eye, end);
            if (c.isPresent() && c.get().distanceToSqr(eye) < best) {
                best = c.get().distanceToSqr(eye);
                end = c.get();
            }
        }
        return end;
    }

    // ------------------------------------------------------------------ server feedback

    public static void onFeedback(byte kind, float value) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (kind == ArsenalNet.SHAKE) {
            shake = Math.min(5.0F, shake + value);
            fovPunch = Math.min(0.1F, fovPunch + value * 0.01F);
            return;
        }
        hitMarker = kind == ArsenalNet.KILL ? 16 : 8;
        hitKind = kind;
        hitDamage = value;
        String sound = kind == ArsenalNet.KILL ? "kill" : kind == ArsenalNet.HEAD ? "head" : "hit";
        play(p, ArsenalSounds.shared(sound), kind == ArsenalNet.HIT ? 0.5F : 0.85F, 1.0F);
    }

    // ------------------------------------------------------------------ frame, camera and view

    private static void onFrame(RenderFrameEvent.Pre event) {
        partial = event.getPartialTick().getGameTimeDeltaPartialTick(true);
    }

    private static void onRenderStage(RenderLevelStageEvent event) {
        if (event.getStage() == RenderLevelStageEvent.Stage.AFTER_PARTICLES) ArsenalFx.render(event);
    }

    private static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (shake < 0.01F) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !mc.options.getCameraType().isFirstPerson() && shake < 0.5F) return;
        double t = mc.player.tickCount + event.getPartialTick();
        float s = shake;
        event.setPitch(event.getPitch() + (float) (Math.sin(t * 2.7) * 0.6 + Math.sin(t * 6.1) * 0.35) * s);
        event.setYaw(event.getYaw() + (float) (Math.cos(t * 3.3) * 0.45) * s);
        event.setRoll(event.getRoll() + (float) (Math.sin(t * 4.3) * 0.9) * s);
    }

    private static void onFov(ViewportEvent.ComputeFov event) {
        if (!event.usedConfiguredFov()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        float pt = (float) event.getPartialTick();
        double fov = event.getFOV();
        ArsenalItem it = held(p);
        if (it != null) {
            float a = Mth.lerp(pt, adsO, ads);
            if (a > 0.001F) fov *= Mth.lerp(a, 1.0, 1.0 / zoom(p.getMainHandItem(), it.def));
            fov *= 1.0 + Mth.lerp(pt, fovPunchO, fovPunch);
            event.setFOV(fov);
        }
        worldFov = fov;
    }

    /** Magnification while aiming. */
    public static float zoom(ItemStack s, ArsenalDef d) {
        float z = Math.max(1.0F, d.zoom);
        if (ArsenalModule.has(s, ArsenalModule.SCOPE)) z = Math.max(z * 1.5F, 4.0F);
        return z;
    }

    public static boolean scoped() {
        Minecraft mc = Minecraft.getInstance();
        ArsenalItem it = held(mc.player);
        if (it == null || ads < 0.9F || !mc.options.getCameraType().isFirstPerson()) return false;
        return ArsenalModule.has(mc.player.getMainHandItem(), ArsenalModule.SCOPE) || it.def.sight == ArsenalDef.Sight.SCOPE && it.def.zoom >= 3.0F;
    }

    /** Slower mouse while zoomed, so the reticle can actually be held on target. */
    private static void onTurn(CalculatePlayerTurnEvent event) {
        Minecraft mc = Minecraft.getInstance();
        ArsenalItem it = held(mc.player);
        if (it == null || ads < 0.05F) return;
        float z = zoom(mc.player.getMainHandItem(), it.def);
        double k = Mth.lerp(ads, 1.0, 1.0 / Math.pow(z, 0.85));
        event.setMouseSensitivity(event.getMouseSensitivity() * k);
    }

    /** Aiming slows you less than drawing a bow; heavy weapons slow you more. */
    private static void onMovementInput(MovementInputUpdateEvent event) {
        if (!(event.getEntity() instanceof LocalPlayer p)) return;
        ArsenalItem it = held(p);
        if (it == null || p.isPassenger()) return;
        float k = 1.0F;
        if (aiming(p)) k = 2.6F * (it.def.weight >= 6.0F ? 0.75F : 1.0F);
        else if (it.def.weight >= 7.0F) k = 0.8F;
        if (k != 1.0F) {
            event.getInput().leftImpulse = Mth.clamp(event.getInput().leftImpulse * k, -1.0F, 1.0F);
            event.getInput().forwardImpulse = Mth.clamp(event.getInput().forwardImpulse * k, -1.0F, 1.0F);
        }
    }

    /** Arsenal weapons draw their own crosshair. */
    private static void onGuiLayer(RenderGuiLayerEvent.Pre event) {
        if (event.getName().equals(VanillaGuiLayers.CROSSHAIR) && holding()) event.setCanceled(true);
    }

    /** Two-handed weapons: the off hand is busy holding the gun. */
    private static void onRenderHand(RenderHandEvent event) {
        if (event.getHand() == InteractionHand.OFF_HAND && holding() && !event.getItemStack().isEmpty()) {
            ArsenalItem it = held(Minecraft.getInstance().player);
            if (it != null && (it.def.cat != ArsenalDef.Cat.PISTOL || ads > 0.2F)) event.setCanceled(true);
        }
    }

    public static boolean triggerHeld() {
        return triggerSent;
    }
}
