package com.blockwars.arsenal.client;

import com.blockwars.BlockWars;
import com.blockwars.arsenal.ArsenalData;
import com.blockwars.arsenal.ArsenalDef;
import com.blockwars.arsenal.ArsenalDef.Fire;
import com.blockwars.arsenal.ArsenalItem;
import com.blockwars.arsenal.ArsenalLogic;
import com.blockwars.arsenal.ArsenalModule;
import com.blockwars.arsenal.ArsenalModuleItem;
import com.blockwars.arsenal.ArsenalNet;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;

/**
 * Arsenal HUD: a crosshair of its own for every category, charge and reload rings, hit markers, the scope, and a
 * panel with the charge left, the reserve, the fire mode, heat and the installed upgrades.
 */
public final class ArsenalHud {
    private ArsenalHud() {}

    private static final ResourceLocation SCOPE = BlockWars.id("textures/arsenal/fx/scope_overlay.png");

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui) return;
        ArsenalItem it = ArsenalClient.held(p);
        if (it == null) return;
        ArsenalDef d = it.def;
        ItemStack s = p.getMainHandItem();
        Font font = mc.font;
        int w = g.guiWidth(), h = g.guiHeight();
        float pt = delta.getGameTimeDeltaPartialTick(true);
        long now = p.level().getGameTime();
        int cx = w / 2, cy = h / 2;
        boolean fp = mc.options.getCameraType().isFirstPerson();
        float ads = Mth.lerp(pt, ArsenalClient.adsO, ArsenalClient.ads);

        // ------------------------------------------------------------ scope
        boolean scoped = ArsenalClient.scoped();
        if (scoped) {
            int size = Math.min(w, h);
            int x0 = cx - size / 2, y0 = cy - size / 2;
            g.blit(SCOPE, x0, y0, size, size, 0, 0, 256, 256, 256, 256);
            if (x0 > 0) {
                g.fill(0, 0, x0, h, 0xFF000000);
                g.fill(x0 + size, 0, w, h, 0xFF000000);
            }
            if (y0 > 0) {
                g.fill(0, 0, w, y0, 0xFF000000);
                g.fill(0, y0 + size, w, h, 0xFF000000);
            }
        }

        // ------------------------------------------------------------ crosshair (fades out while aiming down sights)
        if (!scoped && fp) {
            float alpha = Mth.clamp(1.0F - ads * 1.6F, 0.0F, 1.0F);
            if (alpha > 0.02F) crosshair(g, d, s, p, cx, cy, alpha, Mth.lerp(pt, ArsenalClient.bloomO, ArsenalClient.bloom), ArsenalClient.seconds(pt));
        }

        // ------------------------------------------------------------ charge arc
        float charge = Mth.lerp(pt, ArsenalClient.chargeO, ArsenalClient.charge);
        if (charge > 0.01F) {
            int col = charge >= 0.999F ? 0xFFFFFFFF : 0xE0000000 | (d.flashColor & 0xFFFFFF);
            arc(g, cx, cy, 12, 40, charge, col, 2);
        }

        // ------------------------------------------------------------ reload ring
        float rel = ArsenalData.reloadProgress(s, now + pt);
        if (rel >= 0) {
            arc(g, cx, cy, 15, 48, 1.0F, 0x50FFFFFF, 1);
            arc(g, cx, cy, 15, 48, rel, 0xE0FFFFFF, 1);
        }

        // ------------------------------------------------------------ hit marker
        if (ArsenalClient.hitMarker > 0) {
            int k = ArsenalClient.hitKind;
            int col = k == ArsenalNet.KILL ? 0xFFFF3B30 : k == ArsenalNet.HEAD ? 0xFFFFD23C : 0xFFFFFFFF;
            int o = 4 + (k == ArsenalNet.KILL ? 2 : 0), l = 4 + (k == ArsenalNet.KILL ? 2 : 0);
            for (int i = 0; i < l; i++) {
                g.fill(cx - o - i - 1, cy - o - i - 1, cx - o - i, cy - o - i, col);
                g.fill(cx + o + i, cy - o - i - 1, cx + o + i + 1, cy - o - i, col);
                g.fill(cx - o - i - 1, cy + o + i, cx - o - i, cy + o + i + 1, col);
                g.fill(cx + o + i, cy + o + i, cx + o + i + 1, cy + o + i + 1, col);
            }
        }

        // ------------------------------------------------------------ ammo panel (bottom right)
        int px = w - 8, py = h - 30;
        Component mode = Component.translatable("arsenal.blockwars.mode." + d.mode(ArsenalData.mode(s)).name().toLowerCase());
        Component name = s.getHoverName();
        g.drawString(font, name, px - font.width(name), py - 22, 0xFFE8E8E8, true);
        if (d.usesAmmo()) {
            int ammo = ArsenalData.ammo(s);
            int mag = ArsenalModule.mag(s, d);
            int reserve = p.isCreative() ? -1 : ArsenalLogic.reserve(p, d);
            String big = String.valueOf(ammo);
            String small = reserve < 0 ? " / ∞" : " / " + reserve;
            int colBig = ammo == 0 ? 0xFFFF4A3A : ammo <= Math.max(1, mag / 4) ? 0xFFFFC23A : 0xFFFFFFFF;
            g.pose().pushPose();
            g.pose().translate(px - font.width(small) - font.width(big) * 2, py - 10, 0);
            g.pose().scale(2.0F, 2.0F, 1.0F);
            g.drawString(font, big, 0, 0, colBig, true);
            g.pose().popPose();
            g.drawString(font, small, px - font.width(small), py - 2, 0xFFB8B8B8, true);
            // the charge as a bar in the weapon's colour
            int bw = 70, bx = px - bw, by = py + 10;
            g.fill(bx - 1, by - 1, bx + bw + 1, by + 3, 0x80000000);
            g.fill(bx, by, bx + Math.round(bw * Mth.clamp(ammo / (float) Math.max(1, mag), 0, 1)), by + 2, 0xFF000000 | (d.tracerColor & 0xFFFFFF));
        }
        if (d.usesHeat()) {
            float heat = ArsenalData.heat(s, now, Math.max(0.004F, d.heatPerShot * 0.18F));
            boolean lock = ArsenalData.locked(s);
            int bw = 70, bx = px - bw, by = py + 16;
            g.fill(bx - 1, by - 1, bx + bw + 1, by + 4, 0x80000000);
            int fillw = Math.round(bw * heat);
            int col = lock ? ((now / 3) % 2 == 0 ? 0xFFFF3020 : 0xFFAA2010) : heat > 0.75F ? 0xFFFF7A20 : 0xFFFFC060;
            g.fill(bx, by, bx + fillw, by + 3, col);
            Component lbl = Component.translatable(lock ? "arsenal.blockwars.overheated" : "arsenal.blockwars.heat");
            g.drawString(font, lbl, bx - font.width(lbl) - 4, by - 2, lock ? 0xFFFF5040 : 0xFFB0B0B0, true);
        }
        g.drawString(font, mode, px - font.width(mode), py + (d.usesHeat() ? 24 : 16), 0xFF9AD0FF, true);

        // installed upgrades, the off-hand install hint and the danger warning stack up above the name
        int y = py - 33;
        for (ArsenalModule m : ArsenalModule.installed(s).values()) {
            Component c = Component.literal("+ ").append(Component.translatable("item.blockwars." + m.itemId));
            g.drawString(font, c, px - font.width(c), y, 0xFF8AE08A, true);
            y -= 10;
        }
        ItemStack off = p.getOffhandItem();
        if (off.getItem() instanceof ArsenalModuleItem mi) {
            Component hint = Component.translatable(mi.module.fits(d) ? "arsenal.blockwars.install_hint" : "arsenal.blockwars.module_unfit", off.getHoverName());
            g.drawString(font, hint, px - font.width(hint), y, mi.module.fits(d) ? 0xFF9AFF9A : 0xFFFF9A9A, true);
            y -= 10;
        }
        if (d.dangerous) {
            Component warn = Component.translatable("arsenal.blockwars.danger_hud");
            int c = (now / 10) % 2 == 0 ? 0xFFFF4030 : 0xFFAA2A20;
            g.drawString(font, warn, px - font.width(warn), y - 2, c, true);
        }
        if (ArsenalData.ammo(s) == 0 && d.usesAmmo() && rel < 0 && (now / 8) % 2 == 0) {
            Component r = Component.translatable("arsenal.blockwars.reload_hint");
            g.drawCenteredString(font, r, cx, cy + 24, 0xFFFF6A5A);
        }
        if (charge > 0 && d.mode(ArsenalData.mode(s)) == Fire.CHARGE && charge >= 0.999F) {
            g.drawCenteredString(font, Component.translatable("arsenal.blockwars.charged"), cx, cy + 24, 0xFFFFFFFF);
        }
    }

    // ------------------------------------------------------------------ crosshairs

    /** Every category aims through a crosshair of its own. */
    private static void crosshair(GuiGraphics g, ArsenalDef d, ItemStack s, LocalPlayer p, int cx, int cy, float alpha, float bloom, double time) {
        int a = Math.round(alpha * 230) << 24;
        int col = a | 0xFFFFFF;
        int tint = a | (d.tracerColor & 0xFFFFFF);
        float spread = d.spreadHip * ArsenalModule.hipSpreadMul(s);
        if (p.isCrouching()) spread *= 0.75F;
        int gap = Math.round(3 + spread * 1.6F + bloom * 8);
        g.fill(cx, cy, cx + 1, cy + 1, col);
        switch (d.cat) {
            case PISTOL -> {
                int len = 4;
                g.fill(cx - gap - len, cy, cx - gap, cy + 1, col);
                g.fill(cx + gap + 1, cy, cx + gap + 1 + len, cy + 1, col);
                g.fill(cx, cy + gap + 1, cx + 1, cy + gap + 1 + len, col);
                g.fill(cx, cy - gap - len, cx + 1, cy - gap, col);
                ring(g, cx, cy, gap + 6, 20, tint, 0, (float) (time * 0.6));
            }
            case LAUNCHER -> {
                // a honeycomb cell; it turns amber when a wasp will have something to chase
                boolean lock = ArsenalLogic.crosshairTarget(p, d.range) != null;
                polygon(g, cx, cy, gap + 6, 6, lock ? a | 0xFFB020 : col, 0.5236F);
                if (lock) polygon(g, cx, cy, gap + 3, 6, a | 0xFFE070, 0.5236F);
            }
            case SNIPER -> {
                ring(g, cx, cy, 10, 36, col, 0, 0);
                g.fill(cx - 16, cy, cx - 11, cy + 1, col);
                g.fill(cx + 12, cy, cx + 17, cy + 1, col);
                g.fill(cx, cy + 12, cx + 1, cy + 17, col);
            }
            case RIFLE -> {
                // electrodes: four short bars and a ring that shows when the arc can reach someone
                int len = 3;
                g.fill(cx - gap - len, cy - 1, cx - gap, cy + 2, tint);
                g.fill(cx + gap + 1, cy - 1, cx + gap + 1 + len, cy + 2, tint);
                g.fill(cx - 1, cy + gap + 1, cx + 2, cy + gap + 1 + len, tint);
                g.fill(cx - 1, cy - gap - len, cx + 2, cy - gap, tint);
                if (ArsenalLogic.crosshairTarget(p, d.range) != null) ring(g, cx, cy, gap + 6, 24, a | 0x9FE0FF, 2, (float) (time * 3.0));
            }
            case SHOTGUN -> {
                int r = gap + 6;
                for (int i = 0; i < 12; i++) {
                    double an = i * Math.PI / 6 + time * 0.8;
                    int x = cx + (int) Math.round(Math.cos(an) * r), y = cy + (int) Math.round(Math.sin(an) * r);
                    int c = ArsenalParticleTypes.PARTY[i % ArsenalParticleTypes.PARTY.length];
                    g.fill(x - 1, y - 1, x + 1, y + 1, a | (c & 0xFFFFFF));
                }
            }
            case EXOTIC -> {
                // three ticks turning around a void
                for (int i = 0; i < 3; i++) {
                    double an = i * Math.PI * 2 / 3 + time * 1.5;
                    for (int k = 0; k < 5; k++) {
                        int x = cx + (int) Math.round(Math.cos(an) * (gap + 4 + k)), y = cy + (int) Math.round(Math.sin(an) * (gap + 4 + k));
                        g.fill(x, y, x + 1, y + 1, tint);
                    }
                }
                ring(g, cx, cy, 3, 12, tint, 0, 0);
            }
            case FLAMER -> {
                arc(g, cx, cy, gap + 10, 40, 1.0F, a | 0xFF9A30, 1);
                g.fill(cx - 3, cy, cx - 1, cy + 1, col);
                g.fill(cx + 2, cy, cx + 4, cy + 1, col);
            }
            case BEAM -> {
                g.fill(cx - 3, cy, cx + 4, cy + 1, col);
                g.fill(cx, cy - 3, cx + 1, cy + 4, col);
                ring(g, cx, cy, 7, 24, a | (ArsenalFx.hue((float) (time * 0.4), 0.8F) & 0xFFFFFF), 0, 0);
            }
            case SONIC -> {
                // brackets that open with the cone
                int r = gap + 8;
                for (int k = 0; k < 3; k++) {
                    int rr = r + k * 4;
                    for (int i = -4; i <= 4; i++) {
                        double an = i * 0.12;
                        int x = (int) Math.round(Math.cos(an) * rr), y = (int) Math.round(Math.sin(an) * rr);
                        int c = a | (k == 0 ? 0xFFFFFF : d.tracerColor & 0xFFFFFF);
                        g.fill(cx + x, cy + y, cx + x + 1, cy + y + 1, c);
                        g.fill(cx - x, cy + y, cx - x + 1, cy + y + 1, c);
                    }
                }
            }
            case MINIGUN -> {
                // the circle tightens as the barrels spin up
                float spin = Mth.clamp(ArsenalClient.spinSpeed / 60.0F, 0, 1);
                int r = Math.round(gap + 14 - 8 * spin);
                ring(g, cx, cy, r, 28, spin > 0.83F ? tint : col, 0, (float) (ArsenalClient.spin * 0.05F));
            }
        }
    }

    private static void ring(GuiGraphics g, int cx, int cy, int r, int n, int col, int size, float rot) {
        for (int i = 0; i < n; i++) {
            double an = rot + i * Math.PI * 2 / n;
            int x = cx + (int) Math.round(Math.cos(an) * r), y = cy + (int) Math.round(Math.sin(an) * r);
            g.fill(x, y, x + 1 + (size > 1 ? 1 : 0), y + 1 + (size > 1 ? 1 : 0), col);
        }
    }

    private static void arc(GuiGraphics g, int cx, int cy, int r, int n, float frac, int col, int size) {
        int steps = Math.round(n * Mth.clamp(frac, 0, 1));
        for (int i = 0; i < steps; i++) {
            double an = -Math.PI / 2 + i * Math.PI * 2 / n;
            int x = cx + (int) Math.round(Math.cos(an) * r), y = cy + (int) Math.round(Math.sin(an) * r);
            g.fill(x, y, x + size, y + size, col);
        }
    }

    private static void polygon(GuiGraphics g, int cx, int cy, int r, int sides, int col, float rot) {
        for (int i = 0; i < sides; i++) {
            double a0 = rot + i * Math.PI * 2 / sides, a1 = rot + (i + 1) * Math.PI * 2 / sides;
            double x0 = cx + Math.cos(a0) * r, y0 = cy + Math.sin(a0) * r, x1 = cx + Math.cos(a1) * r, y1 = cy + Math.sin(a1) * r;
            int steps = (int) Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) + 1;
            for (int k = 0; k <= steps; k++) {
                double f = k / (double) steps;
                int x = (int) Math.round(x0 + (x1 - x0) * f), y = (int) Math.round(y0 + (y1 - y0) * f);
                g.fill(x, y, x + 1, y + 1, col);
            }
        }
    }
}
