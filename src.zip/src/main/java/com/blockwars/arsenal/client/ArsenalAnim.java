package com.blockwars.arsenal.client;

import com.blockwars.arsenal.ArsenalData;
import com.blockwars.arsenal.ArsenalDef;
import com.blockwars.arsenal.ArsenalModule;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Procedural animation. Every weapon mesh carries its own animation channels as metadata
 * ({@code anim.<part>.<n> = kind, axis, amount, driver, speed, phase}); each channel moves, turns, scales, spins, hides or
 * lights one part from one driver (firing, recoil kick, charge, heat, reload, shots fired, spin, ammo left, inspect...).
 * The whole weapon also gets a reload gesture per handling style and an inspect routine per category.
 */
public final class ArsenalAnim {
    private ArsenalAnim() {}

    // channel kinds
    public static final int ROT = 0, MOVE = 1, SCALE = 2, OSC_ROT = 3, OSC_MOVE = 4, SPIN = 5, GLOW = 6, HIDE = 7, PULSE = 8;
    // drivers
    public static final int D_TIME = 0, D_FIRING = 1, D_KICK = 2, D_CHARGE = 3, D_HEAT = 4, D_RELOAD = 5, D_SHOTS = 6, D_SPINV = 7,
            D_AMMO = 8, D_INSPECT = 9, D_IDLE = 10, D_RELOAD_RAW = 11, D_CYCLE = 12, D_ONE = 13, D_EMPTY = 14, D_SPENT = 15;
    private static final int DRIVERS = 16;

    /** Snapshot of the clocks for one frame. */
    public static final class State {
        public boolean local;           // the local player's weapon (clocks are meaningful)
        public double time;             // seconds, for oscillators
        public float sinceShot = 999;   // ticks since the last shot
        public float sinceCycle = 999;  // ticks since a manual cycle started
        public float sinceReloadEnd = 999;
        public float reload = -1;       // 0..1 progress of the current reload step, -1 = none
        public int reloadKind;
        public float inspect = -1;      // 0..1
        public float spin;              // rotary barrel angle (degrees)
        public float charge;            // 0..1
        public float heat;              // 0..1
        public float firing;            // 0..1, eased
        public int ammo;
        public int mag = 1;
        public int shots;
        public boolean trigger;
        public float pt;
        final float[] drv = new float[DRIVERS];
    }

    /** One compiled animation channel. */
    static final class Channel {
        final int kind, axis, driver;
        final float amount, speed, phase;
        final int slot;  // accumulator slot for SPIN channels, -1 otherwise

        Channel(float[] m, int slot) {
            this.kind = (int) m[0];
            this.axis = (int) m[1];
            this.amount = m[2];
            this.driver = Mth.clamp((int) m[3], 0, DRIVERS - 1);
            this.speed = m.length > 4 ? m[4] : 0.0F;
            this.phase = m.length > 5 ? m[5] : 0.0F;
            this.slot = slot;
        }
    }

    /** Channels of one mesh, by part index, plus the integrated spin angles of the local weapon. */
    static final class Compiled {
        final Channel[][] byPart;
        final boolean[] lit;
        float[] acc = new float[0];
        float[] accO = new float[0];

        Compiled(BwmModel model) {
            int np = model.parts.size();
            this.byPart = new Channel[np][];
            this.lit = new boolean[np];
            int spins = 0;
            for (int i = 0; i < np; i++) {
                String name = model.parts.get(i).name;
                List<Channel> list = new ArrayList<>();
                for (int n = 0; n < 16; n++) {
                    float[] m = model.meta("anim." + name + "." + n);
                    if (m == null) break;
                    if (m.length < 4) continue;
                    int kind = (int) m[0];
                    Channel c = new Channel(m, kind == SPIN ? spins++ : -1);
                    list.add(c);
                    if (kind == GLOW || kind == PULSE) this.lit[i] = true;
                }
                this.byPart[i] = list.toArray(new Channel[0]);
            }
            this.acc = new float[spins];
            this.accO = new float[spins];
        }
    }

    private static final Map<BwmModel, Compiled> COMPILED = new WeakHashMap<>();

    static Compiled compiled(BwmModel model) {
        return COMPILED.computeIfAbsent(model, Compiled::new);
    }

    // ------------------------------------------------------------------ states

    /** Clock state of the local player's held weapon. */
    public static State local(ItemStack s, ArsenalDef d, float pt) {
        State st = new State();
        float now = ArsenalClient.now(pt);
        st.local = true;
        st.pt = pt;
        st.time = ArsenalClient.seconds(pt);
        st.sinceShot = now - ArsenalClient.lastShot;
        st.sinceCycle = now - ArsenalClient.cycleStart;
        st.sinceReloadEnd = now - ArsenalClient.reloadEnded;
        st.reload = ArsenalData.reloadProgress(s, now);
        st.reloadKind = st.reload >= 0 ? ArsenalData.reloadKind(s) : 0;
        float ins = now - ArsenalClient.inspectStart;
        st.inspect = ins >= 0 && ins < inspectTicks(d) ? ins / inspectTicks(d) : -1;
        st.spin = Mth.lerp(pt, ArsenalClient.spinO, ArsenalClient.spin);
        st.charge = Mth.lerp(pt, ArsenalClient.chargeO, ArsenalClient.charge);
        st.firing = Mth.lerp(pt, ArsenalClient.firingO, ArsenalClient.firing);
        st.heat = d.usesHeat() ? ArsenalData.heat(s, (long) now, Math.max(0.004F, d.heatPerShot * 0.18F)) : 0;
        st.ammo = ArsenalData.ammo(s);
        st.mag = Math.max(1, ArsenalModule.mag(s, d));
        st.shots = ArsenalClient.shots;
        st.trigger = ArsenalClient.triggerHeld();
        drivers(st, d);
        return st;
    }

    /** State for weapons held by others, dropped or on display: idle motion only. */
    public static State still(ItemStack s, ArsenalDef d, float pt) {
        State st = new State();
        st.pt = pt;
        st.time = ArsenalClient.seconds(pt);
        st.ammo = ArsenalData.ammo(s);
        st.mag = Math.max(1, d.mag);
        st.heat = 0;
        drivers(st, d);
        return st;
    }

    public static float inspectTicks(ArsenalDef d) {
        return switch (d.cat) {
            case PISTOL, BUBBLE, CARDS -> 46.0F;
            case EXOTIC, FLAMER, STAFF, MORTAR -> 64.0F;
            default -> 56.0F;
        };
    }

    // ------------------------------------------------------------------ curves

    static float clamp01(float x) {
        return x < 0 ? 0 : x > 1 ? 1 : x;
    }

    static float smooth(float a, float b, float x) {
        float t = clamp01((x - a) / (b - a));
        return t * t * (3 - 2 * t);
    }

    /** 0 -> 1 -> 0 over [a, b] with soft edges of width e */
    static float window(float a, float b, float e, float x) {
        return smooth(a, a + e, x) * (1 - smooth(b - e, b, x));
    }

    /** Recoil impulse: snaps to 1 in half a tick, settles over {@code back} ticks. */
    static float kick(float t, float back) {
        if (t < 0) return 0;
        if (t < 0.5F) return t / 0.5F;
        float k = 1 - (t - 0.5F) / back;
        return k <= 0 ? 0 : k * k;
    }

    /** 0..1 progress of a manual cycle (pump), worked a moment after the shot. */
    static float cycle(State s, ArsenalDef d) {
        float len = Math.max(4, d.cycleTicks);
        float t = (s.sinceCycle - len * 0.15F) / (len * 0.7F);
        return t <= 0 || t >= 1 ? -1 : t;
    }

    static void drivers(State s, ArsenalDef d) {
        float[] v = s.drv;
        v[D_TIME] = (float) (s.time % 3600.0);
        v[D_FIRING] = s.firing;
        v[D_KICK] = s.local ? kick(s.sinceShot, Mth.clamp(d.cooldown() * 0.6F, 1.5F, 6.0F)) : 0;
        v[D_CHARGE] = s.charge;
        v[D_HEAT] = s.heat;
        v[D_RELOAD] = s.reload >= 0 ? window(0.06F, 0.9F, 0.2F, s.reload) : 0;
        v[D_SHOTS] = s.local ? s.shots - 1 + clamp01(s.sinceShot / 1.5F) : 0;
        v[D_SPINV] = s.spin;
        v[D_AMMO] = d.usesAmmo() ? Mth.clamp(s.ammo / (float) Math.max(1, s.mag), 0, 1) : 1;
        v[D_INSPECT] = s.inspect >= 0 ? window(0.08F, 0.92F, 0.15F, s.inspect) : 0;
        v[D_IDLE] = 1 - s.firing;
        v[D_RELOAD_RAW] = s.reload >= 0 ? s.reload : 0;
        float c = s.local ? cycle(s, d) : -1;
        float cyc = c < 0 ? 0 : Mth.sin(c * Mth.PI);
        if (s.local && s.reload < 0 && s.sinceReloadEnd < 10 && d.manual()) {
            cyc = Math.max(cyc, window(0.1F, 0.9F, 0.3F, s.sinceReloadEnd / 10.0F));
        }
        v[D_CYCLE] = cyc;
        v[D_ONE] = 1;
        // 1 while there is nothing loaded (the harpoon, shell, capsule or crescent on the weapon is gone)
        v[D_EMPTY] = d.usesAmmo() && s.ammo <= 0 ? 1 : 0;
        // the share of the load already used up (tanks and bottles modelled full drain with it)
        v[D_SPENT] = 1 - v[D_AMMO];
    }

    // ------------------------------------------------------------------ per-tick integration of spinning parts

    /** Advances the spin channels of the local weapon by one tick (degrees per second scaled by the driver). */
    public static void integrate(BwmModel model, State s) {
        Compiled c = compiled(model);
        for (Channel[] list : c.byPart) {
            for (Channel ch : list) {
                if (ch.kind != SPIN) continue;
                c.accO[ch.slot] = c.acc[ch.slot];
                float rate = ch.speed * (1 + ch.amount * s.drv[ch.driver]);
                c.acc[ch.slot] = (c.acc[ch.slot] + rate / 20.0F) % 360.0F;
                if (Math.abs(c.acc[ch.slot] - c.accO[ch.slot]) > 180.0F) c.accO[ch.slot] = c.acc[ch.slot] - rate / 20.0F;
            }
        }
    }

    // ------------------------------------------------------------------ parts

    /**
     * Applies the animation of one part (item pixels, about its pivot) to {@code m}.
     * Returns false when the part is hidden in this state.
     */
    public static boolean part(Matrix4f m, int index, BwmModel model, State s, ArsenalDef d) {
        BwmModel.Part p = model.parts.get(index);
        float px = p.px, py = p.py, pz = p.pz;
        if (p.name.equals("trigger")) {
            float pull = s.trigger ? 1 : clamp01(1 - s.sinceShot / 2.0F);
            rot(m, 0, px, py, pz, -14 * pull);
        }
        Compiled c = compiled(model);
        Channel[] list = c.byPart[index];
        for (Channel ch : list) {
            float dv = s.drv[ch.driver];
            switch (ch.kind) {
                case ROT -> rot(m, ch.axis, px, py, pz, ch.amount * dv);
                case MOVE -> move(m, ch.axis, ch.amount * dv);
                case SCALE -> {
                    float k = Math.max(0.0F, 1 + ch.amount * dv);
                    if (k < 0.02F) return false;
                    if (k != 1) m.translate(px, py, pz).scale(k).translate(-px, -py, -pz);
                }
                case OSC_ROT -> rot(m, ch.axis, px, py, pz, ch.amount * dv * osc(s.time, ch.speed, ch.phase));
                case OSC_MOVE -> move(m, ch.axis, ch.amount * dv * osc(s.time, ch.speed, ch.phase));
                case SPIN -> {
                    float a;
                    if (s.local && ch.slot < c.acc.length) a = lerpAngle(s.pt, c.accO[ch.slot], c.acc[ch.slot]);
                    else a = (float) ((s.time * ch.speed) % 360.0);
                    rot(m, ch.axis, px, py, pz, a);
                }
                case HIDE -> {
                    if (ch.amount * dv > 0.5F) return false;
                }
                default -> { }
            }
        }
        return true;
    }

    /** Emissive brightness of a part (0..1), or -1 when the part has no light channels of its own. */
    public static float partGlow(int index, BwmModel model, State s) {
        Compiled c = compiled(model);
        if (!c.lit[index]) return -1;
        float base = 0;
        float add = 0;
        for (Channel ch : c.byPart[index]) {
            float dv = s.drv[ch.driver];
            if (ch.kind == GLOW) {
                base = Math.max(base, ch.speed);
                add += ch.amount * dv;
            } else if (ch.kind == PULSE) {
                base = Math.max(base, ch.speed);
                add += ch.amount * dv * (0.5F + 0.5F * (float) Math.sin(((s.time * ch.phase) % (Math.PI * 2.0))));
            }
        }
        return clamp01(base + add);
    }

    static float osc(double time, float speed, float phase) {
        return (float) Math.sin((time * speed + phase) % (Math.PI * 2.0));
    }

    static float lerpAngle(float t, float a, float b) {
        float d = b - a;
        if (d > 180) d -= 360;
        if (d < -180) d += 360;
        return a + d * t;
    }

    static void rot(Matrix4f m, int axis, float px, float py, float pz, float deg) {
        if (deg == 0) return;
        float r = deg * Mth.DEG_TO_RAD;
        m.translate(px, py, pz);
        switch (axis) {
            case 0 -> m.rotateX(r);
            case 1 -> m.rotateY(r);
            default -> m.rotateZ(r);
        }
        m.translate(-px, -py, -pz);
    }

    static void move(Matrix4f m, int axis, float d) {
        if (d == 0) return;
        switch (axis) {
            case 0 -> m.translate(d, 0, 0);
            case 1 -> m.translate(0, d, 0);
            default -> m.translate(0, 0, d);
        }
    }

    /** Emissive brightness (0..1) of parts without channels of their own: charge, heat and shots light them up. */
    public static float glow(State s, ArsenalDef d) {
        float g = 0.7F + 0.3F * Math.max(s.charge, s.heat);
        if (s.sinceShot < 3) g = Math.min(1.0F, g + 0.3F * (1 - s.sinceShot / 3.0F));
        return Math.max(g, 0.7F + 0.3F * s.firing);
    }

    // ------------------------------------------------------------------ whole weapon

    /**
     * Reload gesture and inspect routine, applied in first-person hand space (origin = sight anchor, units = blocks).
     * side = +1 right hand, -1 left hand.
     */
    public static void gunMotion(Matrix4f m, State s, ArsenalDef d, int side) {
        if (s.reload >= 0) {
            float r = s.reload;
            boolean round = s.reloadKind == ArsenalData.REL_ROUND;
            float env = round ? 1.0F : window(0.0F, 1.0F, 0.14F, r);
            float rollZ, pitch, yaw = 0, dy, dx = 0, dz = 0;
            switch (d.mech) {
                case PISTOL -> { rollZ = -28; pitch = 14; dy = -0.035F; }
                case LAUNCHER -> { rollZ = -16; pitch = 20; yaw = 10; dy = -0.07F; }
                case PUMP -> { rollZ = round ? -58 : -30; pitch = round ? 12 : -4; dy = -0.06F; dx = -0.03F; }
                case ENERGY -> { rollZ = -20; pitch = 10; yaw = 16; dy = -0.05F; dz = 0.03F; }
                case HEAVY -> { rollZ = -12; pitch = -10; dy = -0.08F; dx = -0.05F; }
                // a new quiver: the bow drops low and turns flat
                case BOW -> { rollZ = -48; pitch = -14; yaw = -8; dy = -0.09F; dx = 0.02F; }
                // the staff is raised and the crystal recharged
                case STAFF -> { rollZ = 10; pitch = 34; yaw = 12; dy = 0.04F; dz = 0.05F; }
                default -> { rollZ = -32; pitch = -6; dy = -0.06F; dx = -0.03F; }
            }
            // a little bump when the new cell seats
            float seat = round ? 0 : window(0.6F, 0.72F, 0.05F, r);
            m.translate(dx * side * env, dy * env + seat * 0.012F, dz * env);
            m.rotateZ(rollZ * side * env * Mth.DEG_TO_RAD);
            m.rotateX((pitch * env + seat * 2.5F) * Mth.DEG_TO_RAD);
            m.rotateY(yaw * side * env * Mth.DEG_TO_RAD);
        } else if (s.sinceReloadEnd < 10 && d.manual()) {
            // racking the pump after loading
            float t = s.sinceReloadEnd / 10.0F;
            float env = window(0.0F, 1.0F, 0.3F, t);
            m.rotateZ(-14 * side * env * Mth.DEG_TO_RAD);
        }
        if (s.inspect >= 0) inspect(m, s, d, side);
    }

    /** Every category looks its weapon over in its own way. */
    private static void inspect(Matrix4f m, State s, ArsenalDef d, int side) {
        float t = s.inspect;
        float in = window(0.0F, 1.0F, 0.18F, t);
        switch (d.cat) {
            case PISTOL -> {
                // a gunslinger twirl around the trigger finger
                float spin = smooth(0.22F, 0.62F, t) * 360.0F;
                m.translate(-0.04F * side * in, 0.04F * in, 0.03F * in);
                m.translate(0, -0.05F, 0.12F);
                m.rotateX(-spin * Mth.DEG_TO_RAD);
                m.translate(0, 0.05F, -0.12F);
                m.rotateY(18 * side * window(0.62F, 0.95F, 0.12F, t) * Mth.DEG_TO_RAD);
            }
            case LAUNCHER -> {
                // hold the hive to the ear and give it a shake
                float shake = window(0.3F, 0.75F, 0.08F, t) * (float) Math.sin(s.time * 38.0) * 4.0F;
                m.translate(-0.07F * side * in, 0.05F * in, 0.08F * in);
                m.rotateY((40 * side * in) * Mth.DEG_TO_RAD);
                m.rotateZ((-14 * side * in + shake * side) * Mth.DEG_TO_RAD);
            }
            case SNIPER -> {
                // turn the crystal to the light
                float a = window(0.05F, 0.55F, 0.15F, t), b = window(0.45F, 0.95F, 0.15F, t);
                m.translate(-0.05F * side * a, 0.03F * (a + b), 0.06F * a);
                m.rotateY((52 * a - 20 * b) * side * Mth.DEG_TO_RAD);
                m.rotateX((14 * a - 6 * b) * Mth.DEG_TO_RAD);
                m.rotateZ((-20 * a + 48 * b) * side * Mth.DEG_TO_RAD);
            }
            case RIFLE -> {
                // admire the coils; the static makes your hand twitch
                float twitch = window(0.4F, 0.6F, 0.04F, t) * (float) Math.sin(s.time * 90.0) * 2.5F;
                m.translate(-0.06F * side * in, 0.03F * in, 0.05F * in);
                m.rotateY((46 * side * in + twitch) * Mth.DEG_TO_RAD);
                m.rotateZ((-24 * side * in) * Mth.DEG_TO_RAD);
            }
            case SHOTGUN -> {
                // toss it up, let it spin once, catch it
                float air = window(0.25F, 0.7F, 0.2F, t);
                float flip = smooth(0.28F, 0.66F, t) * 360.0F;
                m.translate(0, 0.12F * air, 0.02F * in);
                m.translate(0, 0, 0.1F);
                m.rotateZ(flip * side * Mth.DEG_TO_RAD);
                m.translate(0, 0, -0.1F);
                m.rotateY(20 * side * in * Mth.DEG_TO_RAD);
            }
            case EXOTIC -> {
                // bring the singularity close to the face and stare into it
                m.translate(-0.09F * side * in, 0.06F * in, 0.12F * in);
                m.rotateY((70 * side * in) * Mth.DEG_TO_RAD);
                m.rotateX((-10 * in + 3.0F * (float) Math.sin(s.time * 2.0) * in) * Mth.DEG_TO_RAD);
            }
            case FLAMER -> {
                // the dragon shakes its head
                float shake = window(0.35F, 0.8F, 0.1F, t) * (float) Math.sin(s.time * 14.0) * 9.0F;
                m.translate(-0.05F * side * in, 0.04F * in, 0.05F * in);
                m.rotateY((34 * side * in + shake * side) * Mth.DEG_TO_RAD);
                m.rotateX((8 * in) * Mth.DEG_TO_RAD);
            }
            case BEAM -> {
                // look through the prism
                float a = window(0.05F, 0.6F, 0.15F, t), b = window(0.5F, 0.95F, 0.12F, t);
                m.translate(-0.05F * side * a, 0.04F * (a + b), 0.04F * a);
                m.rotateY((60 * a) * side * Mth.DEG_TO_RAD);
                m.rotateZ((-30 * a + 40 * b) * side * Mth.DEG_TO_RAD);
            }
            case SONIC -> {
                // feel the bass: three thumps
                float thump = window(0.2F, 0.8F, 0.08F, t) * Math.max(0, (float) Math.sin(s.time * 16.0)) * 0.012F;
                m.translate(-0.05F * side * in, 0.02F * in, 0.05F * in + thump);
                m.rotateY((38 * side * in) * Mth.DEG_TO_RAD);
                m.rotateZ((-12 * side * in) * Mth.DEG_TO_RAD);
            }
            case MINIGUN -> {
                // heave it up and check the barrels
                m.translate(-0.03F * side * in, 0.05F * in, 0.04F * in);
                m.rotateX((-12 * in) * Mth.DEG_TO_RAD);
                m.rotateY((28 * side * in) * Mth.DEG_TO_RAD);
            }
            case BOOMERANG -> {
                // spin the launcher round on its grip like a yo-yo
                float spin = smooth(0.2F, 0.75F, t) * 720.0F;
                m.translate(-0.03F * side * in, 0.03F * in, 0.04F * in);
                m.rotateZ(spin * side * Mth.DEG_TO_RAD);
            }
            case HARPOON -> {
                // test the chain: a sharp tug
                float tug = window(0.4F, 0.62F, 0.05F, t);
                m.translate(-0.05F * side * in, 0.02F * in, 0.05F * in + tug * 0.05F);
                m.rotateY((36 * side * in) * Mth.DEG_TO_RAD);
                m.rotateX((-8 * tug) * Mth.DEG_TO_RAD);
            }
            case BUBBLE -> {
                // blow on the wand ring
                float a = window(0.1F, 0.9F, 0.2F, t);
                m.translate(-0.06F * side * a, 0.06F * a, 0.09F * a);
                m.rotateY((62 * side * a) * Mth.DEG_TO_RAD);
                m.rotateX((-14 * a + 3.0F * (float) Math.sin(s.time * 6.0) * a) * Mth.DEG_TO_RAD);
            }
            case CARDS -> {
                // a flourish: the deck flips over and back
                float flip = smooth(0.25F, 0.55F, t) * 180.0F - smooth(0.6F, 0.9F, t) * 180.0F;
                m.translate(-0.04F * side * in, 0.04F * in, 0.04F * in);
                m.rotateZ(flip * side * Mth.DEG_TO_RAD);
                m.rotateY((22 * side * in) * Mth.DEG_TO_RAD);
            }
            case STAFF -> {
                // lift the staff and let the crystal float
                m.translate(-0.02F * side * in, 0.08F * in, 0.02F * in);
                m.rotateX((26 * in) * Mth.DEG_TO_RAD);
                m.rotateY((float) (Math.sin(s.time * 2.5) * 10.0 * in) * side * Mth.DEG_TO_RAD);
            }
            case GOO -> {
                // shake the tank and watch it slosh
                float shake = window(0.25F, 0.8F, 0.1F, t) * (float) Math.sin(s.time * 22.0) * 6.0F;
                m.translate(-0.05F * side * in, 0.03F * in, 0.04F * in);
                m.rotateY((30 * side * in) * Mth.DEG_TO_RAD);
                m.rotateZ((shake * side) * Mth.DEG_TO_RAD);
            }
            case BOW -> {
                // hold the bow flat and sight along the arrow
                m.translate(-0.06F * side * in, 0.04F * in, 0.02F * in);
                m.rotateZ((-70 * side * in) * Mth.DEG_TO_RAD);
                m.rotateY((12 * side * in) * Mth.DEG_TO_RAD);
            }
            case MORTAR -> {
                // tip the tube up and peer down the muzzle
                m.translate(-0.03F * side * in, 0.06F * in, 0.05F * in);
                m.rotateX((44 * in) * Mth.DEG_TO_RAD);
                m.rotateY((18 * side * in) * Mth.DEG_TO_RAD);
            }
            case DEPLOYER -> {
                // check the capsule: tilt it toward you, then away
                float a = window(0.05F, 0.55F, 0.15F, t), b = window(0.45F, 0.95F, 0.15F, t);
                m.translate(-0.05F * side * a, 0.03F * (a + b), 0.05F * a);
                m.rotateY((50 * a - 16 * b) * side * Mth.DEG_TO_RAD);
                m.rotateX((-18 * a + 10 * b) * Mth.DEG_TO_RAD);
            }
            case DISC -> {
                // spin the blade up and listen to it
                m.translate(-0.06F * side * in, 0.04F * in, 0.06F * in);
                m.rotateY((48 * side * in) * Mth.DEG_TO_RAD);
                m.rotateZ((-20 * side * in) * Mth.DEG_TO_RAD);
            }
        }
    }
}
