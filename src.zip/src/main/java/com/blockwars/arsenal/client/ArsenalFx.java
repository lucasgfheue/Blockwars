package com.blockwars.arsenal.client;

import com.blockwars.BlockWars;
import com.blockwars.arsenal.ArsenalDef;
import com.blockwars.arsenal.ArsenalDef.Flash;
import com.blockwars.arsenal.ArsenalItem;
import com.blockwars.arsenal.ArsenalParticles;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Light effects drawn additively after the particles: each weapon's own muzzle flash (ion rings, hex burst, snowflake,
 * lightning, candy pop, implosion, dragon fire, prism flare, sound rings, plasma), the rainbow beam of «Prisma», chain
 * lightning, sonic wave fronts, fireballs and the collapse of a singularity. Server-sent effect particles land here too.
 */
public final class ArsenalFx {
    private ArsenalFx() {}

    private static ResourceLocation tex(String n) {
        return BlockWars.id("textures/arsenal/fx/" + n + ".png");
    }

    public static final ResourceLocation FLASH_STAR = tex("flash_star");
    public static final ResourceLocation FLASH_SIDE = tex("flash_side");
    public static final ResourceLocation GLOW = tex("glow");
    public static final ResourceLocation BEAM = tex("beam");
    public static final ResourceLocation ARC = tex("arc");
    public static final ResourceLocation RING = tex("ring");
    public static final ResourceLocation WAVE = tex("wave");
    public static final ResourceLocation BLAST = tex("blast");
    public static final ResourceLocation PLASMA = tex("plasma");
    public static final ResourceLocation HEX = tex("hex");
    public static final ResourceLocation SNOW = tex("snow");
    public static final ResourceLocation POP = tex("pop");
    public static final ResourceLocation SPIRAL = tex("spiral");
    public static final ResourceLocation FLARE = tex("flare");
    public static final ResourceLocation VOID = tex("void");
    public static final ResourceLocation CRESCENT = tex("crescent");
    public static final ResourceLocation BUBBLE = tex("bubble");
    public static final ResourceLocation SLIME = tex("slime");
    public static final ResourceLocation CHAIN = tex("chain");
    public static final ResourceLocation SIGIL = tex("sigil");
    public static final ResourceLocation SPLASH = tex("splash");
    public static final ResourceLocation SCAN = tex("scan");

    static final float TWO_PI = (float) (Math.PI * 2.0);
    static final float HALF_PI = (float) (Math.PI * 0.5);
    private static final int MAX = 700;
    private static final List<Fx> FX = new ArrayList<>();
    private static final RandomSource RND = RandomSource.create();

    abstract static class Fx {
        int age;
        int life;
        int delay;

        Fx(int life) {
            this.life = life;
        }

        boolean tick() {
            return ++this.age < this.life + this.delay;
        }

        boolean visible() {
            return this.age >= this.delay;
        }

        float t(float pt) {
            return Mth.clamp((this.age - this.delay + pt) / this.life, 0.0F, 1.0F);
        }

        abstract void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt);
    }

    static void add(Fx f) {
        if (FX.size() >= MAX) FX.remove(0);
        FX.add(f);
    }

    public static void tick() {
        Iterator<Fx> it = FX.iterator();
        while (it.hasNext()) {
            if (!it.next().tick()) it.remove();
        }
        liveBeamTick();
    }

    public static void clear() {
        FX.clear();
        liveDef = null;
    }

    public static void render(RenderLevelStageEvent e) {
        Camera cam = e.getCamera();
        Vec3 cp = cam.getPosition();
        Quaternionf rot = cam.rotation();
        float pt = e.getPartialTick().getGameTimeDeltaPartialTick(false);
        boolean live = liveDef != null;
        ArsenalDef mortar = mortarHeld();
        if (FX.isEmpty() && !live && mortar == null) return;
        MultiBufferSource.BufferSource bs = Minecraft.getInstance().renderBuffers().bufferSource();
        for (Fx f : FX) if (f.visible()) f.render(bs, cp, rot, pt);
        if (live) renderLiveBeam(bs, cp, rot, pt);
        if (mortar != null) renderMortarMarker(bs, cp, rot, pt, mortar);
        bs.endBatch();
    }

    // ================================================================== «Bombarda»: where the shell will land

    @Nullable
    private static ArsenalDef mortarHeld() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        ArsenalItem it = ArsenalClient.held(p);
        if (it == null || it.def.proj != ArsenalDef.Proj.MORTAR || mc.options.hideGui) return null;
        var s = p.getMainHandItem();
        if (com.blockwars.arsenal.ArsenalData.reloading(s) || com.blockwars.arsenal.ArsenalData.ammo(s) <= 0) return null;
        return it.def;
    }

    /** Follows the shell's flight (same physics as the server: drag 0.99, then gravity) to its first block. */
    @Nullable
    static Vec3 mortarLanding(LocalPlayer p, ArsenalDef d, float pt) {
        Vec3 eye = p.getEyePosition(pt);
        Vec3 pos = new Vec3(eye.x, eye.y - 0.1, eye.z);
        Vec3 look = p.getViewVector(pt);
        double h = Math.sqrt(look.x * look.x + look.z * look.z);
        if (h < 1.0E-4) return null;
        double pitch = Math.min(Math.toRadians(80.0), Math.atan2(look.y, h) + Math.toRadians(d.sp2));
        double k = Math.cos(pitch) / h;
        Vec3 v = new Vec3(look.x * k, Math.sin(pitch), look.z * k).scale(d.velocity);
        for (int i = 0; i < 240; i++) {
            Vec3 next = pos.add(v);
            var bh = p.level().clip(new net.minecraft.world.level.ClipContext(pos, next, net.minecraft.world.level.ClipContext.Block.COLLIDER,
                    net.minecraft.world.level.ClipContext.Fluid.NONE, p));
            if (bh.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) return bh.getLocation();
            pos = next;
            v = v.scale(0.99).add(0, -d.gravity, 0);
            if (pos.y < p.level().getMinBuildHeight() - 8) return null;
        }
        return null;
    }

    private static void renderMortarMarker(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt, ArsenalDef d) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        Vec3 at = mortarLanding(p, d, pt);
        if (at == null) return;
        double time = ArsenalClient.seconds(pt);
        Vector3f c = rel(at.add(0, 0.05, 0), cam);
        Vector3f up = new Vector3f(0, 1, 0);
        float pulse = 0.85F + 0.15F * (float) Math.sin(time * 6.0);
        facing(buf.getBuffer(RenderType.eyes(RING)), c, up, 2.4F * pulse, (float) (time * 0.8 % TWO_PI), argb(d.tracerColor, 0.65F));
        facing(buf.getBuffer(RenderType.eyes(GLOW)), c, up, 0.5F, 0, argb(0xFFD080, 0.6F));
    }

    // ================================================================== low level drawing

    /** additive vertex (eyes render type: position, colour, uv, overlay, light, normal) */
    static void v(VertexConsumer vc, Vector3f p, int argb, float u, float w) {
        vc.addVertex(p.x, p.y, p.z, argb, u, w, OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, 0.0F, 1.0F, 0.0F);
    }

    /** a quad visible from both sides */
    static void quad2(VertexConsumer vc, Vector3f a, Vector3f b, Vector3f c, Vector3f d, int argb, float u0, float v0, float u1, float v1) {
        v(vc, a, argb, u0, v1);
        v(vc, b, argb, u1, v1);
        v(vc, c, argb, u1, v0);
        v(vc, d, argb, u0, v0);
        v(vc, d, argb, u0, v0);
        v(vc, c, argb, u1, v0);
        v(vc, b, argb, u1, v1);
        v(vc, a, argb, u0, v1);
    }

    /** Colour scaled by an intensity (additive blending: brightness is the alpha). */
    static int argb(int rgb, float k) {
        k = Mth.clamp(k, 0.0F, 1.0F);
        int r = Math.round(((rgb >> 16) & 0xFF) * k), g = Math.round(((rgb >> 8) & 0xFF) * k), b = Math.round((rgb & 0xFF) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Hue (0..1, wraps) to a saturated rainbow colour. */
    static int hue(float h, float sat) {
        h = h - (float) Math.floor(h);
        float r = Mth.clamp(Math.abs(h * 6 - 3) - 1, 0, 1);
        float g = Mth.clamp(2 - Math.abs(h * 6 - 2), 0, 1);
        float b = Mth.clamp(2 - Math.abs(h * 6 - 4), 0, 1);
        r = 1 - sat + sat * r;
        g = 1 - sat + sat * g;
        b = 1 - sat + sat * b;
        return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
    }

    /** camera-facing billboard at camera-relative position p, half size s, rotated by roll */
    static void billboard(VertexConsumer vc, Quaternionf rot, Vector3f p, float s, float roll, int argb, float u0, float v0, float u1, float v1) {
        float c = Mth.cos(roll) * s, sn = Mth.sin(roll) * s;
        Vector3f[] corners = {new Vector3f(-c + sn, -sn - c, 0), new Vector3f(c + sn, sn - c, 0), new Vector3f(c - sn, sn + c, 0), new Vector3f(-c - sn, -sn + c, 0)};
        for (Vector3f q : corners) rot.transform(q).add(p);
        quad2(vc, corners[0], corners[1], corners[2], corners[3], argb, u0, v0, u1, v1);
    }

    static void billboard(VertexConsumer vc, Quaternionf rot, Vector3f p, float s, float roll, int argb) {
        billboard(vc, rot, p, s, roll, argb, 0, 0, 1, 1);
    }

    /** camera-facing ribbon from a to b (camera-relative), half width w */
    static void ribbon(VertexConsumer vc, Vector3f a, Vector3f b, float w, int argbA, int argbB, float u0, float u1) {
        Vector3f dir = new Vector3f(b).sub(a);
        Vector3f mid = new Vector3f(a).add(b).mul(0.5F);
        Vector3f side = new Vector3f(dir).cross(mid);
        if (side.lengthSquared() < 1.0E-10F) return;
        side.normalize().mul(w);
        Vector3f p0 = new Vector3f(a).add(side), p1 = new Vector3f(a).sub(side), p2 = new Vector3f(b).sub(side), p3 = new Vector3f(b).add(side);
        v(vc, p0, argbA, u0, 0);
        v(vc, p1, argbA, u0, 1);
        v(vc, p2, argbB, u1, 1);
        v(vc, p3, argbB, u1, 0);
        v(vc, p3, argbB, u1, 0);
        v(vc, p2, argbB, u1, 1);
        v(vc, p1, argbA, u0, 1);
        v(vc, p0, argbA, u0, 0);
    }

    /** A quad facing along {@code n} (a disc across a direction), at camera-relative p, half size s, rolled. */
    static void facing(VertexConsumer vc, Vector3f p, Vector3f n, float s, float roll, int argb) {
        Vector3f nn = new Vector3f(n).normalize();
        Vector3f up = Math.abs(nn.y) > 0.9F ? new Vector3f(1, 0, 0) : new Vector3f(0, 1, 0);
        Vector3f s1 = new Vector3f(nn).cross(up).normalize();
        Vector3f s2 = new Vector3f(nn).cross(s1).normalize();
        float c = Mth.cos(roll), sn = Mth.sin(roll);
        Vector3f a1 = new Vector3f(s1).mul(c).add(new Vector3f(s2).mul(sn)).mul(s);
        Vector3f a2 = new Vector3f(s2).mul(c).sub(new Vector3f(s1).mul(sn)).mul(s);
        quad2(vc, new Vector3f(p).sub(a1).sub(a2), new Vector3f(p).add(a1).sub(a2), new Vector3f(p).add(a1).add(a2), new Vector3f(p).sub(a1).add(a2),
                argb, 0, 0, 1, 1);
    }

    static Vector3f rel(Vec3 p, Vec3 cam) {
        return new Vector3f((float) (p.x - cam.x), (float) (p.y - cam.y), (float) (p.z - cam.z));
    }

    // ------------------------------------------------------------------ helpers in a muzzle frame (item pixels, -Z out of the barrel)

    /** A disc across the bore at depth z. */
    private static void disc(VertexConsumer vc, Matrix4f m, float r, float z, float roll, int argb) {
        float c = Mth.cos(roll) * r, s = Mth.sin(roll) * r;
        quad2(vc, m.transformPosition(new Vector3f(-c + s, -s - c, z)), m.transformPosition(new Vector3f(c + s, s - c, z)),
                m.transformPosition(new Vector3f(c - s, s + c, z)), m.transformPosition(new Vector3f(-c - s, -s + c, z)), argb, 0, 0, 1, 1);
    }

    /** A flame tongue in a plane through the bore axis, rolled by {@code roll}, from z0 forward over length L. */
    private static void petal(VertexConsumer vc, Matrix4f m, float roll, float w, float len, float z0, int argb) {
        Matrix4f pm = new Matrix4f(m).rotateZ(roll);
        quad2(vc, pm.transformPosition(new Vector3f(-w, 0, z0)), pm.transformPosition(new Vector3f(w, 0, z0)),
                pm.transformPosition(new Vector3f(w, 0, z0 - len)), pm.transformPosition(new Vector3f(-w, 0, z0 - len)), argb, 0, 0, 1, 1);
    }

    /** A spike in the plane across the bore, pointing outward at angle a. */
    private static void spike(VertexConsumer vc, Matrix4f m, float a, float w, float len, float z, int argb) {
        float cx = Mth.cos(a), cy = Mth.sin(a);
        float px = -cy * w, py = cx * w;
        quad2(vc, m.transformPosition(new Vector3f(px, py, z)), m.transformPosition(new Vector3f(-px, -py, z)),
                m.transformPosition(new Vector3f(cx * len - px, cy * len - py, z)), m.transformPosition(new Vector3f(cx * len + px, cy * len + py, z)),
                argb, 1, 0, 0, 1);
    }

    // ================================================================== muzzle flashes (shared by the item renderer and the world flash)

    /** How long the flash of each style lasts, in ticks. */
    public static float flashDuration(ArsenalDef d) {
        return switch (d.flash) {
            case RINGS, SHOCK -> 3.5F;
            case IMPLODE, ARCANE -> 5.0F;
            case FROST, CONFETTI, SPLASH, BUBBLES, CARDS, SLIME, DEPLOY -> 2.5F;
            case DRAGON, PLASMA, SPARKS -> 1.6F;
            case MORTAR, CRESCENT, DAWN -> 3.0F;
            default -> 2.0F;
        };
    }

    /**
     * Draws the muzzle flash of a weapon at {@code at} (origin = muzzle, -Z = out of the barrel, units = item pixels).
     * {@code k} = 1 at the shot fading to 0; {@code seed} varies it shot to shot; {@code time} in seconds animates it.
     */
    public static void drawFlash(MultiBufferSource buf, Matrix4f at, ArsenalDef d, float k, int seed, float scale, double time) {
        if (k <= 0.01F || d.flash == Flash.NONE) return;
        RandomSource r = RandomSource.create(seed * 7919L + d.index * 31L);
        float fs = d.flashSize * scale * (0.9F + r.nextFloat() * 0.2F);
        float p = 1.0F - k;
        float roll = r.nextFloat() * TWO_PI;
        int col = d.flashColor;
        switch (d.flash) {
            case RINGS -> {
                VertexConsumer star = buf.getBuffer(RenderType.eyes(FLASH_STAR));
                disc(star, at, 2.0F * fs, -0.3F, roll, argb(col, k));
                disc(star, at, 0.8F * fs, -0.2F, -roll, argb(0xFFFFFF, k));
                VertexConsumer ring = buf.getBuffer(RenderType.eyes(RING));
                for (int i = 0; i < 3; i++) {
                    float z = -(1.0F + i * 1.7F + p * (3.0F + i * 2.2F)) * fs;
                    float rr = (1.2F + i * 0.55F) * fs * (0.7F + 0.6F * p);
                    int c = i == 1 ? 0xFF4A6A : col;
                    disc(ring, at, rr, z, roll + i, argb(c, k * (1.0F - i * 0.12F)));
                }
            }
            case HIVE -> {
                VertexConsumer hex = buf.getBuffer(RenderType.eyes(HEX));
                float hr = (2.2F + 1.2F * p) * fs;
                disc(hex, at, hr, -0.4F, (seed % 6) * (TWO_PI / 6) + 0.2618F, argb(col, k));
                disc(hex, at, hr * 0.55F, -0.6F, 0.2618F, argb(0xFFE890, k * 0.8F));
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                for (int j = 0; j < 6; j++) {
                    spike(side, at, j * (TWO_PI / 6) + 0.2618F, 0.45F * fs, (2.6F + r.nextFloat()) * fs * (0.8F + 0.4F * p), -0.5F, argb(col, k * 0.8F));
                }
                petal(side, at, roll, 1.2F * fs, 3.4F * fs, 0.0F, argb(col, k * 0.9F));
                petal(side, at, roll + HALF_PI, 1.2F * fs, 3.0F * fs, 0.0F, argb(col, k * 0.9F));
            }
            case FROST -> {
                VertexConsumer snow = buf.getBuffer(RenderType.eyes(SNOW));
                disc(snow, at, 3.0F * fs * (0.8F + 0.5F * p), -0.4F, roll, argb(col, k));
                disc(snow, at, 1.6F * fs, -0.5F, roll + 0.5236F, argb(0xFFFFFF, k * 0.8F));
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                for (int j = 0; j < 3; j++) petal(side, at, roll + j * (TWO_PI / 3), 0.45F * fs, (6.0F + r.nextFloat() * 2.0F) * fs, 0.0F, argb(0xDFF8FF, k));
                VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
                disc(g, at, 2.4F * fs, -0.2F, 0, argb(col, k * 0.6F));
            }
            case ELECTRIC -> {
                VertexConsumer star = buf.getBuffer(RenderType.eyes(FLASH_STAR));
                disc(star, at, 1.7F * fs, -0.3F, roll, argb(col, k));
                disc(star, at, 0.7F * fs, -0.2F, -roll, argb(0xFFFFFF, k));
                VertexConsumer arc = buf.getBuffer(RenderType.eyes(ARC));
                RandomSource fr = RandomSource.create(seed * 131L + (long) (time * 40.0));
                for (int b = 0; b < 5; b++) {
                    Vector3f dir = new Vector3f(fr.nextFloat() - 0.5F, fr.nextFloat() - 0.5F, -0.6F - fr.nextFloat()).normalize();
                    Vector3f prev = new Vector3f(0, 0, -0.2F);
                    for (int s = 0; s < 4; s++) {
                        Vector3f next = new Vector3f(prev).add(new Vector3f(dir).mul(1.3F * fs))
                                .add((fr.nextFloat() - 0.5F) * fs, (fr.nextFloat() - 0.5F) * fs, (fr.nextFloat() - 0.5F) * 0.5F * fs);
                        Vector3f a = at.transformPosition(new Vector3f(prev)), c = at.transformPosition(new Vector3f(next));
                        ribbon(arc, a, c, 0.35F * fs * pxScale(at), argb(col, k * 0.9F), argb(col, k * 0.6F), 0, 1);
                        ribbon(arc, a, c, 0.12F * fs * pxScale(at), argb(0xFFFFFF, k), argb(0xFFFFFF, k * 0.7F), 0, 1);
                        prev = next;
                    }
                }
            }
            case CONFETTI -> {
                VertexConsumer pop = buf.getBuffer(RenderType.eyes(POP));
                disc(pop, at, (2.4F + 1.4F * p) * fs, -0.4F, roll, argb(col, k));
                disc(pop, at, 1.0F * fs, -0.5F, -roll, argb(0xFFFFFF, k * 0.8F));
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                int[] candy = {0xFF7AC8, 0x7AFFD0, 0xFFE070, 0x8AC8FF};
                for (int j = 0; j < 4; j++) petal(side, at, roll + j * HALF_PI, 1.6F * fs, (3.2F + r.nextFloat()) * fs, 0.0F, argb(candy[j], k));
            }
            case IMPLODE -> {
                // a ring that falls inward instead of out
                VertexConsumer ring = buf.getBuffer(RenderType.eyes(RING));
                disc(ring, at, (1.0F + 4.5F * k) * fs, -1.0F, roll, argb(col, Math.min(1.0F, k * 1.4F)));
                disc(ring, at, (0.6F + 2.5F * k) * fs, -1.5F, -roll, argb(0xE0C8FF, k * 0.7F));
                VertexConsumer sp = buf.getBuffer(RenderType.eyes(SPIRAL));
                disc(sp, at, 2.6F * fs * (0.5F + 0.5F * k), -0.8F, (float) (time * 9.0 % TWO_PI), argb(col, k));
                VertexConsumer star = buf.getBuffer(RenderType.eyes(FLASH_STAR));
                disc(star, at, 1.2F * fs * p, -0.6F, roll, argb(0xFFFFFF, k * 0.6F));
            }
            case DRAGON -> {
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                for (int j = 0; j < 4; j++) {
                    float len = (4.0F + r.nextFloat() * 2.5F) * fs;
                    petal(side, at, roll + j * (Mth.PI / 4) + r.nextFloat() * 0.4F, 2.0F * fs, len, 0.3F, argb(j % 2 == 0 ? col : 0xFFD050, k));
                }
                VertexConsumer star = buf.getBuffer(RenderType.eyes(FLASH_STAR));
                disc(star, at, 2.0F * fs, -0.3F, roll, argb(col, k));
                disc(star, at, 0.9F * fs, -0.2F, -roll, argb(0xFFF0C0, k));
            }
            case PRISM -> {
                VertexConsumer fl = buf.getBuffer(RenderType.eyes(FLARE));
                disc(fl, at, 2.2F * fs, -0.2F, roll, argb(0xFFFFFF, k));
                for (int i = 1; i <= 6; i++) {
                    disc(fl, at, (0.35F + 0.12F * (i % 3)) * fs, -i * 0.9F * fs, roll, argb(hue(i / 6.0F + (float) time * 0.3F, 0.85F), k * 0.8F));
                }
                VertexConsumer ring = buf.getBuffer(RenderType.eyes(RING));
                disc(ring, at, (2.0F + 1.2F * p) * fs, -0.6F, roll, argb(hue((float) time * 0.5F, 0.9F), k));
            }
            case SHOCK -> {
                VertexConsumer w = buf.getBuffer(RenderType.eyes(WAVE));
                for (int i = 0; i < 3; i++) {
                    float pp = Mth.clamp(p * 1.3F - i * 0.15F, 0, 1);
                    float rr = (1.2F + pp * (5.0F + i * 2.5F)) * fs;
                    float z = -(0.5F + pp * (2.0F + i * 2.0F)) * fs;
                    disc(w, at, rr, z, roll + i, argb(col, k * (1 - pp * 0.5F)));
                }
                VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
                disc(g, at, 3.0F * fs, -0.3F, 0, argb(col, k * 0.4F));
            }
            case PLASMA -> {
                VertexConsumer pl = buf.getBuffer(RenderType.eyes(PLASMA));
                disc(pl, at, 2.4F * fs, -0.3F, roll, argb(col, k));
                disc(pl, at, 0.9F * fs, -0.2F, -roll, argb(0xEFFFF0, k));
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                petal(side, at, roll, 1.3F * fs, 3.6F * fs, 0.0F, argb(col, k));
                petal(side, at, roll + HALF_PI, 1.3F * fs, 3.2F * fs, 0.0F, argb(col, k));
            }
            case CRESCENT -> {
                // a golden crescent swept across the launcher as the blade leaves
                VertexConsumer cr = buf.getBuffer(RenderType.eyes(CRESCENT));
                float sweep = roll + p * 2.4F;
                disc(cr, at, (2.6F + 1.6F * p) * fs, -0.6F - p * 2.0F * fs, sweep, argb(col, k));
                disc(cr, at, (1.6F + 1.0F * p) * fs, -0.4F, sweep + Mth.PI, argb(0xFFF4D0, k * 0.7F));
                VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
                disc(g, at, 1.8F * fs, -0.3F, 0, argb(col, k * 0.5F));
            }
            case SPLASH -> {
                // a burst of sea water around the harpoon
                VertexConsumer sp = buf.getBuffer(RenderType.eyes(SPLASH));
                disc(sp, at, (2.0F + 2.2F * p) * fs, -0.5F - p * 1.5F * fs, roll, argb(col, k));
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                for (int j = 0; j < 5; j++) {
                    petal(side, at, roll + j * (TWO_PI / 5), 0.5F * fs, (3.0F + r.nextFloat() * 2.0F) * fs * (0.7F + 0.5F * p), 0.0F, argb(0xD8F4FF, k * 0.8F));
                }
            }
            case BUBBLES -> {
                VertexConsumer b = buf.getBuffer(RenderType.eyes(BUBBLE));
                for (int j = 0; j < 4; j++) {
                    float z = -(0.6F + j * 1.1F + p * (1.0F + j)) * fs;
                    float rr = (0.6F + 0.25F * r.nextFloat() + 0.3F * p) * fs;
                    Matrix4f mm = new Matrix4f(at).translate((r.nextFloat() - 0.5F) * 1.6F * fs, (r.nextFloat() - 0.5F) * 1.6F * fs, 0);
                    disc(b, mm, rr, z, roll + j, argb(hue(j * 0.2F + (float) time * 0.2F, 0.35F), k));
                }
            }
            case CARDS -> {
                // a fan of white flashes with red and black tips
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                for (int j = -2; j <= 2; j++) {
                    petal(side, at, HALF_PI + j * 0.32F, 0.5F * fs, (2.8F + 0.4F * Math.abs(j)) * fs * (0.8F + 0.4F * p), 0.0F,
                            argb(j % 2 == 0 ? 0xFFFFFF : 0xFF3A40, k));
                }
                VertexConsumer pop = buf.getBuffer(RenderType.eyes(POP));
                disc(pop, at, 1.4F * fs, -0.3F, roll, argb(0xFFFFFF, k * 0.8F));
            }
            case ARCANE -> {
                // a turning magic circle in front of the crystal
                VertexConsumer sg = buf.getBuffer(RenderType.eyes(SIGIL));
                disc(sg, at, (2.4F + 1.0F * p) * fs, -0.8F, (float) (time * 2.0 % TWO_PI), argb(col, k));
                disc(sg, at, 1.4F * fs, -1.4F, (float) (-time * 3.0 % TWO_PI), argb(0xFFD8A0, k * 0.7F));
                VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
                disc(g, at, 2.0F * fs, -0.4F, 0, argb(col, k * 0.6F));
            }
            case SLIME -> {
                VertexConsumer sl = buf.getBuffer(RenderType.eyes(SLIME));
                disc(sl, at, (1.6F + 1.4F * p) * fs, -0.5F, roll, argb(col, k));
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                for (int j = 0; j < 3; j++) petal(side, at, roll + j * (TWO_PI / 3), 0.6F * fs, (2.4F + r.nextFloat()) * fs, 0.0F, argb(col, k * 0.8F));
            }
            case DAWN -> {
                // the arrow leaves a star of dawn light
                VertexConsumer fl = buf.getBuffer(RenderType.eyes(FLARE));
                disc(fl, at, (2.0F + 1.5F * p) * fs, -0.3F, roll, argb(0xFFFFFF, k));
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                for (int j = 0; j < 8; j++) {
                    spike(side, at, j * (TWO_PI / 8) + roll * 0.2F, 0.18F * fs, (3.2F + (j % 2) * 1.6F) * fs * (0.7F + 0.6F * p), -0.4F,
                            argb(j % 2 == 0 ? col : 0xFFB0D8, k));
                }
            }
            case MORTAR -> {
                // a heavy blast out of the tube and a ring of dust
                VertexConsumer star = buf.getBuffer(RenderType.eyes(FLASH_STAR));
                disc(star, at, 2.8F * fs, -0.4F, roll, argb(col, k));
                disc(star, at, 1.2F * fs, -0.3F, -roll, argb(0xFFF0C0, k));
                VertexConsumer ring = buf.getBuffer(RenderType.eyes(RING));
                disc(ring, at, (1.5F + 4.5F * p) * fs, -0.2F, roll, argb(0xC8B898, k * 0.7F));
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                petal(side, at, roll, 1.8F * fs, 5.0F * fs, 0.2F, argb(col, k));
                petal(side, at, roll + HALF_PI, 1.8F * fs, 4.5F * fs, 0.2F, argb(col, k));
            }
            case DEPLOY -> {
                // a holographic launch ring
                VertexConsumer sc = buf.getBuffer(RenderType.eyes(SCAN));
                disc(sc, at, (1.6F + 1.8F * p) * fs, -0.6F - p * 2.0F * fs, roll, argb(col, k));
                VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
                disc(g, at, 1.6F * fs, -0.3F, 0, argb(col, k * 0.6F));
            }
            case SPARKS -> {
                // the blade throws a spray of hot sparks off the guard
                VertexConsumer star = buf.getBuffer(RenderType.eyes(FLASH_STAR));
                disc(star, at, 1.2F * fs, -0.3F, roll, argb(col, k));
                VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
                for (int j = 0; j < 7; j++) {
                    spike(side, at, (r.nextFloat() - 0.5F) * 2.2F + Mth.PI * 1.5F, 0.08F * fs, (2.0F + r.nextFloat() * 3.0F) * fs, -0.3F - r.nextFloat() * fs,
                            argb(j % 2 == 0 ? col : 0xFFFFFF, k));
                }
            }
            default -> { }
        }
    }

    /** Output units per item pixel of a muzzle frame: ribbons need their widths in output units. */
    private static float pxScale(Matrix4f m) {
        return new Vector3f(m.m00(), m.m01(), m.m02()).length();
    }

    /** Charging glow at the muzzle: a growing snowflake for the ice rifle, an inward vortex for the singularity. */
    public static void drawCharge(MultiBufferSource buf, Matrix4f at, ArsenalDef d, float c, double time) {
        if (c <= 0.01F) return;
        float fs = d.flashSize;
        if (d.flash == Flash.IMPLODE) {
            VertexConsumer sp = buf.getBuffer(RenderType.eyes(SPIRAL));
            disc(sp, at, (1.0F + 2.6F * c) * fs, -0.6F, (float) (time * (4.0 + 10.0 * c) % TWO_PI), argb(d.flashColor, 0.4F + 0.6F * c));
            VertexConsumer ring = buf.getBuffer(RenderType.eyes(RING));
            float pulse = (float) ((time * 3.0) % 1.0);
            disc(ring, at, (4.0F - 3.0F * pulse) * fs * c, -0.8F, 0, argb(0xC8A0FF, c * pulse));
        } else if (d.flash == Flash.DAWN) {
            // light gathers on the arrowhead as the string is drawn
            VertexConsumer fl = buf.getBuffer(RenderType.eyes(FLARE));
            disc(fl, at, (0.6F + 2.0F * c) * fs, -0.3F, (float) (time * 1.2 % TWO_PI), argb(d.flashColor, 0.3F + 0.7F * c));
            VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
            disc(g, at, (0.8F + 2.2F * c) * fs, -0.2F, 0, argb(0xFFB0D8, 0.2F + 0.5F * c * c));
        } else {
            VertexConsumer snow = buf.getBuffer(RenderType.eyes(SNOW));
            disc(snow, at, (0.8F + 2.2F * c) * fs, -0.4F, (float) (time * 1.5 % TWO_PI), argb(d.flashColor, 0.3F + 0.7F * c));
            VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
            disc(g, at, (1.0F + 2.5F * c) * fs, -0.2F, 0, argb(d.flashColor, 0.25F + 0.5F * c * c));
        }
    }

    /** The dragon's breath right at the jaws while «Fénix» fires (first person and third person). */
    public static void drawBreath(MultiBufferSource buf, Matrix4f at, ArsenalDef d, float k, double time) {
        if (k <= 0.01F) return;
        VertexConsumer side = buf.getBuffer(RenderType.eyes(FLASH_SIDE));
        RandomSource r = RandomSource.create((long) (time * 30.0));
        for (int j = 0; j < 5; j++) {
            float len = (7.0F + r.nextFloat() * 5.0F);
            float roll = j * (Mth.PI / 5) + r.nextFloat() * 0.5F;
            petal(side, at, roll, 1.6F + r.nextFloat() * 0.8F, len, 0.4F, argb(j % 2 == 0 ? d.flashColor : 0xFFD060, k * (0.7F + 0.3F * r.nextFloat())));
        }
        VertexConsumer core = buf.getBuffer(RenderType.eyes(GLOW));
        disc(core, at, 2.4F, -0.5F, 0, argb(0xFFE0A0, k * 0.9F));
    }

    // ================================================================== effect kinds

    static final class FlashFx extends Fx {
        final Vec3 pos;
        final Vec3 dir;
        final ArsenalDef d;
        final float size;
        final int seed;

        FlashFx(Vec3 pos, Vec3 dir, ArsenalDef d, float size, int seed) {
            super(Math.max(2, (int) Math.ceil(flashDuration(d))));
            this.pos = pos;
            this.dir = dir.normalize();
            this.d = d;
            this.size = size;
            this.seed = seed;
        }

        @Override
        void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
            float k = 1.0F - this.t(pt);
            Vector3f p = rel(this.pos, cam);
            // orientation: -Z along dir
            float yaw = (float) Math.atan2(-this.dir.x, -this.dir.z);
            float pitch = (float) Math.asin(Mth.clamp(this.dir.y, -1, 1));
            Matrix4f m = new Matrix4f().translate(p).rotateY(yaw).rotateX(pitch).scale(this.size / 16.0F);
            drawFlash(buf, m, this.d, k, this.seed, 1.0F, ArsenalClient.seconds(pt));
            VertexConsumer vc = buf.getBuffer(RenderType.eyes(GLOW));
            billboard(vc, rot, p, 0.5F * this.size * k, 0, argb(this.d.flashColor, 0.3F * k));
        }
    }

    static final class GlowFx extends Fx {
        final Vec3 pos;
        final float size;
        final int rgb;
        final float intensity;

        GlowFx(Vec3 pos, float size, int rgb, int life, float intensity) {
            super(life);
            this.pos = pos;
            this.size = size;
            this.rgb = rgb;
            this.intensity = intensity;
        }

        @Override
        void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
            float k = 1.0F - this.t(pt);
            VertexConsumer vc = buf.getBuffer(RenderType.eyes(GLOW));
            billboard(vc, rot, rel(this.pos, cam), this.size * (0.7F + 0.3F * k), 0, argb(this.rgb, this.intensity * k));
        }
    }

    /** A beam from a to b in the weapon's style: «Prisma» splits into a turning rainbow. */
    static final class BeamFx extends Fx {
        final Vec3 a;
        final Vec3 b;
        final ArsenalDef d;

        BeamFx(Vec3 a, Vec3 b, ArsenalDef d, int life) {
            super(life);
            this.a = a;
            this.b = b;
            this.d = d;
        }

        @Override
        void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
            float k = 1.0F - this.t(pt) * this.t(pt);
            drawBeam(buf, rot, rel(this.a, cam), rel(this.b, cam), this.d, k, ArsenalClient.seconds(pt));
        }
    }

    static void drawBeam(MultiBufferSource buf, Quaternionf rot, Vector3f pa, Vector3f pb, ArsenalDef d, float k, double time) {
        float len = pa.distance(pb);
        if (len < 1.0E-3F) return;
        float w = 0.03F * Math.max(0.4F, d.tracerWidth);
        VertexConsumer vc = buf.getBuffer(RenderType.eyes(BEAM));
        if (d.flash == Flash.PRISM) {
            // rainbow sheath in coloured segments flowing outward
            int n = Math.min(160, Math.max(4, (int) (len * 2.0F)));
            Vector3f prev = new Vector3f(pa);
            float flicker = 0.9F + 0.1F * (float) Math.sin(time * 61.0);
            for (int i = 1; i <= n; i++) {
                float f0 = (i - 1) / (float) n, f1 = i / (float) n;
                Vector3f next = new Vector3f(pa).lerp(pb, f1);
                int c0 = hue(f0 * len * 0.08F - (float) time * 1.2F, 0.9F), c1 = hue(f1 * len * 0.08F - (float) time * 1.2F, 0.9F);
                ribbon(vc, prev, next, w * 3.2F * flicker, argb(c0, 0.75F * k), argb(c1, 0.75F * k), 0, 1);
                prev = next;
            }
            ribbon(vc, pa, pb, w * 0.9F, argb(0xFFFFFF, k), argb(0xFFFFFF, 0.9F * k), 0, len * 0.5F);
            // a helix of sparkles winding around it
            Vector3f dir = new Vector3f(pb).sub(pa);
            Vector3f fwd = new Vector3f(dir).normalize();
            Vector3f up = Math.abs(fwd.y) > 0.9F ? new Vector3f(1, 0, 0) : new Vector3f(0, 1, 0);
            Vector3f s1 = new Vector3f(fwd).cross(up).normalize();
            Vector3f s2 = new Vector3f(fwd).cross(s1).normalize();
            VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
            int sp = Math.min(220, (int) (len * 5));
            for (int i = 0; i < sp; i++) {
                float f = i / (float) sp;
                float ang = f * len * 2.4F - (float) (time * 8.0 % TWO_PI);
                float rad = 0.07F + 0.02F * Mth.sin(f * 40.0F);
                Vector3f p = new Vector3f(pa).add(new Vector3f(dir).mul(f)).add(new Vector3f(s1).mul(Mth.cos(ang) * rad)).add(new Vector3f(s2).mul(Mth.sin(ang) * rad));
                billboard(g, rot, p, 0.03F, 0, argb(hue(f * 3.0F + (float) time, 0.7F), 0.8F * k));
            }
            billboard(g, rot, pb, 0.35F, 0, argb(0xFFFFFF, 0.9F * k));
            billboard(g, rot, pb, 0.7F, 0, argb(hue((float) time * 0.7F, 0.8F), 0.5F * k));
            billboard(g, rot, pa, 0.2F, 0, argb(0xFFFFFF, 0.7F * k));
            return;
        }
        if (d.flash == Flash.DEPLOY) {
            // the turret's bolts: short, sharp and quick
            float f0 = Math.max(0.0F, 1.0F - k * 1.4F);
            Vector3f a = new Vector3f(pa).lerp(pb, f0), b = new Vector3f(pa).lerp(pb, Math.min(1.0F, f0 + 0.35F));
            ribbon(vc, a, b, w * 2.0F, argb(d.tracerColor, 0.8F * k), argb(d.tracerColor, 0.8F * k), 0, 1);
            ribbon(vc, a, b, w * 0.6F, argb(0xFFFFFF, k), argb(0xFFFFFF, k), 0, 1);
            VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
            billboard(g, rot, pa, w * 6, 0, argb(d.tracerColor, 0.9F * k));
            billboard(g, rot, pb, w * 5, 0, argb(0xFFFFFF, 0.6F * k));
            return;
        }
        ribbon(vc, pa, pb, w * 2.6F, argb(d.tracerColor, 0.55F * k), argb(d.tracerColor, 0.45F * k), 0, len * 0.5F);
        ribbon(vc, pa, pb, w * 0.7F, argb(0xFFFFFF, 0.9F * k), argb(0xFFFFFF, 0.8F * k), 0, len * 0.5F);
        VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
        billboard(g, rot, pb, w * 9, 0, argb(d.tracerColor, 0.8F * k));
        billboard(g, rot, pa, w * 6, 0, argb(d.tracerColor, 0.6F * k));
    }

    /** Electric arc: a jagged path re-rolled every tick, with forks and a hot white core. */
    static final class ArcFx extends Fx {
        final Vec3 a;
        final Vec3 b;
        final int rgb;
        final List<Vector3f[]> segs = new ArrayList<>();

        ArcFx(Vec3 a, Vec3 b, int rgb, int life) {
            super(life);
            this.a = a;
            this.b = b;
            this.rgb = rgb;
            this.reroll();
        }

        void reroll() {
            this.segs.clear();
            Vec3 d = this.b.subtract(this.a);
            double len = d.length();
            int n = Math.max(5, (int) (len * 3.0));
            Vector3f prev = new Vector3f(0, 0, 0);
            float jit = (float) Math.min(0.7, 0.14 + len * 0.035);
            for (int i = 1; i <= n; i++) {
                float f = i / (float) n;
                Vector3f p = new Vector3f((float) (d.x * f), (float) (d.y * f), (float) (d.z * f));
                if (i < n) {
                    float env = Mth.sin(f * Mth.PI);
                    p.add((RND.nextFloat() - 0.5F) * jit * env, (RND.nextFloat() - 0.5F) * jit * env, (RND.nextFloat() - 0.5F) * jit * env);
                }
                this.segs.add(new Vector3f[] {prev, p});
                if (RND.nextInt(4) == 0 && i < n) {
                    // a fork that dies out
                    Vector3f q = new Vector3f(p);
                    for (int k = 0; k < 2 + RND.nextInt(2); k++) {
                        Vector3f r = new Vector3f(q).add((RND.nextFloat() - 0.5F) * jit * 2.4F, (RND.nextFloat() - 0.5F) * jit * 2.4F, (RND.nextFloat() - 0.5F) * jit * 2.4F);
                        this.segs.add(new Vector3f[] {q, r, null});
                        q = r;
                    }
                }
                prev = p;
            }
        }

        @Override
        boolean tick() {
            if (this.age % 2 == 0) this.reroll();
            return super.tick();
        }

        @Override
        void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
            float k = 1.0F - this.t(pt) * 0.75F;
            Vector3f base = rel(this.a, cam);
            VertexConsumer vc = buf.getBuffer(RenderType.eyes(ARC));
            for (Vector3f[] s : this.segs) {
                boolean fork = s.length > 2;
                Vector3f p0 = new Vector3f(s[0]).add(base), p1 = new Vector3f(s[1]).add(base);
                float w = fork ? 0.045F : 0.085F;
                ribbon(vc, p0, p1, w, argb(this.rgb, 0.75F * k), argb(this.rgb, (fork ? 0.4F : 0.75F) * k), 0, 1);
                ribbon(vc, p0, p1, w * 0.3F, argb(0xFFFFFF, k), argb(0xFFFFFF, (fork ? 0.5F : 1.0F) * k), 0, 1);
            }
            VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
            billboard(g, rot, rel(this.b, cam), 0.6F, 0, argb(this.rgb, 0.8F * k));
            billboard(g, rot, rel(this.b, cam), 0.22F, 0, argb(0xFFFFFF, 0.9F * k));
            billboard(g, rot, base, 0.3F, 0, argb(this.rgb, 0.6F * k));
        }
    }

    /** Expanding ring, facing {@code normal} (or the camera when the normal is zero). */
    static final class RingFx extends Fx {
        final Vec3 pos;
        final Vec3 normal;
        final float radius;
        final int rgb;
        final ResourceLocation texture;

        RingFx(Vec3 pos, Vec3 normal, float radius, int rgb, int life, ResourceLocation texture) {
            super(life);
            this.pos = pos;
            this.normal = normal;
            this.radius = radius;
            this.rgb = rgb;
            this.texture = texture;
        }

        @Override
        void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
            float t = this.t(pt);
            float r = this.radius * (0.15F + 0.85F * (1 - (1 - t) * (1 - t)));
            int col = argb(this.rgb, 0.85F * (1 - t));
            VertexConsumer vc = buf.getBuffer(RenderType.eyes(this.texture));
            Vector3f p = rel(this.pos, cam);
            if (this.normal.lengthSqr() < 1.0E-4) billboard(vc, rot, p, r, 0, col);
            else facing(vc, p, new Vector3f((float) this.normal.x, (float) this.normal.y, (float) this.normal.z), r, 0, col);
        }
    }

    /** Sonic blast: wave fronts that race forward and spread out along the cone. */
    static final class WaveFx extends Fx {
        final Vec3 origin;
        final Vec3 dir;
        final float range;
        final float cone;
        final int rgb;

        WaveFx(Vec3 origin, Vec3 dir, float range, float coneDeg, int rgb) {
            super(14);
            this.origin = origin;
            this.dir = dir.normalize();
            this.range = range;
            this.cone = (float) Math.tan(Math.toRadians(Math.max(8.0F, coneDeg)));
            this.rgb = rgb;
        }

        @Override
        void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
            float age = this.age - this.delay + pt;
            VertexConsumer vc = buf.getBuffer(RenderType.eyes(WAVE));
            Vector3f n = new Vector3f((float) this.dir.x, (float) this.dir.y, (float) this.dir.z);
            for (int j = 0; j < 4; j++) {
                float a = age - j * 1.6F;
                if (a < 0) continue;
                float f = a / 8.0F;
                if (f > 1) continue;
                float dist = this.range * (1 - (1 - f) * (1 - f));
                float r = 0.35F + dist * this.cone * 0.95F;
                Vector3f p = rel(this.origin.add(this.dir.scale(dist)), cam);
                facing(vc, p, n, r, j * 0.7F, argb(this.rgb, 0.7F * (1 - f) * (1 - j * 0.18F)));
            }
        }
    }

    /** Fireball: a few animated billboards from a 4x4 sheet, plus a flash at the start. */
    static final class BlastFx extends Fx {
        final Vec3 pos;
        final float size;
        final int rgb;
        final float[][] puffs;

        BlastFx(Vec3 pos, float size, int rgb) {
            super(18);
            this.pos = pos;
            this.size = size;
            this.rgb = rgb;
            int n = 4 + (int) Math.min(6, size * 2);
            this.puffs = new float[n][];
            for (int i = 0; i < n; i++) {
                this.puffs[i] = new float[] {(RND.nextFloat() - 0.5F) * size * 0.7F, (RND.nextFloat() - 0.3F) * size * 0.6F,
                        (RND.nextFloat() - 0.5F) * size * 0.7F, RND.nextFloat() * TWO_PI, 0.6F + RND.nextFloat() * 0.6F, RND.nextInt(3)};
            }
        }

        @Override
        void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
            float t = this.t(pt);
            Vector3f c = rel(this.pos, cam);
            VertexConsumer vc = buf.getBuffer(RenderType.eyes(BLAST));
            for (float[] p : this.puffs) {
                float lt = Mth.clamp(t * (1.0F + p[5] * 0.15F), 0, 1);
                int frame = Math.min(15, (int) (lt * 16));
                float u0 = (frame % 4) / 4.0F, v0 = (frame / 4) / 4.0F;
                Vector3f q = new Vector3f(c).add(p[0] * (0.5F + t), p[1] * (0.5F + t) + t * this.size * 0.3F, p[2] * (0.5F + t));
                float s = this.size * 0.55F * p[4] * (0.5F + 0.8F * (float) Math.sqrt(lt));
                billboard(vc, rot, q, s, p[3] + t * 0.6F, argb(this.rgb, 1.0F - lt * 0.5F), u0, v0, u0 + 0.25F, v0 + 0.25F);
            }
            if (t < 0.25F) {
                VertexConsumer g = buf.getBuffer(RenderType.eyes(GLOW));
                billboard(g, rot, c, this.size * 2.2F * (1 - t * 3), 0, argb(0xFFF0D8, 1.0F - t * 4));
            }
        }
    }

    /** The end of a singularity: everything rushes in to a point, then a violet shock rolls out. */
    static final class ImplodeFx extends Fx {
        final Vec3 pos;
        final float radius;
        final int rgb;

        ImplodeFx(Vec3 pos, float radius, int rgb) {
            super(30);
            this.pos = pos;
            this.radius = radius;
            this.rgb = rgb;
        }

        @Override
        void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
            float t = this.t(pt);
            Vector3f c = rel(this.pos, cam);
            // one render type at a time: asking the buffer source for another one ends (draws) the previous batch,
            // and writing to an ended buffer throws
            if (t < 0.3F) {
                float f = t / 0.3F;
                float r = this.radius * 1.8F * (1 - f * f);
                billboard(buf.getBuffer(RenderType.eyes(RING)), rot, c, r, f * 2.0F, argb(this.rgb, 0.4F + 0.6F * f));
                billboard(buf.getBuffer(RenderType.eyes(SPIRAL)), rot, c, r * 0.8F, f * 12.0F, argb(this.rgb, 0.8F));
                billboard(buf.getBuffer(RenderType.eyes(GLOW)), rot, c, 0.3F + f * 0.8F, 0, argb(0xFFFFFF, f));
            } else {
                float f = (t - 0.3F) / 0.7F;
                float r = this.radius * 2.6F * (float) Math.sqrt(f);
                VertexConsumer ring = buf.getBuffer(RenderType.eyes(RING));
                billboard(ring, rot, c, r, f, argb(this.rgb, 1.0F - f));
                billboard(ring, rot, c, r * 0.7F, -f * 2.0F, argb(0xE8D8FF, (1.0F - f) * 0.6F));
                if (f < 0.35F) {
                    billboard(buf.getBuffer(RenderType.eyes(GLOW)), rot, c, this.radius * 2.5F * (1 - f / 0.35F) + 0.5F, 0, argb(0xF0E0FF, 1.0F - f / 0.35F));
                }
            }
        }
    }

    /** «Meteoro»: a magic circle on the ground that marks where the rock will fall, until it lands. */
    static final class SigilFx extends Fx {
        final Vec3 pos;
        final float radius;
        final int rgb;

        SigilFx(Vec3 pos, float radius, int life, int rgb) {
            super(Math.max(6, life + 4));
            this.pos = pos;
            this.radius = radius;
            this.rgb = rgb;
        }

        @Override
        void render(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
            float t = this.t(pt);
            float in = Mth.clamp(t * 6.0F, 0, 1), out = 1.0F - Mth.clamp((t - 0.85F) / 0.15F, 0, 1);
            float age = this.age + pt;
            Vector3f c = rel(this.pos, cam);
            Vector3f up = new Vector3f(0, 1, 0);
            facing(buf.getBuffer(RenderType.eyes(SIGIL)), c, up, this.radius * in, age * 0.08F, argb(this.rgb, 0.9F * out));
            facing(buf.getBuffer(RenderType.eyes(SIGIL)), new Vector3f(c).add(0, 0.02F, 0), up, this.radius * 0.6F * in, -age * 0.14F,
                    argb(0xFFD0A0, 0.6F * out * (0.7F + 0.3F * Mth.sin(age * 0.6F))));
            facing(buf.getBuffer(RenderType.eyes(GLOW)), new Vector3f(c).add(0, 0.04F, 0), up, this.radius * 0.5F * in, 0, argb(this.rgb, 0.4F * out));
        }
    }

    // ================================================================== the live beam («Prisma»): recomputed every frame

    @Nullable private static ArsenalDef liveDef;
    private static long liveUntil;

    /** Keeps the local continuous beam alive until {@code until} (game time). */
    public static void liveBeam(ArsenalDef d, long until) {
        liveDef = d;
        liveUntil = until;
    }

    private static void liveBeamTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (liveDef == null) return;
        if (p == null || mc.level == null || mc.level.getGameTime() > liveUntil || !(p.getMainHandItem().getItem() instanceof ArsenalItem it) || it.def != liveDef) {
            liveDef = null;
            return;
        }
        // sparks and light where the beam lands
        Vec3 end = ArsenalClient.beamEnd(p, liveDef.range, 1.0F);
        Vec3 back = end.subtract(p.getViewVector(1.0F).scale(0.05));
        ClientLevel level = mc.level;
        for (int i = 0; i < 3; i++) {
            level.addParticle(ArsenalParticles.of(ArsenalParticles.SPARK, hue(RND.nextFloat(), 0.6F)), back.x, back.y, back.z,
                    RND.nextGaussian() * 0.12, RND.nextGaussian() * 0.12 + 0.05, RND.nextGaussian() * 0.12);
        }
        if (RND.nextInt(3) == 0) level.addParticle(ArsenalParticles.of(ArsenalParticles.SMOKE, 0xD8D8E8), back.x, back.y, back.z, 0, 0.02, 0);
    }

    private static void renderLiveBeam(MultiBufferSource buf, Vec3 cam, Quaternionf rot, float pt) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        ArsenalDef d = liveDef;
        if (p == null || d == null) return;
        Vec3 eye = p.getEyePosition(pt);
        boolean fp = mc.options.getCameraType().isFirstPerson() && ArsenalClient.fpMuzzle != null;
        Vec3 start = fp ? eye.add(ArsenalClient.fpMuzzle) : com.blockwars.arsenal.ArsenalLogic.muzzle(p);
        Vec3 end = ArsenalClient.beamEnd(p, d.range, pt);
        double time = ArsenalClient.seconds(pt);
        drawBeam(buf, rot, rel(start, cam), rel(end, cam), d, 1.0F, time);
    }

    // ================================================================== spawning API

    public static void flash(Vec3 pos, Vec3 dir, ArsenalDef d, float size) {
        add(new FlashFx(pos, dir, d, size, RND.nextInt(1000)));
    }

    public static void glow(Vec3 pos, float size, int rgb, int life, float intensity) {
        add(new GlowFx(pos, size, rgb, life, intensity));
    }

    public static void impactGlow(Vec3 at, int rgb) {
        add(new GlowFx(at, 0.35F, rgb, 6, 0.9F));
    }

    public static void beam(Vec3 a, Vec3 b, ArsenalDef d, int life) {
        add(new BeamFx(a, b, d, life));
    }

    public static void arc(Vec3 a, Vec3 b, ArsenalDef d, int life) {
        add(new ArcFx(a, b, d.tracerColor, life));
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) {
            for (int i = 0; i < 5; i++) {
                mc.level.addParticle(ArsenalParticles.of(ArsenalParticles.SPARK, d.tracerColor), b.x, b.y, b.z,
                        RND.nextGaussian() * 0.15, RND.nextGaussian() * 0.15 + 0.05, RND.nextGaussian() * 0.15);
            }
        }
    }

    public static void ring(Vec3 pos, Vec3 normal, float radius, int rgb, int life) {
        add(new RingFx(pos, normal, radius, rgb, life, RING));
    }

    public static void blast(Vec3 pos, float size, int rgb) {
        add(new BlastFx(pos, size, rgb));
    }

    public static void sigil(Vec3 pos, float radius, int ticks, int rgb) {
        add(new SigilFx(pos, radius, ticks, rgb));
    }

    public static void implode(Vec3 pos, float radius, int rgb) {
        add(new ImplodeFx(pos, radius, rgb));
        BlastFx b = new BlastFx(pos, radius * 0.9F, rgb);
        b.delay = 9;
        add(b);
    }

    /** The sonic weapon's wave fronts, plus dust kicked up along the cone for the local shooter. */
    public static void wave(Vec3 muzzle, Vec3 look, ArsenalDef d, boolean local) {
        add(new WaveFx(muzzle, look, d.range, d.spreadHip, d.tracerColor));
        Minecraft mc = Minecraft.getInstance();
        if (!local || mc.level == null) return;
        for (int i = 0; i < 10; i++) {
            Vec3 v = look.add(RND.nextGaussian() * 0.2, RND.nextGaussian() * 0.2, RND.nextGaussian() * 0.2).normalize().scale(0.4 + RND.nextFloat() * 0.5);
            Vec3 at = muzzle.add(look.scale(0.5 + RND.nextFloat() * 2.0));
            mc.level.addParticle(ArsenalParticles.of(ArsenalParticles.SMOKE, 0xC8CCD8), at.x, at.y, at.z, v.x, v.y, v.z);
        }
    }

    /** Local prediction of the dragon fire stream. */
    public static void flames(LocalPlayer p, ArsenalDef d, Vec3 muzzle, Vec3 look) {
        ClientLevel level = (ClientLevel) p.level();
        for (int i = 0; i < 6; i++) {
            Vec3 v = look.add(RND.nextGaussian() * 0.09, RND.nextGaussian() * 0.09, RND.nextGaussian() * 0.09).normalize()
                    .scale(d.range * (0.06 + RND.nextFloat() * 0.035)).add(p.getDeltaMovement());
            level.addParticle(ArsenalParticles.of(ArsenalParticles.FIRE, i % 3 == 0 ? 0xFFC040 : d.tracerColor), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
        }
        if (RND.nextInt(2) == 0) {
            Vec3 v = look.scale(0.5 + RND.nextFloat() * 0.4).add(RND.nextGaussian() * 0.1, RND.nextGaussian() * 0.1 + 0.05, RND.nextGaussian() * 0.1);
            level.addParticle(ArsenalParticles.of(ArsenalParticles.SPARK, 0xFFB040), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
        }
    }

    /** Muzzle effects in the world for the local shooter (seen in third person, and as smoke, light and debris). */
    public static void muzzleWorld(LocalPlayer p, ArsenalDef d, Vec3 muzzle, Vec3 fwd, float charge) {
        ClientLevel level = (ClientLevel) p.level();
        Minecraft mc = Minecraft.getInstance();
        Vec3 mv = p.getDeltaMovement();
        for (int i = 0; i < d.smoke; i++) {
            Vec3 v = fwd.scale(0.03 + RND.nextFloat() * 0.05).add(RND.nextGaussian() * 0.01, 0.006 + RND.nextFloat() * 0.01, RND.nextGaussian() * 0.01).add(mv.scale(0.8));
            level.addParticle(ArsenalParticles.of(ArsenalParticles.SMOKE, smokeColor(d)), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
        }
        switch (d.flash) {
            case CONFETTI -> {
                for (int i = 0; i < 10; i++) {
                    Vec3 v = fwd.scale(0.25 + RND.nextFloat() * 0.35).add(RND.nextGaussian() * 0.08, RND.nextGaussian() * 0.08 + 0.04, RND.nextGaussian() * 0.08).add(mv);
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.CONFETTI, 0), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                }
            }
            case FROST -> {
                for (int i = 0; i < 8; i++) {
                    Vec3 v = fwd.scale(0.08 + RND.nextFloat() * 0.2).add(RND.nextGaussian() * 0.05, RND.nextGaussian() * 0.05, RND.nextGaussian() * 0.05);
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.FROST, 0xE6FAFF), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                }
            }
            case ELECTRIC, HIVE -> {
                for (int i = 0; i < 4; i++) {
                    Vec3 v = fwd.scale(0.3 + RND.nextFloat() * 0.4).add(RND.nextGaussian() * 0.12, RND.nextGaussian() * 0.12, RND.nextGaussian() * 0.12);
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.SPARK, d.flashColor), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                }
            }
            case IMPLODE -> {
                for (int i = 0; i < 16; i++) {
                    Vec3 o = new Vec3(RND.nextGaussian(), RND.nextGaussian(), RND.nextGaussian()).normalize().scale(0.8 + RND.nextFloat());
                    level.addParticle(ParticleTypes.PORTAL, muzzle.x, muzzle.y, muzzle.z, o.x, o.y - 1.0, o.z);
                }
            }
            case PLASMA, RINGS, CRESCENT, ARCANE, DAWN -> {
                Vec3 v = fwd.scale(0.2).add(RND.nextGaussian() * 0.05, RND.nextGaussian() * 0.05, RND.nextGaussian() * 0.05);
                level.addParticle(ArsenalParticles.of(ArsenalParticles.GLOW, d.flashColor), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
            }
            case SPLASH -> {
                for (int i = 0; i < 8; i++) {
                    level.addParticle(ParticleTypes.SPLASH, muzzle.x, muzzle.y, muzzle.z, fwd.x * 0.3 + RND.nextGaussian() * 0.1, 0.1, fwd.z * 0.3 + RND.nextGaussian() * 0.1);
                }
            }
            case BUBBLES -> {
                for (int i = 0; i < 3; i++) {
                    Vec3 v = fwd.scale(0.06 + RND.nextFloat() * 0.06).add(RND.nextGaussian() * 0.02, 0.01, RND.nextGaussian() * 0.02);
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.BUBBLE, d.flashColor), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                }
            }
            case CARDS -> {
                Vec3 v = fwd.scale(0.15).add(RND.nextGaussian() * 0.05, 0.05, RND.nextGaussian() * 0.05);
                level.addParticle(ArsenalParticles.of(ArsenalParticles.SUIT, 0), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
            }
            case SLIME -> {
                for (int i = 0; i < 3; i++) {
                    Vec3 v = fwd.scale(0.15 + RND.nextFloat() * 0.1).add(RND.nextGaussian() * 0.04, 0.03, RND.nextGaussian() * 0.04);
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.DRIP, d.flashColor), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                }
            }
            case MORTAR -> {
                for (int i = 0; i < 6; i++) {
                    Vec3 v = fwd.scale(0.05 + RND.nextFloat() * 0.08).add(RND.nextGaussian() * 0.03, 0.04 + RND.nextFloat() * 0.04, RND.nextGaussian() * 0.03);
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.SMOKE, 0x8A8478), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                }
            }
            case DEPLOY, SPARKS -> {
                for (int i = 0; i < 5; i++) {
                    Vec3 v = fwd.scale(0.2 + RND.nextFloat() * 0.3).add(RND.nextGaussian() * 0.12, RND.nextGaussian() * 0.12 + 0.05, RND.nextGaussian() * 0.12);
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.SPARK, d.flashColor), muzzle.x, muzzle.y, muzzle.z, v.x, v.y, v.z);
                }
            }
            default -> { }
        }
        if (d.flash != Flash.DRAGON && d.flash != Flash.NONE) {
            glow(muzzle.add(fwd.scale(0.1)), 0.4F + 0.3F * charge, d.flashColor, 3, d.flash == Flash.PRISM ? 0.4F : 0.7F);
        }
    }

    static int smokeColor(ArsenalDef d) {
        return switch (d.flash) {
            case CONFETTI -> 0xFFC6E2;
            case FROST -> 0xEAF8FF;
            case HIVE -> 0x9A8A68;
            case DRAGON -> 0x3A3632;
            case PLASMA -> 0xA8D8B0;
            case IMPLODE -> 0x2A1840;
            case SLIME -> 0xB8E8A0;
            case MORTAR -> 0x6A665E;
            case SPLASH, BUBBLES -> 0xE0F4FF;
            case ARCANE -> 0x9A80C8;
            default -> 0xC9C5BE;
        };
    }
}
