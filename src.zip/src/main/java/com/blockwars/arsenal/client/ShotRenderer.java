package com.blockwars.arsenal.client;

import com.blockwars.BlockWars;
import com.blockwars.arsenal.ArsenalDef;
import com.blockwars.arsenal.ArsenalShot;
import com.blockwars.arsenal.ArsenalSounds;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Projectiles: spinning ion rings, robot wasps beating their wings, crystal ice lances (that melt where they stick),
 * tumbling candies, the singularity with its accretion disc and jets, comet-tailed plasma bolts, and the second ten:
 * whirling crescents, a harpoon on its chain, soap bubbles (and the bubble around a catch), spinning cards, a burning
 * meteor, goo blobs and their puddles, light arrows, mortar shells and bomblets, the turret that tracks its targets and
 * saw blades.
 */
public class ShotRenderer extends EntityRenderer<ArsenalShot> {
    private static final Map<ArsenalShot, Boolean> BUZZING = new WeakHashMap<>();

    public ShotRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public boolean shouldRender(ArsenalShot e, Frustum frustum, double x, double y, double z) {
        return true;
    }

    @Override
    public ResourceLocation getTextureLocation(ArsenalShot e) {
        return InventoryMenu.BLOCK_ATLAS;
    }

    /** Where the shot visually leaves from: it starts at the barrel and converges on its true path. */
    private static Vec3 launchOffset(ArsenalShot e, float pt) {
        float age = e.tickCount + pt;
        if (age > 4.0F || e.flag(ArsenalShot.F_CHILD)) return Vec3.ZERO;
        float k = 1.0F - age / 4.0F;
        k = k * k;
        Entity owner = e.getOwner();
        Minecraft mc = Minecraft.getInstance();
        if (owner == mc.player && mc.options.getCameraType().isFirstPerson() && ArsenalClient.fpMuzzle != null) {
            return ArsenalClient.fpMuzzle.add(0, 0.08, 0).scale(k);
        }
        if (owner instanceof LivingEntity le) {
            Vec3 look = le.getViewVector(pt);
            Vec3 right = look.cross(new Vec3(0, 1, 0));
            if (right.lengthSqr() < 1.0E-4) return Vec3.ZERO;
            right = right.normalize();
            return look.scale(0.9).add(right.scale(0.32)).add(0, -0.14, 0).scale(k);
        }
        return Vec3.ZERO;
    }

    @Override
    public void render(ArsenalShot e, float yaw, float pt, PoseStack pose, MultiBufferSource buffers, int light) {
        ArsenalDef d = e.def();
        if (d == null) return;
        int state = e.shotState();
        Quaternionf camRot = this.entityRenderDispatcher.cameraOrientation();
        Vec3 off = state == ArsenalShot.FLYING ? launchOffset(e, pt) : Vec3.ZERO;
        Vector3f o = new Vector3f((float) off.x, (float) off.y, (float) off.z);
        Vec3 v = e.getDeltaMovement();
        double speed = v.length();
        Vec3 dir = state == ArsenalShot.FLYING && speed > 1.0E-4 ? v.scale(1.0 / speed) : rotDir(e);
        float t = e.tickCount + pt;
        Matrix4f base = pose.last().pose();
        Vector3f c = base.transformPosition(new Vector3f(o));
        Vector3f fwd = new Vector3f((float) dir.x, (float) dir.y, (float) dir.z);
        float size = d.projSize * (0.7F + 0.3F * e.chargeLevel());

        switch (d.proj) {
            case RING -> {
                VertexConsumer ring = buffers.getBuffer(RenderType.eyes(ArsenalFx.RING));
                for (int i = 0; i < 3; i++) {
                    Vector3f p = new Vector3f(c).sub(new Vector3f(fwd).mul(i * 0.32F * size));
                    int col = i == 1 ? 0xFF4A6A : d.tracerColor;
                    ArsenalFx.facing(ring, p, fwd, (0.24F - i * 0.04F) * size, t * 0.8F + i, ArsenalFx.argb(col, 1.0F - i * 0.2F));
                }
                VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
                ArsenalFx.billboard(g, camRot, c, 0.3F * size, 0, ArsenalFx.argb(d.tracerColor, 0.7F));
                ArsenalFx.billboard(g, camRot, c, 0.08F * size, 0, ArsenalFx.argb(0xFFFFFF, 1.0F));
                streak(buffers, c, fwd, (float) Math.min(1.4, speed * 0.4 + 0.2), 0.03F * size, d.tracerColor, 0.6F);
            }
            case WASP -> {
                if (BUZZING.putIfAbsent(e, Boolean.TRUE) == null && state == ArsenalShot.FLYING) {
                    Minecraft.getInstance().getSoundManager().play(new ArsenalLoop(ArsenalSounds.shared("wasp_buzz"), e));
                }
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                pose.mulPose(orient(dir));
                // a lazy weave as it flies
                pose.mulPose(new Quaternionf().rotateZ(Mth.sin(t * 0.9F + e.getId()) * 0.35F));
                float sc = size / 16.0F;
                pose.scale(sc, sc, sc);
                float flap = Mth.sin(t * 9.0F) * 38.0F;
                mesh(pose, buffers, d.projMesh, light, (name, m, px, py, pz) -> {
                    if (name.equals("wing_l")) rotZ(m, px, py, pz, flap);
                    else if (name.equals("wing_r")) rotZ(m, px, py, pz, -flap);
                }, 0xFFFFFFFF);
                pose.popPose();
                // thruster glow under the abdomen
                Vector3f tail = new Vector3f(c).sub(new Vector3f(fwd).mul(0.22F * size));
                VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
                ArsenalFx.billboard(g, camRot, tail, 0.16F * size * (0.85F + 0.15F * Mth.sin(t * 4.1F)), 0, ArsenalFx.argb(0xFFB020, 0.8F));
            }
            case ICE -> {
                float melt = state == ArsenalShot.STUCK ? Mth.clamp((e.stateTicks() + pt) / 70.0F, 0, 1) : 0;
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                pose.mulPose(orient(dir));
                pose.mulPose(new Quaternionf().rotateZ(state == ArsenalShot.FLYING ? t * 0.35F : 0.0F));
                float sc = size * (1.0F - 0.45F * melt) / 16.0F;
                pose.scale(sc, sc, sc);
                mesh(pose, buffers, d.projMesh, light, null, 0xFFFFFFFF);
                pose.popPose();
                VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
                Vector3f tip = new Vector3f(c).add(new Vector3f(fwd).mul(0.3F * size));
                ArsenalFx.billboard(g, camRot, tip, 0.22F * size * (1 - melt), 0, ArsenalFx.argb(d.tracerColor, 0.7F * (1 - melt)));
                if (state == ArsenalShot.FLYING) streak(buffers, c, fwd, (float) Math.min(4.0, speed * 0.6), 0.05F * size, d.tracerColor, 0.5F);
            }
            case CANDY -> {
                int col = ArsenalParticleTypes.PARTY[Math.floorMod(e.getId() * 7, ArsenalParticleTypes.PARTY.length)];
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                Vector3f axis = new Vector3f(Mth.sin(e.getId()), Mth.cos(e.getId() * 1.7F), 0.5F).normalize();
                pose.mulPose(new Quaternionf().rotateAxis(t * 0.45F, axis));
                float sc = size / 16.0F;
                pose.scale(sc, sc, sc);
                mesh(pose, buffers, d.projMesh, light, null, 0xFF000000 | col);
                pose.popPose();
            }
            case VOID -> renderVoid(e, d, state, t, pt, c, camRot, buffers);
            case BOOMERANG -> {
                // the crescent whirls flat as it flies (out and back)
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                pose.mulPose(new Quaternionf().rotateY(-t * 1.6F * (e.flag(ArsenalShot.F_LEFT) ? -1 : 1)));
                float sc = size / 16.0F;
                pose.scale(sc, sc, sc);
                mesh(pose, buffers, d.projMesh, light, null, 0xFFFFFFFF);
                pose.popPose();
                VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
                ArsenalFx.billboard(g, camRot, c, 0.42F * size, 0, ArsenalFx.argb(d.tracerColor, 0.45F));
                VertexConsumer cr = buffers.getBuffer(RenderType.eyes(ArsenalFx.CRESCENT));
                ArsenalFx.facing(cr, c, new Vector3f(0, 1, 0), 0.55F * size, -t * 1.6F, ArsenalFx.argb(d.tracerColor, 0.55F));
            }
            case HARPOON -> {
                Vec3 hand = ownerHand(e, pt);
                Vector3f handRel = hand == null ? null : new Vector3f((float) (hand.x - Mth.lerp(pt, e.xo, e.getX())),
                        (float) (hand.y - Mth.lerp(pt, e.yo, e.getY())), (float) (hand.z - Mth.lerp(pt, e.zo, e.getZ())));
                Vec3 look = dir;
                if (state == ArsenalShot.REEL && handRel != null && handRel.lengthSquared() > 1.0E-4F) {
                    look = new Vec3(-handRel.x, -handRel.y, -handRel.z).normalize();
                }
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                pose.mulPose(orient(look));
                float sc = size / 16.0F;
                pose.scale(sc, sc, sc);
                mesh(pose, buffers, d.projMesh, light, null, 0xFFFFFFFF);
                pose.popPose();
                if (handRel != null) chain(buffers, base.transformPosition(new Vector3f(o)), base.transformPosition(handRel), light, state == ArsenalShot.FLYING);
            }
            case BUBBLE -> {
                VertexConsumer b = buffers.getBuffer(RenderType.entityTranslucent(ArsenalFx.BUBBLE));
                if (state == ArsenalShot.TRAP) {
                    Entity held = e.link();
                    float r = 0.6F;
                    Vector3f at = c;
                    if (held != null) {
                        r = Math.max(held.getBbWidth(), held.getBbHeight()) * 0.72F + 0.15F;
                        Vec3 hc = held.getPosition(pt).add(0, held.getBbHeight() * 0.5, 0);
                        at = base.transformPosition(new Vector3f((float) (hc.x - Mth.lerp(pt, e.xo, e.getX())),
                                (float) (hc.y - Mth.lerp(pt, e.yo, e.getY())), (float) (hc.z - Mth.lerp(pt, e.zo, e.getZ()))));
                    }
                    float wob = 1.0F + 0.04F * Mth.sin(t * 0.6F);
                    bubble(b, camRot, at, r * wob, t, 0.75F);
                } else {
                    bubble(b, camRot, c, 0.22F * size * (1.0F + 0.05F * Mth.sin(t * 0.8F)), t, 0.9F);
                }
            }
            case CARD -> {
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                pose.mulPose(orient(dir));
                if (state == ArsenalShot.FLYING) pose.mulPose(new Quaternionf().rotateY(t * 1.9F));
                float sc = size / 16.0F;
                pose.scale(sc, sc, sc);
                mesh(pose, buffers, d.projMesh, light, null, 0xFFFFFFFF);
                pose.popPose();
                if (state == ArsenalShot.FLYING) streak(buffers, c, fwd, (float) Math.min(1.2, speed * 0.35), 0.025F * size, 0xFFFFFF, 0.35F);
            }
            case METEOR -> {
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                pose.mulPose(new Quaternionf().rotateAxis(t * 0.3F, new Vector3f(0.6F, 0.2F, 0.77F).normalize()));
                float sc = size / 16.0F;
                pose.scale(sc, sc, sc);
                mesh(pose, buffers, d.projMesh, LightTexture.FULL_BRIGHT, null, 0xFFFFFFFF);
                pose.popPose();
                VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
                ArsenalFx.billboard(g, camRot, c, 1.4F * size * (0.9F + 0.1F * Mth.sin(t * 2.3F)), 0, ArsenalFx.argb(0xFF6A20, 0.75F));
                ArsenalFx.billboard(g, camRot, c, 0.6F * size, 0, ArsenalFx.argb(0xFFE0A0, 0.8F));
                streak(buffers, c, fwd, (float) Math.min(6.0, speed * 3.0), 0.35F * size, 0xFF7A20, 0.85F);
            }
            case GOO -> {
                if (state == ArsenalShot.PUDDLE) {
                    renderPuddle(e, d, pt, c, buffers, light);
                } else {
                    VertexConsumer b = buffers.getBuffer(RenderType.entityTranslucent(ArsenalFx.SLIME));
                    float wob = 1.0F + 0.12F * Mth.sin(t * 1.7F);
                    blob(b, camRot, c, 0.16F * size * wob, 0.16F * size / wob, t * 0.3F, d.tracerColor, light);
                }
            }
            case ARROW -> {
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                pose.mulPose(orient(dir));
                float sc = size / 16.0F;
                pose.scale(sc, sc, sc);
                mesh(pose, buffers, d.projMesh, light, null, 0xFFFFFFFF);
                pose.popPose();
                if (state == ArsenalShot.FLYING) {
                    streak(buffers, c, fwd, (float) Math.min(3.0, speed * 0.9), 0.05F * size, d.tracerColor, 0.7F);
                    VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
                    ArsenalFx.billboard(g, camRot, new Vector3f(c).add(new Vector3f(fwd).mul(0.35F * size)), 0.2F * size, 0, ArsenalFx.argb(d.tracerColor, 0.8F));
                } else {
                    float k = 1.0F - Mth.clamp((e.stateTicks() + pt) / ArsenalShot.stuckLife(d), 0, 1);
                    VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
                    ArsenalFx.billboard(g, camRot, c, 0.18F * size, 0, ArsenalFx.argb(d.tracerColor, 0.6F * k));
                }
            }
            case MORTAR -> {
                boolean bomblet = e.flag(ArsenalShot.F_BOMBLET);
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                if (bomblet) pose.mulPose(new Quaternionf().rotateAxis(t * 0.5F, new Vector3f(Mth.sin(e.getId()), 0.4F, Mth.cos(e.getId())).normalize()));
                else pose.mulPose(orient(dir));
                float sc = size * (bomblet ? 0.55F : 1.0F) / 16.0F;
                pose.scale(sc, sc, sc);
                mesh(pose, buffers, d.projMesh, light, null, 0xFFFFFFFF);
                pose.popPose();
                VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
                Vector3f tail = new Vector3f(c).sub(new Vector3f(fwd).mul(0.3F * size));
                ArsenalFx.billboard(g, camRot, bomblet ? c : tail, (bomblet ? 0.12F : 0.2F) * size * (0.8F + 0.2F * Mth.sin(t * 5.0F)), 0,
                        ArsenalFx.argb(0xFFB050, 0.8F));
            }
            case TURRET -> renderTurret(e, d, state, t, pt, o, c, camRot, pose, buffers, light);
            case SAW -> {
                pose.pushPose();
                pose.translate(o.x, o.y, o.z);
                // the blade lies in the plane of its flight and spins hard; stuck in a wall it stands still
                pose.mulPose(orient(new Vec3(dir.x, 0, dir.z).lengthSqr() > 1.0E-4 ? new Vec3(dir.x, 0, dir.z).normalize() : new Vec3(0, 0, -1)));
                if (state == ArsenalShot.FLYING) pose.mulPose(new Quaternionf().rotateY(-t * 2.6F));
                else pose.mulPose(new Quaternionf().rotateX(0.35F));
                float sc = size / 16.0F;
                pose.scale(sc, sc, sc);
                mesh(pose, buffers, d.projMesh, light, null, 0xFFFFFFFF);
                pose.popPose();
                if (state == ArsenalShot.FLYING) {
                    VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.FLARE));
                    ArsenalFx.facing(g, c, new Vector3f(0, 1, 0), 0.32F * size, t * 2.6F, ArsenalFx.argb(0xFFF0D0, 0.35F));
                }
            }
            case PLASMA -> {
                float s = 0.15F * size * (0.9F + 0.1F * Mth.sin(t * 3.0F));
                VertexConsumer pl = buffers.getBuffer(RenderType.eyes(ArsenalFx.PLASMA));
                ArsenalFx.billboard(pl, camRot, c, s, t * 0.5F, ArsenalFx.argb(d.tracerColor, 1.0F));
                ArsenalFx.billboard(pl, camRot, c, s * 0.5F, -t * 0.8F, ArsenalFx.argb(0xF0FFF0, 0.9F));
                VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
                ArsenalFx.billboard(g, camRot, c, s * 3.2F, 0, ArsenalFx.argb(d.tracerColor, 0.45F));
                streak(buffers, c, fwd, (float) Math.min(1.6, speed * 0.45 + 0.2), s * 0.55F, d.tracerColor, 0.8F);
            }
            default -> { }
        }
    }

    /** The singularity: a black core, a violet halo, an accretion disc, a faint lensing ring and, once open, two jets. */
    private void renderVoid(ArsenalShot e, ArsenalDef d, int state, float t, float pt, Vector3f c, Quaternionf camRot, MultiBufferSource buffers) {
        boolean well = state == ArsenalShot.WELL;
        int life = Math.max(30, (int) d.sp2);
        float st = e.stateTicks() + pt;
        float grow = well ? Math.min(1.0F, st / 15.0F) : 0.0F;
        float shrink = well ? 1.0F - Mth.clamp((st - (life - 8)) / 8.0F, 0, 1) : 1.0F;
        float pulse = 0.94F + 0.06F * Mth.sin(t * (well ? 9.0F : 6.0F));
        float core = (0.28F + 0.9F * grow) * pulse * shrink * (0.75F + 0.25F * e.chargeLevel());
        if (core < 0.01F) return;
        // halo first (additive), then the core darkens what is behind it
        VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
        ArsenalFx.billboard(g, camRot, c, core * 3.0F, 0, ArsenalFx.argb(d.tracerColor, 0.55F));
        VertexConsumer disc = buffers.getBuffer(RenderType.eyes(ArsenalFx.SPIRAL));
        Vector3f n = new Vector3f(0.0F, 1.0F, 0.0F).rotateX(0.42F).rotateY(e.getId() * 0.7F);
        ArsenalFx.facing(disc, c, n, core * (well ? 4.2F : 3.0F), -t * (well ? 0.5F : 0.35F), ArsenalFx.argb(0xC090FF, 0.9F));
        ArsenalFx.facing(disc, c, n, core * (well ? 2.6F : 2.0F), -t * 0.8F, ArsenalFx.argb(0xFFFFFF, 0.5F));
        VertexConsumer ring = buffers.getBuffer(RenderType.eyes(ArsenalFx.RING));
        ArsenalFx.billboard(ring, camRot, c, core * 1.45F, t * 0.2F, ArsenalFx.argb(0xE8D8FF, 0.45F));
        if (well) {
            // relativistic jets out of the poles
            VertexConsumer jet = buffers.getBuffer(RenderType.eyes(ArsenalFx.BEAM));
            float len = 2.5F * grow * shrink * (0.85F + 0.15F * Mth.sin(t * 13.0F));
            Vector3f up = new Vector3f(n).mul(len);
            ArsenalFx.ribbon(jet, c, new Vector3f(c).add(up), 0.12F * core, ArsenalFx.argb(d.tracerColor, 0.9F), ArsenalFx.argb(d.tracerColor, 0.0F), 0, 1);
            ArsenalFx.ribbon(jet, c, new Vector3f(c).sub(up), 0.12F * core, ArsenalFx.argb(d.tracerColor, 0.9F), ArsenalFx.argb(d.tracerColor, 0.0F), 0, 1);
        }
        VertexConsumer dark = buffers.getBuffer(RenderType.entityTranslucent(ArsenalFx.VOID));
        Vector3f[] q = corners(camRot, c, core);
        int black = 0xFFFFFFFF;
        dark.addVertex(q[0].x, q[0].y, q[0].z, black, 0, 1, OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, 0, 1, 0);
        dark.addVertex(q[1].x, q[1].y, q[1].z, black, 1, 1, OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, 0, 1, 0);
        dark.addVertex(q[2].x, q[2].y, q[2].z, black, 1, 0, OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, 0, 1, 0);
        dark.addVertex(q[3].x, q[3].y, q[3].z, black, 0, 0, OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, 0, 1, 0);
    }

    /** Where the harpoon chain starts: the barrel of the owner's weapon (first person: the drawn weapon's muzzle). */
    private static Vec3 ownerHand(ArsenalShot e, float pt) {
        Entity owner = e.getOwner();
        if (!(owner instanceof LivingEntity le)) return null;
        Minecraft mc = Minecraft.getInstance();
        Vec3 eye = le.getEyePosition(pt);
        if (owner == mc.player && mc.options.getCameraType().isFirstPerson() && ArsenalClient.fpMuzzle != null) return eye.add(ArsenalClient.fpMuzzle);
        Vec3 look = le.getViewVector(pt);
        Vec3 right = look.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() < 1.0E-4 ? Vec3.ZERO : right.normalize();
        return eye.add(look.scale(0.9)).add(right.scale(0.32)).add(0, -0.18, 0);
    }

    /** The harpoon's chain: links along a slight sag from the harpoon to the gun (camera-relative points). */
    private static void chain(MultiBufferSource buffers, Vector3f a, Vector3f b, int light, boolean slack) {
        float len = a.distance(b);
        if (len < 0.05F) return;
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(ArsenalFx.CHAIN));
        int n = Math.max(2, Math.min(24, (int) (len * 1.5F)));
        float sag = slack ? Math.min(0.6F, len * 0.04F) : Math.min(0.15F, len * 0.01F);
        Vector3f prev = new Vector3f(a);
        float u = 0;
        for (int i = 1; i <= n; i++) {
            float f = i / (float) n;
            Vector3f p = new Vector3f(a).lerp(b, f);
            p.y -= sag * 4.0F * f * (1.0F - f);
            float seg = prev.distance(p);
            chainQuad(vc, prev, p, 0.06F, u, u + seg * 3.0F, light);
            u += seg * 3.0F;
            prev = p;
        }
    }

    private static void chainQuad(VertexConsumer vc, Vector3f a, Vector3f b, float w, float u0, float u1, int light) {
        Vector3f dir = new Vector3f(b).sub(a);
        Vector3f mid = new Vector3f(a).add(b).mul(0.5F);
        Vector3f side = new Vector3f(dir).cross(mid);
        if (side.lengthSquared() < 1.0E-10F) return;
        side.normalize().mul(w);
        Vector3f p0 = new Vector3f(a).add(side), p1 = new Vector3f(a).sub(side), p2 = new Vector3f(b).sub(side), p3 = new Vector3f(b).add(side);
        int col = 0xFFFFFFFF;
        int ov = OverlayTexture.NO_OVERLAY;
        vc.addVertex(p0.x, p0.y, p0.z, col, u0, 0, ov, light, 0, 1, 0);
        vc.addVertex(p1.x, p1.y, p1.z, col, u0, 1, ov, light, 0, 1, 0);
        vc.addVertex(p2.x, p2.y, p2.z, col, u1, 1, ov, light, 0, 1, 0);
        vc.addVertex(p3.x, p3.y, p3.z, col, u1, 0, ov, light, 0, 1, 0);
    }

    /** A soap bubble: a camera-facing sphere picture with a rainbow sheen that turns slowly. */
    private static void bubble(VertexConsumer vc, Quaternionf camRot, Vector3f c, float r, float t, float alpha) {
        Vector3f[] q = corners(camRot, c, r);
        int col = ((int) (alpha * 255) << 24) | ArsenalFx.hue(t * 0.01F, 0.25F);
        int ov = OverlayTexture.NO_OVERLAY, l = LightTexture.FULL_BRIGHT;
        vc.addVertex(q[0].x, q[0].y, q[0].z, col, 0, 1, ov, l, 0, 1, 0);
        vc.addVertex(q[1].x, q[1].y, q[1].z, col, 1, 1, ov, l, 0, 1, 0);
        vc.addVertex(q[2].x, q[2].y, q[2].z, col, 1, 0, ov, l, 0, 1, 0);
        vc.addVertex(q[3].x, q[3].y, q[3].z, col, 0, 0, ov, l, 0, 1, 0);
    }

    /** A wobbling blob of goo (camera-facing, stretched). */
    private static void blob(VertexConsumer vc, Quaternionf camRot, Vector3f c, float rx, float ry, float roll, int rgb, int light) {
        float cs = Mth.cos(roll), sn = Mth.sin(roll);
        Vector3f[] q = {new Vector3f(-rx * cs + ry * sn, -rx * sn - ry * cs, 0), new Vector3f(rx * cs + ry * sn, rx * sn - ry * cs, 0),
                new Vector3f(rx * cs - ry * sn, rx * sn + ry * cs, 0), new Vector3f(-rx * cs - ry * sn, -rx * sn + ry * cs, 0)};
        for (Vector3f p : q) camRot.transform(p).add(c);
        int col = 0xFF000000 | rgb;
        int ov = OverlayTexture.NO_OVERLAY;
        vc.addVertex(q[0].x, q[0].y, q[0].z, col, 0, 1, ov, light, 0, 1, 0);
        vc.addVertex(q[1].x, q[1].y, q[1].z, col, 1, 1, ov, light, 0, 1, 0);
        vc.addVertex(q[2].x, q[2].y, q[2].z, col, 1, 0, ov, light, 0, 1, 0);
        vc.addVertex(q[3].x, q[3].y, q[3].z, col, 0, 0, ov, light, 0, 1, 0);
    }

    /** A goo puddle lying on its block face: grows in, quivers, shrinks away at the end. */
    private static void renderPuddle(ArsenalShot e, ArsenalDef d, float pt, Vector3f c, MultiBufferSource buffers, int light) {
        int life = Math.max(40, (int) d.sp2);
        float st = e.stateTicks() + pt;
        float grow = Mth.clamp(st / 4.0F, 0, 1) * (1.0F - Mth.clamp((st - (life - 15)) / 15.0F, 0, 1));
        float r = Math.max(0.8F, d.sp1) * e.chargeLevel() * grow * (1.0F + 0.03F * Mth.sin(st * 0.5F + e.getId()));
        if (r < 0.02F) return;
        net.minecraft.core.Direction f = e.face();
        Vector3f n = new Vector3f(f.getStepX(), f.getStepY(), f.getStepZ());
        Vector3f up = Math.abs(n.y) > 0.5F ? new Vector3f(1, 0, 0) : new Vector3f(0, 1, 0);
        Vector3f a = new Vector3f(up).cross(n).normalize();
        Vector3f b = new Vector3f(n).cross(a).normalize();
        Quaternionf q = new Quaternionf().rotateAxis(e.getId() * 1.3F, n);
        q.transform(a);
        q.transform(b);
        a.mul(r);
        b.mul(r);
        VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(ArsenalFx.SLIME));
        int col = 0xF0000000 | (d.tracerColor & 0xFFFFFF);
        int ov = OverlayTexture.NO_OVERLAY;
        Vector3f p0 = new Vector3f(c).sub(a).sub(b), p1 = new Vector3f(c).add(a).sub(b), p2 = new Vector3f(c).add(a).add(b), p3 = new Vector3f(c).sub(a).add(b);
        vc.addVertex(p0.x, p0.y, p0.z, col, 0, 1, ov, light, n.x, n.y, n.z);
        vc.addVertex(p1.x, p1.y, p1.z, col, 1, 1, ov, light, n.x, n.y, n.z);
        vc.addVertex(p2.x, p2.y, p2.z, col, 1, 0, ov, light, n.x, n.y, n.z);
        vc.addVertex(p3.x, p3.y, p3.z, col, 0, 0, ov, light, n.x, n.y, n.z);
    }

    /** Smoothed head angles of the deployed turrets (client). */
    private static final Map<ArsenalShot, float[]> AIM = new WeakHashMap<>();

    /** «Vigía»: the capsule tumbles as it flies; deployed, it unfolds, its head tracks the target and its dish turns. */
    private void renderTurret(ArsenalShot e, ArsenalDef d, int state, float t, float pt, Vector3f o, Vector3f c, Quaternionf camRot, PoseStack pose,
                              MultiBufferSource buffers, int light) {
        pose.pushPose();
        pose.translate(o.x, o.y, o.z);
        if (state != ArsenalShot.TURRET) {
            pose.mulPose(new Quaternionf().rotateAxis(t * 0.4F, new Vector3f(0.3F, 1.0F, 0.2F).normalize()));
            float sc = d.projSize * 0.7F / 16.0F;
            pose.scale(sc, sc, sc);
            mesh(pose, buffers, d.projMesh, light, (name, m, px, py, pz) -> {
                if (name.equals("legs")) m.translate(px, py, pz).scale(0.4F).translate(-px, -py, -pz);
            }, 0xFFFFFFFF);
            pose.popPose();
            return;
        }
        float st = e.stateTicks() + pt;
        float unfold = Mth.clamp(st / 8.0F, 0, 1);
        int life = Math.max(60, (int) d.sp1);
        float pack = Mth.clamp((st - (life - 10)) / 10.0F, 0, 1);
        // aim: yaw and pitch toward the target, eased (per tick of game time, whatever the frame rate); deployed facing
        // the way its owner looked (the turret's yRot holds the owner's yaw)
        float[] aim = AIM.computeIfAbsent(e, k -> new float[] {180.0F - e.getYRot(), 0, t});
        float dt = Mth.clamp(t - aim[2], 0.0F, 4.0F);
        aim[2] = t;
        Entity target = e.link();
        float wantYaw, wantPitch = 0;
        if (target != null) {
            Vec3 head = e.getPosition(pt).add(0, 0.55, 0);
            Vec3 to = target.getPosition(pt).add(0, target.getBbHeight() * 0.5, 0).subtract(head);
            wantYaw = (float) Math.toDegrees(Math.atan2(-to.x, -to.z));
            wantPitch = (float) Math.toDegrees(Math.atan2(to.y, Math.sqrt(to.x * to.x + to.z * to.z)));
        } else {
            wantYaw = aim[0] + 2.0F * dt;   // idle sweep
        }
        float ease = 1.0F - (float) Math.pow(0.6, dt);
        aim[0] = aim[0] + Mth.wrapDegrees(wantYaw - aim[0]) * (target != null ? ease : 1.0F);
        aim[1] = aim[1] + (wantPitch - aim[1]) * ease;
        float yaw = aim[0] * Mth.DEG_TO_RAD, pitch = Mth.clamp(aim[1], -30, 60) * Mth.DEG_TO_RAD;
        float sc = d.projSize * (0.3F + 0.7F * unfold) * (1.0F - 0.6F * pack) / 16.0F;
        pose.scale(sc, sc, sc);
        float spin = t * 6.0F;
        mesh(pose, buffers, d.projMesh, light, (name, m, px, py, pz) -> {
            switch (name) {
                case "head" -> m.translate(px, py, pz).rotateY(yaw).rotateX(pitch).translate(-px, -py, -pz);
                case "dish" -> m.translate(px, py, pz).rotateY(yaw).rotateY(spin * 0.1F).translate(-px, -py, -pz);
                case "legs" -> m.translate(px, py, pz).scale(0.4F + 0.6F * unfold).translate(-px, -py, -pz);
                default -> { }
            }
        }, 0xFFFFFFFF);
        pose.popPose();
        // the scanner light on top
        VertexConsumer g = buffers.getBuffer(RenderType.eyes(ArsenalFx.GLOW));
        Vector3f lamp = new Vector3f(c).add(0, 0.85F * d.projSize * unfold, 0);
        float blink = target != null ? 0.9F : 0.4F + 0.3F * Mth.sin(t * 0.4F);
        ArsenalFx.billboard(g, camRot, lamp, 0.12F * d.projSize, 0, ArsenalFx.argb(target != null ? 0xFF4030 : d.tracerColor, blink * (1 - pack)));
    }

    /** A fading streak behind a fast shot. */
    private static void streak(MultiBufferSource buffers, Vector3f head, Vector3f fwd, float len, float w, int rgb, float k) {
        if (len < 0.05F) return;
        VertexConsumer b = buffers.getBuffer(RenderType.eyes(ArsenalFx.BEAM));
        Vector3f tail = new Vector3f(head).sub(new Vector3f(fwd).mul(len));
        ArsenalFx.ribbon(b, head, tail, w, ArsenalFx.argb(rgb, k), ArsenalFx.argb(rgb, 0.0F), 0, 1);
        ArsenalFx.ribbon(b, head, tail, w * 0.35F, ArsenalFx.argb(0xFFFFFF, k), ArsenalFx.argb(rgb, 0.0F), 0, 1);
    }

    interface PartAnim {
        void apply(String name, Matrix4f m, float px, float py, float pz);
    }

    /** Draws a projectile mesh (models/arsenal/proj/<name>.bwm) at the current pose, all layers, with an optional tint. */
    private static void mesh(PoseStack pose, MultiBufferSource buffers, String name, int light, PartAnim anim, int tint) {
        BwmModel model = MeshCache.get("proj/" + name);
        if (model == null) return;
        PoseStack.Pose ps = pose.last();
        // meshes are stored in item space (model origin at 8, 10, 8): bring the projectile centre to the entity
        Matrix4f m0 = new Matrix4f(ps.pose()).translate(-8.0F, -10.0F, -8.0F);
        Matrix3f n0 = new Matrix3f(ps.normal());
        ResourceLocation tex = BlockWars.id("textures/arsenal/proj/" + name + ".png");
        int np = model.parts.size();
        Matrix4f[] pm = new Matrix4f[np];
        Matrix3f[] nm = new Matrix3f[np];
        for (int i = 0; i < np; i++) {
            BwmModel.Part part = model.parts.get(i);
            Matrix4f local = new Matrix4f();
            if (anim != null) anim.apply(part.name, local, part.px, part.py, part.pz);
            pm[i] = new Matrix4f(m0).mul(local);
            nm[i] = new Matrix3f(n0).mul(new Matrix3f(local));
        }
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(tex));
        for (int i = 0; i < np; i++) {
            for (BwmModel.Layer l : model.parts.get(i).layers) {
                if (l.layer == BwmModel.OPAQUE) MeshCache.draw(vc, pm[i], nm[i], l, tint, light, OverlayTexture.NO_OVERLAY, false);
                else if (l.layer == BwmModel.EMISSIVE) MeshCache.draw(vc, pm[i], nm[i], l, 0xFFFFFFFF, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, true);
            }
        }
        VertexConsumer glass = null;
        for (int i = 0; i < np; i++) {
            for (BwmModel.Layer l : model.parts.get(i).layers) {
                if (l.layer != BwmModel.GLASS) continue;
                if (glass == null) glass = buffers.getBuffer(RenderType.entityTranslucent(tex));
                MeshCache.draw(glass, pm[i], nm[i], l, 0xFFFFFFFF, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, false);
            }
        }
    }

    private static void rotZ(Matrix4f m, float px, float py, float pz, float deg) {
        m.translate(px, py, pz).rotateZ(deg * Mth.DEG_TO_RAD).translate(-px, -py, -pz);
    }

    /** Turns -Z (the way meshes point) toward {@code dir}. */
    static Quaternionf orient(Vec3 dir) {
        float ry = (float) Math.atan2(-dir.x, -dir.z);
        float rx = (float) Math.asin(Mth.clamp(dir.y, -1, 1));
        return new Quaternionf().rotateY(ry).rotateX(rx);
    }

    /** Flight direction from the projectile's rotation (yRot = atan2(vx, vz), xRot = atan2(vy, horizontal)). */
    private static Vec3 rotDir(ArsenalShot e) {
        float y = e.getYRot() * Mth.DEG_TO_RAD, x = e.getXRot() * Mth.DEG_TO_RAD;
        return new Vec3(Mth.sin(y) * Mth.cos(x), Mth.sin(x), Mth.cos(y) * Mth.cos(x));
    }

    static Vector3f[] corners(Quaternionf rot, Vector3f c, float s) {
        Vector3f[] q = {new Vector3f(-s, -s, 0), new Vector3f(s, -s, 0), new Vector3f(s, s, 0), new Vector3f(-s, s, 0)};
        for (Vector3f p : q) rot.transform(p).add(c);
        return q;
    }
}
