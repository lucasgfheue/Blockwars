package com.blockwars.arsenal.client;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A smooth Arsenal mesh (.bwm): named animated parts, each split by material layer (0 opaque, 1 glass, 2 emissive),
 * with positions in item pixels, texture coordinates, normals and named metadata points.
 */
public final class BwmModel {
    public static final int OPAQUE = 0, GLASS = 1, EMISSIVE = 2;

    public static final class Layer {
        public final int layer;
        /** x, y, z, u, v, nx, ny, nz per vertex */
        public final float[] v;
        public final int[] idx;

        Layer(int layer, float[] v, int[] idx) {
            this.layer = layer;
            this.v = v;
            this.idx = idx;
        }

        public int triangles() {
            return this.idx.length / 3;
        }
    }

    public static final class Part {
        public final String name;
        /** pivot in item pixels */
        public final float px, py, pz;
        public final List<Layer> layers = new ArrayList<>();

        Part(String name, float px, float py, float pz) {
            this.name = name;
            this.px = px;
            this.py = py;
            this.pz = pz;
        }

        public boolean hasLayer(int l) {
            for (Layer ly : this.layers) if (ly.layer == l) return true;
            return false;
        }
    }

    public final List<Part> parts = new ArrayList<>();
    public final Map<String, Part> byName = new HashMap<>();
    public final Map<String, float[]> meta = new HashMap<>();
    public final float[] lo = new float[3];
    public final float[] hi = new float[3];
    public int texW, texH;
    public int triangles;

    public Part part(String name) {
        return this.byName.get(name);
    }

    public float[] meta(String key) {
        return this.meta.get(key);
    }

    public float meta(String key, int i, float def) {
        float[] m = this.meta.get(key);
        return m != null && i < m.length ? m[i] : def;
    }

    public static BwmModel read(InputStream in) throws IOException {
        DataInputStream d = new DataInputStream(in);
        byte[] magic = new byte[4];
        d.readFully(magic);
        if (magic[0] != 'B' || magic[1] != 'W' || magic[2] != 'M' || magic[3] != '1') throw new IOException("not a BWM mesh");
        int version = d.readUnsignedShort();
        if (version != 2) throw new IOException("unsupported BWM version " + version);
        BwmModel m = new BwmModel();
        float lx = d.readFloat(), ly = d.readFloat(), lz = d.readFloat();
        float qs = d.readFloat();
        m.texW = d.readUnsignedShort();
        m.texH = d.readUnsignedShort();
        m.lo[0] = Float.MAX_VALUE;
        m.lo[1] = Float.MAX_VALUE;
        m.lo[2] = Float.MAX_VALUE;
        m.hi[0] = -Float.MAX_VALUE;
        m.hi[1] = -Float.MAX_VALUE;
        m.hi[2] = -Float.MAX_VALUE;
        int nparts = d.readUnsignedByte();
        for (int p = 0; p < nparts; p++) {
            String name = str(d);
            Part part = new Part(name, d.readFloat(), d.readFloat(), d.readFloat());
            int nl = d.readUnsignedByte();
            for (int l = 0; l < nl; l++) {
                int layer = d.readUnsignedByte();
                int nv = d.readInt();
                int nt = d.readInt();
                float[] v = new float[nv * 8];
                for (int i = 0; i < nv; i++) {
                    float x = lx + d.readUnsignedShort() * qs;
                    float y = ly + d.readUnsignedShort() * qs;
                    float z = lz + d.readUnsignedShort() * qs;
                    float u = d.readUnsignedShort() / 65535.0F;
                    float vv = d.readUnsignedShort() / 65535.0F;
                    float nx = d.readByte() / 127.0F, ny = d.readByte() / 127.0F, nz = d.readByte() / 127.0F;
                    int o = i * 8;
                    v[o] = x;
                    v[o + 1] = y;
                    v[o + 2] = z;
                    v[o + 3] = u;
                    v[o + 4] = vv;
                    v[o + 5] = nx;
                    v[o + 6] = ny;
                    v[o + 7] = nz;
                    if (x < m.lo[0]) m.lo[0] = x;
                    if (y < m.lo[1]) m.lo[1] = y;
                    if (z < m.lo[2]) m.lo[2] = z;
                    if (x > m.hi[0]) m.hi[0] = x;
                    if (y > m.hi[1]) m.hi[1] = y;
                    if (z > m.hi[2]) m.hi[2] = z;
                }
                int[] idx = new int[nt * 3];
                boolean small = nv < 65536;
                for (int i = 0; i < idx.length; i++) idx[i] = small ? d.readUnsignedShort() : d.readInt();
                part.layers.add(new Layer(layer, v, idx));
                m.triangles += nt;
            }
            m.parts.add(part);
            m.byName.put(name, part);
        }
        int nmeta = d.readUnsignedByte();
        for (int i = 0; i < nmeta; i++) {
            String key = str(d);
            int n = d.readUnsignedByte();
            float[] vals = new float[n];
            for (int k = 0; k < n; k++) vals[k] = d.readFloat();
            m.meta.put(key, vals);
        }
        return m;
    }

    private static String str(DataInputStream d) throws IOException {
        int n = d.readUnsignedShort();
        byte[] b = new byte[n];
        d.readFully(b);
        return new String(b, StandardCharsets.UTF_8);
    }
}
