package com.blockwars.arsenal.client;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A smooth Arsenal mesh (.bwm): named animated parts, each split by material layer (0 opaque, 1 glass, 2 emissive),
 * with positions in item pixels, texture coordinates, normals and named metadata points.
 */
public final class BwmModel {
    public static final int OPAQUE = 0, GLASS = 1, EMISSIVE = 2;

    public static final class Layer {
        public final int layer;
        /** x, y, z, u, v, nx, ny, nz per vertex */
        public final float[] v;
        public final int[] idx;

        Layer(int layer, float[] v, int[] idx) {
            this.layer = layer;
            this.v = v;
            this.idx = idx;
        }

        public int triangles() {
            return this.idx.length / 3;
        }
    }

    public static final class Part {
        public final String name;
        /** pivot in item pixels */
        public final float px, py, pz;
        public final List<Layer> layers = new ArrayList<>();

        Part(String name, float px, float py, float pz) {
            this.name = name;
            this.px = px;
            this.py = py;
            this.pz = pz;
        }

        public boolean hasLayer(int l) {
            for (Layer ly : this.layers) if (ly.layer == l) return true;
            return false;
        }
    }

    public final List<Part> parts = new ArrayList<>();
    public final Map<String, Part> byName = new HashMap<>();
    public final Map<String, float[]> meta = new HashMap<>();
    public final float[] lo = new float[3];
    public final float[] hi = new float[3];
    public int texW, texH;
    public int triangles;

    public Part part(String name) {
        return this.byName.get(name);
    }

    public float[] meta(String key) {
        return this.meta.get(key);
    }

    public float meta(String key, int i, float def) {
        float[] m = this.meta.get(key);
        return m != null && i < m.length ? m[i] : def;
    }

    public static BwmModel read(InputStream in) throws IOException {
        DataInputStream d = new DataInputStream(new BufferedInputStream(in));
        byte[] magic = new byte[4];
        d.readFully(magic);
        if (magic[0] != 'B' || magic[1] != 'W' || magic[2] != 'M' || magic[3] != '1') throw new IOException("not a BWM mesh");
        int version = d.readUnsignedShort();
        if (version != 2 && version != 3) throw new IOException("unsupported BWM version " + version);
        BwmModel m = new BwmModel();
        float lx = d.readFloat(), ly = d.readFloat(), lz = d.readFloat();
        float qs = d.readFloat();
        m.texW = d.readUnsignedShort();
        m.texH = d.readUnsignedShort();
        m.lo[0] = Float.MAX_VALUE;
        m.lo[1] = Float.MAX_VALUE;
        m.lo[2] = Float.MAX_VALUE;
        m.hi[0] = -Float.MAX_VALUE;
        m.hi[1] = -Float.MAX_VALUE;
        m.hi[2] = -Float.MAX_VALUE;
        int nparts = d.readUnsignedByte();
        for (int p = 0; p < nparts; p++) {
            String name = str(d);
            Part part = new Part(name, d.readFloat(), d.readFloat(), d.readFloat());
            int nl = d.readUnsignedByte();
            for (int l = 0; l < nl; l++) {
                int layer = d.readUnsignedByte();
                int nv = d.readInt();
                int nt = d.readInt();
                if (nv < 0 || nt < 0 || nv > 1 << 22 || nt > 1 << 22) throw new IOException("corrupt BWM mesh");
                float[] v = new float[nv * 8];
                int[] idx = new int[nt * 3];
                if (version == 2) {
                    for (int i = 0; i < nv; i++) {
                        int o = i * 8;
                        v[o] = lx + d.readUnsignedShort() * qs;
                        v[o + 1] = ly + d.readUnsignedShort() * qs;
                        v[o + 2] = lz + d.readUnsignedShort() * qs;
                        v[o + 3] = d.readUnsignedShort() / 65535.0F;
                        v[o + 4] = d.readUnsignedShort() / 65535.0F;
                        v[o + 5] = d.readByte() / 127.0F;
                        v[o + 6] = d.readByte() / 127.0F;
                        v[o + 7] = d.readByte() / 127.0F;
                    }
                    boolean small = nv < 65536;
                    for (int i = 0; i < idx.length; i++) idx[i] = small ? d.readUnsignedShort() : d.readInt();
                } else {
                    readLayerV3(d, nv, lx, ly, lz, qs, v, idx);
                }
                for (int i = 0; i < nv; i++) {
                    int o = i * 8;
                    float x = v[o], y = v[o + 1], z = v[o + 2];
                    if (x < m.lo[0]) m.lo[0] = x;
                    if (y < m.lo[1]) m.lo[1] = y;
                    if (z < m.lo[2]) m.lo[2] = z;
                    if (x > m.hi[0]) m.hi[0] = x;
                    if (y > m.hi[1]) m.hi[1] = y;
                    if (z > m.hi[2]) m.hi[2] = z;
                }
                for (int i : idx) if (i < 0 || i >= nv) throw new IOException("corrupt BWM mesh");
                part.layers.add(new Layer(layer, v, idx));
                m.triangles += nt;
            }
            m.parts.add(part);
            m.byName.put(name, part);
        }
        int nmeta = d.readUnsignedByte();
        for (int i = 0; i < nmeta; i++) {
            String key = str(d);
            int n = d.readUnsignedByte();
            float[] vals = new float[n];
            for (int k = 0; k < n; k++) vals[k] = d.readFloat();
            m.meta.put(key, vals);
        }
        return m;
    }

    /**
     * Version 3 layer: dictionary tables of positions, texture coordinates and normals (u16 values as zigzag deltas)
     * plus per-vertex table ids and triangle corners as "high-water" codes, every u16 stream split into a low-byte and
     * a high-byte plane. Decodes to exactly the values of version 2.
     */
    private static void readLayerV3(DataInputStream d, int nv, float lx, float ly, float lz, float qs, float[] v, int[] idx) throws IOException {
        int npos = d.readInt(), nuv = d.readInt(), nnrm = d.readInt();
        if (npos < 0 || nuv < 0 || nnrm < 0 || npos > nv || nuv > nv || nnrm > nv) throw new IOException("corrupt BWM mesh");
        int[] px = deltas(d, npos), py = deltas(d, npos), pz = deltas(d, npos);
        int[] pid = ids(d, nv, npos);
        int[] tu = deltas(d, nuv), tv = deltas(d, nuv);
        int[] uid = ids(d, nv, nuv);
        byte[] nx = new byte[nnrm], ny = new byte[nnrm], nz = new byte[nnrm];
        d.readFully(nx);
        d.readFully(ny);
        d.readFully(nz);
        int[] nid = ids(d, nv, nnrm);
        int[] corners = ids(d, idx.length, nv);
        for (int i = 0; i < nv; i++) {
            int o = i * 8, p = pid[i], t = uid[i], n = nid[i];
            v[o] = lx + px[p] * qs;
            v[o + 1] = ly + py[p] * qs;
            v[o + 2] = lz + pz[p] * qs;
            v[o + 3] = tu[t] / 65535.0F;
            v[o + 4] = tv[t] / 65535.0F;
            v[o + 5] = nx[n] / 127.0F;
            v[o + 6] = ny[n] / 127.0F;
            v[o + 7] = nz[n] / 127.0F;
        }
        System.arraycopy(corners, 0, idx, 0, idx.length);
    }

    /** {@code n} unsigned 16-bit values stored as a low-byte plane followed by a high-byte plane */
    private static int[] u16(DataInputStream d, int n) throws IOException {
        byte[] lo = new byte[n], hi = new byte[n];
        d.readFully(lo);
        d.readFully(hi);
        int[] r = new int[n];
        for (int i = 0; i < n; i++) r[i] = (lo[i] & 0xFF) | (hi[i] & 0xFF) << 8;
        return r;
    }

    /** zigzag deltas (modulo 2^16) back to absolute u16 values */
    private static int[] deltas(DataInputStream d, int n) throws IOException {
        int[] r = u16(d, n);
        int prev = 0;
        for (int i = 0; i < n; i++) {
            int z = r[i];
            prev = (prev + ((z >>> 1) ^ -(z & 1))) & 0xFFFF;
            r[i] = prev;
        }
        return r;
    }

    /** high-water codes: 0 is the next new id, k > 0 the id k below it; every id must be below {@code limit} */
    private static int[] ids(DataInputStream d, int n, int limit) throws IOException {
        int[] r = u16(d, n);
        int hw = 0;
        for (int i = 0; i < n; i++) {
            int t = r[i];
            if (t > hw) throw new IOException("corrupt BWM mesh");
            int id = hw - t;
            if (t == 0) hw++;
            if (id >= limit) throw new IOException("corrupt BWM mesh");
            r[i] = id;
        }
        return r;
    }

    private static String str(DataInputStream d) throws IOException {
        int n = d.readUnsignedShort();
        byte[] b = new byte[n];
        d.readFully(b);
        return new String(b, StandardCharsets.UTF_8);
    }
}
