package com.blockwars.arsenal.client;

import com.blockwars.BlockWars;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/** Loads .bwm meshes on first use, forgets them on resource reload, and streams them into vertex consumers. */
public final class MeshCache implements ResourceManagerReloadListener {
    public static final MeshCache INSTANCE = new MeshCache();
    private static final Logger LOG = LoggerFactory.getLogger("BlockWars/Arsenal");
    private static final Map<String, Optional<BwmModel>> CACHE = new ConcurrentHashMap<>();

    private MeshCache() {}

    @Override
    public void onResourceManagerReload(ResourceManager manager) {
        CACHE.clear();
    }

    /** {@code path} relative to models/arsenal without extension, e.g. "pulsar" or "proj/wasp". */
    @Nullable
    public static BwmModel get(String path) {
        return CACHE.computeIfAbsent(path, MeshCache::load).orElse(null);
    }

    private static Optional<BwmModel> load(String path) {
        ResourceLocation rl = BlockWars.id("models/arsenal/" + path + ".bwm");
        try {
            Optional<Resource> res = Minecraft.getInstance().getResourceManager().getResource(rl);
            if (res.isEmpty()) {
                LOG.warn("Missing arsenal mesh {}", rl);
                return Optional.empty();
            }
            try (InputStream in = res.get().open()) {
                return Optional.of(BwmModel.read(in));
            }
        } catch (Exception e) {
            LOG.error("Could not read arsenal mesh {}", rl, e);
            return Optional.empty();
        }
    }

    // ------------------------------------------------------------------ drawing

    private static final Vector3f TMP = new Vector3f();
    private static final Vector3f TMPN = new Vector3f();

    /**
     * Streams one layer as degenerate quads (a, b, c, c). {@code m} maps item pixels to the target space,
     * {@code n} transforms normals. {@code argb} tints, {@code upNormal} forces flat full lighting (emissive).
     */
    public static void draw(VertexConsumer vc, Matrix4f m, Matrix3f n, BwmModel.Layer l, int argb, int light, int overlay, boolean upNormal) {
        float[] v = l.v;
        int[] idx = l.idx;
        for (int t = 0; t < idx.length; t += 3) {
            for (int k = 0; k < 4; k++) {
                int o = idx[t + Math.min(k, 2)] * 8;
                m.transformPosition(v[o], v[o + 1], v[o + 2], TMP);
                if (upNormal) {
                    TMPN.set(0.0F, 1.0F, 0.0F);
                } else {
                    n.transform(v[o + 5], v[o + 6], v[o + 7], TMPN);
                    float len = TMPN.length();
                    if (len > 1.0E-6F) TMPN.div(len);
                }
                vc.addVertex(TMP.x, TMP.y, TMP.z, argb, v[o + 3], v[o + 4], overlay, light, TMPN.x, TMPN.y, TMPN.z);
            }
        }
    }
}
