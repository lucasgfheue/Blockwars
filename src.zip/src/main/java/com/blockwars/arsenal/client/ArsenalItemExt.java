package com.blockwars.arsenal.client;

import com.blockwars.arsenal.ArsenalItem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

/** Arsenal weapons: custom renderer, both arms up in third person, full first-person placement. */
public class ArsenalItemExt implements IClientItemExtensions {
    @Override
    public BlockEntityWithoutLevelRenderer getCustomRenderer() {
        return ArsenalItemRenderer.get();
    }

    @Override
    public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
        return hand == InteractionHand.MAIN_HAND ? HumanoidModel.ArmPose.CROSSBOW_HOLD : null;
    }

    @Override
    public boolean applyForgeHandTransform(PoseStack pose, LocalPlayer player, HumanoidArm arm, ItemStack stack, float partialTick,
                                           float equipProcess, float swingProcess) {
        // main hand only. (Not an identity check against the player's stack: the hand renderer keeps the previous stack
        // object until its next tick, and every ammo change on the server brings a new one.)
        if (!(stack.getItem() instanceof ArsenalItem it) || arm != player.getMainArm()) return false;
        int side = arm == HumanoidArm.RIGHT ? 1 : -1;
        BwmModel model = MeshCache.get(it.def.id);
        pose.mulPose(ArsenalView.hand(player, stack, it.def, model, side, partialTick, equipProcess));
        return true;
    }
}
