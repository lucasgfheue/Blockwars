package com.blockwars.arsenal.client;

import com.blockwars.arsenal.ArsenalShot;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;

/**
 * A looping sound that follows an entity: the hum of a continuous weapon while its owner fires (fades in and out), or
 * the buzz of a robot wasp in flight.
 */
final class ArsenalLoop extends AbstractTickableSoundInstance {
    private final Entity follow;
    private final boolean shot;
    private boolean on = true;

    ArsenalLoop(SoundEvent event, Entity follow) {
        super(event, SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
        this.follow = follow;
        this.shot = follow instanceof ArsenalShot;
        this.looping = true;
        this.delay = 0;
        this.volume = this.shot ? 0.9F : 0.05F;
        this.pitch = this.shot ? 0.9F + (follow.getId() % 7) * 0.04F : 1.0F;
        this.x = follow.getX();
        this.y = follow.getEyeY();
        this.z = follow.getZ();
    }

    /** Continuous weapons: keep playing while {@code firing}, fade out otherwise. */
    void keep(boolean firing) {
        this.on = firing;
    }

    @Override
    public void tick() {
        if (this.follow.isRemoved() || this.shot && ((ArsenalShot) this.follow).shotState() != ArsenalShot.FLYING) {
            this.stop();
            return;
        }
        this.x = this.follow.getX();
        this.y = this.shot ? this.follow.getY() : this.follow.getEyeY();
        this.z = this.follow.getZ();
        if (this.shot) return;
        if (this.on) {
            this.volume = Math.min(1.0F, this.volume + 0.3F);
        } else {
            this.volume -= 0.2F;
            if (this.volume <= 0.02F) {
                this.volume = 0.0F;
                this.stop();
            }
        }
    }
}
