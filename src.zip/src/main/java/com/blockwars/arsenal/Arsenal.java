package com.blockwars.arsenal;

import com.blockwars.BlockWars;
import com.blockwars.ModItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.LinkedHashMap;
import java.util.Map;

/** BlockWars Arsenal: twenty fictional weapons, their ammunition, upgrades, sounds, particles and projectile entity. */
public final class Arsenal {
    private Arsenal() {}

    public static final Map<String, DeferredItem<ArsenalItem>> WEAPONS = new LinkedHashMap<>();
    public static final Map<String, DeferredItem<ArsenalAmmoItem>> AMMO = new LinkedHashMap<>();
    public static final Map<ArsenalModule, DeferredItem<ArsenalModuleItem>> MODULES = new LinkedHashMap<>();

    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BlockWars.MODID);

    static {
        for (ArsenalDef d : ArsenalCatalog.ALL) {
            WEAPONS.put(d.id, ModItems.ITEMS.register(d.id, () -> new ArsenalItem(
                    new Item.Properties().stacksTo(1).rarity(d.dangerous ? Rarity.EPIC : rarity(d)), d)));
        }
        for (ArsenalCatalog.AmmoDef a : ArsenalCatalog.AMMO) {
            AMMO.put(a.id(), ModItems.ITEMS.register(a.id(), () -> new ArsenalAmmoItem(new Item.Properties().stacksTo(a.stack()), a)));
        }
        for (ArsenalModule m : ArsenalModule.values()) {
            MODULES.put(m, ModItems.ITEMS.register(m.itemId, () -> new ArsenalModuleItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON), m)));
        }
    }

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("arsenal", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.blockwars.arsenal"))
            .icon(() -> WEAPONS.values().iterator().next().get().getDefaultInstance())
            .displayItems((params, out) -> {
                for (ArsenalDef d : ArsenalCatalog.ALL) {
                    out.accept(WEAPONS.get(d.id).get());
                    DeferredItem<ArsenalAmmoItem> a = AMMO.get(d.ammo);
                    if (a != null) out.accept(a.get());
                }
                for (DeferredItem<ArsenalModuleItem> m : MODULES.values()) out.accept(m.get());
            })
            .build());

    private static Rarity rarity(ArsenalDef d) {
        return switch (d.cat) {
            case PISTOL, BUBBLE, CARDS -> Rarity.COMMON;
            case SHOTGUN, RIFLE, FLAMER, SONIC, GOO, HARPOON, BOOMERANG, DISC -> Rarity.UNCOMMON;
            default -> Rarity.RARE;
        };
    }

    /** Called from the mod constructor before the item register is attached to the bus. */
    public static void init(IEventBus modBus) {
        ArsenalSounds.SOUNDS.register(modBus);
        ArsenalParticles.PARTICLES.register(modBus);
        ArsenalEntities.ENTITY_TYPES.register(modBus);
        TABS.register(modBus);
        modBus.addListener(ArsenalNet::register);
        // a trigger held while logging out, dying or changing dimension must not keep firing afterwards
        NeoForge.EVENT_BUS.addListener(Arsenal::onLogout);
        NeoForge.EVENT_BUS.addListener(Arsenal::onRespawn);
        NeoForge.EVENT_BUS.addListener(Arsenal::onChangeDimension);
    }

    private static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        ArsenalLogic.forget(event.getEntity());
    }

    private static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        ArsenalLogic.forget(event.getEntity());
    }

    private static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        ArsenalLogic.forget(event.getEntity());
    }

    public static ArsenalDef def(int index) {
        return index >= 0 && index < ArsenalCatalog.ALL.size() ? ArsenalCatalog.ALL.get(index) : null;
    }
}
