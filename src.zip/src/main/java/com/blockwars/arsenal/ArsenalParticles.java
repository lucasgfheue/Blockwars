package com.blockwars.arsenal;

import com.blockwars.BlockWars;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Arsenal effect particles. All carry a 24-bit payload (a colour, or a weapon index for the weapon-styled effects);
 * several use the velocity arguments as data (scorch marks: the face normal scaled by size; beams: the vector to the far end).
 */
public final class ArsenalParticles {
    private ArsenalParticles() {}

    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(Registries.PARTICLE_TYPE, BlockWars.MODID);

    // ------------------------------------------------------------------ light effects (drawn by the client FX layer)
    /** muzzle flash seen by other players / in third person: payload = weapon index, velocity = direction * size */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> FLASH = register("a_flash", true);
    /** explosion fireball: velocity.x = size */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> BLAST = register("a_blast", true);
    /** weapon beam: payload = weapon index, velocity = vector to the far end */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> BEAM = register("a_beam", true);
    /** electric arc: payload = weapon index, velocity = vector to the far end */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> ARC = register("a_arc", true);
    /** expanding ring: velocity = normal * radius (zero: faces the camera) */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> RING = register("a_ring", true);
    /** sonic wave front travelling forward: payload = weapon index, velocity = direction * range */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> WAVE = register("a_wave", true);
    /** singularity collapse: velocity.x = blast radius */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> IMPLODE = register("a_implode", true);
    /** magic circle on the ground where a meteor will land: velocity.x = radius, velocity.y = ticks until impact */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> SIGIL = register("a_sigil", true);

    // ------------------------------------------------------------------ world particles (sprite sets)
    /** smoke, vapour and dust */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> SMOKE = register("a_smoke", false);
    /** hot spark streak */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> SPARK = register("a_spark", false);
    /** soft glow orb (energy trails, impact glows) */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> GLOW = register("a_glow", false);
    /** fire puff / dragon fire */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> FIRE = register("a_fire", false);
    /** scorch mark: velocity = face normal * size */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> SCORCH = register("a_scorch", false);
    /** paper confetti and sprinkles: payload 0 = random party colours */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> CONFETTI = register("a_confetti", false);
    /** glittering frost flakes */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> FROST = register("a_frost", false);
    /** candy wrappers thrown out by the pump of «Dulce Venganza» */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> WRAPPER = register("a_wrapper", false);
    /** soap bubble that drifts up and pops («Pompa») */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> BUBBLE = register("a_bubble", false);
    /** card suit that tumbles down («Comodín»): payload 0 = red or black at random */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> SUIT = register("a_suit", false);
    /** drop of goo that falls and splats («Pegote») */
    public static final DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> DRIP = register("a_drip", false);

    /** Exact 24-bit payload (colour, or a weapon index). */
    public static ColorParticleOption of(DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> type, int rgb) {
        return ColorParticleOption.create(type.get(), 0xFF000000 | (rgb & 0xFFFFFF));
    }

    /** Reads the 24-bit payload back on the client. */
    public static int payload(ColorParticleOption o) {
        return (Math.round(o.getRed() * 255.0F) << 16) | (Math.round(o.getGreen() * 255.0F) << 8) | Math.round(o.getBlue() * 255.0F);
    }

    private static DeferredHolder<ParticleType<?>, ParticleType<ColorParticleOption>> register(String name, boolean alwaysShow) {
        return PARTICLES.register(name, () -> new ParticleType<ColorParticleOption>(alwaysShow) {
            @Override
            public MapCodec<ColorParticleOption> codec() {
                return ColorParticleOption.codec(this);
            }

            @Override
            public StreamCodec<? super RegistryFriendlyByteBuf, ColorParticleOption> streamCodec() {
                return ColorParticleOption.streamCodec(this);
            }
        });
    }
}
