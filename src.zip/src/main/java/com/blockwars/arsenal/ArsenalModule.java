package com.blockwars.arsenal;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.Map;

/**
 * Weapon upgrades. Each one changes how the weapon behaves, not just a number; one per slot.
 * Which ones fit is decided per weapon ({@link ArsenalDef#modMask}).
 */
public enum ArsenalModule {
    /** overclocked core: fires 30% faster and hits 20% harder, but heats up 60% faster */
    OVERCLOCK(Slot.CORE, "mejora_nucleo_sobrecargado"),
    /** expanded chamber: half again as much ammunition, a little slower to reload */
    EXTMAG(Slot.MAG, "mejora_recamara_ampliada"),
    /** gyro stabiliser: 40% less recoil and a much tighter spread from the hip */
    STABILIZER(Slot.GRIP, "mejora_estabilizador"),
    /** long-range visor: 4x zoom when aiming and perfect aimed accuracy */
    SCOPE(Slot.OPTIC, "mejora_visor"),
    /** igneous core: every hit sets the target on fire */
    INCENDIARY(Slot.ELEMENT, "mejora_nucleo_igneo"),
    /** gelid core: every hit chills and slows the target */
    CRYO(Slot.ELEMENT, "mejora_nucleo_gelido"),
    /** voltaic core: hits jolt the target and arc to one more enemy nearby */
    SHOCK(Slot.ELEMENT, "mejora_nucleo_voltaico");

    public enum Slot { CORE, MAG, GRIP, OPTIC, ELEMENT }

    public final Slot slot;
    public final String itemId;

    ArsenalModule(Slot slot, String itemId) {
        this.slot = slot;
        this.itemId = itemId;
    }

    public int bit() {
        return 1 << this.ordinal();
    }

    public boolean fits(ArsenalDef d) {
        return (d.modMask & this.bit()) != 0;
    }

    @Nullable
    public static ArsenalModule byName(String n) {
        for (ArsenalModule m : values()) if (m.name().equals(n)) return m;
        return null;
    }

    // ------------------------------------------------------------------ stack helpers

    public static Map<Slot, ArsenalModule> installed(ItemStack s) {
        Map<Slot, ArsenalModule> out = new EnumMap<>(Slot.class);
        CompoundTag t = ArsenalData.read(s).getCompound("Mods");
        for (Slot sl : Slot.values()) {
            ArsenalModule m = byName(t.getString(sl.name()));
            if (m != null) out.put(sl, m);
        }
        return out;
    }

    public static boolean has(ItemStack s, ArsenalModule m) {
        return ArsenalData.read(s).getCompound("Mods").getString(m.slot.name()).equals(m.name());
    }

    @Nullable
    public static ArsenalModule in(ItemStack s, Slot slot) {
        return byName(ArsenalData.read(s).getCompound("Mods").getString(slot.name()));
    }

    public static void set(ItemStack s, Slot slot, @Nullable ArsenalModule m) {
        ArsenalData.edit(s, t -> {
            CompoundTag mods = t.getCompound("Mods");
            if (m == null) mods.remove(slot.name());
            else mods.putString(slot.name(), m.name());
            if (mods.isEmpty()) t.remove("Mods");
            else t.put("Mods", mods);
        });
    }

    // ------------------------------------------------------------------ effective stats

    public static int mag(ItemStack s, ArsenalDef d) {
        return has(s, EXTMAG) ? Math.round(d.mag * 1.5F) : d.mag;
    }

    public static float damageMul(ItemStack s) {
        return has(s, OVERCLOCK) ? 1.2F : 1.0F;
    }

    public static float cooldownMul(ItemStack s) {
        return has(s, OVERCLOCK) ? 0.77F : 1.0F;
    }

    public static float heatMul(ItemStack s) {
        return has(s, OVERCLOCK) ? 1.6F : 1.0F;
    }

    public static float chargeMul(ItemStack s) {
        return has(s, OVERCLOCK) ? 0.75F : 1.0F;
    }

    public static float reloadMul(ItemStack s) {
        return has(s, EXTMAG) ? 1.2F : 1.0F;
    }

    public static float hipSpreadMul(ItemStack s) {
        return has(s, STABILIZER) ? 0.55F : 1.0F;
    }

    public static float adsSpreadMul(ItemStack s) {
        if (has(s, SCOPE)) return 0.0F;
        return has(s, STABILIZER) ? 0.8F : 1.0F;
    }

    public static float pelletSpreadMul(ItemStack s) {
        return has(s, STABILIZER) ? 0.75F : 1.0F;
    }

    public static float recoilMul(ItemStack s) {
        return has(s, STABILIZER) ? 0.6F : 1.0F;
    }

    public static float loudnessMul(ItemStack s) {
        return 1.0F;
    }

    /** Elemental core installed, or null. */
    @Nullable
    public static ArsenalModule element(ItemStack s) {
        return in(s, Slot.ELEMENT);
    }
}
