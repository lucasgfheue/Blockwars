package com.blockwars.arsenal;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** A weapon module item. Installed with the module in the off hand: sneak + mode key. */
public class ArsenalModuleItem extends Item {
    public final ArsenalModule module;

    public ArsenalModuleItem(Properties props, ArsenalModule module) {
        super(props);
        this.module = module;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("arsenal.blockwars.slot." + this.module.slot.name().toLowerCase()).withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("item.blockwars." + this.module.itemId + ".desc").withStyle(ChatFormatting.GRAY));
        int n = 0;
        for (ArsenalDef d : ArsenalCatalog.ALL) if (this.module.fits(d)) n++;
        tooltip.add(Component.translatable("arsenal.blockwars.fits", n).withStyle(ChatFormatting.DARK_GREEN));
        tooltip.add(Component.translatable("arsenal.blockwars.install_howto").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
    }
}
