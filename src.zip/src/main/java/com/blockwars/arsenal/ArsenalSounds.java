package com.blockwars.arsenal;

import com.blockwars.BlockWars;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.HashMap;
import java.util.Map;

/**
 * Every Arsenal weapon has its own fire, reload, equip and special sound (charge whine, spin-up, pump, hum...), plus a
 * shared set of impacts, loops and handling noises.
 */
public final class ArsenalSounds {
    private ArsenalSounds() {}

    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, BlockWars.MODID);
    private static final Map<String, DeferredHolder<SoundEvent, SoundEvent>> BY_KEY = new HashMap<>();

    public static final String[] SLOTS = {"fire", "reload", "equip", "special"};
    public static final String[] SHARED = {"dry", "mode", "round", "upgrade", "hit", "kill", "head", "impact_glass", "energy_hit",
            "boom_small", "boom_big", "overheat", "zap", "candy_pop", "candy_bounce", "ice_shatter", "gravity", "void_open",
            "void_collapse", "wasp_pop", "wasp_buzz", "plasma_hit", "beam_loop", "flame_loop", "wrapper", "inspect"};

    static {
        for (ArsenalDef d : ArsenalCatalog.ALL) {
            for (String slot : SLOTS) register("arsenal." + d.id + "." + slot);
        }
        for (String s : SHARED) register("arsenal." + s);
    }

    private static void register(String key) {
        BY_KEY.put(key, SOUNDS.register(key, () -> SoundEvent.createVariableRangeEvent(BlockWars.id(key))));
    }

    public static SoundEvent get(String key) {
        DeferredHolder<SoundEvent, SoundEvent> h = BY_KEY.get(key);
        return h != null ? h.get() : SoundEvents.IRON_GOLEM_STEP;
    }

    public static SoundEvent weapon(ArsenalDef d, String slot) {
        return get("arsenal." + d.id + "." + slot);
    }

    public static SoundEvent shared(String s) {
        return get("arsenal." + s);
    }
}
