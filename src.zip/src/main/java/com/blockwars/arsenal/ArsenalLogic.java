package com.blockwars.arsenal;

import com.blockwars.arsenal.ArsenalDef.Fire;
import com.blockwars.arsenal.ArsenalDef.Proj;
import com.blockwars.arsenal.ArsenalDef.Special;
import com.blockwars.entity.BaseMechaEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileDeflection;
import net.minecraft.world.entity.projectile.ThrownEnderpearl;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Server side of the Arsenal: triggers, fire modes, ammunition, upgrades, reloading, heat, charge, every kind of shot
 * (rings, wasps, ice lances, chain lightning, candy, singularities, fire, lasers, shock waves, plasma) and the impacts.
 */
public final class ArsenalLogic {
    private ArsenalLogic() {}

    private static final class State {
        boolean trigger;
        int hold;
        int cooldown;
        int burstLeft;
        int slot = -1;
        int spin;
        float fireAcc;
        int beamSound;
        int shots;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    private static State state(Player p) {
        return STATES.computeIfAbsent(p.getUUID(), k -> new State());
    }

    @Nullable
    private static ArsenalItem held(ServerPlayer p) {
        if (p.getVehicle() instanceof BaseMechaEntity || p.isSpectator()) return null;
        return p.getMainHandItem().getItem() instanceof ArsenalItem a ? a : null;
    }

    public static void forget(Player p) {
        STATES.remove(p.getUUID());
    }

    // ============================================================== network entry

    public static void action(ServerPlayer p, byte a) {
        ArsenalItem it = held(p);
        State st = state(p);
        if (it == null) {
            st.trigger = false;
            return;
        }
        ItemStack s = p.getMainHandItem();
        ArsenalDef d = it.def;
        switch (a) {
            case ArsenalNet.TRIGGER_DOWN -> triggerDown(p, s, d, st);
            case ArsenalNet.TRIGGER_UP -> triggerUp(p, s, d, st);
            case ArsenalNet.RELOAD -> startReload(p, s, d);
            case ArsenalNet.MODE -> modeKey(p, s, d);
            default -> { }
        }
    }

    private static void triggerDown(ServerPlayer p, ItemStack s, ArsenalDef d, State st) {
        if (st.trigger) return;
        st.trigger = true;
        st.hold = 0;
        if (ArsenalData.reloading(s) && ArsenalData.reloadKind(s) == ArsenalData.REL_ROUND && ArsenalData.ammo(s) > 0) {
            ArsenalData.edit(s, t -> {
                t.remove("RelEnd");
                t.remove("RelLen");
                t.remove("RelKind");
            });
        }
        switch (d.mode(ArsenalData.mode(s))) {
            case SEMI -> tryShoot(p, s, d, 1.0F);
            case BURST -> {
                if (st.burstLeft <= 0 && st.cooldown <= 0) st.burstLeft = d.burst;
            }
            case CHARGE -> {
                if (!canShoot(p, s, d, true)) st.trigger = false;
                else playOthers(p, ArsenalSounds.weapon(d, "special"), 1.0F, 1.0F);
            }
            default -> { }
        }
    }

    private static void triggerUp(ServerPlayer p, ItemStack s, ArsenalDef d, State st) {
        if (!st.trigger) return;
        st.trigger = false;
        if (d.mode(ArsenalData.mode(s)) == Fire.CHARGE) {
            int full = chargeTicks(s, d);
            if (st.hold >= Math.max(3, full / 4)) tryShoot(p, s, d, Mth.clamp(st.hold / (float) full, 0.0F, 1.0F));
            else p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.4F, 1.6F);
        }
        st.hold = 0;
    }

    /** Mode key: next fire mode; with sneak, install the upgrade in the off hand (or strip them all). */
    private static void modeKey(ServerPlayer p, ItemStack s, ArsenalDef d) {
        if (p.isShiftKeyDown()) {
            installModule(p, s, d);
            return;
        }
        if (d.modes.length < 2) return;
        int m = (ArsenalData.mode(s) + 1) % d.modes.length;
        ArsenalData.edit(s, t -> t.putInt("Mode", m));
        state(p).burstLeft = 0;
        playAll(p, ArsenalSounds.shared("mode"), 0.7F, 1.0F);
        p.displayClientMessage(Component.translatable("arsenal.blockwars.mode." + d.mode(m).name().toLowerCase()), true);
    }

    // ============================================================== upgrades

    private static void installModule(ServerPlayer p, ItemStack s, ArsenalDef d) {
        if (ArsenalData.reloading(s)) return;
        ItemStack off = p.getOffhandItem();
        if (off.getItem() instanceof ArsenalModuleItem mi) {
            ArsenalModule m = mi.module;
            if (!m.fits(d)) {
                p.displayClientMessage(Component.translatable("arsenal.blockwars.module_unfit"), true);
                playAll(p, ArsenalSounds.shared("dry"), 0.6F, 0.6F);
                return;
            }
            ArsenalModule old = ArsenalModule.in(s, m.slot);
            if (old == m) return;
            off.shrink(1);
            ArsenalModule.set(s, m.slot, m);
            if (old != null) giveBack(p, new ItemStack(Arsenal.MODULES.get(old).get()));
            clampAmmo(p, s, d);
            playAll(p, ArsenalSounds.shared("upgrade"), 1.0F, 1.2F);
            p.displayClientMessage(Component.translatable("arsenal.blockwars.module_on", Component.translatable("item.blockwars." + m.itemId)), true);
            return;
        }
        if (!off.isEmpty()) {
            p.displayClientMessage(Component.translatable("arsenal.blockwars.install_howto"), true);
            return;
        }
        var mods = ArsenalModule.installed(s);
        if (mods.isEmpty()) {
            p.displayClientMessage(Component.translatable("arsenal.blockwars.install_howto"), true);
            return;
        }
        for (var e : mods.entrySet()) {
            ArsenalModule.set(s, e.getKey(), null);
            giveBack(p, new ItemStack(Arsenal.MODULES.get(e.getValue()).get()));
        }
        clampAmmo(p, s, d);
        playAll(p, ArsenalSounds.shared("upgrade"), 1.0F, 0.8F);
        p.displayClientMessage(Component.translatable("arsenal.blockwars.module_off"), true);
    }

    private static void giveBack(ServerPlayer p, ItemStack it) {
        if (!p.getInventory().add(it)) p.drop(it, false);
    }

    private static void clampAmmo(ServerPlayer p, ItemStack s, ArsenalDef d) {
        int max = ArsenalModule.mag(s, d);
        int ammo = ArsenalData.ammo(s);
        if (ammo <= max) return;
        ArsenalData.setAmmo(s, max);
        if (d.reload != ArsenalDef.Reload.CELL && !p.isCreative()) {
            var item = Arsenal.AMMO.get(d.ammo);
            if (item != null) giveBack(p, new ItemStack(item.get(), ammo - max));
        }
    }

    public static int chargeTicks(ItemStack s, ArsenalDef d) {
        return Math.max(4, Math.round(d.chargeTicks * ArsenalModule.chargeMul(s)));
    }

    // ============================================================== ammunition

    private static int count(Player p, String ammoId) {
        int n = 0;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.getItem() instanceof ArsenalAmmoItem ai && ai.ammo.id().equals(ammoId)) n += s.getCount();
        }
        return n;
    }

    private static int take(Player p, String ammoId, int max) {
        int got = 0;
        ItemStack off = p.getOffhandItem();
        if (off.getItem() instanceof ArsenalAmmoItem ai && ai.ammo.id().equals(ammoId)) {
            int k = Math.min(max, off.getCount());
            off.shrink(k);
            got += k;
        }
        for (int i = 0; i < p.getInventory().getContainerSize() && got < max; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.getItem() instanceof ArsenalAmmoItem ai && ai.ammo.id().equals(ammoId)) {
                int k = Math.min(max - got, s.getCount());
                s.shrink(k);
                got += k;
            }
        }
        return got;
    }

    /** Shots available in the inventory (a cell item refills the whole weapon). */
    public static int reserve(Player p, ArsenalDef d) {
        return count(p, d.ammo) * Math.max(1, d.reload == ArsenalDef.Reload.CELL ? d.mag : d.ammoPerItem);
    }

    private static void startReload(ServerPlayer p, ItemStack s, ArsenalDef d) {
        if (!d.usesAmmo() || ArsenalData.reloading(s)) return;
        int ammo = ArsenalData.ammo(s);
        if (ammo >= ArsenalModule.mag(s, d)) return;
        if (!p.isCreative() && count(p, d.ammo) <= 0) {
            p.displayClientMessage(Component.translatable("arsenal.blockwars.no_ammo", Component.translatable("item.blockwars." + d.ammo)), true);
            playAll(p, ArsenalSounds.shared("dry"), 0.8F, 0.8F);
            return;
        }
        long now = p.level().getGameTime();
        int kind;
        int len;
        if (d.reload == ArsenalDef.Reload.ROUND) {
            kind = ArsenalData.REL_ROUND;
            len = d.roundTicks;
        } else {
            kind = ammo == 0 ? ArsenalData.REL_EMPTY : ArsenalData.REL_TACTICAL;
            len = Math.round((ammo == 0 ? d.reloadEmptyTicks : d.reloadTicks) * ArsenalModule.reloadMul(s));
        }
        int fk = kind, fl = len;
        ArsenalData.edit(s, t -> {
            t.putLong("RelEnd", now + fl);
            t.putInt("RelLen", fl);
            t.putInt("RelKind", fk);
        });
        state(p).burstLeft = 0;
        p.level().playSound(null, p.getX(), p.getY() + 1, p.getZ(), ArsenalSounds.weapon(d, "reload"), SoundSource.PLAYERS, 0.9F, 1.0F);
    }

    private static void finishReload(ServerPlayer p, ItemStack s, ArsenalDef d) {
        CompoundTag t = ArsenalData.read(s);
        int kind = t.getInt("RelKind");
        int ammo = ArsenalData.ammo(s);
        int mag = ArsenalModule.mag(s, d);
        boolean creative = p.isCreative();
        ArsenalData.edit(s, tag -> {
            tag.remove("RelEnd");
            tag.remove("RelLen");
            tag.remove("RelKind");
        });
        if (kind == ArsenalData.REL_ROUND) {
            if (ammo >= mag) return;
            int got = creative ? 1 : take(p, d.ammo, 1);
            if (got <= 0) return;
            int n = Math.min(mag, ammo + Math.max(1, d.ammoPerItem));
            ArsenalData.setAmmo(s, n);
            playAll(p, ArsenalSounds.shared("round"), 0.7F, 0.95F + p.getRandom().nextFloat() * 0.1F);
            if (n < mag && (creative || count(p, d.ammo) > 0)) {
                long now = p.level().getGameTime();
                ArsenalData.edit(s, tag -> {
                    tag.putLong("RelEnd", now + d.roundTicks);
                    tag.putInt("RelLen", d.roundTicks);
                    tag.putInt("RelKind", ArsenalData.REL_ROUND);
                });
            }
            return;
        }
        if (d.reload == ArsenalDef.Reload.CELL) {
            if (!creative && take(p, d.ammo, 1) < 1) return;
            ArsenalData.setAmmo(s, mag);
            return;
        }
        int need = mag - ammo;
        int perItem = Math.max(1, d.ammoPerItem);
        int items = (need + perItem - 1) / perItem;
        int got = creative ? items : take(p, d.ammo, items);
        ArsenalData.setAmmo(s, Math.min(mag, ammo + got * perItem));
    }

    // ============================================================== ticking

    public static void inventoryTick(ServerPlayer p, ItemStack s, ArsenalDef d, int slot, boolean selected) {
        long now = p.level().getGameTime();
        CompoundTag t = ArsenalData.read(s);
        if (t.contains("RelEnd") && now >= t.getLong("RelEnd")) {
            if (selected) finishReload(p, s, d);
            else ArsenalData.edit(s, tag -> {
                tag.remove("RelEnd");
                tag.remove("RelLen");
                tag.remove("RelKind");
            });
        }
        if (d.usesHeat() && t.getBoolean("Lock") && ArsenalData.heat(s, now, heatDecay(d)) <= 0.15F) {
            ArsenalData.setHeat(s, ArsenalData.heat(s, now, heatDecay(d)), now, false);
            p.level().playSound(null, p.getX(), p.getY() + 1, p.getZ(), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.5F, 1.8F);
        }
        if (!selected) return;
        State st = state(p);
        if (st.slot != slot) {
            st.slot = slot;
            st.trigger = false;
            st.burstLeft = 0;
            st.hold = 0;
            st.spin = 0;
        }
        if (p.getVehicle() instanceof BaseMechaEntity) {
            st.trigger = false;
            return;
        }
        if (st.cooldown > 0) st.cooldown--;
        if (st.trigger) st.hold++;
        if (d.spinUp > 0) {
            if (st.trigger) {
                if (st.spin == 0) playOthers(p, ArsenalSounds.weapon(d, "special"), 1.0F, 1.0F);
                st.spin = Math.min(d.spinUp, st.spin + 1);
            } else {
                st.spin = Math.max(0, st.spin - 2);
            }
        }
        switch (d.mode(ArsenalData.mode(s))) {
            case AUTO, BEAM -> {
                if (st.trigger && (d.spinUp == 0 || st.spin >= d.spinUp) && st.cooldown <= 0) {
                    if (d.rpm > 1200) {
                        st.fireAcc += d.shotsPerTick();
                        int n = (int) st.fireAcc;
                        st.fireAcc -= n;
                        for (int i = 0; i < n; i++) {
                            if (!tryShoot(p, s, d, 1.0F)) {
                                st.trigger = false;
                                break;
                            }
                            st.cooldown = 0;
                        }
                    } else if (!tryShoot(p, s, d, 1.0F)) {
                        st.trigger = false;
                    }
                }
            }
            case BURST -> {
                if (st.burstLeft > 0 && st.cooldown <= 0) {
                    if (tryShoot(p, s, d, 1.0F)) {
                        st.burstLeft--;
                        if (st.burstLeft == 0) st.cooldown = d.cooldown() * 3;
                    } else {
                        st.burstLeft = 0;
                    }
                }
            }
            case CHARGE -> {
                if (st.trigger && st.hold % 3 == 0) {
                    Vec3 m = muzzle(p);
                    float c = Math.min(1.0F, st.hold / (float) chargeTicks(s, d));
                    othersParticles(p.serverLevel(), p, ArsenalParticles.of(ArsenalParticles.GLOW, d.flashColor), m, 1 + (int) (c * 3), 0.08, 0.01);
                }
            }
            default -> { }
        }
    }

    private static float heatDecay(ArsenalDef d) {
        return Math.max(0.004F, d.heatPerShot * 0.18F);
    }

    // ============================================================== shooting

    private static boolean canShoot(ServerPlayer p, ItemStack s, ArsenalDef d, boolean feedback) {
        if (ArsenalData.reloading(s)) return false;
        if (d.usesHeat() && ArsenalData.locked(s)) {
            if (feedback) playAll(p, SoundEvents.FIRE_EXTINGUISH, 0.5F, 1.4F);
            return false;
        }
        if (d.usesAmmo() && ArsenalData.ammo(s) <= 0) {
            if (feedback) {
                playAll(p, ArsenalSounds.shared("dry"), 1.0F, 1.0F);
                startReload(p, s, d);
            }
            return false;
        }
        return true;
    }

    private static boolean tryShoot(ServerPlayer p, ItemStack s, ArsenalDef d, float charge) {
        State st = state(p);
        if (st.cooldown > 0) return false;
        if (!canShoot(p, s, d, true)) return false;
        st.cooldown = Math.max(Math.max(1, Math.round(d.cooldown() * ArsenalModule.cooldownMul(s))), d.manual() ? d.cycleTicks : 0);
        st.shots++;
        if (d.usesAmmo()) ArsenalData.setAmmo(s, ArsenalData.ammo(s) - 1);
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        boolean aiming = p.isUsingItem() && p.getUsedItemHand() == InteractionHand.MAIN_HAND;
        float mul = ArsenalModule.damageMul(s);
        ArsenalModule element = ArsenalModule.element(s);
        if (d.hitscan()) {
            hitscan(p, level, d, s, aiming, charge, mul, element);
        } else if (d.proj == Proj.METEOR) {
            callMeteor(p, level, d, mul, charge, element);
        } else {
            for (int i = 0; i < Math.max(1, d.pellets); i++) spawnProjectile(p, level, d, s, aiming, charge, st.shots, mul, i, element);
        }
        if (d.usesHeat()) {
            float h = ArsenalData.heat(s, now, heatDecay(d)) + d.heatPerShot * ArsenalModule.heatMul(s);
            if (h >= 1.0F) {
                ArsenalData.setHeat(s, 1.0F, now, true);
                playAll(p, ArsenalSounds.shared("overheat"), 1.0F, 1.0F);
                p.displayClientMessage(Component.translatable("arsenal.blockwars.overheated"), true);
                st.trigger = false;
                if (d.cat == ArsenalDef.Cat.MINIGUN) plasmaBacklash(p, level, d);
            } else {
                ArsenalData.setHeat(s, h, now, false);
            }
        }
        boolean beam = d.mode(ArsenalData.mode(s)) == Fire.BEAM;
        Vec3 m = muzzle(p);
        boolean sound = beam ? st.beamSound-- <= 0 : d.rpm < 900 || st.shots % 2 == 0;
        if (sound) {
            float pitch = 0.95F + p.getRandom().nextFloat() * 0.1F;
            level.playSound(p, m.x, m.y, m.z, ArsenalSounds.weapon(d, "fire"), SoundSource.PLAYERS, d.loudness, pitch);
            if (d.manual()) level.playSound(p, m.x, m.y, m.z, ArsenalSounds.weapon(d, "special"), SoundSource.PLAYERS, 0.8F, 1.0F);
            st.beamSound = 4;
        }
        if (d.flash != ArsenalDef.Flash.NONE) {
            othersParticles(level, p, ArsenalParticles.of(ArsenalParticles.FLASH, d.index), m, 0, p.getLookAngle().scale(d.flashSize));
        }
        if (d.smoke > 0 && !beam) othersParticles(level, p, ArsenalParticles.of(ArsenalParticles.SMOKE, d.flashColor), m, Math.min(4, d.smoke), 0.05, 0.01);
        if (d.casing == ArsenalDef.Casing.WRAPPER) {
            // the pump throws out the spent candy wrapper
            float yaw = p.getYRot() * Mth.DEG_TO_RAD;
            Vec3 right = new Vec3(-Mth.cos(yaw), 0, -Mth.sin(yaw));
            Vec3 at = p.getEyePosition().add(p.getLookAngle().scale(0.5)).add(right.scale(0.3)).add(0, -0.3, 0);
            Vec3 v = right.scale(0.12).add(0, 0.14, 0);
            othersParticles(level, p, ArsenalParticles.of(ArsenalParticles.WRAPPER, d.tracerColor), at, 0, v);
        }
        return true;
    }

    /** Hidra: an overheated plasma core vents straight onto the hands holding it. */
    private static void plasmaBacklash(ServerPlayer p, ServerLevel level, ArsenalDef d) {
        p.invulnerableTime = 0;
        p.hurt(level.damageSources().onFire(), 3.0F);
        p.igniteForSeconds(2.0F);
        Vec3 c = p.position().add(0, 1.0, 0);
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), c.x, c.y, c.z, 30, 0.5, 0.4, 0.5, 0.08);
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.SMOKE, 0x9ac8a0), c.x, c.y, c.z, 12, 0.4, 0.3, 0.4, 0.02);
        p.displayClientMessage(Component.translatable("arsenal.blockwars.plasma_backlash"), true);
    }

    /** Roughly where the barrel ends, for effects seen by other players and for beams. */
    public static Vec3 muzzle(Player p) {
        Vec3 look = p.getLookAngle();
        float yaw = p.getYRot() * Mth.DEG_TO_RAD;
        Vec3 right = new Vec3(-Mth.cos(yaw), 0, -Mth.sin(yaw));
        return p.getEyePosition().add(look.scale(1.0)).add(right.scale(0.3)).add(0, -0.22, 0);
    }

    private static float spreadFor(ServerPlayer p, ArsenalDef d, ItemStack stack, boolean aiming) {
        float s = aiming ? d.spreadAds * ArsenalModule.adsSpreadMul(stack) : d.spreadHip * ArsenalModule.hipSpreadMul(stack);
        if (d.pellets > 1) s = Math.max(s, (aiming ? d.spreadAds : d.spreadHip) * 0.6F) * ArsenalModule.pelletSpreadMul(stack);
        if (p.isCrouching()) s *= 0.75F;
        Vec3 v = p.getDeltaMovement();
        if (v.x * v.x + v.z * v.z > 0.01) s *= 1.3F;
        if (!p.onGround()) s *= 1.6F;
        return s;
    }

    private static Vec3 spreadDir(Player p, float degrees) {
        Vec3 d = p.getLookAngle();
        if (degrees <= 0) return d;
        double k = Math.tan(Math.toRadians(degrees)) * 0.6;
        return d.add(p.getRandom().nextGaussian() * k, p.getRandom().nextGaussian() * k, p.getRandom().nextGaussian() * k).normalize();
    }

    private static void spawnProjectile(ServerPlayer p, ServerLevel level, ArsenalDef d, ItemStack s, boolean aiming, float charge, int shotNo, float mul,
                                        int pellet, @Nullable ArsenalModule element) {
        ArsenalShot b = new ArsenalShot(level, p, d);
        Vec3 eye = p.getEyePosition();
        b.setPos(eye.x, eye.y - 0.1, eye.z);
        Vec3 dir = spreadDir(p, spreadFor(p, d, s, aiming));
        if (d.proj == Proj.CARD && d.pellets > 1) {
            // cards leave the deck in a level fan
            dir = rotateYaw(dir, (pellet - (d.pellets - 1) * 0.5F) * Math.max(2.0F, d.sp2));
        } else if (d.proj == Proj.MORTAR) {
            // the tube lobs its shell high
            dir = pitchUp(dir, d.sp2);
        }
        float speed = d.velocity * (d.chargeTicks > 0 ? 0.55F + 0.45F * charge : 1.0F)
                * (d.pellets > 1 && d.proj != Proj.CARD ? 0.9F + p.getRandom().nextFloat() * 0.2F : 1.0F);
        b.setDeltaMovement(dir.scale(speed));
        b.damage = d.damage * mul * (d.chargeTicks > 0 ? 0.3F + 0.7F * charge : 1.0F);
        // long enough to cover the full range: engines keep their speed, everything else slows down in the air
        b.maxAge = Math.max(10, (ArsenalShot.cruises(d) ? (int) Math.ceil(d.range * 1.1F / Math.max(0.2F, speed))
                : ArsenalReach.flightTicks(d.range, Math.max(0.2F, speed), d.drag)) + 6);
        b.pierce = d.pierce + (d.chargeTicks > 0 && charge >= 0.99F ? 1 : 0);
        if (d.cutter() || d.proj == Proj.TURRET) b.pierce = 99;
        if (d.proj == Proj.TURRET) b.maxAge = Math.max(b.maxAge, 120);
        if (d.proj == Proj.MORTAR) b.maxAge = Math.max(b.maxAge, 400);
        if (d.proj == Proj.BOOMERANG) b.maxAge = Math.max(b.maxAge, (int) d.sp1 + 10);
        b.bounces = d.ricochet;
        b.setCharge(charge);
        b.setTracer(true);
        if (element != null) b.setFlag(2 + (element.ordinal() - ArsenalModule.INCENDIARY.ordinal()), true);
        b.setFlag(5, pellet % 2 == 1);
        if (d.proj == Proj.BOOMERANG) b.setFlag(ArsenalShot.F_LEFT, shotNo % 2 == 0);
        if (d.proj == Proj.ARROW && charge >= 0.99F && d.sp1 >= 2) b.setFlag(ArsenalShot.F_SPLIT, true);
        if (d.special == Special.HOMING) b.homingTarget = crosshairTarget(p, d.range);
        level.addFreshEntity(b);
    }

    static Vec3 rotateYaw(Vec3 v, float deg) {
        double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
        return new Vec3(v.x * c - v.z * s, v.y, v.x * s + v.z * c);
    }

    /** Raises a direction by {@code deg} degrees of pitch (capped short of straight up). */
    static Vec3 pitchUp(Vec3 v, float deg) {
        double h = Math.sqrt(v.x * v.x + v.z * v.z);
        if (h < 1.0E-4) return v;
        double pitch = Math.min(Math.toRadians(80.0), Math.atan2(v.y, h) + Math.toRadians(deg));
        double k = Math.cos(pitch) / h;
        return new Vec3(v.x * k, Math.sin(pitch), v.z * k);
    }

    /** «Meteoro»: a rock falls out of the sky onto the point under the crosshair, after a magic circle marks it. */
    private static void callMeteor(ServerPlayer p, ServerLevel level, ArsenalDef d, float mul, float charge, @Nullable ArsenalModule element) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        // the rock can only fall where the world is simulated (beyond that it would hang in the sky)
        BlockHitResult bh = ArsenalReach.clip(level, eye, ArsenalReach.simulatedEnd(level, eye, eye.add(look.scale(d.range))), p);
        Vec3 target;
        if (bh.getType() == HitResult.Type.BLOCK) {
            target = bh.getLocation();
        } else {
            // aimed at the sky: the ground below the far end of the sight line (cut short where the loaded world ends)
            Vec3 far = bh.getLocation();
            BlockHitResult down = level.clip(new ClipContext(far, far.add(0, -128, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            target = down.getType() == HitResult.Type.BLOCK ? down.getLocation() : far;
        }
        Entity aimed = crosshairTarget(p, d.range);
        if (aimed != null && aimed.distanceToSqr(eye) < target.distanceToSqr(eye) && ArsenalReach.simulatedAt(level, aimed.position())) {
            target = aimed.position();
        }
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : flat.normalize();
        double h = d.sp2 > 4 ? d.sp2 : 24.0;
        Vec3 from = target.add(flat.scale(-h * 0.35)).add(0, h, 0);
        from = new Vec3(from.x, Math.min(from.y, level.getMaxBuildHeight() - 2.0), from.z);
        // the rock comes straight down when its slanted path would start outside the simulated world
        if (!ArsenalReach.allLoaded(level, target, from) || !ArsenalReach.simulatedAt(level, from)) {
            from = new Vec3(target.x, Math.min(target.y + h, level.getMaxBuildHeight() - 2.0), target.z);
        }
        // under a roof (a cave, a house) the rock breaks through just below the ceiling instead of inside the rock
        BlockHitResult sky = level.clip(new ClipContext(target.add(0, 0.5, 0), from, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (sky.getType() == HitResult.Type.BLOCK) {
            Vec3 up = from.subtract(target);
            double reach = sky.getLocation().distanceTo(target);
            from = target.add(up.normalize().scale(Math.max(2.5, reach - 1.0)));
        }
        Vec3 path = target.subtract(from);
        double speed = Math.max(0.6, d.velocity);
        ArsenalShot m = new ArsenalShot(level, p, d);
        m.setPos(from.x, from.y, from.z);
        m.setDeltaMovement(path.normalize().scale(speed));
        m.damage = d.damage * mul * (d.chargeTicks > 0 ? 0.3F + 0.7F * charge : 1.0F);
        m.maxAge = 240;
        m.setCharge(charge);
        m.setTracer(true);
        m.setFlag(ArsenalShot.F_CHILD, true);
        if (element != null) m.setFlag(2 + (element.ordinal() - ArsenalModule.INCENDIARY.ordinal()), true);
        level.addFreshEntity(m);
        // flight time with the 1 % air drag of every thrown projectile: speed * (1 - 0.99^n) / 0.01 = distance
        double q = 1.0 - path.length() * 0.01 / speed;
        int ticks = q > 0.05 ? (int) Math.ceil(Math.log(q) / Math.log(0.99)) : (int) Math.ceil(path.length() / speed * 1.4);
        fx(level, ArsenalParticles.of(ArsenalParticles.SIGIL, d.tracerColor), target.add(0, 0.06, 0), new Vec3(ArsenalShot.meteorRadius(d, charge), ticks, 0));
        level.playSound(null, target.x, target.y, target.z, ArsenalSounds.shared("meteor_fall"), SoundSource.PLAYERS, 3.0F, 1.0F);
    }

    /** The living thing under the crosshair (see {@link ArsenalReach#target}). */
    @Nullable
    public static Entity crosshairTarget(Player p, double range) {
        return ArsenalReach.target(p, range);
    }

    // ============================================================== hitscan weapons

    private static void hitscan(ServerPlayer p, ServerLevel level, ArsenalDef d, ItemStack s, boolean aiming, float charge, float mul,
                                @Nullable ArsenalModule element) {
        Vec3 eye = p.getEyePosition();
        Vec3 m = muzzle(p);
        switch (d.proj) {
            case FLAME, WAVE -> cone(p, level, d, mul, element);
            case ARC -> arcShot(p, level, d, mul, element);
            default -> {
                Vec3 dir = spreadDir(p, spreadFor(p, d, s, aiming));
                float dmg = d.damage * mul * (d.chargeTicks > 0 ? 0.3F + 0.7F * charge : 1.0F);
                Vec3 end = beam(p, level, eye, dir, d.range, 1 + d.pierce, dmg, d, element);
                othersParticles(level, p, ArsenalParticles.of(ArsenalParticles.BEAM, d.index), m, 0, end.subtract(m));
            }
        }
    }

    /** Instant beam: damages up to {@code hits} entities, stops at blocks (glass shatters), returns the end point. */
    private static Vec3 beam(ServerPlayer p, ServerLevel level, Vec3 from, Vec3 dir, float range, int hits, float dmg, ArsenalDef d,
                             @Nullable ArsenalModule element) {
        BlockHitResult bh = ArsenalReach.clip(level, from, from.add(dir.scale(range)), p);
        Vec3 end = bh.getLocation();
        List<Entity> hit = new ArrayList<>();
        for (LivingEntity e : ArsenalReach.along(level, LivingEntity.class, from, end, 1.0, e -> e != p && e.isAlive() && !e.isSpectator())) {
            if (e.getBoundingBox().inflate(0.2).clip(from, end).isPresent()) hit.add(e);
        }
        hit.sort(Comparator.comparingDouble(e -> e.distanceToSqr(from)));
        int n = 0;
        for (Entity e : hit) {
            if (n >= hits) {
                end = e.getBoundingBox().getCenter();
                break;
            }
            Optional<Vec3> c = e.getBoundingBox().inflate(0.2).clip(from, end);
            boolean head = e instanceof LivingEntity le && c.isPresent() && c.get().y >= le.getEyeY() - 0.22 && le.getBbHeight() > 0.9F;
            damage(p, null, e, head ? dmg * d.headMul : dmg, head, Vec3.ZERO, 0.15F);
            applySpecial(level, p, d, e, c.orElse(e.position()));
            applyElement(level, p, element, e);
            n++;
        }
        if ((n < hits || hit.isEmpty()) && bh.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = bh.getBlockPos();
            BlockState st = level.getBlockState(pos);
            if (level.getGameTime() % 3 == 0) impact(level, bh.getLocation(), bh.getDirection(), pos, st, d, p);
            if ((st.is(Tags.Blocks.GLASS_PANES) || st.is(Tags.Blocks.GLASS_BLOCKS)) && level.mayInteract(p, pos)) level.destroyBlock(pos, false, p);
            if (d.special == Special.INCENDIARY || element == ArsenalModule.INCENDIARY) ignite(level, p, bh.getLocation(), bh.getDirection(), pos, 0.08F);
        }
        return end;
    }

    /** Flame stream and shock wave: everything inside a cone in front of the shooter. */
    private static void cone(ServerPlayer p, ServerLevel level, ArsenalDef d, float mul, @Nullable ArsenalModule element) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        float range = d.range;
        double cos = Math.cos(Math.toRadians(Math.max(8.0F, d.spreadHip)));
        boolean wave = d.proj == Proj.WAVE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range), e -> e != p && e.isAlive())) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > range || to.normalize().dot(look) < cos) continue;
            if (!ArsenalReach.clear(level, eye, e.getBoundingBox().getCenter(), p)) continue;
            float falloff = (float) (1.0 - dist / range * 0.55);
            Vec3 push = wave ? look.scale(0.9 * d.sp1 * falloff).add(0, 0.35 * falloff, 0) : Vec3.ZERO;
            damage(p, null, e, d.damage * mul * falloff, false, push, wave ? 0.2F : 0.05F);
            if (!wave) applySpecial(level, p, d, e, e.position());
            applyElement(level, p, element, e);
        }
        if (wave) {
            // the wave front swats arrows, fireballs and other projectiles back where they came from
            // (not fishing bobbers, tridents or ender pearls: turning those around would hand them to the shooter)
            for (Projectile pr : level.getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(range), pr -> !(pr instanceof ArsenalShot) && pr.getOwner() != p
                    && !(pr instanceof FishingHook) && !(pr instanceof ThrownTrident) && !(pr instanceof ThrownEnderpearl))) {
                Vec3 to = pr.position().subtract(eye);
                double dist = to.length();
                if (dist > range || dist < 0.01 || to.scale(1.0 / dist).dot(look) < cos) continue;
                pr.deflect(ProjectileDeflection.AIM_DEFLECT, p, p, true);
                pr.setDeltaMovement(pr.getDeltaMovement().add(look.scale(0.6)));
                pr.hurtMarked = true;
            }
        }
        Vec3 m = muzzle(p);
        if (!wave) {
            for (int i = 0; i < 3; i++) {
                Vec3 v = look.add(p.getRandom().nextGaussian() * 0.1, p.getRandom().nextGaussian() * 0.1, p.getRandom().nextGaussian() * 0.1)
                        .normalize().scale(range * 0.075);
                othersParticles(level, p, ArsenalParticles.of(ArsenalParticles.FIRE, d.tracerColor), m, 0, v);
            }
            BlockHitResult bh = ArsenalReach.clip(level, eye, eye.add(look.scale(range)), p);
            if (bh.getType() == HitResult.Type.BLOCK && p.getRandom().nextFloat() < 0.35F) ignite(level, p, bh.getLocation(), bh.getDirection(), bh.getBlockPos(), 1.0F);
        } else {
            othersParticles(level, p, ArsenalParticles.of(ArsenalParticles.WAVE, d.index), m, 0, look.scale(range));
            // the blast front shatters glass and knocks loose leaves
            BlockHitResult bh = ArsenalReach.clip(level, eye, eye.add(look.scale(range)), p);
            if (bh.getType() == HitResult.Type.BLOCK) {
                BlockPos pos = bh.getBlockPos();
                BlockState st = level.getBlockState(pos);
                if ((st.is(Tags.Blocks.GLASS_PANES) || st.is(Tags.Blocks.GLASS_BLOCKS) || st.is(net.minecraft.tags.BlockTags.LEAVES)) && level.mayInteract(p, pos)) {
                    level.destroyBlock(pos, false, p);
                }
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), bh.getLocation().x, bh.getLocation().y, bh.getLocation().z, 14, 0.3, 0.3, 0.3, 0.1);
            }
            shakeAround(level, m, 6, 0.4F);
        }
    }

    /** Chain lightning: the first target under the crosshair, then up to sp1 jumps to the nearest others. */
    private static void arcShot(ServerPlayer p, ServerLevel level, ArsenalDef d, float mul, @Nullable ArsenalModule element) {
        Vec3 m = muzzle(p);
        // Tempestad is unforgiving with wet hands: in rain or water the arc may close through its owner
        if ((p.isInWaterOrRain()) && p.getRandom().nextFloat() < d.sp2) {
            p.invulnerableTime = 0;
            p.hurt(level.damageSources().lightningBolt(), d.damage * 1.5F);
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3));
            Vec3 c = p.position().add(0, 1.0, 0);
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.ARC, d.index), m.x, m.y, m.z, 0, c.x - m.x, c.y - m.y, c.z - m.z, 1.0);
            level.playSound(null, c.x, c.y, c.z, ArsenalSounds.shared("zap"), SoundSource.PLAYERS, 1.5F, 0.7F);
            p.displayClientMessage(Component.translatable("arsenal.blockwars.arc_backfire"), true);
            return;
        }
        Entity first = crosshairTarget(p, d.range);
        if (first == null) {
            BlockHitResult bh = ArsenalReach.clip(level, p.getEyePosition(), p.getEyePosition().add(p.getLookAngle().scale(d.range)), p);
            Vec3 end = bh.getLocation();
            othersParticles(level, p, ArsenalParticles.of(ArsenalParticles.ARC, d.index), m, 0, end.subtract(m));
            if (bh.getType() == HitResult.Type.BLOCK) impact(level, end, bh.getDirection(), bh.getBlockPos(), level.getBlockState(bh.getBlockPos()), d, p);
            return;
        }
        List<Entity> chain = new ArrayList<>();
        chain.add(first);
        Entity cur = first;
        int jumps = Math.max(0, (int) d.sp1) + (element == ArsenalModule.SHOCK ? 1 : 0);
        for (int j = 0; j < jumps; j++) {
            Entity from = cur;
            Entity next = null;
            double best = 7.0 * 7.0;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, from.getBoundingBox().inflate(7.0), e -> e != p && e.isAlive() && !chain.contains(e))) {
                double dd = e.distanceToSqr(from);
                if (dd < best) {
                    best = dd;
                    next = e;
                }
            }
            if (next == null) break;
            chain.add(next);
            cur = next;
        }
        Vec3 prev = m;
        float dmg = d.damage * mul;
        for (Entity e : chain) {
            Vec3 c = e.getBoundingBox().getCenter();
            // the shooter already drew the first arc from the barrel; the jumps are news to everybody
            if (e == first) othersParticles(level, p, ArsenalParticles.of(ArsenalParticles.ARC, d.index), prev, 0, c.subtract(prev));
            else fx(level, ArsenalParticles.of(ArsenalParticles.ARC, d.index), prev, c.subtract(prev));
            damage(p, null, e, dmg, false, Vec3.ZERO, 0.2F);
            applySpecial(level, p, d, e, c);
            applyElement(level, p, element, e);
            prev = c;
            dmg *= 0.82F;
        }
        level.playSound(null, first.getX(), first.getY(), first.getZ(), ArsenalSounds.shared("zap"), SoundSource.PLAYERS, 1.0F, 1.1F);
    }

    // ============================================================== hits

    /** Damage with gun rules: no invulnerability frames between hits, softened knockback, hit markers for the shooter. */
    public static void damage(@Nullable Entity owner, @Nullable Entity direct, Entity target, float dmg, boolean head, Vec3 push, float knockScale) {
        if (target == owner) return;
        Level level = target.level();
        Vec3 before = target.getDeltaMovement();
        if (target instanceof LivingEntity le) le.invulnerableTime = 0;
        boolean hurt;
        if (direct instanceof Projectile proj) {
            hurt = target.hurt(level.damageSources().thrown(proj, owner), dmg);
        } else if (owner instanceof Player pl) {
            hurt = target.hurt(level.damageSources().playerAttack(pl), dmg);
        } else {
            hurt = target.hurt(level.damageSources().magic(), dmg);
        }
        if (!hurt) return;
        Vec3 after = target.getDeltaMovement();
        target.setDeltaMovement(before.add(after.subtract(before).scale(knockScale)).add(push));
        target.hurtMarked = true;
        if (owner instanceof ServerPlayer sp && target instanceof LivingEntity le) {
            byte kind = !le.isAlive() || le.getHealth() <= 0 ? ArsenalNet.KILL : head ? ArsenalNet.HEAD : ArsenalNet.HIT;
            ArsenalNet.feedback(sp, kind, dmg);
        }
    }

    /** Built-in on-hit effects of a weapon. */
    public static void applySpecial(ServerLevel level, @Nullable Entity owner, ArsenalDef d, Entity target, Vec3 at) {
        switch (d.special) {
            case INCENDIARY -> target.igniteForSeconds(Math.max(2.0F, d.sp1));
            case CRYO -> freeze(target, Math.max(1.0F, d.sp1));
            case SHOCK -> {
                if (target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 25, 3));
            }
            case KNOCKBACK -> {
                if (owner != null) {
                    Vec3 v = target.position().subtract(owner.position()).normalize().scale(0.6 * Math.max(1.0F, d.sp1));
                    target.push(v.x, 0.3, v.z);
                    target.hurtMarked = true;
                }
            }
            case STICKY -> {
                // goo: stuck in place for a few seconds
                if (target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 70, 3));
            }
            case SPLIT -> {
                // dawn light clings to whatever it hits: it glows through walls for a while
                if (target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
            }
            case METEOR -> target.igniteForSeconds(4.0F);
            default -> { }
        }
    }

    /** Upgrade cores: fire, frost or a voltaic jolt on every hit. */
    public static void applyElement(ServerLevel level, @Nullable Entity owner, @Nullable ArsenalModule element, Entity target) {
        if (element == null) return;
        Vec3 c = target.getBoundingBox().getCenter();
        switch (element) {
            case INCENDIARY -> {
                target.igniteForSeconds(3.0F);
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.FIRE, 0xFF7A20), c.x, c.y, c.z, 4, 0.2, 0.3, 0.2, 0.02);
            }
            case CRYO -> {
                freeze(target, 1.0F);
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.FROST, 0xBFEFFF), c.x, c.y, c.z, 6, 0.3, 0.4, 0.3, 0.02);
            }
            case SHOCK -> {
                if (target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 2));
                level.sendParticles(ArsenalParticles.of(ArsenalParticles.SPARK, 0x9ED8FF), c.x, c.y, c.z, 6, 0.2, 0.3, 0.2, 0.15);
            }
            default -> { }
        }
    }

    public static void freeze(Entity target, float strength) {
        target.setTicksFrozen(Math.min(target.getTicksRequiredToFreeze() + 140, target.getTicksFrozen() + (int) (60 * strength)));
        if (target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, (int) (60 * strength), (int) Math.min(4, 1 + strength)));
    }

    /** Fire where a flame or an incendiary shot lands. */
    public static void ignite(ServerLevel level, @Nullable Entity owner, Vec3 at, Direction face, BlockPos pos, float chance) {
        if (!(owner instanceof Player pl) || level.random.nextFloat() >= chance) return;
        BlockPos fp = pos.relative(face);
        if (level.getBlockState(fp).isAir() && level.mayInteract(pl, fp) && level.getBlockState(fp.below()).isSolid()) {
            level.setBlockAndUpdate(fp, Blocks.FIRE.defaultBlockState());
        }
    }

    public static void blast(ServerLevel level, @Nullable Entity owner, Vec3 at, float radius, boolean terrain, int color) {
        if (radius <= 0) return;
        level.explode(owner, at.x, at.y, at.z, radius, terrain ? Level.ExplosionInteraction.MOB : Level.ExplosionInteraction.NONE);
        fx(level, ArsenalParticles.of(ArsenalParticles.BLAST, color), at, new Vec3(radius, 0, 0));
        level.sendParticles(ArsenalParticles.of(ArsenalParticles.SMOKE, 0x5A5550), at.x, at.y, at.z, 4 + (int) (radius * 3), radius * 0.4, radius * 0.3, radius * 0.4, 0.02);
        level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared(radius >= 3 ? "boom_big" : "boom_small"), SoundSource.PLAYERS, 2.5F + radius, 0.9F + level.random.nextFloat() * 0.2F);
        shakeAround(level, at, 10 + radius * 6, Math.min(3.0F, radius * 0.6F));
    }

    /** Splash damage around a point that spares the blocks (wasps, candy, plasma). */
    public static void splash(ServerLevel level, @Nullable Entity owner, @Nullable Entity direct, Vec3 at, float radius, float dmg, @Nullable Entity skip) {
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(radius + 1.0), e -> e != skip && e.isAlive())) {
            double dist = e.getBoundingBox().getCenter().distanceTo(at);
            if (dist > radius + 0.5) continue;
            float k = (float) Math.max(0.2, 1.0 - dist / (radius + 0.5));
            if (e == owner) k *= 0.35F;
            Vec3 push = e.getBoundingBox().getCenter().subtract(at).normalize().scale(0.25 * k).add(0, 0.12 * k, 0);
            damage(owner, direct, e, dmg * k, false, push, 0.4F);
        }
    }

    /** Impact marks, debris, glow and the right sound for what was hit. */
    public static void impact(ServerLevel level, Vec3 at, Direction face, BlockPos pos, BlockState st, ArsenalDef d, @Nullable Entity owner) {
        double nx = face.getStepX(), ny = face.getStepY(), nz = face.getStepZ();
        double ox = at.x + nx * 0.012, oy = at.y + ny * 0.012, oz = at.z + nz * 0.012;
        int col = d.tracerColor;
        if (!st.isAir()) {
            switch (d.proj) {
                case ICE -> level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.ICE.defaultBlockState()), ox, oy, oz, 14, 0.15, 0.15, 0.15, 0.2);
                case CANDY -> level.sendParticles(ArsenalParticles.of(ArsenalParticles.CONFETTI, col), ox, oy, oz, 10, 0.1, 0.1, 0.1, 0.18);
                default -> level.sendParticles(ArsenalParticles.of(ArsenalParticles.SCORCH, col), ox, oy, oz, 0, nx * 0.24, ny * 0.24, nz * 0.24, 1.0);
            }
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st), ox, oy, oz, 5, 0.06, 0.06, 0.06, 0.15);
            level.sendParticles(ArsenalParticles.of(ArsenalParticles.GLOW, col), ox, oy, oz, 3, 0.05, 0.05, 0.05, 0.03);
        }
        SoundType sound = st.getSoundType(level, pos, owner);
        String key = switch (d.proj) {
            case CANDY -> "candy_pop";
            case ICE -> "ice_shatter";
            case SAW, BOOMERANG -> "saw_ricochet";
            case HARPOON -> "harpoon_hit";
            default -> "energy_hit";
        };
        if (sound == SoundType.GLASS) key = "impact_glass";
        level.playSound(null, at.x, at.y, at.z, ArsenalSounds.shared(key), SoundSource.PLAYERS, 0.7F, 0.85F + level.random.nextFloat() * 0.3F);
    }

    public static void shakeAround(ServerLevel level, Vec3 at, double radius, float strength) {
        for (ServerPlayer sp : level.players()) {
            double dd = sp.position().distanceTo(at);
            if (dd > radius) continue;
            float s = strength * (float) (1.0 - dd / radius);
            if (s > 0.05F) ArsenalNet.feedback(sp, ArsenalNet.SHAKE, s);
        }
    }

    private static void playAll(ServerPlayer p, SoundEvent s, float vol, float pitch) {
        p.level().playSound(null, p.getX(), p.getY() + 1, p.getZ(), s, SoundSource.PLAYERS, vol, pitch);
    }

    private static void playOthers(ServerPlayer p, SoundEvent s, float vol, float pitch) {
        p.level().playSound(p, p.getX(), p.getY() + 1, p.getZ(), s, SoundSource.PLAYERS, vol, pitch);
    }

    private static void othersParticles(ServerLevel level, ServerPlayer shooter, ParticleOptions po, Vec3 at, int n, double spread, double speed) {
        for (ServerPlayer sp : level.players()) {
            if (sp == shooter) continue;
            level.sendParticles(sp, po, false, at.x, at.y, at.z, n, spread, spread, spread, speed);
        }
    }

    /** Exact-velocity particle (count 0) for everyone but the shooter: the velocity carries data (beam span, flash direction). */
    private static void othersParticles(ServerLevel level, ServerPlayer shooter, ParticleOptions po, Vec3 at, int n, Vec3 data) {
        for (ServerPlayer sp : level.players()) {
            if (sp == shooter) continue;
            level.sendParticles(sp, po, true, at.x, at.y, at.z, 0, data.x, data.y, data.z, 1.0);
        }
    }

    /** One exact-data effect particle for every player within 256 blocks. */
    public static void fx(ServerLevel level, ParticleOptions po, Vec3 at, Vec3 data) {
        for (ServerPlayer sp : level.players()) {
            if (sp.distanceToSqr(at) > 256 * 256) continue;
            level.sendParticles(sp, po, true, at.x, at.y, at.z, 0, data.x, data.y, data.z, 1.0);
        }
    }
}
