package com.blockwars.arsenal;

import net.minecraft.ChatFormatting;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** A cartridge, shell, cell or round made for one specific Arsenal weapon. */
public class ArsenalAmmoItem extends Item {
    public final ArsenalCatalog.AmmoDef ammo;

    public ArsenalAmmoItem(Properties props, ArsenalCatalog.AmmoDef ammo) {
        super(props);
        this.ammo = ammo;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        String base = "item.blockwars." + this.ammo.id();
        if (Language.getInstance().has(base + ".desc")) {
            tooltip.add(Component.translatable(base + ".desc").withStyle(ChatFormatting.GRAY));
        }
        tooltip.add(Component.translatable("arsenal.blockwars.ammo_for", Component.translatable("item.blockwars." + this.ammo.weapon()))
                .withStyle(ChatFormatting.DARK_AQUA));
        if (this.ammo.rounds() > 1) {
            tooltip.add(Component.translatable("arsenal.blockwars.cell_rounds", this.ammo.rounds()).withStyle(ChatFormatting.DARK_GRAY));
        }
    }
}
