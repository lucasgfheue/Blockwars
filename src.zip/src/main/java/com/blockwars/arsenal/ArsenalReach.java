package com.blockwars.arsenal;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

/**
 * Long reach (weapons up to 250 blocks) without hurting the server, shared by the Arsenal and the armory:
 * <ul>
 * <li>block rays stop short of chunks that are not loaded (a ray there would load, or even generate, them on the spot);</li>
 * <li>entities along a ray are searched in short boxes, never in one box as big as the shot;</li>
 * <li>the target under the crosshair sits in a narrow cone that only widens a little with distance;</li>
 * <li>projectiles end where the world stops simulating, instead of hanging frozen in the air;</li>
 * <li>flight times account for the air drag of thrown projectiles.</li>
 * </ul>
 */
public final class ArsenalReach {
    private ArsenalReach() {}

    /** The longest reach of any hand-held weapon, in blocks. */
    public static final float MAX_RANGE = 250.0F;
    /** Length of each search box along a ray. */
    private static final double STEP = 16.0;

    // ================================================================== loaded ground

    /** Is the chunk fully loaded right now? (Never waits for one that is still loading.) */
    private static boolean loaded(Level level, int cx, int cz) {
        return level.getChunkSource().getChunkNow(cx, cz) != null;
    }

    /** A test on one chunk column. */
    private interface ChunkTest {
        boolean ok(int cx, int cz);
    }

    /**
     * How much of the segment (0..1) runs over chunks that pass the test. The segment is walked in pieces of 8 blocks and
     * every chunk under each piece (with half a block to spare, for rays that run along a chunk border) has to pass; the
     * answer is where the first piece with a failing chunk starts, so a ray cut there never touches one.
     */
    private static double part(Vec3 from, Vec3 to, ChunkTest test) {
        double dx = to.x - from.x, dz = to.z - from.z;
        int n = Math.max(1, (int) Math.ceil(from.distanceTo(to) / 8.0));
        for (int i = 0; i < n; i++) {
            double f0 = i / (double) n, f1 = (i + 1) / (double) n;
            double x0 = from.x + dx * f0, x1 = from.x + dx * f1, z0 = from.z + dz * f0, z1 = from.z + dz * f1;
            int ax = Mth.floor(Math.min(x0, x1) - 0.5) >> 4, bx = Mth.floor(Math.max(x0, x1) + 0.5) >> 4;
            int az = Mth.floor(Math.min(z0, z1) - 0.5) >> 4, bz = Mth.floor(Math.max(z0, z1) + 0.5) >> 4;
            for (int cx = ax; cx <= bx; cx++) {
                for (int cz = az; cz <= bz; cz++) {
                    if (!test.ok(cx, cz)) return f0;
                }
            }
        }
        return 1.0;
    }

    private static double loadedPart(Level level, Vec3 from, Vec3 to) {
        return part(from, to, (cx, cz) -> loaded(level, cx, cz));
    }

    /** Every chunk under the segment is loaded. */
    public static boolean allLoaded(Level level, Vec3 from, Vec3 to) {
        return loadedPart(level, from, to) >= 1.0;
    }

    /** The end of the segment, pulled back to just before the first chunk that is not loaded. */
    public static Vec3 loadedEnd(Level level, Vec3 from, Vec3 to) {
        double part = loadedPart(level, from, to);
        return part >= 1.0 ? to : from.add(to.subtract(from).scale(part));
    }

    /** A block ray (solid blocks, no fluids) that stays over loaded chunks: a miss ends where the loaded ground ends. */
    public static BlockHitResult clip(Level level, Vec3 from, Vec3 to, Entity viewer) {
        return clip(level, from, to, ClipContext.Fluid.NONE, viewer);
    }

    public static BlockHitResult clip(Level level, Vec3 from, Vec3 to, ClipContext.Fluid fluid, Entity viewer) {
        return level.clip(new ClipContext(from, loadedEnd(level, from, to), ClipContext.Block.COLLIDER, fluid, viewer));
    }

    /** Nothing solid, and nothing unloaded, between the two points. */
    public static boolean clear(Level level, Vec3 from, Vec3 to, Entity viewer) {
        if (!allLoaded(level, from, to)) return false;
        return level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, viewer)).getType() == HitResult.Type.MISS;
    }

    // ================================================================== entities along a ray

    /** Entities of a class whose box comes within {@code pad} blocks of the segment, nearest to {@code from} first. */
    public static <T extends Entity> List<T> along(Level level, Class<T> type, Vec3 from, Vec3 to, double pad, Predicate<? super T> filter) {
        Vec3 d = to.subtract(from);
        int n = Math.max(1, (int) Math.ceil(d.length() / STEP));
        List<T> out = new ArrayList<>();
        Set<Integer> seen = new HashSet<>();
        for (int i = 0; i < n; i++) {
            AABB box = new AABB(from.add(d.scale(i / (double) n)), from.add(d.scale((i + 1) / (double) n))).inflate(pad);
            for (T e : level.getEntitiesOfClass(type, box, filter)) {
                if (seen.add(e.getId())) out.add(e);
            }
        }
        out.sort(Comparator.comparingDouble((T e) -> e.distanceToSqr(from)));
        return out;
    }

    // ================================================================== the target under the crosshair

    private record Sighted(LivingEntity e, double dot) {}

    /** How far off the line of sight a target may stand, at a distance. */
    private static double slack(double dist) {
        return 1.5 + dist * 0.05;
    }

    /**
     * The living thing under the crosshair within {@code range}: inside a cone of about 18 degrees up close that narrows to
     * a few blocks of slack far away, the best aligned first, and only if it can be seen.
     */
    @Nullable
    public static LivingEntity target(Player p, double range) {
        Level level = p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        int n = Math.max(1, (int) Math.ceil(range / STEP));
        List<Sighted> found = new ArrayList<>();
        Set<Integer> ids = new HashSet<>();
        for (int i = 0; i < n; i++) {
            double d0 = range * i / n, d1 = range * (i + 1) / n;
            double pad = Math.min(STEP, slack(d1) + 1.5);
            AABB box = new AABB(eye.add(look.scale(d0)), eye.add(look.scale(d1))).inflate(pad);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive() && !e.isSpectator())) {
                if (!ids.add(e.getId())) continue;
                Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
                double dist = to.length();
                if (dist > range || dist < 1.0E-3) continue;
                double ahead = to.dot(look);
                double dot = ahead / dist;
                if (dot < 0.95) continue;
                double off = Math.sqrt(Math.max(0.0, dist * dist - ahead * ahead));
                if (off > slack(dist) + e.getBbWidth() * 0.5) continue;
                found.add(new Sighted(e, dot));
            }
        }
        found.sort(Comparator.comparingDouble((Sighted s) -> -s.dot()));
        for (Sighted s : found) {
            if (clear(level, eye, s.e().getBoundingBox().getCenter(), p)) return s.e();
        }
        return null;
    }

    // ================================================================== the edge of the simulated world

    /** Do entities still tick in this chunk? (It and its eight neighbours all tick blocks.) */
    public static boolean simulated(ServerLevel level, int cx, int cz) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (!level.shouldTickBlocksAt(ChunkPos.asLong(cx + dx, cz + dz))) return false;
            }
        }
        return true;
    }

    /** Does the world simulate entities at this point? */
    public static boolean simulatedAt(ServerLevel level, Vec3 at) {
        return simulated(level, Mth.floor(at.x) >> 4, Mth.floor(at.z) >> 4);
    }

    /** The end of the segment, pulled back to where the world still simulates entities (things placed beyond would freeze). */
    public static Vec3 simulatedEnd(ServerLevel level, Vec3 from, Vec3 to) {
        Map<Long, Boolean> seen = new HashMap<>();
        double f = part(from, to, (cx, cz) -> seen.computeIfAbsent(ChunkPos.asLong(cx, cz), k -> simulated(level, cx, cz)));
        return f >= 1.0 ? to : from.add(to.subtract(from).scale(f));
    }

    /**
     * Keeps a projectile inside the simulated world: past its edge entities stop ticking, so a shot would hang frozen in
     * the air. One per projectile; it remembers the last chunk it confirmed, so the check is free while the shot stays there.
     */
    public static final class Horizon {
        private long known = Long.MAX_VALUE;

        /** False when, within the next two ticks, a thing at {@code pos} moving by {@code v} would leave the simulated world. */
        public boolean ok(ServerLevel level, Vec3 pos, Vec3 v) {
            for (int k = 1; k <= 2; k++) {
                int cx = Mth.floor(pos.x + v.x * k) >> 4, cz = Mth.floor(pos.z + v.z * k) >> 4;
                long key = ChunkPos.asLong(cx, cz);
                if (key == this.known) continue;
                if (!simulated(level, cx, cz)) return false;
                this.known = key;
            }
            return true;
        }
    }

    // ================================================================== flight times

    /**
     * Ticks a thrown projectile needs to cover {@code range} blocks (and a tenth more) when it leaves at {@code speed} and
     * loses 1 % of its speed to the air each tick, plus {@code drag} more; if it can never get that far, the ticks until it
     * has all but stopped.
     */
    public static int flightTicks(double range, double speed, double drag) {
        if (speed <= 1.0E-4) return 10;
        double keep = 0.99 * (1.0 - Math.min(0.9, Math.max(0.0, drag)));
        double reach = speed / (1.0 - keep);
        double want = Math.min(range * 1.1, reach * 0.97);
        return Math.max(1, (int) Math.ceil(Math.log(1.0 - want / reach) / Math.log(keep)));
    }

    // ================================================================== beams and arcs seen from afar

    /** A straight beam (armory rail gun and fusion lance) that every client within 256 blocks draws at full length. */
    public static void ray(ServerLevel level, Vec3 from, Vec3 to, int rgb) {
        ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.RAY, rgb), from, to.subtract(from));
    }

    /** An electric arc (armory tesla coil) that every client within 256 blocks draws at full length. */
    public static void zap(ServerLevel level, Vec3 from, Vec3 to, int rgb) {
        ArsenalLogic.fx(level, ArsenalParticles.of(ArsenalParticles.ZAP, rgb), from, to.subtract(from));
    }
}
