package com.blockwars.arsenal;

import com.blockwars.BlockWars;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Arsenal networking: client -> server actions, server -> client feedback (hit markers, shake). */
public final class ArsenalNet {
    private ArsenalNet() {}

    public static final byte TRIGGER_DOWN = 0, TRIGGER_UP = 1, RELOAD = 2, MODE = 3;
    public static final byte HIT = 0, KILL = 1, HEAD = 2, SHAKE = 3;

    public record Action(byte action) implements CustomPacketPayload {
        public static final Type<Action> TYPE = new Type<>(BlockWars.id("arsenal_action"));
        public static final StreamCodec<ByteBuf, Action> STREAM_CODEC = ByteBufCodecs.BYTE.map(Action::new, Action::action);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record Feedback(byte kind, float value) implements CustomPacketPayload {
        public static final Type<Feedback> TYPE = new Type<>(BlockWars.id("arsenal_feedback"));
        public static final StreamCodec<ByteBuf, Feedback> STREAM_CODEC = StreamCodec.composite(
                ByteBufCodecs.BYTE, Feedback::kind,
                ByteBufCodecs.FLOAT, Feedback::value,
                Feedback::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("arsenal1");
        registrar.playToServer(Action.TYPE, Action.STREAM_CODEC, (payload, context) -> {
            if (context.player() instanceof ServerPlayer player) ArsenalLogic.action(player, payload.action());
        });
        registrar.playToClient(Feedback.TYPE, Feedback.STREAM_CODEC,
                (payload, context) -> com.blockwars.arsenal.client.ArsenalClient.onFeedback(payload.kind(), payload.value()));
    }

    public static void feedback(ServerPlayer p, byte kind, float value) {
        PacketDistributor.sendToPlayer(p, new Feedback(kind, value));
    }

    public static void send(byte action) {
        PacketDistributor.sendToServer(new Action(action));
    }
}
