package com.blockwars.arsenal;

import com.blockwars.BlockWars;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ArsenalEntities {
    private ArsenalEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(Registries.ENTITY_TYPE, BlockWars.MODID);

    /** Every shot of the Arsenal: seen up to 256 blocks away (the longest reach is 250); never saved with the world. */
    public static final DeferredHolder<EntityType<?>, EntityType<ArsenalShot>> SHOT =
            ENTITY_TYPES.register("arsenal_shot", () -> EntityType.Builder.<ArsenalShot>of(ArsenalShot::new, MobCategory.MISC)
                    .sized(0.12F, 0.12F).clientTrackingRange(16).updateInterval(1).noSave().build("arsenal_shot"));
}
