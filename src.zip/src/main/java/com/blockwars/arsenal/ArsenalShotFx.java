package com.blockwars.arsenal;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Client-side particle trails of the Arsenal projectiles. Only ever called on the logical client (from
 * {@link ArsenalShot#tick()} when the level is client side); it touches nothing but {@link Level#addParticle}.
 */
public final class ArsenalShotFx {
    private ArsenalShotFx() {}

    /** Called every client tick while the shot flies; {@code before} is where it was at the start of the tick. */
    static void trail(ArsenalShot s, ArsenalDef d, Vec3 before) {
        Level level = s.level();
        RandomSource r = s.getRandom();
        Vec3 now = s.position();
        Vec3 step = now.subtract(before);
        double len = step.length();
        Vec3 dir = len > 1.0E-4 ? step.scale(1.0 / len) : new Vec3(0, 0, 1);
        int age = s.tickCount;
        switch (d.trail) {
            case RINGS -> {
                // ion sparkle along the path
                int n = Math.max(1, (int) Math.ceil(len * 1.5));
                for (int i = 0; i < n; i++) {
                    Vec3 p = before.add(step.scale((i + r.nextFloat()) / n));
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.GLOW, i % 3 == 0 ? 0xFF4A6A : d.tracerColor), p.x, p.y, p.z,
                            r.nextGaussian() * 0.01, r.nextGaussian() * 0.01, r.nextGaussian() * 0.01);
                }
            }
            case BUZZ -> {
                // a little thruster under the abdomen and a buzz of sparks
                Vec3 tail = now.subtract(dir.scale(0.25));
                level.addParticle(ArsenalParticles.of(ArsenalParticles.GLOW, 0xFFB020), tail.x, tail.y, tail.z, -dir.x * 0.02, -dir.y * 0.02, -dir.z * 0.02);
                if (age % 2 == 0) {
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.SMOKE, 0x6A5A40), tail.x, tail.y, tail.z, -dir.x * 0.03, 0.01, -dir.z * 0.03);
                }
                if (r.nextInt(3) == 0) {
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.SPARK, 0xFFD050), tail.x, tail.y, tail.z,
                            r.nextGaussian() * 0.06, r.nextGaussian() * 0.06, r.nextGaussian() * 0.06);
                }
            }
            case FROST -> {
                int n = Math.max(2, (int) Math.ceil(len * 1.2));
                for (int i = 0; i < n; i++) {
                    Vec3 p = before.add(step.scale((i + r.nextFloat()) / n));
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), p.x, p.y, p.z, 0, 0, 0);
                    if (r.nextInt(3) == 0) {
                        level.addParticle(ArsenalParticles.of(ArsenalParticles.FROST, 0xE6FAFF), p.x, p.y, p.z,
                                r.nextGaussian() * 0.03, r.nextGaussian() * 0.03 - 0.01, r.nextGaussian() * 0.03);
                    }
                }
                if (age % 2 == 0) level.addParticle(ArsenalParticles.of(ArsenalParticles.SMOKE, 0xDDF4FF), now.x, now.y, now.z, 0, 0, 0);
            }
            case SPRINKLES -> {
                if (r.nextInt(2) == 0) {
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.CONFETTI, 0), now.x, now.y, now.z,
                            r.nextGaussian() * 0.04, 0.02, r.nextGaussian() * 0.04);
                }
            }
            case VOID -> {
                // matter already falls into the orb on its way (portal sparks end where they were spawned: start = pos + v, plus 1 up)
                for (int i = 0; i < 3; i++) {
                    Vec3 o = new Vec3(r.nextGaussian(), r.nextGaussian(), r.nextGaussian()).normalize().scale(0.8 + r.nextFloat() * 1.2);
                    level.addParticle(ParticleTypes.PORTAL, now.x, now.y, now.z, o.x, o.y - 1.0, o.z);
                }
                level.addParticle(ArsenalParticles.of(ArsenalParticles.SMOKE, 0x1A0830), before.x, before.y, before.z, 0, 0, 0);
            }
            case PLASMA -> {
                level.addParticle(ArsenalParticles.of(ArsenalParticles.GLOW, d.tracerColor), before.x, before.y, before.z, 0, 0, 0);
                if (r.nextInt(4) == 0) {
                    level.addParticle(ArsenalParticles.of(ArsenalParticles.SPARK, d.tracerColor), now.x, now.y, now.z,
                            r.nextGaussian() * 0.05, r.nextGaussian() * 0.05, r.nextGaussian() * 0.05);
                }
            }
            default -> { }
        }
        if (s.element() == ArsenalModule.INCENDIARY && r.nextInt(2) == 0) {
            level.addParticle(ArsenalParticles.of(ArsenalParticles.FIRE, 0xFF8A30), now.x, now.y, now.z, 0, 0.01, 0);
        } else if (s.element() == ArsenalModule.CRYO && r.nextInt(2) == 0) {
            level.addParticle(ArsenalParticles.of(ArsenalParticles.FROST, 0xCFF4FF), now.x, now.y, now.z, 0, -0.01, 0);
        } else if (s.element() == ArsenalModule.SHOCK && r.nextInt(2) == 0) {
            level.addParticle(ArsenalParticles.of(ArsenalParticles.SPARK, 0x9ED8FF), now.x, now.y, now.z,
                    r.nextGaussian() * 0.08, r.nextGaussian() * 0.08, r.nextGaussian() * 0.08);
        }
        if (s.isInWater()) level.addParticle(ParticleTypes.BUBBLE, now.x, now.y, now.z, 0, 0, 0);
    }

    /** Particles of a shot that stopped: a melting ice lance, or the singularity. */
    static void still(ArsenalShot s, ArsenalDef d, int state) {
        Level level = s.level();
        RandomSource r = s.getRandom();
        double x = s.getX(), y = s.getY(), z = s.getZ();
        if (state == ArsenalShot.STUCK) {
            if (r.nextInt(6) == 0) level.addParticle(ParticleTypes.DRIPPING_WATER, x, y - 0.1, z, 0, 0, 0);
            if (r.nextInt(4) == 0) level.addParticle(ArsenalParticles.of(ArsenalParticles.FROST, 0xE6FAFF), x, y, z, 0, -0.005, 0);
            return;
        }
        if (state != ArsenalShot.WELL) return;
        float radius = Math.max(3.0F, d.sp1);
        int life = Math.max(30, (int) d.sp2);
        float t = Mth.clamp(s.stateTicks() / (float) life, 0.0F, 1.0F);
        // everything around spirals in: portal sparks converge on the core
        int n = 6 + (int) (t * 10);
        for (int i = 0; i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double rr = radius * (0.35 + r.nextDouble() * 0.65);
            double h = (r.nextDouble() - 0.5) * radius * 0.5;
            level.addParticle(ParticleTypes.PORTAL, x, y, z, Math.cos(a) * rr, h - 1.0, Math.sin(a) * rr);
        }
        // the accretion disc: glowing matter orbiting fast and falling in
        for (int i = 0; i < 4; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double rr = 1.2 + r.nextDouble() * 2.2;
            double px = x + Math.cos(a) * rr, pz = z + Math.sin(a) * rr;
            double tang = 0.35 / Math.sqrt(rr);
            double vx = -Math.sin(a) * tang - Math.cos(a) * 0.06, vz = Math.cos(a) * tang - Math.sin(a) * 0.06;
            level.addParticle(ArsenalParticles.of(ArsenalParticles.GLOW, i % 2 == 0 ? 0xB070FF : 0xFFFFFF), px, y + r.nextGaussian() * 0.08, pz, vx, 0, vz);
        }
        if (r.nextInt(3) == 0) {
            level.addParticle(ArsenalParticles.of(ArsenalParticles.SMOKE, 0x120620), x + r.nextGaussian() * radius * 0.4, y + r.nextGaussian() * 0.6,
                    z + r.nextGaussian() * radius * 0.4, 0, 0, 0);
        }
    }
}
