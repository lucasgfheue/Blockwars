package com.blockwars.arsenal;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

import java.util.function.Consumer;

/**
 * Per-stack weapon state in the item's custom data. Reload and heat are stored as game-time stamps so the stack only
 * changes when something happens (no per-tick NBT churn).
 * <ul>
 *     <li>Ammo: rounds in the weapon</li>
 *     <li>Mode: selected fire mode index</li>
 *     <li>RelEnd / RelLen / RelKind: reload end time, length, kind (0 = tactical, 1 = empty, 2 = one round)</li>
 *     <li>Heat / HeatT / Lock: heat 0..1, when it was written, overheated lock</li>
 * </ul>
 */
public final class ArsenalData {
    private ArsenalData() {}

    public static final int REL_TACTICAL = 0, REL_EMPTY = 1, REL_ROUND = 2;

    public static CompoundTag read(ItemStack s) {
        CustomData d = s.get(DataComponents.CUSTOM_DATA);
        return d == null ? new CompoundTag() : d.copyTag();
    }

    public static void edit(ItemStack s, Consumer<CompoundTag> f) {
        CustomData.update(DataComponents.CUSTOM_DATA, s, f);
    }

    public static int ammo(ItemStack s) {
        return read(s).getInt("Ammo");
    }

    public static void setAmmo(ItemStack s, int n) {
        edit(s, t -> t.putInt("Ammo", Math.max(0, n)));
    }

    public static int mode(ItemStack s) {
        return read(s).getInt("Mode");
    }

    public static boolean reloading(ItemStack s) {
        return read(s).contains("RelEnd");
    }

    /** 0..1 progress of the current reload step, or -1 when not reloading. */
    public static float reloadProgress(ItemStack s, float now) {
        CompoundTag t = read(s);
        if (!t.contains("RelEnd")) return -1.0F;
        long end = t.getLong("RelEnd");
        int len = Math.max(1, t.getInt("RelLen"));
        return Mth.clamp(1.0F - (end - now) / (float) len, 0.0F, 1.0F);
    }

    public static int reloadKind(ItemStack s) {
        return read(s).getInt("RelKind");
    }

    public static float heat(ItemStack s, long now, float decayPerTick) {
        CompoundTag t = read(s);
        float h = t.getFloat("Heat");
        long at = t.getLong("HeatT");
        float k = t.getBoolean("Lock") ? decayPerTick * 1.6F : decayPerTick;
        return Mth.clamp(h - (now - at) * k, 0.0F, 1.0F);
    }

    public static boolean locked(ItemStack s) {
        return read(s).getBoolean("Lock");
    }

    public static void setHeat(ItemStack s, float h, long now, boolean lock) {
        edit(s, t -> {
            t.putFloat("Heat", Mth.clamp(h, 0.0F, 1.0F));
            t.putLong("HeatT", now);
            t.putBoolean("Lock", lock);
        });
    }
}
