package com.blockwars.arsenal;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

/** An Arsenal weapon. Left click fires (server side through {@link ArsenalLogic}), right click aims down sights. */
public class ArsenalItem extends Item {
    public final ArsenalDef def;

    public ArsenalItem(Properties props, ArsenalDef def) {
        super(props);
        this.def = def;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND) return InteractionResultHolder.pass(stack);
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.NONE;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (!level.isClientSide && entity instanceof ServerPlayer sp) {
            ArsenalLogic.inventoryTick(sp, stack, this.def, slot, selected);
        }
    }

    @Override
    public boolean canAttackBlock(BlockState state, Level level, BlockPos pos, Player player) {
        return false;
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return this.def.usesAmmo() || this.def.usesHeat();
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        if (!this.def.usesAmmo()) return Math.round(13.0F * (1.0F - ArsenalData.read(stack).getFloat("Heat")));
        return Math.round(13.0F * Mth.clamp(ArsenalData.ammo(stack) / (float) ArsenalModule.mag(stack, this.def), 0.0F, 1.0F));
    }

    @Override
    public int getBarColor(ItemStack stack) {
        if (!this.def.usesAmmo()) return 0xFF7020;
        int a = ArsenalData.ammo(stack);
        return a == 0 ? 0xE03020 : a <= ArsenalModule.mag(stack, this.def) / 4 ? 0xE0B020 : 0x7FE8FF;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        String base = "item.blockwars." + this.def.id;
        Language lang = Language.getInstance();
        tooltip.add(Component.translatable("arsenal.blockwars.maker." + this.def.maker).append(" · ")
                .append(Component.translatable("arsenal.blockwars.cat." + this.def.cat.name().toLowerCase())).withStyle(ChatFormatting.GOLD));
        for (int i = 0; i < 6 && lang.has(base + ".lore." + i); i++) {
            tooltip.add(Component.translatable(base + ".lore." + i).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        }
        if (this.def.dangerous) {
            tooltip.add(Component.translatable("arsenal.blockwars.danger").withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
            if (lang.has(base + ".danger")) tooltip.add(Component.translatable(base + ".danger").withStyle(ChatFormatting.RED));
        }
        tooltip.add(Component.translatable(base + ".stats").withStyle(ChatFormatting.DARK_AQUA));
        if (this.def.usesAmmo()) {
            tooltip.add(Component.translatable("arsenal.blockwars.loaded", ArsenalData.ammo(stack), ArsenalModule.mag(stack, this.def),
                    Component.translatable("item.blockwars." + this.def.ammo)).withStyle(ChatFormatting.YELLOW));
        }
        for (ArsenalModule m : ArsenalModule.installed(stack).values()) {
            tooltip.add(Component.literal(" + ").append(Component.translatable("item.blockwars." + m.itemId)).withStyle(ChatFormatting.GREEN));
        }
        tooltip.add(Component.translatable("arsenal.blockwars.controls").withStyle(ChatFormatting.DARK_GRAY));
    }
}
