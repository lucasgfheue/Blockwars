package com.blockwars;

import com.blockwars.entity.BastionEntity;
import com.blockwars.entity.BulletEntity;
import com.blockwars.entity.GenericMechaEntity;
import com.blockwars.entity.GoliathEntity;
import com.blockwars.entity.GunBulletEntity;
import com.blockwars.entity.GunRocketEntity;
import com.blockwars.entity.SingularityEntity;
import com.blockwars.entity.NaniteSwarmEntity;
import com.blockwars.entity.MechaShotEntity;
import com.blockwars.mecha.MechaSpec;
import com.blockwars.mecha.MechaSpecs;
import com.blockwars.entity.MechaEntity;
import com.blockwars.entity.MissileEntity;
import com.blockwars.entity.VanguardEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, BlockWars.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<MechaEntity>> MECHA =
            ENTITY_TYPES.register("mecha", () -> EntityType.Builder.of(MechaEntity::new, MobCategory.MISC)
                    .sized(2.0F, 3.4F).fireImmune().clientTrackingRange(10).build("mecha"));

    public static final DeferredHolder<EntityType<?>, EntityType<GoliathEntity>> GOLIATH =
            ENTITY_TYPES.register("goliath", () -> EntityType.Builder.of(GoliathEntity::new, MobCategory.MISC)
                    .sized(2.4F, 3.1F).fireImmune().clientTrackingRange(10).build("goliath"));

    public static final DeferredHolder<EntityType<?>, EntityType<VanguardEntity>> VANGUARD =
            ENTITY_TYPES.register("vanguard", () -> EntityType.Builder.of(VanguardEntity::new, MobCategory.MISC)
                    .sized(2.0F, 3.9F).fireImmune().clientTrackingRange(10).build("vanguard"));

    public static final DeferredHolder<EntityType<?>, EntityType<BastionEntity>> BASTION =
            ENTITY_TYPES.register("bastion", () -> EntityType.Builder.of(BastionEntity::new, MobCategory.MISC)
                    .sized(2.6F, 3.5F).fireImmune().clientTrackingRange(10).build("bastion"));

    public static final DeferredHolder<EntityType<?>, EntityType<BulletEntity>> BULLET =
            ENTITY_TYPES.register("bullet", () -> EntityType.Builder.<BulletEntity>of(BulletEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(8).updateInterval(1).build("bullet"));

    public static final DeferredHolder<EntityType<?>, EntityType<MissileEntity>> MISSILE =
            ENTITY_TYPES.register("missile", () -> EntityType.Builder.<MissileEntity>of(MissileEntity::new, MobCategory.MISC)
                    .sized(0.4F, 0.4F).clientTrackingRange(8).updateInterval(1).build("missile"));

    public static final DeferredHolder<EntityType<?>, EntityType<MechaShotEntity>> SHOT =
            ENTITY_TYPES.register("mecha_shot", () -> EntityType.Builder.<MechaShotEntity>of(MechaShotEntity::new, MobCategory.MISC)
                    .sized(0.3F, 0.3F).clientTrackingRange(8).updateInterval(1).build("mecha_shot"));

    public static final DeferredHolder<EntityType<?>, EntityType<GunBulletEntity>> GUN_BULLET =
            ENTITY_TYPES.register("gun_bullet", () -> EntityType.Builder.<GunBulletEntity>of(GunBulletEntity::new, MobCategory.MISC)
                    .sized(0.15F, 0.15F).clientTrackingRange(6).updateInterval(1).build("gun_bullet"));

    public static final DeferredHolder<EntityType<?>, EntityType<GunRocketEntity>> GUN_ROCKET =
            ENTITY_TYPES.register("gun_rocket", () -> EntityType.Builder.<GunRocketEntity>of(GunRocketEntity::new, MobCategory.MISC)
                    .sized(0.35F, 0.35F).clientTrackingRange(8).updateInterval(1).build("gun_rocket"));

    public static final DeferredHolder<EntityType<?>, EntityType<SingularityEntity>> SINGULARITY =
            ENTITY_TYPES.register("singularity", () -> EntityType.Builder.<SingularityEntity>of(SingularityEntity::new, MobCategory.MISC)
                    .sized(1.0F, 1.0F).clientTrackingRange(10).updateInterval(2).fireImmune().build("singularity"));

    public static final DeferredHolder<EntityType<?>, EntityType<NaniteSwarmEntity>> NANITE_SWARM =
            ENTITY_TYPES.register("nanite_swarm", () -> EntityType.Builder.<NaniteSwarmEntity>of(NaniteSwarmEntity::new, MobCategory.MISC)
                    .sized(1.5F, 1.5F).clientTrackingRange(10).updateInterval(1).fireImmune().build("nanite_swarm"));

    /** The 40 generated mechas, by id. */
    public static final Map<String, DeferredHolder<EntityType<?>, EntityType<GenericMechaEntity>>> GENERATED = new LinkedHashMap<>();

    static {
        for (MechaSpec spec : MechaSpecs.ALL) {
            GENERATED.put(spec.id, ENTITY_TYPES.register(spec.id, () -> EntityType.Builder.<GenericMechaEntity>of(
                            (type, level) -> new GenericMechaEntity(type, level, spec), MobCategory.MISC)
                    .sized(spec.width, spec.height).fireImmune().clientTrackingRange(10).build(spec.id)));
        }
    }
}
