package com.blockwars.network;

import com.blockwars.BlockWars;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: hit markers and screen shake from nearby blasts. */
public record GunFeedbackPayload(byte kind, float value) implements CustomPacketPayload {
    public static final byte HIT = 0;
    public static final byte KILL = 1;
    public static final byte HEADSHOT = 2;
    public static final byte SHAKE = 3;

    public static final Type<GunFeedbackPayload> TYPE = new Type<>(BlockWars.id("gun_feedback"));
    public static final StreamCodec<ByteBuf, GunFeedbackPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BYTE, GunFeedbackPayload::kind,
            ByteBufCodecs.FLOAT, GunFeedbackPayload::value,
            GunFeedbackPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
