package com.blockwars.network;

import com.blockwars.entity.BaseMechaEntity;
import com.blockwars.entity.GenericMechaEntity;
import com.blockwars.gun.GunLogic;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class ModNetwork {
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("3");

        registrar.playToServer(MechaActionPayload.TYPE, MechaActionPayload.STREAM_CODEC, (payload, context) -> {
            Player player = context.player();
            if (!(player.getVehicle() instanceof BaseMechaEntity mecha) || mecha.getControllingPassenger() != player) {
                return;
            }
            if (mecha instanceof GenericMechaEntity g && g.isRogueActive()) {
                return; // the machine is not listening to you right now
            }
            switch (payload.action()) {
                case MechaActionPayload.PRIMARY -> mecha.tryPrimary(player);
                case MechaActionPayload.SECONDARY -> mecha.trySecondary(player);
                case MechaActionPayload.BOOST_ON -> mecha.setBoosting(mecha.canFly());
                case MechaActionPayload.BOOST_OFF -> mecha.setBoosting(false);
                default -> { }
            }
        });

        registrar.playToServer(GunActionPayload.TYPE, GunActionPayload.STREAM_CODEC, (payload, context) -> {
            if (!(context.player() instanceof ServerPlayer player)) return;
            switch (payload.action()) {
                case GunActionPayload.TRIGGER_DOWN -> GunLogic.trigger(player, true);
                case GunActionPayload.TRIGGER_UP -> GunLogic.trigger(player, false);
                case GunActionPayload.RELOAD -> GunLogic.reloadRequest(player);
                case GunActionPayload.ALT -> GunLogic.alt(player);
                default -> { }
            }
        });

        registrar.playToClient(GunFeedbackPayload.TYPE, GunFeedbackPayload.STREAM_CODEC,
                (payload, context) -> com.blockwars.client.gun.GunClient.onFeedback(payload.kind(), payload.value()));
    }
}
