package com.blockwars.network;

import com.blockwars.BlockWars;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: trigger pressed/released, reload, alternate function. */
public record GunActionPayload(byte action) implements CustomPacketPayload {
    public static final byte TRIGGER_DOWN = 0;
    public static final byte TRIGGER_UP = 1;
    public static final byte RELOAD = 2;
    public static final byte ALT = 3;

    public static final Type<GunActionPayload> TYPE = new Type<>(BlockWars.id("gun_action"));
    public static final StreamCodec<ByteBuf, GunActionPayload> STREAM_CODEC =
            ByteBufCodecs.BYTE.map(GunActionPayload::new, GunActionPayload::action);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
